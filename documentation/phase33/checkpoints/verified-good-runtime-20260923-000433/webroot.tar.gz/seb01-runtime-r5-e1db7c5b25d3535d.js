/* SEB-01 F30.4C R4. One authorized batch reader per active schema.
 * No discovery, device commands, static measurement files, or credential search.
 * Transport-independent; a UI adapter specifies only scope, slot and formatting.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory;
  else if (!root.IQF_SEB01_RUNTIME) root.IQF_SEB01_RUNTIME = factory(root);
}(typeof window !== 'undefined' ? window : globalThis, function (env) {
  'use strict';
  const VERSION = 'F30.4C-R5-PERSISTED-READER';
  const POLL_MS = 5000, TIMEOUT_MS = 8000, MAX_HTTP_AGE_MS = 20000;
  let ctx = null, epoch = 0, timer = null, inflight = null, modelFlight = null;
  let lastSuccess = 0, responseTime = '', model = null, error = 'NO_CONTEXT';
  let values = Object.create(null), reqs = 0, ignored = 0, serial = 0;
  const leases = new Set(), listeners = new Set(), controllers = new Set();
  const adapters = new Map(), paints = new WeakMap();
  let paintQueued = false, writeChain = Promise.resolve();
  const text = v => v == null ? '' : String(v).trim();
  const now = () => env.Date ? env.Date.now() : Date.now();
  const uuid = v => /^[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}$/i.test(text(v));
  const identity = v => text(v).toLowerCase().replace(/[:\-]/g, '');
  const errCode = e => /^[A-Z][A-Z_\d]*$/.test(e && e.message || '') ? e.message :
    e && e.name === 'AbortError' ? 'REQUEST_TIMEOUT' : 'REQUEST_FAILED';
  const own = (o,k) => Object.prototype.hasOwnProperty.call(o || {}, k);
  const fail = c => { throw new Error(c); };
  const delay = (f,n) => env.setTimeout(f,n), clear = n => env.clearTimeout(n);
  function apiUrl(path) {
    if (!ctx) fail('NO_CONTEXT');
    const url = new URL(ctx.base + path, env.location.origin);
    if (!['http:','https:'].includes(url.protocol) || url.username || url.password ||
        (env.location.protocol === 'https:' && url.protocol !== 'https:')) fail('API_CONFIGURATION');
    return url.href;
  }
  async function request(path, options, generation) {
    const c = ctx;
    if (!c || generation !== epoch) fail('CONTEXT_CHANGED');
    const url = apiUrl(path), control = new env.AbortController();
    controllers.add(control);
    const deadline = delay(() => control.abort(), TIMEOUT_MS);
    try {
      const response = await env.fetch(url, {
        method: options && options.method || 'GET', redirect:'error', cache:'no-store',
        credentials:'same-origin', signal:control.signal,
        headers:{Accept:'application/json', Authorization:'Bearer ' + c.token,
          ...(options && options.body ? {'Content-Type':'application/json'} : {})},
        ...(options && options.body ? {body:JSON.stringify(options.body)} : {})
      });
      if (generation !== epoch || ctx !== c) fail('CONTEXT_CHANGED');
      if (!response.ok) fail('HTTP_' + response.status);
      if (!/\bapplication\/(?:[\w.-]+\+)?json\b/i.test(response.headers.get('content-type') || '')) fail('NON_JSON_RESPONSE');
      const data = await response.json();
      if (generation !== epoch || ctx !== c) fail('CONTEXT_CHANGED');
      if (!data || typeof data !== 'object' || Array.isArray(data)) fail('JSON_SHAPE');
      if (text(data.device_uuid).toLowerCase() !== c.uuid) fail('WRONG_DEVICE');
      return data;
    } finally { clear(deadline); controllers.delete(control); }
  }
  function view(slot, expectedUuid) {
    if (!ctx || (expectedUuid && ctx.uuid !== text(expectedUuid).toLowerCase())) return {has_value:false, status:'no_context', value:null};
    if (error) return {has_value:false, status:error.toLowerCase(), value:null};
    if (now() - lastSuccess > MAX_HTTP_AGE_MS) return {has_value:false, status:'api_stale', value:null};
    return own(values,slot) ? values[slot] : {has_value:false,status:'unbound',value:null};
  }
  function numeric(v) {
    if (typeof v === 'number') return Number.isFinite(v) ? v : null;
    if (typeof v !== 'string' || !/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:e[+-]?\d+)?$/i.test(v.trim())) return null;
    const n = Number(v.trim().replace(',','.')); return Number.isFinite(n) ? n : null;
  }
  function format(entry, unit, digits) {
    const e = entry || {}, suffix = text(unit || e.unit), missing = '\u2014' + (suffix ? ' ' + suffix : '');
    if (e.has_value !== true || e.available === false) {
      if (suffix) return missing;
      return ['unavailable','offline'].includes(e.status) ? 'Nedostupn\u00e9' :
        e.status === 'unknown' ? 'Nezn\u00e1m\u00fd stav' : '\u2014';
    }
    if (e.value_type === 'boolean' || typeof e.value === 'boolean') {
      return e.value === true ? 'Zapnuto' : e.value === false ? 'Vypnuto' : '\u2014';
    }
    if (e.value_type === 'number' || numeric(e.value) !== null) {
      let n = numeric(e.value); if (n === null) return missing;
      const src = text(e.unit);
      if (suffix && src !== suffix) {
        if (src === 'W' && suffix === 'kW') n /= 1000;
        else if (src === 'kW' && suffix === 'W') n *= 1000;
        else return missing;
      }
      const d = Number.isInteger(digits) ? Math.max(0,Math.min(6,digits)) : 1;
      return new Intl.NumberFormat('cs-CZ',{minimumFractionDigits:d,maximumFractionDigits:d}).format(n) + (suffix ? ' ' + suffix : '');
    }
    return e.value == null ? missing : text(e.value);
  }
  function hint(entry) {
    const e = entry || {};
    if (e.status === 'snapshot_only') return 'Chyb\u00ed pr\u016fb\u011b\u017en\u00e1 telemetrie. Ulo\u017een\u00e9 vyhled\u00e1v\u00e1n\u00ed nen\u00ed aktu\u00e1ln\u00ed m\u011b\u0159en\u00ed.';
    if (e.status === 'unbound') return 'Zdroj dosud nen\u00ed ulo\u017een\u00fd na serveru. Administr\u00e1tor potvrd\u00ed v\u00fdb\u011br tla\u010d\u00edtkem Ulo\u017eit.';
    if (/^http_|wrong_device|request_|no_context|api_stale|loading/i.test(e.status||'')) return 'SEB-01: '+text(e.status)+'. Dvojklik na hodnotu p\u0159\u00edkonu v administraci ulo\u017e\u00ed diagnostiku.';
    const times = e.times || {};
    return 'SEB-01: ' + text(e.status || 'waiting') +
      (times.measured_at ? '; m\u011b\u0159en\u00ed: ' + times.measured_at : '; \u010das fyzick\u00e9ho m\u011b\u0159en\u00ed neov\u011b\u0159en') +
      (e.updated_at ? '; \u010das hl\u00e1\u0161en\u00ed/zm\u011bny: ' + e.updated_at : '');
  }
  function snapshot() {
    return {version:VERSION, deviceUuid:ctx ? ctx.uuid : '', admin:!!(ctx && ctx.admin),
      error, requests:reqs, ignoredResponses:ignored, httpReceivedAt:lastSuccess || null,
      serverResponseGeneratedAt:responseTime, refreshMs:POLL_MS, endToEnd20sVerified:false,
      adapterErrors:Object.fromEntries(Array.from(adapters.entries()).filter(([,a])=>a.lastError).map(([k,a])=>[k,a.lastError])),
      values:Object.fromEntries(Object.keys(values).map(k => [k,view(k)]))};
  }
  function notify() {
    const s = snapshot(); for (const listener of listeners) { try { listener(s); } catch (_) {} }
    schedulePaint();
  }
  function scheduleNext(started, generation) {
    if (timer !== null) clear(timer);
    if (ctx && generation === epoch) timer = delay(() => {timer=null;void refresh();}, Math.max(0,POLL_MS-(now()-started)));
  }
  async function refresh() {
    if (!ctx) return;
    if (inflight) return inflight;
    if (timer !== null) {clear(timer);timer=null;}
    const generation = epoch, c = ctx, started = now();
    const operation = (async () => {
      try {
        reqs += 1;
        const data = await request('/api/v1/portal/devices/'+encodeURIComponent(c.uuid)+'/individual-project/schema-entity-values',null,generation);
        if (!data.values || typeof data.values !== 'object' || Array.isArray(data.values)) fail('VALUES_SHAPE');
        if (generation !== epoch || c !== ctx) {ignored+=1;return;}
        const t = Date.parse(data.response_generated_at || data.values_generated_at || '');
        if (responseTime && Number.isFinite(t) && t < Date.parse(responseTime)) fail('OUT_OF_ORDER_RESPONSE');
        values = Object.assign(Object.create(null),data.values); error = ''; lastSuccess=now();
        responseTime = Number.isFinite(t) ? new Date(t).toISOString() : '';
      } catch (e) {
        if (generation !== epoch || c !== ctx) {ignored+=1;return;}
        error=errCode(e); values=Object.create(null);
      } finally {
        if (generation === epoch && c === ctx) {inflight=null;notify();scheduleNext(started,generation);}
      }
    })();
    inflight=operation;return operation;
  }
  function reset() {
    closeSourcePicker();
    epoch += 1; if(timer!==null) clear(timer);timer=null;
    for(const c of controllers) c.abort();controllers.clear();
    ctx=null;inflight=null;modelFlight=null;model=null;values=Object.create(null);
    responseTime='';lastSuccess=0;error='NO_CONTEXT';notify();
  }
  function acquire(params, listener) {
    const p=params || {}, token=text(p.token).replace(/^Bearer\s+/i,'');
    const next={uuid:text(p.deviceUuid).toLowerCase(),token,base:typeof p.apiBase==='string'?p.apiBase.trim().replace(/\/+$/,''):null,admin:p.admin===true};
    if(!uuid(next.uuid)||!token||next.base===null) fail('CONTEXT_REQUIRED');
    if(ctx && (ctx.uuid!==next.uuid||ctx.token!==next.token||ctx.base!==next.base||ctx.admin!==next.admin)) {
      // Reject simultaneous principals instead of sharing any state or token.
      fail('CONTEXT_CONFLICT');
    }
    const first=!ctx,id=++serial;
    if(first) {ctx=next;epoch+=1;error='LOADING';}
    leases.add(id);if(listener) listeners.add(listener);
    if(listener) listener(snapshot());
    if(first) {void refresh();if(next.admin) void adminModel().catch(()=>{});}
    return () => { if(!leases.delete(id)) return;if(listener) listeners.delete(listener);if(!leases.size) reset(); };
  }
  async function adminModel(force=false) {
    if(!ctx||!ctx.admin) fail('ADMIN_CONTEXT_REQUIRED');
    if(modelFlight) return modelFlight;
    if(model&&!force) return model;
    const generation=epoch, c=ctx;
    const operation=(async()=>{
      const data=await request('/api/v1/admin/devices/'+encodeURIComponent(c.uuid)+'/individual-project/schema-entity-options',null,generation);
      if(!Array.isArray(data.options)||!data.bindings||typeof data.bindings!=='object'||Array.isArray(data.bindings)) fail('OPTIONS_SHAPE');
      if(data.has_more===true) fail('CATALOGUE_PAGINATION_REQUIRES_HANDLING');
      if(generation!==epoch) fail('CONTEXT_CHANGED');
      model=data;schedulePaint();return data;
    })();
    modelFlight=operation;
    try{return await operation;}finally{if(generation===epoch) modelFlight=null;}
  }
  function match(old, options) {
    if(!old||typeof old!=='object') return null;
    const eid=text(old.entity_id), dev=identity(old.ieee||old.device_id);
    if(!eid || !dev) return null; // Never guess from labels or list order.
    const hits=options.filter(o=>text(o.entity_id)===eid &&
      (!old.transport||text(old.transport).toLowerCase()===text(o.transport).toLowerCase()) &&
      [identity(o.ieee),identity(o.device_id)].includes(dev));
    return hits.length===1 ? hits[0] : null;
  }
  function optionsFor(adapter) {
    const opts=(model&&model.options||[]).filter(o=>!adapter.capability||o.capability===adapter.capability||
      (o.capabilities||[]).includes(adapter.capability));
    return opts.map(o=>({...o,uid:text(o.id)||[o.transport,o.device_id,o.entity_id].join('|'),
      display_value:format(o,o.unit,adapter.digits)}));
  }
  function bindingFor(slot) { return model&&model.bindings ? model.bindings[slot]||null : null; }
  function catalogFor(adapter) {
    const options=optionsFor(adapter), binding=bindingFor(adapter.slot);
    const saved=binding ? options.find(o=>text(o.id)===text(binding.id)&&text(o.entity_id)===text(binding.entity_id))||match(binding,options) : null;
    let proposed=null;
    if(!binding && ctx&&ctx.admin) {try{proposed=match(adapter.legacy&&adapter.legacy(),options);}catch(_) {}}
    const groups=new Map();
    for(const o of options) {
      const key=[o.transport,o.device_id].join('|');
      if(!groups.has(key)) groups.set(key,{device_name:o.device_name,transport:o.transport,entities:[],options:[]});
      groups.get(key).entities.push(o);groups.get(key).options.push(o);
    }
    const devices=Array.from(groups.values());
    return {options,devices,groups:{devices},recommended:[],selected:saved,
      selected_for_form:saved||proposed,migration_needs_confirmation:!!(!binding&&proposed)};
  }
  function save(slot, chosen) {
    const requestedEpoch=epoch, requestedContext=ctx;
    const operation=writeChain.catch(()=>{}).then(async()=>{
      if(!ctx||!ctx.admin||epoch!==requestedEpoch||ctx!==requestedContext) fail('ADMIN_CONTEXT_REQUIRED');
      const a=adapters.get(slot);if(!a) fail('SLOT_NOT_REGISTERED');
      if(a.deviceUuid&&a.deviceUuid.toLowerCase()!==ctx.uuid) fail('SLOT_SCOPE_MISMATCH');
      const fresh=await adminModel(true), option=match(chosen,fresh.options);
      if(!option) fail('ENTITY_IDENTITY_NOT_UNIQUE');
      const result=await request('/api/v1/admin/devices/'+encodeURIComponent(ctx.uuid)+'/individual-project/schema-entity-bindings/'+encodeURIComponent(slot),
        {method:'PUT',body:{entity:option,capability:a.capability||option.capability}},requestedEpoch);
      if(result.binding_persisted!==true) fail('BINDING_NOT_PERSISTED');
      if(!result.binding||text(result.binding.entity_id)!==text(option.entity_id)||
        result.binding.verified_against_current_options!==true) fail('BINDING_NOT_CONFIRMED');
      model=null;
      const confirmed=await adminModel(true);
      const stored=confirmed.bindings && confirmed.bindings[slot];
      if(!stored || text(stored.entity_id)!==text(option.entity_id) ||
         text(stored.transport)!==text(option.transport) ||
         identity(stored.device_id)!==identity(option.device_id) ||
         stored.verified_against_current_options!==true) fail('BINDING_READBACK_MISMATCH');
      await refresh();return stored;
    });
    writeChain=operation;return operation;
  }
  function saveMessage(slot, expectedUuid) {
    const entry=view(slot,expectedUuid);
    return 'Vazba ulo\u017eena a ov\u011b\u0159ena na serveru. ' +
      (entry.has_value===true ? 'Posledn\u00ed hl\u00e1\u0161en\u00e1 hodnota: '+format(entry,entry.unit,entry.capability==='power'?3:1) : hint(entry));
  }
  function paintText(box, findText, entry, unit, digits, slot) {
    if(!box) return;
    let node=paints.get(box);
    if(!node||!node.isConnected||!box.contains(node)) {node=findText(box);if(!node) return;paints.set(box,node);}
    const label=format(entry,unit,digits);
    if(node.nodeType===3) {if(node.nodeValue!==label) node.nodeValue=label;}
    else if(node.textContent!==label) node.textContent=label;
    const host=node.nodeType===3 ? node.parentElement : node;
    if(host) {host.setAttribute('data-seb01-slot',slot);host.setAttribute('title',hint(entry));}
  }
  function renderAdapters() {
    for(const adapter of adapters.values()) {
      try {
        const target=adapter.locate(); if(!target||!target.card||!target.box) continue;
        const eligible=ctx && (!adapter.deviceUuid||adapter.deviceUuid.toLowerCase()===ctx.uuid);
        if(!eligible) {adapter.paint({has_value:false,status:'no_context',value:null});
          if(adapter.pickerSelector) target.card.querySelectorAll(adapter.pickerSelector).forEach(el=>el.remove()); continue;}
        adapter.paint(view(adapter.slot));
        if(ctx.admin && model) {
          const data=catalogFor(adapter);adapter.build(data,data.selected_for_form);
          if(data.migration_needs_confirmation && adapter.statusSelector) {
            const el=target.card.querySelector(adapter.statusSelector);
            if(el && !el.dataset.seb01Prompt) {el.dataset.seb01Prompt='true';el.textContent='Ulo\u017eenou m\u00edstn\u00ed volbu potvr\u010fte tla\u010d\u00edtkem Ulo\u017eit. Hodnota se pot\u00e9 bude \u010d\u00edst ze serveru.';}
          }
        } else if(adapter.pickerSelector) {
          target.card.querySelectorAll(adapter.pickerSelector).forEach(el=>el.remove());
        }
      }catch(e){ /* No data fallback: adapter error is diagnosable, not a value. */ adapter.lastError=errCode(e); }
    }
  }
  function schedulePaint() {
    if(paintQueued) return;paintQueued=true;
    Promise.resolve().then(()=>{paintQueued=false;renderAdapters();});
  }
  // Generic metadata picker. Does not read from devices and never changes physical state.
  let sourceDialog = null;
  function closeSourcePicker() {
    if(!sourceDialog) return;
    const el=sourceDialog;sourceDialog=null;
    try {if(el.open) el.close();} catch(_) {}
    el.remove();
  }
  async function openSourcePicker(slot, anchor) {
    if(!ctx||!ctx.admin||!env.document||!anchor||!anchor.isConnected) return;
    const adapter=adapters.get(slot),generation=epoch;
    if(!adapter || adapter.deviceUuid&&adapter.deviceUuid.toLowerCase()!==ctx.uuid) return;
    closeSourcePicker();
    const doc=env.document,dialog=doc.createElement('dialog');sourceDialog=dialog;
    dialog.setAttribute('data-seb01-source-dialog',slot);
    Object.assign(dialog.style,{color:'#def7ff',background:'#061b28',border:'1px solid #39d4fa',
      borderRadius:'12px',padding:'20px',width:'min(640px,calc(100vw - 64px))',maxHeight:'75vh',overflow:'auto'});
    const make=(tag,label)=>{const e=doc.createElement(tag);if(label)e.textContent=label;return e;};
    const title=make('h3',adapter.title||'Vybrat zdroj entity');title.id='seb01-source-dialog-title';dialog.appendChild(title);
    dialog.setAttribute('aria-labelledby',title.id);
    const netLabel=make('label','Komunika\u010dn\u00ed s\u00ed\u0165: '),network=make('select');
    network.setAttribute('data-seb01-network-filter','true');
    for(const [value,label] of [['','V\u0161echny'],['wifi','Wi-Fi'],['zigbee','Zigbee']]){
      const o=make('option',label);o.value=value;network.appendChild(o);
    }
    netLabel.appendChild(network);dialog.appendChild(netLabel);
    const entityLabel=make('label','Za\u0159\u00edzen\u00ed a entita:');
    entityLabel.style.display='block';entityLabel.style.marginTop='12px';
    const select=make('select');select.setAttribute('data-seb01-entity-select','true');
    Object.assign(select.style,{width:'100%',marginTop:'6px',minHeight:'38px',background:'#061b28',color:'#def7ff'});
    entityLabel.appendChild(select);dialog.appendChild(entityLabel);
    const info=make('p','Na\u010d\u00edt\u00e1m katalog t\u00e9to instalace\u2026');
    info.setAttribute('role','status');dialog.appendChild(info);
    const note=make('p','V\u00fdb\u011br pouze p\u0159i\u0159ad\u00ed zdroj. Nespou\u0161t\u00ed vyhled\u00e1v\u00e1n\u00ed ani ovl\u00e1d\u00e1n\u00ed za\u0159\u00edzen\u00ed.');
    note.style.fontSize='0.85em';dialog.appendChild(note);
    const saveButton=make('button','Ulo\u017eit vazbu'),close=make('button','Zav\u0159\u00edt');
    saveButton.type=close.type='button';saveButton.disabled=true;
    for(const b of [saveButton,close]){b.style.padding='8px 12px';b.style.marginRight='8px';dialog.appendChild(b);}
    close.addEventListener('click',closeSourcePicker);dialog.addEventListener('cancel',closeSourcePicker);
    doc.body.appendChild(dialog);
    try {dialog.showModal();} catch(_) {dialog.setAttribute('open','');}
    let options=[],byId=new Map();
    const alive=()=>!!ctx&&ctx.admin&&epoch===generation&&sourceDialog===dialog;
    const describe=()=>{
      const o=byId.get(select.value);saveButton.disabled=!o;
      if(!o){info.textContent='Vyberte zdroj ze seznamu.';return;}
      info.textContent=[o.device_name,o.entity_name].filter(Boolean).join(' / ')+' \u2014 '+
        (o.data_kind==='catalogue'||o.status==='snapshot_only' ?
        'Za\u0159\u00edzen\u00ed je evidovan\u00e9; pr\u016fb\u011b\u017en\u00e1 telemetrie zat\u00edm chyb\u00ed.' :
        'Posledn\u00ed dostupn\u00fd stav v katalogu: '+format(o,o.unit,adapter.digits));
    };
    const fill=(selectedId)=>{
      byId=new Map();select.replaceChildren();
      const empty=make('option','Vyberte entitu\u2026');empty.value='';select.appendChild(empty);
      for(const o of options){
        if(network.value&&text(o.transport)!==network.value)continue;
        const id=text(o.id)||[o.transport,o.device_id,o.entity_id].join('|');
        if(byId.has(id))continue;byId.set(id,o);
        const label=[o.device_name||o.device_id,o.entity_name||o.entity_id,o.transport,o.unit].filter(Boolean).join(' / ');
        const opt=make('option',label);opt.value=id;select.appendChild(opt);
      }
      if(selectedId&&byId.has(selectedId))select.value=selectedId;
      describe();
    };
    network.addEventListener('change',()=>fill(select.value));select.addEventListener('change',describe);
    saveButton.addEventListener('click',async()=>{
      if(!alive())return;const chosen=byId.get(select.value);if(!chosen)return;
      saveButton.disabled=true;select.disabled=network.disabled=true;info.textContent='Ukl\u00e1d\u00e1m a ov\u011b\u0159uji vazbu na serveru\u2026';
      try {await save(slot,chosen);if(alive())info.textContent=saveMessage(slot,ctx.uuid);}
      catch(e){if(alive())info.textContent='Vazba nepotvrzena: '+errCode(e);}
      finally{if(alive()){select.disabled=network.disabled=false;saveButton.disabled=false;}}
    });
    try {
      await adminModel(true);if(!alive())return;
      const data=catalogFor(adapter);options=data.options;
      const saved=data.selected;if(saved)network.value=['wifi','zigbee'].includes(saved.transport)?saved.transport:'';
      fill(saved&&(text(saved.id)||saved.uid));
      if(!options.length)info.textContent='V katalogu t\u00e9to instalace nen\u00ed kompatibiln\u00ed entita.';
    }catch(e){if(alive())info.textContent='Katalog nen\u00ed dostupn\u00fd: '+errCode(e);}
  }

  function registerAdapter(adapter) {
    if(!adapter||!adapter.slot||adapters.has(adapter.slot)) fail('DUPLICATE_SLOT_ADAPTER');
    adapters.set(adapter.slot,adapter);schedulePaint();return()=>adapters.delete(adapter.slot);
  }
  if(env.document && env.MutationObserver) {
    const observer=new env.MutationObserver(schedulePaint);
    observer.observe(env.document.documentElement,{childList:true,subtree:true});
    env.document.addEventListener('visibilitychange',()=>{if(ctx&&!env.document.hidden) void refresh();});
  }
  if(env.addEventListener) env.addEventListener('online',()=>{if(ctx) void refresh();});
  return Object.freeze({version:VERSION,acquire,refresh,registerAdapter,save,view,format,hint,paintText,
    isAdmin:()=>!!(ctx&&ctx.admin), catalogFor,saveMessage,openSourcePicker,diagnostics:snapshot,matchIdentity:match});
}));
