(() => {
  "use strict";

  const MARK = "__IQF_F31_R74_HEATING_CIRCUIT_TITLES_EQUAL__";
  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  const TITLES = Object.freeze([
    "TOPNÝ OKRUH VÝCHOD",
    "TOPNÝ OKRUH ZÁPAD"
  ]);

  if (window[MARK]) return;
  window[MARK] = true;

  function norm(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function ensureStyle() {
    const id =
      "f31-r74-heating-circuit-titles-equal-style";

    if (document.getElementById(id)) return;

    const style =
      document.createElement("style");

    style.id = id;

    style.textContent = `
      ${ROOT_SELECTOR} .f31-r74-heating-circuit-title {
        display: block !important;
        width: auto !important;
        max-width: none !important;

        white-space: nowrap !important;
        overflow: visible !important;
        text-overflow: clip !important;
        word-break: keep-all !important;

        font-size: 1rem !important;
        font-weight: 900 !important;
        line-height: 1.05 !important;
        letter-spacing: 0 !important;

        text-align: center !important;
      }

      @media (max-width: 1200px) {
        ${ROOT_SELECTOR} .f31-r74-heating-circuit-title {
          font-size: .92rem !important;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function findTitle(rootEl, title) {
    const wanted = norm(title);

    const candidates = Array.from(
      rootEl.querySelectorAll(
        "h1,h2,h3,h4,h5,strong,b,div,span"
      )
    ).filter((el) => {
      return norm(el.textContent) === wanted;
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      return (
        (ar.width * ar.height) -
        (br.width * br.height)
      );
    });

    return candidates[0];
  }

  function apply() {
    ensureStyle();

    const rootEl =
      document.querySelector(
        ROOT_SELECTOR
      );

    if (!rootEl) return false;

    let count = 0;

    for (const title of TITLES) {
      const el =
        findTitle(
          rootEl,
          title
        );

      if (!el) continue;

      el.classList.remove(
        "f31-r73-east-title-one-line"
      );

      el.classList.add(
        "f31-r74-heating-circuit-title"
      );

      el.setAttribute(
        "data-f31-r74-title",
        "equal-size"
      );

      count += 1;
    }

    rootEl.setAttribute(
      "data-f31-r74-title-count",
      String(count)
    );

    return count === 2;
  }

  function boot() {
    apply();

    let attempts = 0;

    const timer =
      window.setInterval(() => {
        attempts += 1;

        if (
          apply() ||
          attempts >= 24
        ) {
          window.clearInterval(timer);
        }
      }, 250);
  }

  if (
    document.readyState === "loading"
  ) {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }

  // F31_R85_LIFECYCLE_PATCH: replay the existing visual operation on each schema mount.
  window.IQF_F31_R85_LAYOUT_HOOKS=window.IQF_F31_R85_LAYOUT_HOOKS||{};
  window.IQF_F31_R85_LAYOUT_HOOKS["R74"]=apply;
  document.dispatchEvent(new Event('iqf-f31-r85-layout-ready'));
})();
