(function phase30Model00012BoilerTempAdminClientDisplayV13() {
  "use strict";
  // F30_04C_R4_SHARED_RUNTIME_ADAPTER
  var R = window.IQF_SEB01_RUNTIME;
  if (!R) throw new Error("SEB01_RUNTIME_NOT_LOADED");

  var MARKER = "__F30_02U_ADMIN_CLIENT_BOILER_TEMP_DISPLAY_V13__";
  if (window[MARKER]) return;
  window[MARKER] = true;

  var BINDING_URL = "/phase30-model00012-boiler-temperature-binding-v13.json?v=20260915-013609";
  var STORE_KEY = "f30_02u_model00012_boiler_temperature_binding_v13";
  var STYLE_ID = "f30-02u-boiler-temperature-style";

  var cachedData = null;
  var userInteractingUntil = 0;
  var selectedPending = null;
  var optionByUid = {};

  function text(value) {
    return value === null || value === undefined ? "" : String(value).trim();
  }

  function normalize(value) {
    return text(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  }

  function compact(value) {
    return normalize(value).replace(/[^a-z0-9]+/g, "");
  }

  function isAdminPage() { return R.isAdmin(); }

  function number(value) {
    if (typeof value === "number" && Number.isFinite(value)) return value;

    if (typeof value === "string") {
      var match = value.replace(",", ".").match(/-?\d+(?:\.\d+)?/);
      if (match) {
        var n = Number(match[0]);
        if (Number.isFinite(n)) return n;
      }
    }

    return null;
  }

  function formatValue(option) { return R.format(option, "\u00b0C", 1); }

  function findSchema() {
    var schema = document.querySelector('[data-f29-00012-schema="svj-blansko-only"], .f29-00012-schema-v2');

    if (!schema) return null;

    var c = compact(schema.textContent || "");

    if (c.indexOf("bojler") === -1) return null;

    if (
      c.indexOf("tnghe1500") === -1 &&
      c.indexOf("bivalence") === -1 &&
      c.indexOf("akunadr") === -1 &&
      c.indexOf("cztblansko") === -1
    ) {
      return null;
    }

    return schema;
  }

  function findBoilerCard(schema) {
    return schema ? schema.querySelector(".f29-00012-boiler") : null;
  }

  function findTemperatureBox(boiler) {
    return boiler ? boiler.querySelector(".f29-00012-temperature") : null;
  }

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;

    var style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = [
      ".f30-02u-picker{margin-top:.65rem;padding:.7rem;border:1px solid rgba(93,203,255,.38);border-radius:14px;background:rgba(2,22,34,.96);display:grid;gap:.5rem;position:relative;z-index:3;min-width:315px;max-width:430px}",
      ".f30-02u-picker label{display:grid;gap:.35rem;color:#d9f5ff;font-size:.72rem;font-weight:900;letter-spacing:.04em;text-transform:uppercase}",
      ".f30-02u-picker select{width:100%;min-height:38px;border-radius:10px;border:1px solid rgba(124,221,255,.42);background:#061b28;color:#f1fbff;padding:.45rem .55rem;font-size:.82rem}",
      ".f30-02u-picker .f30-02u-actions{display:flex;gap:.45rem;align-items:center;justify-content:flex-end}",
      ".f30-02u-picker button{border:1px solid rgba(124,221,255,.55);background:rgba(34,184,255,.20);color:#e7fbff;border-radius:10px;padding:.42rem .75rem;font-weight:900;font-size:.76rem;cursor:pointer}",
      ".f30-02u-picker button:disabled{opacity:.45;cursor:not-allowed}",
      ".f30-02u-picker small{color:#9dc8d7;font-size:.70rem;line-height:1.25}",
      ".f30-02u-picker .f30-02u-status{color:#75f0b3}",
      ".f30-02u-picker .f30-02u-warning{color:#ffd47a}",
      ".f30-02u-source{display:block;margin-top:.2rem;font-size:.68rem;color:#9dc8d7;font-weight:700}",
      ".f30-02u-live-value{display:inline-block;margin-left:.35rem;color:#fff;font-weight:900;text-shadow:0 0 10px rgba(72,220,255,.45)}"
    ].join("\n");

    document.head.appendChild(style);
  }

  async function loadData() { return cachedData; }

  function loadLocalBinding() {
    try {
      var raw = window.localStorage.getItem(STORE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (error) {}

    return null;
  }

  async function saveLocalBinding(binding) {
    try { await R.save("boiler-temperature", binding); return true; }
    catch (error) { return false; }
  }

  function selectedFromOptions(options, binding) {
    if (!binding) return null;

    var uid = text(binding.uid);

    if (uid) {
      for (var i = 0; i < options.length; i += 1) {
        if (text(options[i].uid) === uid) return options[i];
      }
    }

    var entityId = text(binding.entity_id);
    var entityName = compact(binding.entity_name);
    var deviceName = compact(binding.device_name);

    for (var j = 0; j < options.length; j += 1) {
      if (entityId && text(options[j].entity_id) === entityId) return options[j];
      if (
        entityName &&
        deviceName &&
        compact(options[j].entity_name) === entityName &&
        compact(options[j].device_name) === deviceName
      ) {
        return options[j];
      }
    }

    return binding;
  }

  function candidateTextNodes(box) {
    var out = [];

    if (!box) return out;

    var walker = document.createTreeWalker(box, NodeFilter.SHOW_TEXT, {
      acceptNode: function(node) {
        var parent = node.parentElement;

        if (!parent) return NodeFilter.FILTER_REJECT;

        if (
          parent.closest(".f30-02u-picker") ||
          parent.closest(".f30-02u-source") ||
          parent.closest(".f30-02u-live-value")
        ) {
          return NodeFilter.FILTER_REJECT;
        }

        var t = text(node.nodeValue);

        if (!t) return NodeFilter.FILTER_REJECT;

        var c = compact(t);

        if (c === "teplota" || c.indexOf("zdroj") !== -1) return NodeFilter.FILTER_REJECT;

        if (
          t.indexOf("\u00b0C") !== -1 ||
          t.indexOf("\u2014") !== -1 ||
          t === "-" ||
          /^-?\d+(?:[,.]\d+)?$/.test(t)
        ) {
          return NodeFilter.FILTER_ACCEPT;
        }

        return NodeFilter.FILTER_REJECT;
      }
    });

    var node;

    while ((node = walker.nextNode())) out.push(node);

    return out;
  }

  function applyValue(option) {
    var card = findBoilerCard(findSchema());
    var box = findTemperatureBox(card);
    if (!box) return;
    R.paintText(box, function(target) { var nodes = candidateTextNodes(target); return nodes.length ? nodes[0] : null; }, R.view("boiler-temperature", "014a0d23-d440-4131-abb4-28a860595043"), "\u00b0C", 1, "boiler-temperature");
  }

  function optionLabel(option) {
    var label = text(option.display_label);

    if (!label) {
      label = [
        text(option.device_name || "Zarizeni"),
        text(option.entity_name || "Entita"),
        text(option.display_value || formatValue(option))
      ].filter(Boolean).join(" - ");
    }

    return label.length > 150 ? label.slice(0, 147) + "..." : label;
  }

  function addOptions(select, label, options) {
    if (!options || !options.length) return;

    var group = document.createElement("optgroup");
    group.label = label;

    options.forEach(function(option) {
      var uid = text(option.uid);

      if (!uid) return;

      optionByUid[uid] = option;

      var opt = document.createElement("option");
      opt.value = uid;
      opt.textContent = optionLabel(option);
      group.appendChild(opt);
    });

    select.appendChild(group);
  }

  function currentSelected(select) {
    if (!select) return null;

    var uid = text(select.value);

    if (!uid) return null;

    return optionByUid[uid] || null;
  }

  function removeOldPickers(boiler) {
    boiler.querySelectorAll(
      ".f30-02i-boiler-temp-picker,.f30-02j-boiler-temp-picker,.f30-02k-boiler-temp-picker,.f30-02k-r2-picker,.f30-02l-picker,.f30-02m-picker,.f30-02n-picker,.f30-02o-picker,.f30-02p-picker,.f30-02q-picker,.f30-02r-picker,.f30-02s-picker,.f30-02t-picker"
    ).forEach(function(el) {
      el.remove();
    });
  }

  function buildAdminPicker(boiler, data, selected) {
    if (boiler.querySelector(".f30-02u-picker")) return;

    removeOldPickers(boiler);

    ensureStyle();
    optionByUid = {};

    var picker = document.createElement("div");
    picker.className = "f30-02u-picker";
    picker.setAttribute("data-f30-02u", "admin-client-boiler-temp-display-v13");
    picker.innerHTML =
      '<label>Teplota bojler - ulozeni pro admin i klient<select></select></label>' +
      '<small>Admin vybere zdroj. Klient vidi pouze vyslednou hodnotu bez seznamu.</small>' +
      '<div class="f30-02u-actions"><button type="button" class="f30-02u-save" disabled>Ulozit</button></div>' +
      '<small class="f30-02u-status"></small>';

    (findTemperatureBox(boiler) || boiler).appendChild(picker);

    var select = picker.querySelector("select");
    var saveButton = picker.querySelector(".f30-02u-save");
    var status = picker.querySelector(".f30-02u-status");

    var empty = document.createElement("option");
    empty.value = "";
    empty.textContent = data.options.length ? "Vyber zarizeni / entitu..." : "Binding modelu 00012 je prazdny";
    select.appendChild(empty);

    if (data.selected) addOptions(select, "Ulozena vazba pro klienta", [data.selected]);

    (data.groups.devices || []).forEach(function(device) {
      addOptions(select, text(device.device_name || "Zigbee zarizeni"), device.options || []);
    });

    var effectiveSelected = selected || data.selected;

    if (effectiveSelected && text(effectiveSelected.uid) && optionByUid[text(effectiveSelected.uid)]) {
      select.value = text(effectiveSelected.uid);
    }

    function markInteracting() {
      userInteractingUntil = Date.now() + 60000;
    }

    function refreshStatus() {
      var chosen = currentSelected(select);

      selectedPending = chosen;
      saveButton.disabled = !chosen;

      if (!status) return;

      if (chosen) {
        status.className = "f30-02u-status";
        status.textContent =
          "Vybrano: " +
          text(chosen.device_name || "zarizeni") +
          " / " +
          text(chosen.entity_name || "entita") +
          " = " +
          formatValue(chosen) +
          ". Potvrd tlacitkem Ulozit.";
      } else {
        status.className = "f30-02u-status";
        status.textContent =
          data.selected
            ? "Aktualne ulozeno pro klienta: " + text(data.selected.device_name) + " / " + text(data.selected.entity_name) + " = " + formatValue(data.selected) + "."
            : "Vyber zdroj teploty.";
      }
    }

    ["focus", "pointerdown", "mousedown", "keydown", "input", "change", "click"].forEach(function(eventName) {
      select.addEventListener(eventName, markInteracting);
    });

    select.addEventListener("input", refreshStatus);
    select.addEventListener("change", refreshStatus);

    saveButton.addEventListener("pointerdown", markInteracting);
    saveButton.addEventListener("mousedown", markInteracting);

    saveButton.addEventListener("click", async function() {
      markInteracting();

      var chosen = currentSelected(select) || selectedPending;

      if (!chosen) {
        refreshStatus();
        return;
      }

      var ok = await saveLocalBinding(chosen);
        if (!ok) {
          if (status) status.textContent = "Ulozeni vazby na server selhalo; vyber nebyl potvrzen.";
          return;
        }

      data.selected = chosen;
      cachedData.selected = chosen;

      applyValue(chosen);

      saveButton.disabled = false;

      if (status) {
        status.className = "f30-02u-status" + (ok ? "" : " f30-02u-warning");
        status.textContent = R.saveMessage("boiler-temperature", "014a0d23-d440-4131-abb4-28a860595043");
      }
    });

    if (effectiveSelected) {
      applyValue(effectiveSelected);
    }

    refreshStatus();
  }

  R.registerAdapter({
    deviceUuid: "014a0d23-d440-4131-abb4-28a860595043", slot: "boiler-temperature", capability: "temperature",
    digits: 1, legacy: loadLocalBinding,
    pickerSelector: ".f30-02u-picker", statusSelector: ".f30-02u-status",
    locate: function() { var card=findBoilerCard(findSchema()); return card ? {card:card,box:findTemperatureBox(card)} : null; },
    paint: function(entry) { applyValue(entry); },
    build: function(data,selected) { cachedData=data; var card=findBoilerCard(findSchema()); if(card) buildAdminPicker(card,data,selected); }
  });
})();
