(() => {
  "use strict";
  const VERSION = "F32.2Q-R115-NATIVE-TAB-LIFECYCLE";
  const GLOBAL = "IQF_F32_R115_SETTINGS";
  if (window[GLOBAL] && window[GLOBAL].version === VERSION) return;
  const OVERLAY_ID = "f32-r115-settings-workspace";
  const STYLE_ID = "f32-r115-settings-workspace-style";
  const ROOT = '[data-phase28-r177n107-workspace]';
  const NAV = '[data-phase28-r177n107-bottom-nav]';
  const TAB_ATTR = 'data-phase28-r177n107-tab-key';
  const ACTIVE_ATTR = 'data-phase28-r177n107-active';
  const SCREEN_ATTR = 'data-phase28-r177n107-screen';
  const HOST = '[data-phase28-r177n107-screen-host]';
  const FOOTER = '[data-phase28-r177n124-copyright-box]';
  const METEO = '[data-phase28-r177n119-meteo-panel],[data-phase28-r177n118-meteo-panel]';
  const TARGET_UUID = '28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc';
  const KEYS = ['schema','settings','statistics','system','manual','user'];
  const columns = [
    {key:'basic',title:'Základní nastavení'},
    {key:'heating',title:'Nastavení vytápění'},
    {key:'boiler',title:'Nastavení bojleru'}
  ];
  let disposed = false, queued = 0, boundRoot = null, open = false;
  let domObserver = null, nativeObserver = null, sizeObserver = null;
  let last = {version:VERSION, open:false, reason:'STARTING', nativeTab:null};

  function norm(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/\s+/g,' ').trim().toLowerCase();
  }
  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && r.right > 0 && r.bottom > 0 &&
      r.left < innerWidth && r.top < innerHeight &&
      s.display !== 'none' && s.visibility !== 'hidden' &&
      !el.closest('[hidden],[aria-hidden="true"]');
  }
  function own(el) {
    return el instanceof Element && (el.id === STYLE_ID || el.id === OVERLAY_ID ||
      !!el.closest('#'+OVERLAY_ID));
  }
  function sameRoot(el, root) { return el.closest(ROOT) === root; }
  function targetContext(root) {
    // No document.body text search and no sticky approval carried to another account.
    const identity = root.getAttribute('data-device-uuid');
    if (identity && identity !== TARGET_UUID) return null;
    const notes = [...root.querySelectorAll(FOOTER)].filter(el => sameRoot(el,root));
    const note = norm(notes.map(el => [el.textContent,
      ...[...el.querySelectorAll('textarea,input[type="text"]')].map(x => x.value)
    ].join(' ')).join(' '));
    if (note.includes('jasanova 32') && note.includes('blansko')) return 'SCOPED_PROJECT_NOTE';
    if (root.querySelector('[data-f29-00012-schema="svj-blansko-only"]')) return 'SCHEMA_00012_MARKER';
    // UUID fallback is accepted only with the actual visible individual workspace.
    const declared = root.getAttribute('data-device-uuid');
    if (declared && declared !== TARGET_UUID) return null;
    if (declared === TARGET_UUID || location.href.includes(TARGET_UUID)) return 'DEVICE_UUID';
    return null;
  }
  function readNative() {
    const fs = document.fullscreenElement;
    const roots = [...document.querySelectorAll(ROOT)].filter(r => visible(r) && (!fs || fs.contains(r)));
    if (roots.length !== 1) return {reason:roots.length ? 'AMBIGUOUS_VISIBLE_WORKSPACE' : 'NO_VISIBLE_WORKSPACE'};
    const root=roots[0], navs=[...root.querySelectorAll(NAV)].filter(n => sameRoot(n,root) && visible(n));
    if (navs.length !== 1) return {root,reason:'NATIVE_NAV_NOT_UNIQUE'};
    const nav=navs[0], buttons=[...nav.querySelectorAll('button['+TAB_ATTR+']')];
    if (buttons.length !== KEYS.length || !KEYS.every(k => buttons.filter(b=>b.getAttribute(TAB_ATTR)===k).length===1))
      return {root,nav,reason:'NATIVE_TAB_CONTRACT_MISMATCH'};
    const active=buttons.filter(b=>b.getAttribute(ACTIVE_ATTR)==='true');
    if (active.length !== 1) return {root,nav,reason:'NATIVE_ACTIVE_TAB_NOT_UNIQUE'};
    const tab=active[0].getAttribute(TAB_ATTR);
    const source=targetContext(root);
    if (!source) return {root,nav,tab,reason:'OTHER_PROJECT_OR_NO_IDENTITY'};
    const screens=[...root.querySelectorAll('['+SCREEN_ATTR+']')].filter(s=>sameRoot(s,root) && visible(s));
    if (screens.length===1 && KEYS.includes(screens[0].getAttribute(SCREEN_ATTR)) && screens[0].getAttribute(SCREEN_ATTR)!==tab)
      return {root,nav,tab,source,reason:'NATIVE_TAB_TRANSITION'};
    return {root,nav,tab,source,reason:tab==='settings'?'SETTINGS_ACTIVE':'OTHER_NATIVE_TAB'};
  }
  function hide(reason, state={}) {
    open=false;
    const el=document.getElementById(OVERLAY_ID);
    if (el) {
      if(el.dataset.open!=='false') el.dataset.open='false';
      if(el.style.height!=='0px') el.style.height='0px';
    }
    last={version:VERSION,open:false,nativeTab:state.tab||null,reason};
  }
  function setStyle(el,key,value) { if(el.style[key]!==value) el.style[key]=value; }
  function paint(state) {
    const rr=state.root.getBoundingClientRect();
    const footers=[state.nav,...state.root.querySelectorAll(FOOTER+','+METEO)]
      .filter(n=>sameRoot(n,state.root) && visible(n));
    const bottom=Math.floor(Math.min(innerHeight,...footers.map(n=>n.getBoundingClientRect().top))-8);
    const top=Math.ceil(Math.max(0,rr.top)), left=Math.ceil(Math.max(0,rr.left));
    const right=Math.floor(Math.min(innerWidth,rr.right));
    if (bottom-top<120 || right-left<180) { hide('INSUFFICIENT_WORKSPACE_GEOMETRY',state); return; }
    ensureStyle();
    const el=buildOverlay(), host=document.fullscreenElement||document.body;
    if(el.parentNode!==host) host.appendChild(el);  // Reparent only our own frame.
    setStyle(el,'top',top+'px'); setStyle(el,'left',left+'px');
    setStyle(el,'width',(right-left)+'px'); setStyle(el,'height',(bottom-top)+'px');
    if(el.dataset.open!=='true') el.dataset.open='true';
    open=true;
    last={version:VERSION,open:true,nativeTab:state.tab,scope:state.source,
      reason:'NATIVE_SETTINGS_VISIBLE',bottom,footerTop:bottom+8};
  }
  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${OVERLAY_ID} {
        position: fixed;
        left: 0;
        top: 0;
        width: 100vw;
        z-index: 2147483646;
        display: none;
        box-sizing: border-box;
        overflow: hidden;
        background:
          linear-gradient(
            180deg,
            rgb(3, 22, 31) 0%,
            rgb(2, 18, 27) 100%
          );
        color: #f4fbff;
      }

      #${OVERLAY_ID}[data-open="true"] {
        display: block;
      }

      #${OVERLAY_ID} .f32-r115-shell {
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        padding: clamp(10px, 0.9vw, 18px);
      }

      #${OVERLAY_ID} .f32-r115-grid {
        width: 100%;
        height: 100%;
        min-height: 0;
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: clamp(12px, 1vw, 20px);
      }

      #${OVERLAY_ID} .f32-r115-column {
        min-width: 0;
        min-height: 0;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        box-sizing: border-box;
        border: 1px solid rgba(42, 212, 255, 0.38);
        border-radius: 18px;
        background:
          linear-gradient(
            180deg,
            rgba(6, 39, 52, 0.92),
            rgba(2, 24, 34, 0.90)
          );
        box-shadow:
          inset 0 0 22px rgba(42, 212, 255, 0.035),
          0 0 16px rgba(0, 0, 0, 0.14);
      }

      #${OVERLAY_ID} .f32-r115-column-header {
        flex: 0 0 auto;
        min-height: clamp(54px, 6.2vh, 72px);
        display: flex;
        align-items: center;
        padding: 0 clamp(18px, 1.35vw, 28px);
        box-sizing: border-box;
        border-bottom: 1px solid rgba(42, 212, 255, 0.22);
        background: rgba(3, 28, 40, 0.52);
      }

      #${OVERLAY_ID} .f32-r115-title {
        margin: 0;
        color: #f4fbff;
        font-family: inherit;
        font-size: clamp(1.08rem, 1.32vw, 1.55rem);
        font-weight: 900;
        line-height: 1.1;
        letter-spacing: 0.005em;
        text-shadow: 0 0 10px rgba(87, 219, 255, 0.18);
      }

      #${OVERLAY_ID} .f32-r115-rows {
        flex: 1 1 auto;
        min-height: 0;
        display: grid;
        grid-template-rows: repeat(8, minmax(32px, 1fr));
        overflow-y: auto;
        gap: clamp(7px, 0.75vh, 11px);
        padding:
          clamp(14px, 1vw, 20px)
          clamp(14px, 1vw, 20px)
          clamp(14px, 1vw, 20px);
        box-sizing: border-box;
      }

      #${OVERLAY_ID} .f32-r115-row {
        min-height: 32px;
        border: 1px solid rgba(85, 197, 226, 0.18);
        border-radius: 12px;
        background:
          linear-gradient(
            180deg,
            rgba(6, 34, 45, 0.74),
            rgba(4, 28, 38, 0.68)
          );
        box-sizing: border-box;
      }

      @media (max-height: 760px) {
        #${OVERLAY_ID} .f32-r115-shell {
          padding: 7px 9px;
        }

        #${OVERLAY_ID} .f32-r115-column-header {
          min-height: 46px;
        }

        #${OVERLAY_ID} .f32-r115-rows {
          gap: 5px;
          padding: 7px 9px 9px;
        }

        #${OVERLAY_ID} .f32-r115-row {
          min-height: 26px;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function buildOverlay() {
    let overlay = document.getElementById(OVERLAY_ID);
    if (overlay) return overlay;

    overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    overlay.dataset.open = "false";
    overlay.dataset.version = VERSION;
    overlay.setAttribute("role", "region");
    overlay.setAttribute("aria-label", "Nastavení individuální instalace");

    const shell = document.createElement("div");
    shell.className = "f32-r115-shell";

    const grid = document.createElement("div");
    grid.className = "f32-r115-grid";

    for (const column of columns) {
      const section = document.createElement("section");
      section.className = "f32-r115-column";
      section.dataset.settingsColumn = column.key;

      const header = document.createElement("header");
      header.className = "f32-r115-column-header";

      const title = document.createElement("h2");
      title.className = "f32-r115-title";
      title.textContent = column.title;

      header.appendChild(title);
      section.appendChild(header);

      const rows = document.createElement("div");
      rows.className = "f32-r115-rows";

      for (let i = 1; i <= 8; i += 1) {
        const row = document.createElement("div");
        row.className = "f32-r115-row";
        row.dataset.settingSlot =
          column.key + "-" + String(i).padStart(2, "0");
        rows.appendChild(row);
      }

      section.appendChild(rows);
      grid.appendChild(section);
    }

    shell.appendChild(grid);
    overlay.appendChild(shell);
    (document.fullscreenElement || document.body).appendChild(overlay);

    return overlay;
  }


  function bind(root) {
    if(root===boundRoot) return;
    if(nativeObserver) nativeObserver.disconnect();
    if(sizeObserver) sizeObserver.disconnect();
    boundRoot=root||null;
    if(!root) return;
    nativeObserver=new MutationObserver(records=>{
      if(records.some(r=>!own(r.target) && (r.type==='attributes' ||
        (r.target instanceof Element?r.target:r.target.parentElement)?.closest(NAV+','+FOOTER)))) schedule();
    });
    nativeObserver.observe(root,{subtree:true,childList:true,characterData:true,
      attributes:true,attributeFilter:[ACTIVE_ATTR,TAB_ATTR,SCREEN_ATTR,'data-device-uuid']});
    if(window.ResizeObserver) {
      sizeObserver=new ResizeObserver(schedule);
      [root,...root.querySelectorAll(NAV+','+FOOTER+','+METEO+','+HOST)].forEach(el=>sizeObserver.observe(el));
    }
  }
  function sync() {
    queued=0;
    if(disposed) return;
    try {
      const state=readNative();
      bind(state.root);
      if(state.reason==='SETTINGS_ACTIVE') paint(state);
      else hide(state.reason,state);
    } catch(error) {
      hide('READER_ERROR_'+(error && error.name || 'UNKNOWN'));
    }
  }
  function schedule() {
    if(!disposed && !queued) queued=requestAnimationFrame(sync);
  }
  function relevantMutations(records) {
    return records.some(r=>{
      if(own(r.target)) return false;
      if(r.type==='attributes') return boundRoot && (r.target===boundRoot || r.target.contains(boundRoot));
      if(boundRoot && (r.target===boundRoot || r.target===boundRoot.parentElement)) return true;
      return [...r.addedNodes,...r.removedNodes].some(n=> n instanceof Element &&
        (n.id===OVERLAY_ID || n.id===STYLE_ID || n.matches(ROOT+','+NAV) ||
         !!n.querySelector(ROOT+','+NAV) || (boundRoot && n.contains(boundRoot))));
    });
  }
  function interaction(event) {
    const el=event.target instanceof Element?event.target:event.target.parentElement;
    if(!el || own(el)) return;
    // Wake the state reader; never derive the selected tab from the clicked text.
    if(el.closest(NAV+','+FOOTER) || (boundRoot && !boundRoot.contains(el))) schedule();
  }
  const wakeEvents=['resize','pageshow','popstate','hashchange'];
  function dispose() {
    disposed=true;
    if(queued) cancelAnimationFrame(queued);
    if(domObserver) domObserver.disconnect();
    if(nativeObserver) nativeObserver.disconnect();
    if(sizeObserver) sizeObserver.disconnect();
    wakeEvents.forEach(n=>window.removeEventListener(n,schedule));
    document.removeEventListener('fullscreenchange',schedule);
    document.removeEventListener('visibilitychange',schedule);
    ['click','input','change'].forEach(n=>document.removeEventListener(n,interaction,true));
    [OVERLAY_ID,STYLE_ID].forEach(id=>{const e=document.getElementById(id); if(e)e.remove();});
  }
  function boot() {
    domObserver=new MutationObserver(r=>{if(relevantMutations(r))schedule();});
    domObserver.observe(document.body,{subtree:true,childList:true,attributes:true,
      attributeFilter:['hidden','aria-hidden','class','style']});
    wakeEvents.forEach(n=>window.addEventListener(n,schedule,{passive:true}));
    document.addEventListener('fullscreenchange',schedule);
    document.addEventListener('visibilitychange',schedule);
    ['click','input','change'].forEach(n=>document.addEventListener(n,interaction,true));
    sync();  // Includes direct Settings entry/reload: no unconditional hide on boot.
  }
  window[GLOBAL]=Object.freeze({version:VERSION,resync:schedule,
    diagnostics:()=>Object.assign({},last),dispose});
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true});
  else boot();
})();
