/*
 * F33_R19_PROVEN_BOILER_SEB01
 *
 * Direct descendant of the verified F30.2J model 00012 selector pattern:
 * findSchema -> findBoilerCard -> .f29-00012-temperature -> in-card picker.
 *
 * Binding path remains the standard SEB-01 API.
 * Live value remains the already-active SEB-01B R5 boiler adapter.
 */
(function () {
  "use strict";

  if (window.__F33_R19_PROVEN_BOILER_SEB01__) {
    return;
  }

  window.__F33_R19_PROVEN_BOILER_SEB01__ = true;

  var DEVICE_UUID =
    "014a0d23-d440-4131-abb4-28a860595043";

  var ELEMENT_KEY =
    "boiler-temperature";

  /* F33_R19R3_API_BASE_FIX */
  var API_BASE_URL =
    "https://api.tngiqfanda.cz";

  var PICKER_CLASS =
    "f33-r19-boiler-temp-picker";

  var STYLE_ID =
    "f33-r19-boiler-temp-picker-style";

  var lastRender = 0;
  var busy = false;

  function text(value) {
    return value === null || value === undefined
      ? ""
      : String(value).trim();
  }

  function compact(value) {
    return text(value)
      .toLocaleLowerCase("cs-CZ")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "");
  }

  function findToken() {
    var preferred = [
      "iqfanda_access_token",
      "access_token",
      "accessToken",
      "token",
      "auth_token",
      "authToken",
      "tng_iq_fanda_token",
      "tng_iqfanda_token"
    ];

    try {
      for (var i = 0; i < preferred.length; i += 1) {
        var candidate =
          window.localStorage.getItem(
            preferred[i]
          );

        if (
          candidate &&
          String(candidate).trim().length > 16
        ) {
          return String(candidate).trim();
        }
      }

      for (
        var index = 0;
        index < window.localStorage.length;
        index += 1
      ) {
        var key =
          window.localStorage.key(index);

        var value =
          key
            ? window.localStorage.getItem(key)
            : "";

        if (
          value &&
          String(value).trim().length > 40 &&
          (
            String(key).toLowerCase().indexOf("token") !== -1 ||
            String(value).split(".").length === 3
          )
        ) {
          return String(value).trim();
        }
      }
    } catch (error) {}

    return "";
  }

  function headers() {
    var result = {
      "Content-Type": "application/json"
    };

    var t = findToken();

    if (t) {
      result.Authorization =
        "Bearer " + t;
    }

    return result;
  }

  async function fetchJson(
    url,
    options
  ) {
    var response =
      await fetch(
        url,
        {
          credentials: "include",
          cache: "no-store",
          ...(options || {}),
          headers: {
            ...headers(),
            ...(
              options &&
              options.headers
                ? options.headers
                : {}
            )
          }
        }
      );

    var raw =
      await response.text();

    var data = null;

    try {
      data =
        raw
          ? JSON.parse(raw)
          : null;
    } catch (error) {
      data = {
        raw: raw
      };
    }

    if (!response.ok) {
      throw new Error(
        (
          data &&
          (
            data.detail ||
            data.message ||
            data.raw
          )
        ) ||
        ("HTTP " + response.status)
      );
    }

    return data;
  }

  function findSchema() {
    var schema =
      document.querySelector(
        '[data-f29-00012-schema="svj-blansko-only"]' +
        '[data-f33-r16-clone-00013="true"]'
      );

    if (!schema) {
      return null;
    }

    var c =
      compact(
        schema.textContent || ""
      );

    if (
      c.indexOf("bojler") === -1
    ) {
      return null;
    }

    return schema;
  }

  function findBoilerCard(schema) {
    if (!schema) return null;

    var exact =
      schema.querySelector(
        ".f29-00012-boiler"
      );

    if (exact) return exact;

    var cards =
      Array.from(
        schema.querySelectorAll(
          "article,section"
        )
      );

    return (
      cards.find(function (card) {
        var value =
          compact(
            card.textContent || ""
          );

        return (
          value.indexOf("bojler") !== -1 &&
          value.indexOf("pripravat") !== -1
        );
      }) ||
      cards.find(function (card) {
        return (
          compact(
            card.textContent || ""
          ).indexOf("bojler") !== -1
        );
      }) ||
      null
    );
  }

  function findTemperatureTarget(boiler) {
    if (!boiler) return null;

    var exact =
      boiler.querySelector(
        ".f29-00012-temperature"
      );

    if (exact) {
      return exact;
    }

    var keyNode =
      boiler.querySelector(
        '[data-f30-schema-element-key="' +
        ELEMENT_KEY +
        '"]'
      );

    if (keyNode) {
      return (
        keyNode.closest(
          "div,p,li"
        ) ||
        keyNode.parentElement ||
        keyNode
      );
    }

    return boiler;
  }

  function adminByWorkspace(schema) {
    if (!schema) return false;

    var workspace =
      schema.closest(
        "[data-phase28-r177n107-source]"
      );

    var source =
      text(
        workspace &&
        workspace.getAttribute(
          "data-phase28-r177n107-source"
        )
      );

    if (
      source ===
      "customer-clone-shell-r177n107"
    ) {
      return false;
    }

    if (
      source ===
      "admin-sodim-r177n94"
    ) {
      return true;
    }

    return false;
  }

  function isAdminPage(schema) {
    if (adminByWorkspace(schema)) {
      return true;
    }

    var path =
      String(
        window.location.pathname || ""
      ).toLowerCase();

    if (
      path.indexOf("/admin") !== -1
    ) {
      return true;
    }

    try {
      var role =
        String(
          window.localStorage.getItem(
            "iqfanda_role"
          ) || ""
        ).toLowerCase();

      if (
        role.indexOf("admin") !== -1
      ) {
        return true;
      }
    } catch (error) {}

    var buttons =
      Array.from(
        document.querySelectorAll(
          "button,a"
        )
      );

    return buttons.some(function (node) {
      var value =
        compact(
          node.textContent || ""
        );

      return (
        value.indexOf(
          "zpetnakartuklienta"
        ) !== -1
      );
    });
  }

  function ensureStyle() {
    if (
      document.getElementById(
        STYLE_ID
      )
    ) {
      return;
    }

    var style =
      document.createElement(
        "style"
      );

    style.id = STYLE_ID;

    style.textContent = [
      ".f33-r19-boiler-temp-picker{margin-top:8px;padding:7px;border:1px solid rgba(72,216,255,.38);border-radius:9px;background:rgba(2,22,34,.90);display:grid;gap:5px;position:relative;z-index:9;width:100%;box-sizing:border-box}",
      ".f33-r19-boiler-temp-picker label{display:grid;gap:4px;color:#d9f5ff;font-size:9px;font-weight:900;letter-spacing:.04em;text-transform:uppercase}",
      ".f33-r19-boiler-temp-picker select{width:100%;min-width:0;height:29px;border-radius:7px;border:1px solid rgba(124,221,255,.42);background:#061b28;color:#f1fbff;padding:2px 6px;font-size:10px}",
      ".f33-r19-boiler-temp-picker .f33-r19-actions{display:flex;align-items:center;gap:6px}",
      ".f33-r19-boiler-temp-picker button{height:28px;padding:0 10px;border-radius:7px;border:1px solid rgba(72,216,255,.62);background:#0b4054;color:#fff;font-size:9px;font-weight:900;cursor:pointer}",
      ".f33-r19-boiler-temp-picker small{font-size:8px;line-height:1.2;color:#9dc8d7}",
      ".f33-r19-boiler-temp-picker .f33-r19-status[data-error='1']{color:#ffaaaa}",
      ".f33-r19-boiler-temp-picker .f33-r19-status[data-error='0']{color:#78efb3}"
    ].join("\n");

    document.head.appendChild(
      style
    );
  }

  function zigbeeTemperature(
    option
  ) {
    if (
      !option ||
      typeof option !== "object"
    ) {
      return false;
    }

    var transport =
      text(
        option.transport
      ).toLowerCase();

    if (
      transport !== "zigbee" &&
      transport !== "zha"
    ) {
      return false;
    }

    var capability =
      text(
        option.capability
      ).toLowerCase();

    var capabilities =
      Array.isArray(
        option.capabilities
      )
        ? option.capabilities.map(
            function (item) {
              return text(item)
                .toLowerCase();
            }
          )
        : [];

    return (
      capability === "temperature" ||
      capabilities.indexOf(
        "temperature"
      ) !== -1
    );
  }

  function signature(option) {
    if (!option) return "";

    return [
      text(option.transport),
      text(option.device_id),
      text(option.entity_id),
      text(option.path)
    ].join("|");
  }

  function optionText(option) {
    var device =
      text(
        option.device_name
      ) || "Zigbee zařízení";

    var entity =
      text(
        option.entity_name
      ) ||
      text(
        option.label
      ) ||
      text(
        option.entity_id
      ) ||
      "Teplota";

    return (
      device +
      " → " +
      entity
    );
  }

  function selectedOption(
    options,
    binding
  ) {
    if (!binding) return null;

    var bindingEntity =
      text(
        binding.entity_id
      );

    var bindingDevice =
      text(
        binding.device_id
      );

    var bindingPath =
      text(
        binding.path
      );

    return (
      options.find(
        function (option) {
          if (
            bindingEntity &&
            text(
              option.entity_id
            ) === bindingEntity
          ) {
            return true;
          }

          if (
            bindingPath &&
            text(
              option.path
            ) === bindingPath
          ) {
            return true;
          }

          return (
            bindingDevice &&
            text(
              option.device_id
            ) === bindingDevice &&
            text(
              option.capability
            ).toLowerCase()
              === "temperature"
          );
        }
      ) ||
      null
    );
  }

  function setStatus(
    picker,
    message,
    error
  ) {
    var status =
      picker.querySelector(
        ".f33-r19-status"
      );

    if (!status) return;

    status.textContent =
      message || "";

    status.setAttribute(
      "data-error",
      error ? "1" : "0"
    );
  }

  async function loadData() {
    var data =
      await fetchJson(
        API_BASE_URL + "/api/v1/admin/devices/" +
        encodeURIComponent(
          DEVICE_UUID
        ) +
        "/individual-project/schema-entity-options?capability=temperature"
      );

    var options =
      (
        Array.isArray(
          data && data.options
        )
          ? data.options
          : []
      ).filter(
        zigbeeTemperature
      );

    var bindings =
      (
        data &&
        typeof data.bindings === "object" &&
        data.bindings
      )
        ? data.bindings
        : {};

    return {
      options: options,
      binding:
        bindings[
          ELEMENT_KEY
        ] || null
    };
  }

  async function saveBinding(
    picker,
    option
  ) {
    setStatus(
      picker,
      "Ukládám vazbu…",
      false
    );

    var result =
      await fetchJson(
        API_BASE_URL + "/api/v1/admin/devices/" +
        encodeURIComponent(
          DEVICE_UUID
        ) +
        "/individual-project/schema-entity-bindings/" +
        encodeURIComponent(
          ELEMENT_KEY
        ),
        {
          method: "PUT",
          body: JSON.stringify({
            capability:
              "temperature",
            entity: option
          })
        }
      );

    setStatus(
      picker,
      "Vazba uložena. SEB-01B zobrazí živou hodnotu.",
      false
    );

    picker.setAttribute(
      "data-f33-r19-saved-entity-id",
      text(
        result &&
        result.binding &&
        result.binding.entity_id
      )
    );

    return result;
  }

  function createPicker(
    boiler,
    data
  ) {
    var schema =
      findSchema();

    if (!schema) return;

    if (
      !isAdminPage(schema)
    ) {
      boiler
        .querySelectorAll(
          "." + PICKER_CLASS
        )
        .forEach(
          function (node) {
            node.remove();
          }
        );

      return;
    }

    ensureStyle();

    var target =
      findTemperatureTarget(
        boiler
      );

    if (!target) return;

    var picker =
      target.querySelector(
        "." + PICKER_CLASS
      );

    if (!picker) {
      picker =
        document.createElement(
          "div"
        );

      picker.className =
        PICKER_CLASS;

      picker.setAttribute(
        "data-f33-r19",
        "proven-seb01-boiler-temperature"
      );

      picker.innerHTML =
        '<label>Zdroj teploty bojleru' +
        '<select data-f33-r19-select>' +
        '<option value="">— vyber Zigbee zařízení / teplotu —</option>' +
        '</select></label>' +
        '<div class="f33-r19-actions">' +
        '<button type="button" data-f33-r19-save>Uložit</button>' +
        '<button type="button" data-f33-r19-reload>Obnovit</button>' +
        '</div>' +
        '<small>SEB-01 · pouze Zigbee entity typu Teplota</small>' +
        '<small class="f33-r19-status" data-error="0"></small>';

      target.appendChild(
        picker
      );
    }

    var select =
      picker.querySelector(
        "[data-f33-r19-select]"
      );

    var save =
      picker.querySelector(
        "[data-f33-r19-save]"
      );

    var reload =
      picker.querySelector(
        "[data-f33-r19-reload]"
      );

    select.innerHTML = "";

    var empty =
      document.createElement(
        "option"
      );

    empty.value = "";
    empty.textContent =
      data.options.length
        ? "— vyber Zigbee zařízení / teplotu —"
        : "— žádná Zigbee teplota —";

    select.appendChild(
      empty
    );

    data.options.forEach(
      function (option) {
        var node =
          document.createElement(
            "option"
          );

        node.value =
          signature(option);

        node.textContent =
          optionText(option);

        node._sebOption =
          option;

        select.appendChild(
          node
        );
      }
    );

    var selected =
      selectedOption(
        data.options,
        data.binding
      );

    if (selected) {
      select.value =
        signature(selected);

      setStatus(
        picker,
        "Aktuální vazba: " +
        optionText(selected),
        false
      );
    } else {
      setStatus(
        picker,
        "Načteno Zigbee teplot: " +
        data.options.length,
        false
      );
    }

    save.onclick =
      async function (event) {
        event.preventDefault();
        event.stopPropagation();

        var chosenNode =
          select.options[
            select.selectedIndex
          ];

        var chosen =
          chosenNode &&
          chosenNode._sebOption;

        if (!chosen) {
          setStatus(
            picker,
            "Nejdřív vyber Zigbee teplotu.",
            true
          );
          return;
        }

        save.disabled =
          true;

        try {
          await saveBinding(
            picker,
            chosen
          );
        } catch (error) {
          setStatus(
            picker,
            "Uložení selhalo: " +
            error.message,
            true
          );
        } finally {
          save.disabled =
            false;
        }
      };

    reload.onclick =
      function (event) {
        event.preventDefault();
        event.stopPropagation();
        schedule(true);
      };
  }

  async function update(force) {
    var schema =
      findSchema();

    if (!schema) return;

    var boiler =
      findBoilerCard(
        schema
      );

    if (!boiler) return;

    var now =
      Date.now();

    if (
      !force &&
      now - lastRender < 5000 &&
      boiler.querySelector(
        "." + PICKER_CLASS
      )
    ) {
      return;
    }

    if (busy) return;

    busy = true;

    try {
      var data =
        await loadData();

      createPicker(
        boiler,
        data
      );

      lastRender =
        Date.now();
    } catch (error) {
      var picker =
        boiler.querySelector(
          "." + PICKER_CLASS
        );

      if (picker) {
        setStatus(
          picker,
          "SEB-01 načtení selhalo: " +
          error.message,
          true
        );
      }

      console.error(
        "F33.R19 SEB-01 picker failed:",
        error
      );
    } finally {
      busy = false;
    }
  }

  function schedule(force) {
    update(
      !!force
    ).catch(
      function (error) {
        console.error(
          "F33.R19 update failed:",
          error
        );
      }
    );
  }

  if (
    document.readyState
    === "loading"
  ) {
    document.addEventListener(
      "DOMContentLoaded",
      function () {
        schedule(true);
      }
    );
  } else {
    schedule(true);
  }

  /*
   * This is intentionally the same durable lifecycle strategy
   * as the proven F30.2J selector on model 00012:
   * observe SPA DOM replacement and periodically restore the
   * admin-only picker if React recreated the workspace.
   * It does NOT read telemetry values; SEB-01B owns values.
   */
  var observer =
    new MutationObserver(
      function () {
        schedule(false);
      }
    );

  observer.observe(
    document.documentElement ||
    document.body,
    {
      childList: true,
      subtree: true
    }
  );

  window.setInterval(
    function () {
      if (findSchema()) {
        schedule(true);
      }
    },
    15000
  );
})();
