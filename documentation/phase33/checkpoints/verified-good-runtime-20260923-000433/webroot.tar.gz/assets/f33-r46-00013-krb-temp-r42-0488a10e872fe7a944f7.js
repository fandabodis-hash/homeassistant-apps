/* F33.R44: UUID 00013 only. Proven SEB-01B/R41 lifecycle applied to fireplace.
 * One lifecycle adapter owns the 00013 fireplace DOM. Server binding keys stay:
 *   bivalence-temperature
 *   bivalence-state
 * The adapter ID below is local renderer identity only.
 */
(function () {
  "use strict";

  const VERSION = "F33.R46-00013-FIREPLACE-TEMP-R42-PAINT";
  const TARGET = "014a0d23-d440-4131-abb4-28a860595043";
  const TEMP_SLOT = "bivalence-temperature";
  const STATE_SLOT = "bivalence-state";
  const DISPLAY_ADAPTER = "f33-r44-00013-fireplace-display-lifecycle";
  const API_BASE = "https://api.tngiqfanda.cz";
  const ROOT =
    '[data-phase28-r177n107-workspace="universal-individual-admin-client-clone"]' +
    '[data-f33-r34-current-device-uuid="' + TARGET + '"]';

  const PANEL_CLASS = "f33-r44-fireplace-panel";
  const R = window.IQF_SEB01_RUNTIME;

  if (window.IQF_SEB01_00013_FIREPLACE_R46) return;

  if (
    !R ||
    R.version !== "F30.4C-R5-PERSISTED-READER" ||
    typeof R.registerAdapter !== "function" ||
    typeof R.diagnostics !== "function"
  ) {
    console.error(VERSION, "SHARED_RUNTIME_UNAVAILABLE");
    return;
  }

  let active = null;

  const text = (value) =>
    value === null || value === undefined ? "" : String(value).trim();

  const normId = (value) =>
    text(value).toLowerCase().replace(/[:-]/g, "");

  const putText = (node, value) => {
    if (node && node.textContent !== value) node.textContent = value;
  };

  const errorCode = (error) => {
    const message = text(error && error.message);
    return /^[A-Z][A-Z0-9_]*$/.test(message)
      ? message
      : "REQUEST_OR_RENDER_FAILED";
  };

  const diagnostic = {
    version: VERSION,
    target: TARGET,
    phase: "WAITING_FOR_WORKSPACE",
    tempCatalogueCount: 0,
    switchCatalogueCount: 0,
    tempSavedEntity: "",
    switchSavedEntity: "",
    tempDisplayed: "",
    stateDisplayed: "",
    error: "",
    paintCount: 0,
  };

  function snapshot() {
    const state = R.diagnostics();

    return {
      deviceUuid: text(state.deviceUuid).toLowerCase(),
      admin: state.admin === true,
      error: text(state.error),
    };
  }

  function isAdminRoot(root) {
    return Boolean(
      root &&
      root.getAttribute("data-phase28-r177n107-source") ===
        "admin-sodim-r177n94"
    );
  }

  function visible(node) {
    if (
      !node ||
      !node.isConnected ||
      !node.getClientRects().length
    ) {
      return false;
    }

    const style = window.getComputedStyle(node);

    return (
      style.display !== "none" &&
      style.visibility !== "hidden"
    );
  }

  function currentRoot() {
    const roots = Array.from(
      document.querySelectorAll(ROOT)
    ).filter(visible);

    return roots.length === 1 ? roots[0] : null;
  }

  function findCard(root) {
    if (!root) return null;

    return root.querySelector(
      ".f29-00012-bivalence," +
      ".f29-00012-bivalence-tuv," +
      ".f29-00012-bivalence-card"
    );
  }

  function findRowByLabel(card, pattern) {
    if (!card) return null;

    const rows = Array.from(
      card.querySelectorAll(".f29-00012-kv")
    );

    for (const row of rows) {
      const label = row.querySelector("span");
      if (label && pattern.test(text(label.textContent))) {
        return row;
      }
    }

    return null;
  }

  function findTemperatureBox(card) {
    if (!card) return null;

    /*
     * Exact proven Bivalence DOM from F30.03B:
     * phase30-00012-bivalence-add-temperature-v2 creates
     * data-f30-03a-r2="temperature".
     *
     * This is the important difference from BOJLER/AKU rows.
     */
    return (
      card.querySelector(
        '[data-f30-03a-r2="temperature"]'
      ) ||
      card.querySelector(
        '[data-f30-schema-element-key="' +
          TEMP_SLOT +
          '"]'
      ) ||
      findRowByLabel(card, /^teplota$/i)
    );
  }

  function findStateBox(card) {
    if (!card) return null;

    return (
      card.querySelector(
        '[data-f30-schema-element-key="' +
          STATE_SLOT +
          '"]'
      ) ||
      findRowByLabel(card, /stav\s*zap\s*\/?\s*vyp/i) ||
      findRowByLabel(card, /^stav/i)
    );
  }

  function clearActive() {
    if (!active) return;

    const old = active;
    active = null;
    old.disposed = true;

    old.controllers.forEach((controller) =>
      controller.abort()
    );
    old.controllers.clear();

    if (old.panel) old.panel.remove();

    diagnostic.tempCatalogueCount = 0;
    diagnostic.switchCatalogueCount = 0;
    diagnostic.tempSavedEntity = "";
    diagnostic.switchSavedEntity = "";
  }

  function locateLifecycle() {
    const root = currentRoot();
    const card = findCard(root);

    if (!root || !card) {
      clearActive();
      diagnostic.phase = root
        ? "WAITING_FOR_FIREPLACE_CARD"
        : "WAITING_FOR_WORKSPACE";
      return null;
    }

    const admin = isAdminRoot(root);

    if (
      active &&
      (
        active.root !== root ||
        active.card !== card ||
        active.admin !== admin
      )
    ) {
      clearActive();
    }

    if (!active) {
      active = {
        root,
        card,
        admin,
        disposed: false,
        controllers: new Set(),
        panel: null,
        token: null,

        tempBox: null,
        stateBox: null,
        title: null,

        tempOptions: [],
        tempByKey: new Map(),
        tempBinding: null,
        tempLoadState: "idle",
        tempLoadError: "",
        tempSaving: false,
        tempSaveMessage: "",

        switchOptions: [],
        switchByKey: new Map(),
        switchBinding: null,
        switchLoadState: "idle",
        switchLoadError: "",
        switchSaving: false,
        switchSaveMessage: "",
      };
    }

    active.title =
      card.querySelector(":scope > h3") ||
      card.querySelector("h3");

    active.tempBox = findTemperatureBox(card);
    active.stateBox = findStateBox(card);

    /*
     * IMPORTANT R44 contract:
     * shared R5 requires target.card AND target.box.
     * The whole card is the stable lifecycle anchor; individual value
     * rows are located inside paintLifecycle().
     */
    return {
      card,
      box: card,
    };
  }

  function ensureTitle(state) {
    if (state && state.title) {
      putText(state.title, "KRB S VÝMĚNÍKEM");
    }
  }

  function valueTextNode(box, kind) {
    if (!box) return null;

    /*
     * Exact proven Bivalence temperature value node from F30.03B.
     * If it exists, use it before any generic scan.
     */
    if (kind === "temperature") {
      const proven =
        box.querySelector(
          ".f30-03a-r2-temp-value"
        );

      if (proven) return proven;
    }

    /*
     * Then use the R42 AKU principle: resolve the existing value node,
     * do not create a second value element.
     */
    const strong = box.querySelector("strong");
    if (strong) return strong;

    const walker = document.createTreeWalker(
      box,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const parent = node.parentElement;

          if (
            !parent ||
            parent.closest(
              "." + PANEL_CLASS +
              ",select,option,button,label"
            )
          ) {
            return NodeFilter.FILTER_REJECT;
          }

          const value = text(node.nodeValue);

          if (!value) return NodeFilter.FILTER_REJECT;

          if (kind === "temperature") {
            if (/teplota/i.test(value)) {
              return NodeFilter.FILTER_REJECT;
            }

            return (
              /°[CF]|\u2014/.test(value) ||
              value === "-" ||
              /^[+-]?\d+(?:[,.]\d+)?$/.test(value)
            )
              ? NodeFilter.FILTER_ACCEPT
              : NodeFilter.FILTER_REJECT;
          }

          if (/stav/i.test(value)) {
            return NodeFilter.FILTER_REJECT;
          }

          return (
            value === "-" ||
            value === "\u2014" ||
            /zapnuto|vypnuto|nedostupn/i.test(value)
          )
            ? NodeFilter.FILTER_ACCEPT
            : NodeFilter.FILTER_REJECT;
        },
      }
    );

    return walker.nextNode();
  }

  function stateRaw(entry) {
    if (!entry || typeof entry !== "object") {
      return null;
    }

    if (entry.has_value === false) {
      return null;
    }

    if (
      entry.value !== undefined &&
      entry.value !== null
    ) {
      return entry.value;
    }

    if (
      entry.state !== undefined &&
      entry.state !== null
    ) {
      return entry.state;
    }

    return null;
  }

  function renderState(entry) {
    const status = text(
      entry && entry.status
    ).toLowerCase();

    if (
      status === "unavailable" ||
      status === "offline"
    ) {
      return "nedostupné";
    }

    const raw = stateRaw(entry);

    if (raw === true || raw === 1) {
      return "zapnuto";
    }

    if (raw === false || raw === 0) {
      return "vypnuto";
    }

    const value = text(raw).toLowerCase();

    if (
      [
        "1",
        "true",
        "on",
        "running",
        "active",
        "enabled",
        "open",
        "zapnuto",
      ].includes(value)
    ) {
      return "zapnuto";
    }

    if (
      [
        "0",
        "false",
        "off",
        "stopped",
        "inactive",
        "disabled",
        "closed",
        "vypnuto",
      ].includes(value)
    ) {
      return "vypnuto";
    }

    return value ? text(raw) : "\u2014";
  }

  function ensureStyle() {
    if (
      document.getElementById(
        "f33-r44-fireplace-style"
      )
    ) {
      return;
    }

    const style =
      document.createElement("style");

    style.id =
      "f33-r44-fireplace-style";

    style.textContent =
      ROOT + " ." + PANEL_CLASS +
      "{margin-top:.55rem;padding:.6rem;border:1px solid rgba(93,203,255,.38);border-radius:12px;background:rgba(2,22,34,.96);display:grid;gap:.5rem;max-width:100%;min-width:0;box-sizing:border-box;position:relative;z-index:4}" +
      ROOT + " ." + PANEL_CLASS +
      " .section{display:grid;gap:.32rem}" +
      ROOT + " ." + PANEL_CLASS +
      " .section-title{font-size:.7rem;font-weight:900;color:#d9f5ff}" +
      ROOT + " ." + PANEL_CLASS +
      " label{display:grid;gap:.25rem;color:#d9f5ff;font-size:.67rem;font-weight:800}" +
      ROOT + " ." + PANEL_CLASS +
      " select{width:100%;min-width:0;min-height:34px;border-radius:8px;border:1px solid rgba(124,221,255,.42);background:#061b28;color:#f1fbff;padding:.35rem;font-size:.71rem}" +
      ROOT + " ." + PANEL_CLASS +
      " .actions{display:flex;flex-wrap:wrap;gap:.35rem}" +
      ROOT + " ." + PANEL_CLASS +
      " button{border:1px solid rgba(124,221,255,.55);background:rgba(34,184,255,.20);color:#e7fbff;border-radius:8px;padding:.35rem .55rem;font-weight:800;font-size:.68rem;cursor:pointer}" +
      ROOT + " ." + PANEL_CLASS +
      " button:disabled{opacity:.5;cursor:not-allowed}" +
      ROOT + " ." + PANEL_CLASS +
      " small{font-size:.64rem;line-height:1.25;overflow-wrap:anywhere;color:#b9dae6}" +
      ROOT + " ." + PANEL_CLASS +
      " [data-error=true]{color:#ffd47a}";

    document.head.appendChild(style);
  }

  function make(tag, content, className) {
    const node = document.createElement(tag);

    if (content) node.textContent = content;
    if (className) node.className = className;

    return node;
  }

  function createSelectorSection(
    title,
    aria,
    emptyText
  ) {
    const section =
      make("div", "", "section");

    section.appendChild(
      make(
        "div",
        title,
        "section-title"
      )
    );

    const label =
      make("label", aria);

    const select =
      make("select");

    select.setAttribute(
      "aria-label",
      aria
    );

    const empty =
      make("option", emptyText);

    empty.value = "";
    select.appendChild(empty);
    select.disabled = true;

    label.appendChild(select);
    section.appendChild(label);

    const actions =
      make("div", "", "actions");

    const save =
      make("button", "Uložit");

    save.type = "button";
    save.disabled = true;

    const reload =
      make(
        "button",
        "Obnovit seznam"
      );

    reload.type = "button";

    actions.append(
      save,
      reload
    );

    section.appendChild(actions);

    const status =
      make("small", "Čekám na kontext modelu 00013.");

    status.setAttribute(
      "role",
      "status"
    );

    section.appendChild(status);

    return {
      section,
      select,
      save,
      reload,
      status,
    };
  }

  function ensurePanel(state) {
    if (!state.admin) return;

    if (
      state.panel &&
      state.panel.isConnected &&
      state.card.contains(state.panel)
    ) {
      return;
    }

    ensureStyle();

    const panel =
      make("div", "", PANEL_CLASS);

    panel.setAttribute(
      "data-f33-r44-fireplace",
      "00013"
    );

    const temp =
      createSelectorSection(
        "Teplotní entita krbu — 00013",
        "Zigbee teplotní entita modelu 00013",
        "Čekám na katalog teplotních entit…"
      );

    const sw =
      createSelectorSection(
        "Spínací zařízení krbu — 00013",
        "Zigbee spínací zařízení modelu 00013",
        "Čekám na katalog spínacích entit…"
      );

    const diagnosticActions =
      make("div", "", "actions");

    const diagnosticButton =
      make("button", "Diagnostika");

    diagnosticButton.type = "button";
    diagnosticActions.appendChild(
      diagnosticButton
    );

    panel.append(
      temp.section,
      sw.section,
      diagnosticActions
    );

    state.card.appendChild(panel);

    Object.assign(state, {
      panel,

      tempSelect: temp.select,
      tempSave: temp.save,
      tempReload: temp.reload,
      tempStatus: temp.status,

      switchSelect: sw.select,
      switchSave: sw.save,
      switchReload: sw.reload,
      switchStatus: sw.status,
    });

    state.tempSelect.addEventListener(
      "change",
      () => {
        state.tempSaveMessage =
          "Výběr teploty není uložený. Potvrďte tlačítkem Uložit.";
        updatePanel(state);
      }
    );

    state.switchSelect.addEventListener(
      "change",
      () => {
        state.switchSaveMessage =
          "Výběr spínacího zařízení není uložený. Potvrďte tlačítkem Uložit.";
        updatePanel(state);
      }
    );

    state.tempSave.addEventListener(
      "click",
      () => {
        void saveTemperature(state);
      }
    );

    state.switchSave.addEventListener(
      "click",
      () => {
        void saveSwitch(state);
      }
    );

    state.tempReload.addEventListener(
      "click",
      () => {
        if (!state.tempSaving) {
          state.tempSaveMessage = "";
          void loadTemperatureCatalogue(
            state
          );
        }
      }
    );

    state.switchReload.addEventListener(
      "click",
      () => {
        if (!state.switchSaving) {
          state.switchSaveMessage = "";
          void loadSwitchCatalogue(
            state
          );
        }
      }
    );

    diagnosticButton.addEventListener(
      "click",
      downloadDiagnostics
    );
  }

  function readToken() {
    try {
      return text(
        window.localStorage.getItem(
          "iqfanda_access_token"
        )
      ).replace(
        /^Bearer\s+/i,
        ""
      );
    } catch (_) {
      return "";
    }
  }

  function writable(state) {
    if (
      !state ||
      state.disposed ||
      active !== state ||
      currentRoot() !== state.root ||
      !isAdminRoot(state.root)
    ) {
      return false;
    }

    const current = snapshot();

    return (
      current.deviceUuid === TARGET &&
      current.admin === true
    );
  }

  function assertWritable(state) {
    if (!writable(state)) {
      throw new Error(
        "CURRENT_ADMIN_CONTEXT_REQUIRED"
      );
    }

    const token = readToken();

    if (!token) {
      throw new Error(
        "SESSION_TOKEN_MISSING"
      );
    }

    return token;
  }

  async function request(
    state,
    suffix,
    method,
    body
  ) {
    const token =
      assertWritable(state);

    const controller =
      new AbortController();

    state.controllers.add(
      controller
    );

    const timeout =
      window.setTimeout(
        () => controller.abort(),
        8000
      );

    try {
      const response =
        await fetch(
          API_BASE +
          "/api/v1/admin/devices/" +
          TARGET +
          "/individual-project/" +
          suffix,
          {
            method: method || "GET",
            cache: "no-store",
            redirect: "error",
            credentials: "same-origin",
            signal: controller.signal,
            headers: {
              Accept: "application/json",
              Authorization:
                "Bearer " + token,
              ...(body
                ? {
                    "Content-Type":
                      "application/json",
                  }
                : {}),
            },
            ...(body
              ? {
                  body:
                    JSON.stringify(body),
                }
              : {}),
          }
        );

      if (
        !writable(state) ||
        readToken() !== token
      ) {
        throw new Error(
          "CONTEXT_CHANGED"
        );
      }

      if (!response.ok) {
        throw new Error(
          "HTTP_" + response.status
        );
      }

      const contentType =
        response.headers.get(
          "content-type"
        ) || "";

      if (
        !/application\/(?:[\w.-]+\+)?json\b/i.test(
          contentType
        )
      ) {
        throw new Error(
          "NON_JSON_RESPONSE"
        );
      }

      const data =
        await response.json();

      if (
        !writable(state) ||
        readToken() !== token
      ) {
        throw new Error(
          "CONTEXT_CHANGED"
        );
      }

      if (
        !data ||
        Array.isArray(data) ||
        text(data.device_uuid).toLowerCase() !==
          TARGET
      ) {
        throw new Error(
          "WRONG_DEVICE_RESPONSE"
        );
      }

      return data;
    } finally {
      window.clearTimeout(timeout);
      state.controllers.delete(
        controller
      );
    }
  }

  function entityKey(option) {
    return JSON.stringify([
      TARGET,
      text(option.transport).toLowerCase(),
      normId(
        option.ieee ||
        option.device_id
      ),
      text(option.entity_id),
    ]);
  }

  function sameEntity(
    binding,
    option
  ) {
    return Boolean(
      binding &&
      option &&
      text(binding.entity_id) ===
        text(option.entity_id) &&
      text(binding.transport).toLowerCase() ===
        text(option.transport).toLowerCase() &&
      R.matchIdentity(
        binding,
        [option]
      )
    );
  }

  function label(option, digits) {
    const name = [
      text(option.device_name) ||
        "Nepojmenované Zigbee zařízení",
      text(option.entity_name),
    ]
      .filter(Boolean)
      .join(" → ");

    const live =
      option.has_value === true
        ? " | katalog: " +
          R.format(
            option,
            option.unit,
            digits
          )
        : "";

    return (
      name +
      " [" +
      text(option.entity_id) +
      "]" +
      (option.unit
        ? " · " + text(option.unit)
        : "") +
      live
    );
  }

  function validateEnvelope(data) {
    if (
      !Array.isArray(data.options) ||
      !data.bindings ||
      Array.isArray(data.bindings) ||
      typeof data.bindings !== "object"
    ) {
      throw new Error(
        "CATALOGUE_SHAPE"
      );
    }

    if (data.has_more === true) {
      throw new Error(
        "CATALOGUE_PAGINATION_NOT_COMPLETE"
      );
    }
  }

  function validateTemperatureCatalogue(
    data
  ) {
    validateEnvelope(data);

    const options = [];
    const seen = new Set();

    for (const option of data.options) {
      if (
        !option ||
        typeof option !== "object" ||
        text(option.transport).toLowerCase() !==
          "zigbee"
      ) {
        continue;
      }

      const caps =
        Array.isArray(
          option.capabilities
        )
          ? option.capabilities.map(
              (value) =>
                text(value).toLowerCase()
            )
          : [];

      if (
        text(option.capability).toLowerCase() !==
          "temperature" &&
        !caps.includes("temperature")
      ) {
        continue;
      }

      if (
        !text(option.entity_id).startsWith(
          "sensor."
        )
      ) {
        continue;
      }

      if (
        text(option.source_device_uuid) &&
        text(
          option.source_device_uuid
        ).toLowerCase() !== TARGET
      ) {
        throw new Error(
          "FOREIGN_SOURCE_IN_TEMPERATURE_CATALOGUE"
        );
      }

      if (
        !normId(
          option.ieee ||
          option.device_id
        )
      ) {
        throw new Error(
          "TEMPERATURE_HARDWARE_IDENTITY_MISSING"
        );
      }

      const key =
        entityKey(option);

      if (seen.has(key)) {
        throw new Error(
          "DUPLICATE_TEMPERATURE_ENTITY"
        );
      }

      seen.add(key);
      options.push(option);
    }

    return {
      options,
      binding:
        data.bindings[TEMP_SLOT] ||
        null,
    };
  }

  function validateSwitchCatalogue(data) {
    validateEnvelope(data);

    const options = [];
    const seen = new Set();

    for (const option of data.options) {
      if (
        !option ||
        typeof option !== "object" ||
        text(option.transport).toLowerCase() !==
          "zigbee"
      ) {
        continue;
      }

      if (
        !text(option.entity_id).startsWith(
          "switch."
        )
      ) {
        continue;
      }

      if (
        text(option.source_device_uuid) &&
        text(
          option.source_device_uuid
        ).toLowerCase() !== TARGET
      ) {
        throw new Error(
          "FOREIGN_SOURCE_IN_SWITCH_CATALOGUE"
        );
      }

      if (
        !normId(
          option.ieee ||
          option.device_id
        )
      ) {
        throw new Error(
          "SWITCH_HARDWARE_IDENTITY_MISSING"
        );
      }

      const key =
        entityKey(option);

      if (seen.has(key)) {
        throw new Error(
          "DUPLICATE_SWITCH_ENTITY"
        );
      }

      seen.add(key);
      options.push(option);
    }

    return {
      options,
      binding:
        data.bindings[STATE_SLOT] ||
        null,
    };
  }

  async function fetchTemperatureCatalogue(
    state
  ) {
    return validateTemperatureCatalogue(
      await request(
        state,
        "schema-entity-options?capability=temperature"
      )
    );
  }

  async function fetchSwitchCatalogue(
    state
  ) {
    return validateSwitchCatalogue(
      await request(
        state,
        "schema-entity-options?capability=switch"
      )
    );
  }

  function fillOptions(
    select,
    map,
    options,
    binding,
    preserve,
    emptyText,
    digits
  ) {
    if (!select) return;

    const nodes = [];
    const empty =
      make("option", emptyText);

    empty.value = "";
    nodes.push(empty);

    map.clear();

    for (const option of options) {
      const key =
        entityKey(option);

      const node =
        make(
          "option",
          label(option, digits)
        );

      node.value = key;
      map.set(key, option);
      nodes.push(node);
    }

    select.replaceChildren(
      ...nodes
    );

    const saved =
      options.find((option) =>
        sameEntity(
          binding,
          option
        )
      );

    select.value =
      map.has(preserve)
        ? preserve
        : saved
          ? entityKey(saved)
          : "";
  }

  function acceptTemperature(
    state,
    data,
    preserve
  ) {
    state.tempOptions =
      data.options;

    state.tempBinding =
      data.binding;

    state.tempLoadState =
      "ready";

    state.tempLoadError = "";

    diagnostic.tempCatalogueCount =
      state.tempOptions.length;

    diagnostic.tempSavedEntity =
      text(
        state.tempBinding &&
        state.tempBinding.entity_id
      );

    fillOptions(
      state.tempSelect,
      state.tempByKey,
      state.tempOptions,
      state.tempBinding,
      preserve,
      "Vyberte teplotní entitu…",
      1
    );
  }

  function acceptSwitch(
    state,
    data,
    preserve
  ) {
    state.switchOptions =
      data.options;

    state.switchBinding =
      data.binding;

    state.switchLoadState =
      "ready";

    state.switchLoadError = "";

    diagnostic.switchCatalogueCount =
      state.switchOptions.length;

    diagnostic.switchSavedEntity =
      text(
        state.switchBinding &&
        state.switchBinding.entity_id
      );

    fillOptions(
      state.switchSelect,
      state.switchByKey,
      state.switchOptions,
      state.switchBinding,
      preserve,
      "Vyberte spínací zařízení…",
      0
    );
  }

  async function loadTemperatureCatalogue(
    state
  ) {
    if (
      state.tempLoadState === "loading" ||
      state.tempSaving
    ) {
      return;
    }

    try {
      state.token =
        assertWritable(state);

      state.tempLoadState =
        "loading";

      state.tempLoadError = "";
      updatePanel(state);

      const preserve =
        state.tempSelect
          ? state.tempSelect.value
          : "";

      const data =
        await fetchTemperatureCatalogue(
          state
        );

      if (
        active !== state ||
        state.disposed
      ) {
        return;
      }

      acceptTemperature(
        state,
        data,
        preserve
      );
    } catch (error) {
      if (
        active === state &&
        !state.disposed
      ) {
        state.tempLoadState =
          "failed";

        state.tempLoadError =
          errorCode(error);

        diagnostic.error =
          state.tempLoadError;
      }
    } finally {
      if (
        active === state &&
        !state.disposed
      ) {
        updatePanel(state);
      }
    }
  }

  async function loadSwitchCatalogue(
    state
  ) {
    if (
      state.switchLoadState === "loading" ||
      state.switchSaving
    ) {
      return;
    }

    try {
      state.token =
        assertWritable(state);

      state.switchLoadState =
        "loading";

      state.switchLoadError = "";
      updatePanel(state);

      const preserve =
        state.switchSelect
          ? state.switchSelect.value
          : "";

      const data =
        await fetchSwitchCatalogue(
          state
        );

      if (
        active !== state ||
        state.disposed
      ) {
        return;
      }

      acceptSwitch(
        state,
        data,
        preserve
      );
    } catch (error) {
      if (
        active === state &&
        !state.disposed
      ) {
        state.switchLoadState =
          "failed";

        state.switchLoadError =
          errorCode(error);

        diagnostic.error =
          state.switchLoadError;
      }
    } finally {
      if (
        active === state &&
        !state.disposed
      ) {
        updatePanel(state);
      }
    }
  }

  function confirmedBinding(
    binding,
    option
  ) {
    return Boolean(
      binding &&
      text(
        binding.source_device_uuid
      ).toLowerCase() === TARGET &&
      binding
        .verified_against_current_options ===
        true &&
      sameEntity(
        binding,
        option
      )
    );
  }

  async function saveTemperature(
    state
  ) {
    if (
      state.tempSaving ||
      !state.tempSelect
    ) {
      return;
    }

    const chosen =
      state.tempByKey.get(
        state.tempSelect.value
      );

    if (!chosen) return;

    try {
      assertWritable(state);

      state.tempSaving = true;
      state.tempLoadError = "";
      state.tempSaveMessage =
        "Ukládám teplotní vazbu a ověřuji…";
      updatePanel(state);

      const fresh =
        await fetchTemperatureCatalogue(
          state
        );

      const exact =
        R.matchIdentity(
          chosen,
          fresh.options
        );

      if (!exact) {
        throw new Error(
          "TEMPERATURE_ENTITY_NO_LONGER_IN_CURRENT_CATALOGUE"
        );
      }

      const payload = {
        entity: {
          ...exact,
          source_device_uuid:
            TARGET,
        },
        capability:
          "temperature",
        source_device_uuid:
          TARGET,
      };

      const result =
        await request(
          state,
          "schema-entity-bindings/" +
            TEMP_SLOT,
          "PUT",
          payload
        );

      if (
        result.binding_persisted !==
          true ||
        !confirmedBinding(
          result.binding,
          exact
        )
      ) {
        throw new Error(
          "TEMPERATURE_BINDING_NOT_CONFIRMED"
        );
      }

      const readback =
        await fetchTemperatureCatalogue(
          state
        );

      if (
        !confirmedBinding(
          readback.binding,
          exact
        )
      ) {
        throw new Error(
          "TEMPERATURE_BINDING_READBACK_MISMATCH"
        );
      }

      acceptTemperature(
        state,
        readback,
        entityKey(exact)
      );

      state.tempSaveMessage =
        "Teplotní vazba uložena a ověřena pro 00013.";

      await R.refresh();
    } catch (error) {
      if (
        active === state &&
        !state.disposed
      ) {
        state.tempLoadError =
          errorCode(error);

        state.tempSaveMessage =
          "Uložení teploty nepotvrzeno: " +
          state.tempLoadError;

        diagnostic.error =
          state.tempLoadError;
      }
    } finally {
      if (
        active === state &&
        !state.disposed
      ) {
        state.tempSaving = false;
        updatePanel(state);
        paintLifecycle();
      }
    }
  }

  async function saveSwitch(
    state
  ) {
    if (
      state.switchSaving ||
      !state.switchSelect
    ) {
      return;
    }

    const chosen =
      state.switchByKey.get(
        state.switchSelect.value
      );

    if (!chosen) return;

    try {
      assertWritable(state);

      state.switchSaving = true;
      state.switchLoadError = "";
      state.switchSaveMessage =
        "Ukládám spínací vazbu a ověřuji…";
      updatePanel(state);

      const fresh =
        await fetchSwitchCatalogue(
          state
        );

      const exact =
        R.matchIdentity(
          chosen,
          fresh.options
        );

      if (!exact) {
        throw new Error(
          "SWITCH_ENTITY_NO_LONGER_IN_CURRENT_CATALOGUE"
        );
      }

      const payload = {
        entity: {
          ...exact,
          source_device_uuid:
            TARGET,
        },
        capability:
          "switch",
        source_device_uuid:
          TARGET,
      };

      const result =
        await request(
          state,
          "schema-entity-bindings/" +
            STATE_SLOT,
          "PUT",
          payload
        );

      if (
        result.binding_persisted !==
          true ||
        !confirmedBinding(
          result.binding,
          exact
        )
      ) {
        throw new Error(
          "SWITCH_BINDING_NOT_CONFIRMED"
        );
      }

      const readback =
        await fetchSwitchCatalogue(
          state
        );

      if (
        !confirmedBinding(
          readback.binding,
          exact
        )
      ) {
        throw new Error(
          "SWITCH_BINDING_READBACK_MISMATCH"
        );
      }

      acceptSwitch(
        state,
        readback,
        entityKey(exact)
      );

      state.switchSaveMessage =
        "Spínací vazba uložena a ověřena pro 00013.";

      await R.refresh();
    } catch (error) {
      if (
        active === state &&
        !state.disposed
      ) {
        state.switchLoadError =
          errorCode(error);

        state.switchSaveMessage =
          "Uložení spínací entity nepotvrzeno: " +
          state.switchLoadError;

        diagnostic.error =
          state.switchLoadError;
      }
    } finally {
      if (
        active === state &&
        !state.disposed
      ) {
        state.switchSaving = false;
        updatePanel(state);
        paintLifecycle();
      }
    }
  }

  function updatePanel(state) {
    if (
      !state.panel ||
      state.disposed ||
      active !== state
    ) {
      return;
    }

    const runtime = snapshot();
    const can = writable(state);
    const hasToken =
      can && Boolean(readToken());

    let tempMessage = "";
    let switchMessage = "";

    if (!can) {
      const message =
        "Čekám na vlastní administrátorský kontext 00013 (" +
        (runtime.deviceUuid ||
          "bez kontextu") +
        ").";

      tempMessage = message;
      switchMessage = message;
    } else if (!hasToken) {
      tempMessage =
        "Chybí přihlašovací relace.";
      switchMessage =
        "Chybí přihlašovací relace.";
    } else {
      if (
        state.tempLoadState ===
        "loading"
      ) {
        tempMessage =
          "Načítám Zigbee teplotní entity 00013…";
      } else if (
        state.tempLoadState ===
        "failed"
      ) {
        tempMessage =
          "Katalog teplot nelze načíst: " +
          state.tempLoadError +
          ".";
      } else if (
        state.tempSaveMessage
      ) {
        tempMessage =
          state.tempSaveMessage;
      } else if (
        state.tempLoadState ===
        "ready"
      ) {
        tempMessage =
          "Teplotní entity: " +
          state.tempOptions.length +
          ". " +
          (state.tempBinding
            ? "Uloženo: " +
              text(
                state.tempBinding.entity_id
              ) +
              "."
            : "Vyberte zdroj a potvrďte Uložit.");
      } else {
        tempMessage =
          "Čekám na katalog teplotních entit 00013.";
      }

      if (
        state.switchLoadState ===
        "loading"
      ) {
        switchMessage =
          "Načítám Zigbee spínací entity 00013…";
      } else if (
        state.switchLoadState ===
        "failed"
      ) {
        switchMessage =
          "Katalog spínacích entit nelze načíst: " +
          state.switchLoadError +
          ".";
      } else if (
        state.switchSaveMessage
      ) {
        switchMessage =
          state.switchSaveMessage;
      } else if (
        state.switchLoadState ===
        "ready"
      ) {
        switchMessage =
          "Spínací entity: " +
          state.switchOptions.length +
          ". " +
          (state.switchBinding
            ? "Uloženo: " +
              text(
                state.switchBinding.entity_id
              ) +
              "."
            : "Vyberte zařízení a potvrďte Uložit.");
      } else {
        switchMessage =
          "Čekám na katalog spínacích entit 00013.";
      }
    }

    putText(
      state.tempStatus,
      tempMessage
    );

    putText(
      state.switchStatus,
      switchMessage
    );

    state.tempStatus.setAttribute(
      "data-error",
      String(
        Boolean(
          state.tempLoadError
        )
      )
    );

    state.switchStatus.setAttribute(
      "data-error",
      String(
        Boolean(
          state.switchLoadError
        )
      )
    );

    state.tempSelect.disabled =
      !can ||
      !hasToken ||
      state.tempSaving ||
      state.tempLoadState !==
        "ready" ||
      !state.tempOptions.length;

    state.tempSave.disabled =
      state.tempSelect.disabled ||
      !state.tempByKey.has(
        state.tempSelect.value
      );

    state.tempReload.disabled =
      !can ||
      !hasToken ||
      state.tempSaving ||
      state.tempLoadState ===
        "loading";

    state.switchSelect.disabled =
      !can ||
      !hasToken ||
      state.switchSaving ||
      state.switchLoadState !==
        "ready" ||
      !state.switchOptions.length;

    state.switchSave.disabled =
      state.switchSelect.disabled ||
      !state.switchByKey.has(
        state.switchSelect.value
      );

    state.switchReload.disabled =
      !can ||
      !hasToken ||
      state.switchSaving ||
      state.switchLoadState ===
        "loading";
  }

  function paintLifecycle() {
    const target =
      locateLifecycle();

    if (!target || !active) return;

    const state = active;
    const runtime = snapshot();

    ensureTitle(state);

    const tempEntry =
      R.view(
        TEMP_SLOT,
        TARGET
      );

    const stateEntry =
      R.view(
        STATE_SLOT,
        TARGET
      );

    diagnostic.paintCount += 1;
    diagnostic.phase =
      runtime.deviceUuid === TARGET
        ? "CURRENT_CONTEXT"
        : "WAITING_FOR_CURRENT_CONTEXT";
    diagnostic.error =
      runtime.error;

    state.tempBox =
      findTemperatureBox(
        state.card
      );

    state.stateBox =
      findStateBox(
        state.card
      );

    if (state.tempBox) {
      const node =
        valueTextNode(
          state.tempBox,
          "temperature"
        );

      if (node) {
        R.paintText(
          state.tempBox,
          (box) =>
            valueTextNode(
              box,
              "temperature"
            ),
          tempEntry,
          "°C",
          1,
          TEMP_SLOT
        );
      }

      diagnostic.tempDisplayed =
        R.format(
          tempEntry,
          "°C",
          1
        );
    }

    if (state.stateBox) {
      const node =
        valueTextNode(
          state.stateBox,
          "state"
        );

      const rendered =
        renderState(stateEntry);

      if (node) {
        if (node.nodeType === 3) {
          if (
            node.nodeValue !==
            rendered
          ) {
            node.nodeValue =
              rendered;
          }
        } else {
          putText(
            node,
            rendered
          );
        }
      }

      diagnostic.stateDisplayed =
        rendered;
    }

    if (state.admin) {
      ensurePanel(state);

      const can = writable(state);
      const token =
        can ? readToken() : "";

      if (
        state.token &&
        token &&
        state.token !== token
      ) {
        state.controllers.forEach(
          (controller) =>
            controller.abort()
        );

        state.tempOptions = [];
        state.tempBinding = null;
        state.tempLoadState =
          "idle";
        state.tempSaveMessage = "";

        state.switchOptions = [];
        state.switchBinding = null;
        state.switchLoadState =
          "idle";
        state.switchSaveMessage = "";
      }

      updatePanel(state);

      if (
        can &&
        token &&
        state.tempLoadState ===
          "idle" &&
        !state.tempSaving
      ) {
        void loadTemperatureCatalogue(
          state
        );
      }

      if (
        can &&
        token &&
        state.switchLoadState ===
          "idle" &&
        !state.switchSaving
      ) {
        void loadSwitchCatalogue(
          state
        );
      }
    } else if (state.panel) {
      state.panel.remove();
      state.panel = null;
    }
  }

  function diagnostics() {
    const runtime = snapshot();
    const root = currentRoot();

    const temp =
      R.view(
        TEMP_SLOT,
        TARGET
      );

    const sw =
      R.view(
        STATE_SLOT,
        TARGET
      );

    return {
      version: VERSION,
      runtime,
      workspacePresent:
        Boolean(root),
      adminWorkspace:
        isAdminRoot(root),
      title:
        active && active.title
          ? text(
              active.title.textContent
            )
          : "",
      temp: {
        status: text(
          temp.status
        ),
        has_value:
          temp.has_value === true,
        value: temp.value,
        unit: text(temp.unit),
        updated_at:
          text(temp.updated_at),
      },
      switch: {
        status: text(
          sw.status
        ),
        has_value:
          sw.has_value === true,
        value: stateRaw(sw),
        updated_at:
          text(sw.updated_at),
      },
      tempEntityIds:
        active
          ? active.tempOptions.map(
              (option) =>
                text(
                  option.entity_id
                )
            )
          : [],
      switchEntityIds:
        active
          ? active.switchOptions.map(
              (option) =>
                text(
                  option.entity_id
                )
            )
          : [],
      diagnostic,
      at:
        new Date().toISOString(),
    };
  }

  function downloadDiagnostics() {
    const blob =
      new Blob(
        [
          JSON.stringify(
            diagnostics(),
            null,
            2
          ),
        ],
        {
          type:
            "text/plain;charset=utf-8",
        }
      );

    const url =
      URL.createObjectURL(blob);

    const anchor =
      document.createElement("a");

    anchor.href = url;
    anchor.download =
      "F33_R46_00013_KRB_BROWSER_" +
      Date.now() +
      ".txt";

    anchor.click();

    window.setTimeout(
      () =>
        URL.revokeObjectURL(
          url
        ),
      1000
    );
  }

  window.IQF_SEB01_00013_FIREPLACE_R46 =
    Object.freeze({
      version: VERSION,
      diagnostics,
      downloadDiagnostics,
    });

  /*
   * ONE lifecycle registration only. Temperature painting follows R42 AKU + proven F30.03B Bivalence DOM.
   * This is deliberately last in the index so it repaints the 00013
   * inherited bivalence cells after the protected 00012 adapters.
   */
  R.registerAdapter({
    slot: DISPLAY_ADAPTER,
    deviceUuid: TARGET,
    capability: "state",
    digits: 0,
    locate: locateLifecycle,
    paint: paintLifecycle,
    build: function () {},
  });
}());

;window.__F33_R46_KRB_TEMPERATURE_R42_PAINT__="F33_R46_KRB_TEMPERATURE_R42_PAINT";
