(() => {
  "use strict";

  const MARK = "__IQF_F31_R59_HIDE_HEATING_CONNECTORS__";

  if (window[MARK]) return;
  window[MARK] = true;

  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  function norm(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function root() {
    return document.querySelector(ROOT_SELECTOR);
  }

  function findCardByText(rootEl, phrase) {
    const wanted = norm(phrase);

    const candidates = Array.from(
      rootEl.querySelectorAll("article,section,div")
    ).filter((el) => {
      const text = norm(el.textContent);
      if (!text.includes(wanted)) return false;

      const r = el.getBoundingClientRect();

      return (
        r.width >= 120 &&
        r.width <= 520 &&
        r.height >= 70 &&
        r.height <= 360
      );
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      return (
        (ar.width * ar.height) -
        (br.width * br.height)
      );
    });

    return candidates[0];
  }

  function isLikelyBlueConnector(el, scopeRect) {
    if (!(el instanceof HTMLElement)) return false;

    const text = norm(el.textContent);

    if (text) return false;

    const r = el.getBoundingClientRect();

    if (r.width <= 0 || r.height <= 0) return false;

    const vertical =
      r.width <= 14 &&
      r.height >= 70 &&
      r.height <= 420;

    const horizontal =
      r.height <= 14 &&
      r.width >= 220 &&
      r.width <= 900;

    if (!vertical && !horizontal) return false;

    const withinX =
      r.right >= scopeRect.left - 40 &&
      r.left <= scopeRect.right + 40;

    const withinY =
      r.bottom >= scopeRect.top - 40 &&
      r.top <= scopeRect.bottom + 80;

    if (!withinX || !withinY) return false;

    const cs = getComputedStyle(el);

    const colorBlob = [
      cs.backgroundColor,
      cs.borderTopColor,
      cs.borderRightColor,
      cs.borderBottomColor,
      cs.borderLeftColor,
      cs.boxShadow,
      cs.color
    ].join(" ").toLowerCase();

    const hasCyanHint =
      /rgb\([^)]*(?:0|1?\d?\d),\s*(?:1\d\d|2\d\d),\s*(?:1\d\d|2\d\d)\)/.test(colorBlob) ||
      /#(?:0ff|00ffff|2dd8ff|3ddcff|4adfff|5ee7ff|63dbff)/.test(colorBlob);

    return hasCyanHint || vertical || horizontal;
  }

  function hideConnectors() {
    const rootEl = root();
    if (!rootEl) return false;

    const c1 = findCardByText(rootEl, "TOPNÝ OKRUH 1");
    const c2 = findCardByText(rootEl, "TOPNÝ OKRUH 2");
    const manifold = findCardByText(rootEl, "ROZDĚLOVAČ ÚT");

    if (!c1 || !c2 || !manifold) {
      return false;
    }

    const r1 = c1.getBoundingClientRect();
    const r2 = c2.getBoundingClientRect();
    const rm = manifold.getBoundingClientRect();

    const scopeRect = {
      left: Math.min(r1.left, r2.left, rm.left),
      right: Math.max(r1.right, r2.right, rm.right),
      top: Math.min(r1.bottom, r2.bottom) - 20,
      bottom: rm.top + 40
    };

    let hidden = 0;

    for (const el of rootEl.querySelectorAll("*")) {
      if (
        el === c1 ||
        el === c2 ||
        el === manifold ||
        c1.contains(el) ||
        c2.contains(el) ||
        manifold.contains(el)
      ) {
        continue;
      }

      if (isLikelyBlueConnector(el, scopeRect)) {
        el.style.setProperty(
          "display",
          "none",
          "important"
        );

        el.setAttribute(
          "data-f31-r59-hidden-connector",
          "1"
        );

        hidden += 1;
      }
    }

    /*
      Backup protection for connectors rendered as pseudo-elements:
      mark the three relevant cards and suppress only bottom/top
      connector pseudo-elements if such styles exist.
    */
    c1.classList.add("f31-r59-heating-card");
    c2.classList.add("f31-r59-heating-card");
    manifold.classList.add("f31-r59-manifold-card");

    ensureStyle();

    rootEl.setAttribute(
      "data-f31-r59-hidden-count",
      String(hidden)
    );

    return true;
  }

  function ensureStyle() {
    const id = "f31-r59-hide-heating-connectors-style";

    if (document.getElementById(id)) return;

    const style = document.createElement("style");
    style.id = id;

    style.textContent = `
      ${ROOT_SELECTOR} [data-f31-r59-hidden-connector="1"] {
        display: none !important;
      }

      /*
        Do not alter the cards themselves.
        Only suppress likely connector pseudo-elements extending
        vertically from heating cards / manifold if present.
      */
      ${ROOT_SELECTOR} .f31-r59-heating-card::after,
      ${ROOT_SELECTOR} .f31-r59-heating-card::before,
      ${ROOT_SELECTOR} .f31-r59-manifold-card::after,
      ${ROOT_SELECTOR} .f31-r59-manifold-card::before {
        --f31-r59-connector-display: none;
      }
    `;

    document.head.appendChild(style);
  }

  function boot() {
    if (hideConnectors()) return;

    let attempts = 0;

    const timer = window.setInterval(() => {
      attempts += 1;

      if (hideConnectors() || attempts >= 24) {
        window.clearInterval(timer);
      }
    }, 250);
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }
})();
