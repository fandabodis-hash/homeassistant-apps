(() => {
  "use strict";

  const MARK = "__IQF_F31_R93R2_SCHEMA_LOGO_00012_SCOPED__";
  const ROOT_SELECTOR = '[data-f29-00012-schema="svj-blansko-only"]';
  const HOST_ID = 'f31-r93r2-schema-logo-00012';

  if (window[MARK]) return;
  window[MARK] = true;

  function removeOldGlobalLogoArtifacts() {
    const node = document.getElementById('f31-r92r3-schema-logo-root');
    if (node) node.remove();

    document.querySelectorAll(
      '[data-f31-r92r2-schema-logo="1"], ' +
      '[data-r92-schema-logo-applied="1"], ' +
      '[data-r92-schema-logo-host="1"]'
    ).forEach((el) => {
      if (el && el.id !== HOST_ID) el.remove();
    });
  }

  function hideLiteralLogoText(root) {
    const nodes = Array.from(
      root.querySelectorAll('div,span,p,h1,h2,h3,h4,h5,h6')
    );

    for (const node of nodes) {
      if (!node || node.id === HOST_ID) continue;
      const text = (node.textContent || '').replace(/\s+/g, ' ').trim();
      if (text !== 'LOGO') continue;
      if (node.children && node.children.length > 0) continue;

      node.style.display = 'none';
      node.setAttribute('data-f31-r93r2-hidden-logo-text', '1');
    }
  }

  function mountLogo() {
    removeOldGlobalLogoArtifacts();

    const root = document.querySelector(ROOT_SELECTOR);
    if (!root) return false;

    if (getComputedStyle(root).position === 'static') {
      root.style.position = 'relative';
    }

    hideLiteralLogoText(root);

    let host = root.querySelector('#' + HOST_ID);
    if (host) return true;

    host = document.createElement('div');
    host.id = HOST_ID;
    host.setAttribute('data-f31-r93r2-schema-logo', '00012');
    host.style.position = 'absolute';
    host.style.top = '16px';
    host.style.left = '54%';
    host.style.transform = 'translateX(-50%)';
    host.style.width = '286px';
    host.style.height = '75px';
    host.style.display = 'flex';
    host.style.alignItems = 'center';
    host.style.justifyContent = 'center';
    host.style.pointerEvents = 'none';
    host.style.zIndex = '40';
    host.style.overflow = 'visible';

    const img = document.createElement('img');
    img.src = '/assets/f31-r93r2-tng-iq-fanda-logo-66e141ea123aaa13eaeb.png';
    img.alt = 'TNG IQ FANDA';
    img.width = 286;
    img.height = 75;
    img.style.display = 'block';
    img.style.width = '286px';
    img.style.height = '75px';
    img.style.maxWidth = '286px';
    img.style.objectFit = 'contain';
    img.style.pointerEvents = 'none';
    img.style.filter = 'drop-shadow(0 0 12px rgba(19,189,255,.18))';

    host.appendChild(img);
    root.appendChild(host);
    return true;
  }

  function boot() {
    removeOldGlobalLogoArtifacts();
    mountLogo();

    const observer = new MutationObserver(() => {
      mountLogo();
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });

    window.addEventListener('resize', () => {
      mountLogo();
    }, { passive: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();