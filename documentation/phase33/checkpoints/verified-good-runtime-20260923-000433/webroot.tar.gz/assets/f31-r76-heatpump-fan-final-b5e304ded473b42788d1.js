(() => {
  "use strict";

  const MARK = "__IQF_F31_R76_FAN_FINAL__";
  const ROOT = '[data-f29-00012-schema="svj-blansko-only"]';
  const THRESHOLD_KW = 0.3;

  if (window[MARK]) return;
  window[MARK] = true;

  let active = false;
  let angle = 0;
  let lastTime = performance.now();
  let fans = [];
  let powerNode = null;
  let powerObserver = null;

  function parseKw(text) {
    const m = String(text || "").match(/(-?\d+(?:[.,]\d+)?)\s*kW/i);
    if (!m) return null;
    const n = Number(m[1].replace(",", "."));
    return Number.isFinite(n) ? n : null;
  }

  function heatpump() {
    return document.querySelector(
      ROOT + " .f29-00012-heatpump"
    );
  }

  function findPowerNode(card) {
    if (!card) return null;

    const rows = Array.from(
      card.querySelectorAll(".f29-00012-metric-row")
    );

    const row = rows.find((el) =>
      /AKTUÁLN[IÍ]\s+ELEKTRICK[YÝ]\s+P[RŘ][IÍ]KON/i
        .test(String(el.textContent || ""))
    );

    if (row) {
      const value = row.querySelector(".f29-00012-metric-value");
      if (value) return value;
    }

    const values = Array.from(
      card.querySelectorAll(".f29-00012-metric-value")
    );

    return values.find((el) =>
      /\bkW\b/i.test(String(el.textContent || ""))
    ) || values[0] || null;
  }

  function ensureStyle() {
    const id = "f31-r76-fan-final-style";
    if (document.getElementById(id)) return;

    const style = document.createElement("style");
    style.id = id;
    style.textContent = `
      ${ROOT} .f29-00012-heatpump .f29-00012-hp-fan {
        display: inline-block !important;
        transform: scale(2) !important;
        transform-origin: 50% 50% !important;
        animation: none !important;
        will-change: rotate !important;
        backface-visibility: hidden !important;
      }
    `;
    document.head.appendChild(style);
  }

  function refreshState() {
    ensureStyle();

    const card = heatpump();
    if (!card) return false;

    fans = Array.from(
      card.querySelectorAll(".f29-00012-hp-fan")
    );

    if (fans.length !== 2) {
      card.setAttribute(
        "data-f31-r76-fan-count",
        String(fans.length)
      );
      return false;
    }

    const nextPowerNode = findPowerNode(card);

    if (nextPowerNode && nextPowerNode !== powerNode) {
      if (powerObserver) {
        powerObserver.disconnect();
      }

      powerNode = nextPowerNode;

      powerObserver = new MutationObserver(() => {
        refreshState();
      });

      powerObserver.observe(powerNode, {
        childList: true,
        subtree: true,
        characterData: true
      });
    }

    const powerKw = powerNode
      ? parseKw(powerNode.textContent)
      : null;

    active =
      powerKw !== null &&
      powerKw > THRESHOLD_KW;

    card.setAttribute(
      "data-f31-r76-fans",
      active ? "on" : "off"
    );

    card.setAttribute(
      "data-f31-r76-power-kw",
      powerKw === null
        ? "unknown"
        : String(powerKw)
    );

    if (!active) {
      angle = 0;

      for (const fan of fans) {
        fan.style.rotate = "0deg";
      }
    }

    return true;
  }

  function animate(now) {
    const delta = Math.max(
      0,
      Math.min(100, now - lastTime)
    );

    lastTime = now;

    if (active && fans.length === 2) {
      angle =
        (angle + delta * (360 / 850)) % 360;

      const deg = angle.toFixed(2) + "deg";

      for (const fan of fans) {
        fan.style.rotate = deg;
      }
    }

    requestAnimationFrame(animate);
  }

  function boot() {
    refreshState();

    let attempts = 0;

    const startup = window.setInterval(() => {
      attempts += 1;

      if (
        refreshState() ||
        attempts >= 20
      ) {
        window.clearInterval(startup);
      }
    }, 250);

    requestAnimationFrame(animate);
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }
})();