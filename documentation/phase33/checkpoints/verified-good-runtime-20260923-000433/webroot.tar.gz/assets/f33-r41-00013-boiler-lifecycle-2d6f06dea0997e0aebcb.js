/* F33.R41: UUID 00013 only. Render lifecycle supplied by the existing SEB R5.
 * The display adapter ID below is NOT a server binding key.
 * Only SLOT is read/saved, and only after an explicit administrator click.
 */
(function () {
  "use strict";
  const VERSION = "F33.R41-00013-BOILER-RUNTIME-LIFECYCLE";
  const TARGET = "014a0d23-d440-4131-abb4-28a860595043";
  const SLOT = "boiler-temperature";
  const DISPLAY_ADAPTER = "f33-r41-00013-boiler-display-lifecycle";
  const API_BASE = "https://api.tngiqfanda.cz";
  const ROOT = '[data-phase28-r177n107-workspace="universal-individual-admin-client-clone"]' +
    '[data-f33-r34-current-device-uuid="' + TARGET + '"]';
  const PICKER = "f33-r41-boiler-picker";
  const NOTICE = "f33-r41-boiler-notice";
  const R = window.IQF_SEB01_RUNTIME;
  if (window.IQF_SEB01_00013_BOILER_R41) return;
  if (!R || R.version !== "F30.4C-R5-PERSISTED-READER" ||
      typeof R.registerAdapter !== "function" || typeof R.diagnostics !== "function") {
    console.error(VERSION, "SHARED_RUNTIME_UNAVAILABLE");
    return;
  }
  let active = null;
  const text = v => v == null ? "" : String(v).trim();
  const normId = v => text(v).toLowerCase().replace(/[:-]/g, "");
  const putText = (el, value) => { if (el && el.textContent !== value) el.textContent = value; };
  const code = e => text(e && e.message).match(/^[A-Z][A-Z0-9_]*$/)
    ? e.message : "REQUEST_OR_RENDER_FAILED";
  const diagnostic = {version:VERSION, target:TARGET, bindingKey:SLOT, phase:"WAITING_FOR_WORKSPACE",
    error:"", catalogueCount:0, savedEntity:"", displayedValue:"", paintCount:0};

  function snapshot() {
    const s = R.diagnostics();
    return {deviceUuid:text(s.deviceUuid).toLowerCase(), admin:s.admin === true, error:text(s.error)};
  }
  function adminRoot(root) {
    return !!root && root.getAttribute("data-phase28-r177n107-source") === "admin-sodim-r177n94";
  }
  function visible(root) {
    if (!root || !root.isConnected || !root.getClientRects().length) return false;
    const s = window.getComputedStyle(root);
    return s.display !== "none" && s.visibility !== "hidden";
  }
  function currentRoot() {
    const roots = Array.from(document.querySelectorAll(ROOT)).filter(visible);
    return roots.length === 1 ? roots[0] : null; // Ambiguous workspaces fail closed.
  }
  function locate() {
    const root = currentRoot();
    const card = root && root.querySelector(".f29-00012-boiler");
    const box = card && (card.querySelector(".f29-00012-temperature") ||
      card.querySelector('[data-f30-schema-element-key="boiler-temperature"]'));
    if (!root || !card || !box) {
      clearActive();
      diagnostic.phase = root ? "WAITING_FOR_BOILER_CELL" : "WAITING_FOR_WORKSPACE";
      return null;
    }
    if (active && (active.root !== root || active.card !== card || active.admin !== adminRoot(root))) clearActive();
    if (!active) {
      active = {root,card,box,admin:adminRoot(root),controllers:new Set(),disposed:false,
        panel:null,notice:null,options:[],byKey:new Map(),binding:null,
        loadState:"idle",loadError:"",saving:false,token:null,saveMessage:""};
    }
    active.box = box;
    return {card,box};
  }
  function clearActive() {
    if (!active) return;
    const old = active;
    active = null;
    old.disposed = true;
    old.controllers.forEach(c => c.abort());
    old.controllers.clear();
    if (old.panel) old.panel.remove();
    if (old.notice) old.notice.remove();
    old.token = null;
    diagnostic.catalogueCount=0; diagnostic.savedEntity=""; diagnostic.displayedValue="";
  }
  function valueNode(box) {
    // Same text-node principle as the proven 00012 adapter; no <strong> assumption.
    const walker = document.createTreeWalker(box, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent || parent.closest("." + PICKER + ",." + NOTICE +
          ",select,option,button,label,.f30-02u-picker,.f30-02u-source")) return NodeFilter.FILTER_REJECT;
        const t = text(node.nodeValue);
        if (!t || /teplota|zdroj/i.test(t)) return NodeFilter.FILTER_REJECT;
        return /°[CF]|\u2014/.test(t) || t === "-" || /^[+-]?\d+(?:[,.]\d+)?$/.test(t)
          ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    return walker.nextNode();
  }
  function ensureStyle() {
    if (document.getElementById("f33-r41-boiler-style")) return;
    const style = document.createElement("style");
    style.id = "f33-r41-boiler-style";
    style.textContent = ROOT + " ." + PICKER +
      "{margin-top:.55rem;padding:.6rem;border:1px solid rgba(93,203,255,.38);border-radius:12px;background:rgba(2,22,34,.96);display:grid;gap:.35rem;max-width:100%;min-width:0;box-sizing:border-box;position:relative;z-index:4}" +
      ROOT + " ." + PICKER + " label{display:grid;gap:.3rem;color:#d9f5ff;font-size:.7rem;font-weight:900}" +
      ROOT + " ." + PICKER + " select{width:100%;min-width:0;min-height:34px;border-radius:8px;border:1px solid rgba(124,221,255,.42);background:#061b28;color:#f1fbff;padding:.35rem;font-size:.73rem}" +
      ROOT + " ." + PICKER + " .actions{display:flex;flex-wrap:wrap;gap:.35rem}" +
      ROOT + " ." + PICKER + " button{border:1px solid rgba(124,221,255,.55);background:rgba(34,184,255,.20);color:#e7fbff;border-radius:8px;padding:.35rem .55rem;font-weight:800;font-size:.7rem;cursor:pointer}" +
      ROOT + " ." + PICKER + " button:disabled{opacity:.5;cursor:not-allowed}" +
      ROOT + " ." + PICKER + " small{font-size:.67rem;line-height:1.25;overflow-wrap:anywhere;color:#b9dae6}" +
      ROOT + " ." + PICKER + " [data-error=true]{color:#ffd47a}" +
      ROOT + " ." + NOTICE + "{font-size:.65rem;color:#b9dae6;display:block;overflow-wrap:anywhere}";
    document.head.appendChild(style);
  }
  function make(tag, content, cls) {
    const el = document.createElement(tag);
    if (content) el.textContent = content;
    if (cls) el.className = cls;
    return el;
  }
  function ensurePanel(s) {
    if (!s.admin) return;
    if (s.panel && s.panel.isConnected && s.card.contains(s.panel)) return;
    ensureStyle();
    const p = make("div", "", PICKER);
    p.setAttribute("data-seb01-model", "00013");
    const label = make("label", "Teplotní entita bojleru — 00013");
    const select = make("select");
    select.setAttribute("aria-label", "Zigbee teplotní entita modelu 00013");
    const empty = make("option", "Čekám na katalog teplotních entit…"); empty.value = "";
    select.appendChild(empty); select.disabled = true; label.appendChild(select); p.appendChild(label);
    const actions = make("div", "", "actions");
    const save = make("button", "Uložit"); save.type="button"; save.disabled=true;
    const reload = make("button", "Obnovit seznam"); reload.type="button";
    const inspect = make("button", "Diagnostika"); inspect.type="button";
    actions.append(save,reload,inspect); p.appendChild(actions);
    const status = make("small", "Čekám na kontext modelu 00013."); status.setAttribute("role","status");
    p.appendChild(status);
    // A sibling of the value, never inside a text element owned by paintText.
    s.card.appendChild(p);
    Object.assign(s,{panel:p,select,save,reload,status});
    select.addEventListener("change", () => { s.saveMessage="Výběr není uložený. Potvrďte tlačítkem Uložit."; updatePanel(s); });
    save.addEventListener("click", () => { void saveSelection(s); });
    reload.addEventListener("click", () => { if (!s.saving) {s.saveMessage="";void loadCatalogue(s);} });
    inspect.addEventListener("click", downloadDiagnostics);
    if (s.options.length) fillOptions(s, "");
  }
  function readToken() {
    try { return text(window.localStorage.getItem("iqfanda_access_token")).replace(/^Bearer\s+/i,""); }
    catch (_) { return ""; }
  }
  function writable(s) {
    if (!s || s.disposed || active !== s || currentRoot() !== s.root || !adminRoot(s.root)) return false;
    const d = snapshot();
    return d.deviceUuid === TARGET && d.admin === true;
  }
  function assertWritable(s) {
    if (!writable(s)) throw new Error("CURRENT_ADMIN_CONTEXT_REQUIRED");
    const t = readToken();
    if (!t) throw new Error("SESSION_TOKEN_MISSING");
    return t;
  }
  async function request(s, suffix, method, body) {
    const t = assertWritable(s);
    const c = new AbortController(); s.controllers.add(c);
    const timeout = window.setTimeout(() => c.abort(), 8000); // Request deadline, not a polling loop.
    try {
      const response = await fetch(API_BASE + "/api/v1/admin/devices/" + TARGET +
        "/individual-project/" + suffix, {method:method || "GET",cache:"no-store",redirect:"error",
        credentials:"same-origin",signal:c.signal,headers:{Accept:"application/json",Authorization:"Bearer " + t,
          ...(body ? {"Content-Type":"application/json"} : {})},...(body ? {body:JSON.stringify(body)} : {})});
      if (!writable(s) || readToken() !== t) throw new Error("CONTEXT_CHANGED");
      if (!response.ok) throw new Error("HTTP_" + response.status);
      if (!/application\/(?:[\w.-]+\+)?json\b/i.test(response.headers.get("content-type") || "")) throw new Error("NON_JSON_RESPONSE");
      const data = await response.json();
      if (!writable(s) || readToken() !== t) throw new Error("CONTEXT_CHANGED");
      if (!data || Array.isArray(data) || text(data.device_uuid).toLowerCase() !== TARGET) throw new Error("WRONG_DEVICE_RESPONSE");
      return data;
    } finally { window.clearTimeout(timeout); s.controllers.delete(c); }
  }
  function entityKey(o) {
    return JSON.stringify([TARGET,text(o.transport).toLowerCase(),normId(o.ieee || o.device_id),text(o.entity_id)]);
  }
  function sameEntity(binding, option) {
    return !!binding && !!option && text(binding.entity_id) === text(option.entity_id) &&
      text(binding.transport).toLowerCase() === text(option.transport).toLowerCase() &&
      !!R.matchIdentity(binding,[option]);
  }
  function label(o) {
    const name = [text(o.device_name) || "Nepojmenované Zigbee zařízení", text(o.entity_name)].filter(Boolean).join(" → ");
    const value = o.has_value === true ? " | katalog: " + R.format(o,o.unit,1) : "";
    return name + " [" + text(o.entity_id) + "]" + (o.unit ? " · " + text(o.unit) : "") + value;
  }
  function validateCatalogue(data) {
    if (!Array.isArray(data.options) || !data.bindings || Array.isArray(data.bindings) ||
        typeof data.bindings !== "object") throw new Error("CATALOGUE_SHAPE");
    if (data.has_more === true) throw new Error("CATALOGUE_PAGINATION_NOT_COMPLETE");
    const options=[]; const seen=new Set();
    for (const o of data.options) {
      if (!o || typeof o !== "object" || text(o.transport).toLowerCase() !== "zigbee") continue;
      const caps=Array.isArray(o.capabilities)?o.capabilities.map(v=>text(v).toLowerCase()):[];
      if (text(o.capability).toLowerCase() !== "temperature" && !caps.includes("temperature")) continue;
      // Measured sensor temperature, not a number.* comfort/setpoint setting.
      if (!text(o.entity_id).startsWith("sensor.")) continue;
      if (text(o.source_device_uuid) && text(o.source_device_uuid).toLowerCase() !== TARGET) throw new Error("FOREIGN_SOURCE_IN_CATALOGUE");
      if (!normId(o.ieee || o.device_id)) throw new Error("ENTITY_HARDWARE_IDENTITY_MISSING");
      const key=entityKey(o); if(seen.has(key)) throw new Error("DUPLICATE_ENTITY_IDENTITY");
      seen.add(key); options.push(o);
    }
    return {options,binding:data.bindings[SLOT] || null};
  }
  async function fetchCatalogue(s) {
    return validateCatalogue(await request(s,"schema-entity-options?capability=temperature"));
  }
  function fillOptions(s, preserve) {
    if (!s.select) return;
    const children=[]; const empty=make("option","Vyberte teplotní entitu…"); empty.value=""; children.push(empty);
    s.byKey=new Map();
    for(const o of s.options) {
      const key=entityKey(o), item=make("option",label(o)); item.value=key;
      s.byKey.set(key,o); children.push(item);
    }
    s.select.replaceChildren(...children);
    const saved=s.options.find(o=>sameEntity(s.binding,o));
    s.select.value=s.byKey.has(preserve)?preserve:(saved?entityKey(saved):"");
  }
  function acceptCatalogue(s, data, preserve) {
    s.options=data.options; s.binding=data.binding; s.loadState="ready"; s.loadError="";
    diagnostic.catalogueCount=s.options.length;
    diagnostic.savedEntity=text(s.binding && s.binding.entity_id);
    fillOptions(s,preserve);
  }
  async function loadCatalogue(s) {
    if (s.loadState === "loading" || s.saving) return;
    try {
      s.token=assertWritable(s); s.loadState="loading"; s.loadError=""; updatePanel(s);
      const preserve=s.select?s.select.value:"";
      const data=await fetchCatalogue(s); if(active!==s || s.disposed) return;
      acceptCatalogue(s,data,preserve);
    } catch(e) { if(active===s&&!s.disposed){s.loadState="failed";s.loadError=code(e); diagnostic.error=s.loadError;} }
    finally { if(active===s&&!s.disposed) updatePanel(s); }
  }
  function confirmedBinding(binding, option) {
    return !!binding && text(binding.source_device_uuid).toLowerCase() === TARGET &&
      binding.verified_against_current_options === true && sameEntity(binding,option);
  }
  async function saveSelection(s) {
    if(s.saving || !s.select) return;
    const chosen=s.byKey.get(s.select.value); if(!chosen) return;
    try {
      assertWritable(s); s.saving=true;s.saveMessage="Ukládám a ověřuji vazbu…";s.loadError="";updatePanel(s);
      const fresh=await fetchCatalogue(s);
      const exact=R.matchIdentity(chosen,fresh.options);
      if(!exact) throw new Error("ENTITY_NO_LONGER_IN_CURRENT_CATALOGUE");
      const payload={entity:{...exact,source_device_uuid:TARGET},capability:"temperature",source_device_uuid:TARGET};
      const result=await request(s,"schema-entity-bindings/" + SLOT,"PUT",payload);
      if(result.binding_persisted!==true || !confirmedBinding(result.binding,exact)) throw new Error("BINDING_NOT_CONFIRMED");
      const readback=await fetchCatalogue(s);
      if(!confirmedBinding(readback.binding,exact)) throw new Error("BINDING_READBACK_MISMATCH");
      acceptCatalogue(s,readback,entityKey(exact));
      s.saveMessage="Vazba uložena a ověřena pro 00013.";
      await R.refresh();
    } catch(e) { if(active===s&&!s.disposed){s.loadError=code(e);s.saveMessage="Uložení nepotvrzeno: " + s.loadError;diagnostic.error=s.loadError;} }
    finally { if(active===s&&!s.disposed){s.saving=false;updatePanel(s);paintValue();} }
  }
  function updatePanel(s) {
    if(!s.panel || s.disposed || active!==s) return;
    const d=snapshot(), can=writable(s), hasToken=can&&!!readToken();
    let message="";
    if(!can) message="Čekám na vlastní administrátorský kontext 00013 (" + (d.deviceUuid || "bez kontextu") + ").";
    else if(!hasToken) message="Chybí přihlašovací relace. Znovu otevřete modul po přihlášení.";
    else if(s.loadState==="loading") message="Načítám teplotní entity Zigbee sítě 00013…";
    else if(s.loadState==="failed") message="Katalog nelze načíst: " + s.loadError + ". Použijte Obnovit seznam.";
    else if(s.saveMessage) message=s.saveMessage;
    else if(s.loadState==="ready") message="Zigbee teplotní entity: " + s.options.length + ". " +
      (s.binding ? "Uloženo: " + text(s.binding.entity_id) + "." : "Vyberte zdroj a potvrďte Uložit.");
    else message="Čekám na katalog teplotních entit 00013.";
    putText(s.status,message);
    s.status.setAttribute("data-error",String(!!s.loadError));
    s.select.disabled=!can||!hasToken||s.saving||s.loadState!=="ready"||!s.options.length;
    s.save.disabled=s.select.disabled||!s.byKey.has(s.select.value);
    s.reload.disabled=!can||!hasToken||s.saving||s.loadState==="loading";
  }
  function paintValue() {
    const target=locate(); if(!target || !active) return;
    const s=active, d=snapshot(), entry=R.view(SLOT,TARGET);
    diagnostic.paintCount+=1;diagnostic.phase=d.deviceUuid===TARGET?"CURRENT_CONTEXT":"WAITING_FOR_CURRENT_CONTEXT";
    diagnostic.error=text(d.error);diagnostic.displayedValue=R.format(entry,"°C",1);
    const node=valueNode(s.box);
    if(node) R.paintText(s.box,valueNode,entry,"°C",1,SLOT);
    else {diagnostic.phase="VALUE_TEXT_NODE_NOT_FOUND";diagnostic.error="VALUE_TEXT_NODE_NOT_FOUND";}
    s.box.setAttribute("data-f33-r41-state",text(entry.status)||"waiting");
    if(s.admin) {
      ensurePanel(s);
      const can=writable(s), t=can?readToken():"";
      if(s.token && t && s.token!==t) {
        s.controllers.forEach(c=>c.abort());s.options=[];s.binding=null;s.loadState="idle";s.token=null;
        s.saveMessage="";fillOptions(s,"");
      }
      updatePanel(s);
      if(can&&t&&s.loadState==="idle"&&!s.saving) void loadCatalogue(s);
    } else {
      if(s.panel){s.panel.remove();s.panel=null;}
      if(!node || (entry.status && entry.status!=="online" && entry.status!=="ok")) {
        ensureStyle();
        if(!s.notice || !s.notice.isConnected){s.notice=make("small","",NOTICE);s.card.appendChild(s.notice);}
        putText(s.notice,!node?"Nelze najít text teploty — diagnostika R41.":R.hint(entry));
      } else if(s.notice){s.notice.remove();s.notice=null;}
    }
  }
  function diagnostics() {
    const d=snapshot(),root=currentRoot();
    const e=R.view(SLOT,TARGET);
    return {...diagnostic,runtime:d,workspacePresent:!!root,adminWorkspace:adminRoot(root),
      value:{status:text(e.status),has_value:e.has_value===true,value:e.value,unit:text(e.unit),updated_at:text(e.updated_at)},
      selectorCount:root?root.querySelectorAll("."+PICKER).length:0,
      entityIds:active?active.options.map(o=>text(o.entity_id)):[],
      catalogueError:active?active.loadError:"",at:new Date().toISOString()};
  }
  function downloadDiagnostics() {
    const b=new Blob([JSON.stringify(diagnostics(),null,2)],{type:"text/plain;charset=utf-8"});
    const u=URL.createObjectURL(b),a=document.createElement("a");
    a.href=u;a.download="F33_R41_00013_BROWSER_"+Date.now()+".txt";a.click();
    window.setTimeout(()=>URL.revokeObjectURL(u),1000);
  }
  window.IQF_SEB01_00013_BOILER_R41=Object.freeze({version:VERSION,diagnostics,downloadDiagnostics});
  // Unique *display* registration; never replace the 00012 boiler-temperature adapter.
  // Existing R5's DOM observer and context refresh call this on mounts and remounts.
  R.registerAdapter({slot:DISPLAY_ADAPTER,deviceUuid:TARGET,capability:"temperature",digits:1,
    locate,paint:paintValue,build:function(){}});
}());
