(() => {
  "use strict";

  const ROOT = '[data-f29-00012-schema="svj-blansko-only"]';
  const PUMP_WRAPPER = '[data-f31-r85-protect="aku-pump"]';
  const SLOT = 'aku-circulation-pump-state';
  const ID = 'f31-r94r6-aku-distributor-flow';
  const LINE_Y_RATIO_ON_AKU = 0.652;

  if (window.__IQF_F31_R94R6_AKU_DISTRIBUTOR_FLOW__) return;
  window.__IQF_F31_R94R6_AKU_DISTRIBUTOR_FLOW__ = true;

  let lastExplicitState = null;

  const norm = (value) =>
    String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toUpperCase();

  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return (
      r.width > 0 &&
      r.height > 0 &&
      s.display !== 'none' &&
      s.visibility !== 'hidden'
    );
  }

  function findCard(root, label) {
    const wanted = norm(label);
    let best = null;
    let bestArea = Infinity;

    for (const el of root.querySelectorAll('article,section,div')) {
      if (!visible(el)) continue;
      if (!norm(el.textContent).includes(wanted)) continue;

      const r = el.getBoundingClientRect();

      if (
        r.width < 140 ||
        r.width > 560 ||
        r.height < 90 ||
        r.height > 430
      ) {
        continue;
      }

      const area = r.width * r.height;

      if (area < bestArea) {
        best = el;
        bestArea = area;
      }
    }

    return best;
  }

  function parseState(value) {
    const text = norm(value);

    if (
      text.includes('NEDOSTUPNE') ||
      text.includes('VYPNUTO') ||
      text === 'OFF' ||
      text === 'FALSE' ||
      text === '0'
    ) {
      return false;
    }

    if (
      text.includes('ZAPNUTO') ||
      text === 'ON' ||
      text === 'TRUE' ||
      text === '1'
    ) {
      return true;
    }

    return null;
  }

  function parseNode(node) {
    if (!node) return null;

    for (const attr of [
      'data-state',
      'data-f31-r84-state',
      'data-f31-r83-state',
      'aria-label',
      'title'
    ]) {
      const raw = node.getAttribute(attr);
      if (!raw) continue;

      const parsed = parseState(raw);
      if (parsed !== null) return parsed;
    }

    return parseState(node.textContent);
  }

  function readPumpState(root) {
    const wrapper = root.querySelector(PUMP_WRAPPER);

    if (wrapper) {
      const direct = wrapper.querySelector(
        `[data-seb01-slot="${SLOT}"]`
      );

      const directState = parseNode(direct);
      if (directState !== null) return directState;

      const wrapperState = parseState(wrapper.textContent);
      if (wrapperState !== null) return wrapperState;
    }

    const direct = root.querySelector(
      `[data-seb01-slot="${SLOT}"]`
    );

    return parseNode(direct);
  }

  function ensureStyle() {
    const styleId = 'f31-r94r6-flow-style';

    if (document.getElementById(styleId)) return;

    const style = document.createElement('style');
    style.id = styleId;

    style.textContent = `
      @keyframes iqf-r94r6-flow-right {
        from { background-position-x: -24px; }
        to   { background-position-x: 0px; }
      }

      #${ID} {
        position: fixed;
        pointer-events: none;
        z-index: 2147480000;
        height: 9px;
        overflow: hidden;
        opacity: 0;
        border-radius: 2px;
        transition: opacity .10s ease;
        background-image:
          radial-gradient(
            circle at center,
            rgb(0,127,255) 0px,
            rgb(0,127,255) 3.75px,
            rgb(0,190,255) 3.82px,
            rgb(0,190,255) 4.50px,
            transparent 4.65px
          );
        background-repeat: repeat-x;
        background-size: 34px 9px;
        background-position: -24px center;
        filter: drop-shadow(0 0 2px rgba(0,140,255,.90));
      }

      #${ID}[data-active="1"] {
        opacity: 1;
        animation: iqf-r94r6-flow-right .58s linear infinite;
      }
    `;

    document.head.appendChild(style);
  }

  function ensureOverlay() {
    let overlay = document.getElementById(ID);

    if (overlay) return overlay;

    overlay = document.createElement('div');
    overlay.id = ID;
    overlay.dataset.active = '0';
    document.body.appendChild(overlay);

    return overlay;
  }

  function layout() {
    const root = document.querySelector(ROOT);
    const overlay = ensureOverlay();

    if (!root || !visible(root)) {
      overlay.style.display = 'none';
      return;
    }

    ensureStyle();

    const aku = findCard(root, 'AKU NÁDRŽ');
    const distributor = findCard(root, 'ROZDĚLOVAČ ÚT');

    if (!aku || !distributor) {
      overlay.style.display = 'none';
      return;
    }

    const akuRect = aku.getBoundingClientRect();
    const distributorRect = distributor.getBoundingClientRect();

    const width = distributorRect.left - akuRect.right;

    if (width < 20) {
      overlay.style.display = 'none';
      return;
    }

    const lineCenterY =
      akuRect.top +
      akuRect.height * LINE_Y_RATIO_ON_AKU;

    overlay.style.display = 'block';
    overlay.style.left = Math.round(akuRect.right) + 'px';
    overlay.style.top = Math.round(lineCenterY - 4.5) + 'px';
    overlay.style.width = Math.max(1, Math.round(width)) + 'px';
    overlay.style.height = '9px';
  }

  function updateState() {
    const root = document.querySelector(ROOT);
    const overlay = ensureOverlay();

    if (!root || !visible(root)) {
      overlay.dataset.active = '0';
      return;
    }

    const explicitState = readPumpState(root);

    if (explicitState !== null) {
      lastExplicitState = explicitState;
    }

    if (lastExplicitState === null) return;

    const next = lastExplicitState ? '1' : '0';

    if (overlay.dataset.active !== next) {
      overlay.dataset.active = next;
    }
  }

  function boot() {
    ensureStyle();
    ensureOverlay();
    layout();
    updateState();

    const layoutTimer = setInterval(() => {
      layout();
      updateState();
    }, 500);

    const stateTimer = setInterval(updateState, 150);

    addEventListener(
      'resize',
      () => {
        layout();
        updateState();
      },
      { passive: true }
    );

    addEventListener(
      'scroll',
      layout,
      { passive: true }
    );

    addEventListener(
      'beforeunload',
      () => {
        clearInterval(layoutTimer);
        clearInterval(stateTimer);
      },
      { once: true }
    );
  }

  if (document.readyState === 'loading') {
    document.addEventListener(
      'DOMContentLoaded',
      boot,
      { once: true }
    );
  } else {
    boot();
  }
})();