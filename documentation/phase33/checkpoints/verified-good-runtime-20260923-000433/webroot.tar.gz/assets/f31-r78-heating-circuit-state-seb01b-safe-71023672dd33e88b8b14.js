(() => {
  "use strict";

  const MARK = "__IQF_F31_R78_HEATING_CIRCUIT_STATE_SEB01B__";
  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  const runtime = window.IQF_SEB01_RUNTIME;
  const EXPECTED_RUNTIME =
    "F30.4C-R5-PERSISTED-READER";
  const DEVICE_UUID =
    "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc";

  if (window[MARK]) return;
  window[MARK] = true;

  if (
    !runtime ||
    runtime.version !== EXPECTED_RUNTIME
  ) {
    console.warn(
      "R78: shared SEB-01 runtime unavailable"
    );
    return;
  }

  const CONFIG = Object.freeze([
    {
      key: "east",
      titles: [
        "TOPNÝ OKRUH VÝCHOD",
        "TOPNÝ OKRUH 1"
      ],
      slot:
        "heating-circuit-east-state",
      pickerTitle:
        "Topný okruh VÝCHOD / stav"
    },
    {
      key: "west",
      titles: [
        "TOPNÝ OKRUH ZÁPAD",
        "TOPNÝ OKRUH 2"
      ],
      slot:
        "heating-circuit-west-state",
      pickerTitle:
        "Topný okruh ZÁPAD / stav"
    }
  ]);

  function norm(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function root() {
    return document.querySelector(
      ROOT_SELECTOR
    );
  }

  function smallestCard(cfg) {
    const rootEl = root();
    if (!rootEl) return null;

    const wanted =
      cfg.titles.map(norm);

    const cards = Array.from(
      rootEl.querySelectorAll(
        "article,section,div"
      )
    ).filter((el) => {
      const text =
        norm(el.textContent);

      if (
        !wanted.some(
          (title) =>
            text.includes(title)
        )
      ) {
        return false;
      }

      const r =
        el.getBoundingClientRect();

      return (
        r.width >= 140 &&
        r.width <= 430 &&
        r.height >= 100 &&
        r.height <= 360
      );
    });

    if (!cards.length) return null;

    cards.sort((a, b) => {
      const ar =
        a.getBoundingClientRect();
      const br =
        b.getBoundingClientRect();

      return (
        ar.width * ar.height -
        br.width * br.height
      );
    });

    return cards[0];
  }

  function leafStateLabel(card) {
    const candidates = Array.from(
      card.querySelectorAll(
        "span,div,p,strong,b"
      )
    ).filter((el) => {
      if (el.children.length > 2) {
        return false;
      }

      const text =
        norm(el.textContent);

      return text === "STAV";
    });

    if (!candidates.length) {
      return null;
    }

    candidates.sort((a, b) => {
      const ar =
        a.getBoundingClientRect();
      const br =
        b.getBoundingClientRect();

      return (
        ar.width * ar.height -
        br.width * br.height
      );
    });

    return candidates[0];
  }

  function stateRow(card) {
    const label =
      leafStateLabel(card);

    if (!label) return null;

    let row =
      label.parentElement;

    for (
      let i = 0;
      row && i < 4;
      i += 1,
      row = row.parentElement
    ) {
      const r =
        row.getBoundingClientRect();

      const text =
        norm(row.textContent);

      if (
        r.width >= 120 &&
        r.height >= 18 &&
        r.height <= 65 &&
        text.startsWith("STAV")
      ) {
        return row;
      }
    }

    return label.parentElement;
  }

  function ensureHost(cfg) {
    const card =
      smallestCard(cfg);

    if (!card) return null;

    const row =
      stateRow(card);

    if (!row) return null;

    if (
      getComputedStyle(row)
        .position === "static"
    ) {
      row.style.position =
        "relative";
    }

    let host =
      row.querySelector(
        `[data-f31-r78-slot="${cfg.slot}"]`
      );

    if (!host) {
      host =
        document.createElement(
          "span"
        );

      host.className =
        "f31-r78-state-host";

      host.setAttribute(
        "data-f31-r78-slot",
        cfg.slot
      );

      host.textContent = "—";

      row.appendChild(host);
    }

    return {
      card,
      row,
      box: host
    };
  }

  function formatState(entry) {
    const e =
      entry &&
      typeof entry === "object"
        ? entry
        : {};

    const status =
      String(
        e.status || ""
      )
      .trim()
      .toLowerCase();

    if (
      e.available === false ||
      status === "unavailable" ||
      status === "offline"
    ) {
      return {
        text: "Nedostupné",
        state: "unavailable"
      };
    }

    if (
      e.has_value !== true ||
      [
        "unknown",
        "unbound",
        "snapshot_only",
        "api_stale",
        "no_context",
        "loading"
      ].includes(status) ||
      /^(http_|request_|wrong_device|context_)/
        .test(status)
    ) {
      return {
        text: "—",
        state: "unknown"
      };
    }

    const v = e.value;

    if (
      v === true ||
      v === 1 ||
      (
        typeof v === "string" &&
        /^(on|true|1|zapnuto)$/i
          .test(v.trim())
      )
    ) {
      return {
        text: "zapnuto",
        state: "on"
      };
    }

    if (
      v === false ||
      v === 0 ||
      (
        typeof v === "string" &&
        /^(off|false|0|vypnuto)$/i
          .test(v.trim())
      )
    ) {
      return {
        text: "vypnuto",
        state: "off"
      };
    }

    return {
      text: "—",
      state: "unknown"
    };
  }

  function ensureStyle() {
    const id =
      "f31-r78-state-style";

    if (
      document.getElementById(id)
    ) {
      return;
    }

    const style =
      document.createElement(
        "style"
      );

    style.id = id;

    style.textContent = `
      ${ROOT_SELECTOR}
      .f31-r78-state-host {
        position: absolute;
        right: 6px;
        top: 50%;
        transform: translateY(-50%);

        min-width: 76px;
        height: 24px;
        padding: 0 8px;

        box-sizing: border-box;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 6px;

        background:
          rgba(0,22,32,.98);

        color: #dff8ff;

        font-size: 10px;
        font-weight: 900;
        line-height: 1;

        white-space: nowrap;

        z-index: 30;
      }

      ${ROOT_SELECTOR}
      button.f31-r78-state-host {
        border: 1px solid
          rgba(72,215,255,.66);

        pointer-events: auto;
        cursor: pointer;
      }

      ${ROOT_SELECTOR}
      button.f31-r78-state-host:hover {
        background:
          rgba(0,61,86,.98);

        box-shadow:
          0 0 9px
          rgba(72,215,255,.18);
      }

      ${ROOT_SELECTOR}
      span.f31-r78-state-host {
        border: 0;
        pointer-events: none;
      }

      ${ROOT_SELECTOR}
      .f31-r78-state-host[data-f31-r78-state="on"] {
        color: #ff4d59;
      }

      ${ROOT_SELECTOR}
      .f31-r78-state-host[data-f31-r78-state="off"] {
        color: #dff8ff;
      }

      ${ROOT_SELECTOR}
      .f31-r78-state-host[data-f31-r78-state="unavailable"] {
        color: #91a9b4;
      }
    `;

    document.head.appendChild(
      style
    );
  }

  function setPickerZigbee() {
    queueMicrotask(() => {
      const dialog =
        document.querySelector(
          'dialog[data-seb01-source-dialog]'
        );

      if (!dialog) return;

      const network =
        dialog.querySelector(
          '[data-seb01-network-filter="true"]'
        );

      if (!network) return;

      if (
        network.value !== "zigbee"
      ) {
        network.value =
          "zigbee";

        network.dispatchEvent(
          new Event(
            "change",
            {
              bubbles: true
            }
          )
        );
      }
    });
  }

  function paint(cfg, entry) {
    const target =
      ensureHost(cfg);

    if (!target) return;

    const value =
      formatState(entry);

    const admin =
      runtime.isAdmin();

    const desiredTag =
      admin
        ? "BUTTON"
        : "SPAN";

    let node =
      target.box;

    if (
      node.tagName !==
      desiredTag
    ) {
      const replacement =
        document.createElement(
          admin
            ? "button"
            : "span"
        );

      replacement.className =
        "f31-r78-state-host";

      replacement.setAttribute(
        "data-f31-r78-slot",
        cfg.slot
      );

      if (admin) {
        replacement.type =
          "button";

        replacement.addEventListener(
          "click",
          (event) => {
            event.preventDefault();
            event.stopPropagation();

            if (
              !runtime.isAdmin()
            ) {
              return;
            }

            void runtime.openSourcePicker(
              cfg.slot,
              replacement
            );

            setPickerZigbee();
          }
        );
      }

      node.replaceWith(
        replacement
      );

      node =
        replacement;
    }

    node.setAttribute(
      "data-f31-r78-state",
      value.state
    );

    node.setAttribute(
      "data-seb01-slot",
      cfg.slot
    );

    const status =
      String(
        (
          entry &&
          entry.status
        ) || ""
      )
      .trim()
      .toLowerCase();

    const text =
      admin &&
      status === "unbound"
        ? "Vybrat"
        : value.text;

    if (
      node.textContent !==
      text
    ) {
      node.textContent =
        text;
    }

    if (admin) {
      node.title =
        "UZV / SEB-01B — vybrat Zigbee spínací entitu: " +
        cfg.pickerTitle;

      node.setAttribute(
        "aria-label",
        "Vybrat Zigbee entitu — " +
        cfg.pickerTitle
      );
    } else {
      node.title =
        cfg.pickerTitle +
        ": " +
        value.text;
    }
  }

  ensureStyle();

  for (
    const cfg
    of CONFIG
  ) {
    try {
      runtime.registerAdapter({
        deviceUuid:
          DEVICE_UUID,

        slot:
          cfg.slot,

        capability:
          "switch",

        transport:
          "zigbee",

        title:
          cfg.pickerTitle,

        digits:
          0,

        locate: () => {
          const target =
            ensureHost(cfg);

          return target
            ? {
                card:
                  target.card,
                box:
                  target.box
              }
            : null;
        },

        paint: (entry) => {
          paint(
            cfg,
            entry
          );
        },

        build: () => {
          ensureHost(cfg);
        }
      });
    } catch (error) {
      console.warn(
        "R78 adapter registration failed",
        cfg.slot,
        error
      );
    }
  }
})();