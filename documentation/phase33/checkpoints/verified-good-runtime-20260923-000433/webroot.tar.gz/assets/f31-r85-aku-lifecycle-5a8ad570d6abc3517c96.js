/* F31.5.7 R85: isolated AKU symbol, shared SEB-01B reader.
 * The legacy geometric cleaner must exclude data-f31-r85-protect.
 * No device command, per-widget fetch, new reader, or credential storage.
 */
(() => {
  'use strict';
  const MARK = '__IQF_F31_R85_AKU_LIFECYCLE__';
  if (window[MARK]) return;
  window[MARK] = true;
  const ROOT = '[data-f29-00012-schema="svj-blansko-only"]';
  const DEVICE = '28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc';
  const SLOT = 'aku-circulation-pump-state';
  const NS = 'http://www.w3.org/2000/svg';
  const PERIOD_MS = 1150; // R55 / LPRS-01 circulation-pump visual cadence.
  let R = null, registered = false, current = null, frame = 0, angle = 0, previous = 0;
  let lastEntry = {has_value:false, status:'no_context', value:null};
  let layoutFrame = 0;
  const stats = {version:'F31.5.7-R85', paints:0, creates:0, lastError:'', registration:false};
  const assignText = (node, value) => { if (node.textContent !== value) node.textContent = value; };
  const attr = (node, key, value) => { if (node.getAttribute(key) !== String(value)) node.setAttribute(key,String(value)); };
  const css = (node, key, value) => { if (node.style.getPropertyValue(key) !== value) node.style.setProperty(key,value); };
  function root() {
    return Array.from(document.querySelectorAll(ROOT)).find(e => e.isConnected && e.getClientRects().length) || null;
  }
  function scopeMatches() {
    return !!(R && R.diagnostics().deviceUuid === DEVICE);
  }
  function installStyle() {
    if (document.getElementById('f31-r85-style')) return;
    const s = document.createElement('style'); s.id='f31-r85-style';
    s.textContent = `
      ${ROOT} .f29-00012-distributor {
        width:50% !important; max-width:50% !important; min-width:0 !important;
        justify-self:center !important; margin-left:auto !important; margin-right:auto !important;
      }
      ${ROOT} .f29-00012-heating-network > .f29-00012-pipe { display:none !important; }
      ${ROOT} [data-f31-r85-protect="aku-pump"] {
        --f31-r85-offset-x:-30px;
        position:absolute; left:0; top:0; width:192px; box-sizing:border-box;
        display:flex; flex-direction:column; align-items:center; gap:0;
        z-index:36; overflow:visible; pointer-events:none;
      }
      ${ROOT} [data-f31-r85-protect="aku-pump"][data-position-ready="0"] {visibility:hidden;}
      ${ROOT} .f31-r85-shell {
        flex:0 0 60px; width:60px; height:60px; box-sizing:border-box;
        border:3px solid #41cfff; border-radius:50%; background:rgba(6,18,34,.94);
        display:grid; place-items:center; position:relative;
        box-shadow:0 0 18px rgba(65,207,255,.26),inset 0 0 12px rgba(65,207,255,.10);
      }
      ${ROOT} .f31-r85-rotor {
        display:block !important; visibility:visible !important; opacity:1 !important;
        position:relative !important; width:34px !important; height:34px !important;
        transform-origin:50% 50%; animation:none !important;
      }
      ${ROOT} .f31-r85-rotor > svg {
        display:block !important; visibility:visible !important; opacity:1 !important;
        width:34px !important; height:34px !important; position:static !important;
      }
      ${ROOT} .f31-r85-rotor path {
        display:inline !important; visibility:visible !important; opacity:1 !important;
        stroke:#dff8ff !important; fill:none !important; stroke-width:2.6 !important;
        stroke-linecap:round; stroke-linejoin:round;
      }
      ${ROOT} .f31-r85-caption {
        margin-top:18px; max-width:192px; font-size:12px; line-height:1.15;
        text-align:center; font-weight:900; color:#61b2ff;
      }
      ${ROOT} .f31-r85-state-row {
        display:flex; align-items:center; justify-content:space-between; gap:8px;
        box-sizing:border-box; width:140px; min-height:24px; margin-top:6px; padding:0 6px;
        border:1px solid rgba(65,207,255,.42); border-radius:7px; background:rgba(0,22,32,.96);
        pointer-events:none;
      }
      ${ROOT} .f31-r85-state-label {font-size:10px; font-weight:900; color:#dff8ff;}
      ${ROOT} .f31-r85-state-value {
        display:inline-flex; align-items:center; justify-content:center; box-sizing:border-box;
        min-width:72px; min-height:20px; padding:0 5px; font-size:10px; font-weight:900;
        line-height:1; white-space:nowrap; border-radius:5px; color:#dff8ff;
      }
      ${ROOT} button.f31-r85-state-value {
        pointer-events:auto; cursor:pointer; border:1px solid #48d7ffa8; background:#001620;
      }
      ${ROOT} button.f31-r85-state-value:hover {background:#003d56;}
      ${ROOT} span.f31-r85-state-value {border:0; pointer-events:none;}
      ${ROOT} .f31-r85-state-value[data-state="on"] {color:#ff4d59;}
      ${ROOT} .f31-r85-state-value[data-state="unavailable"] {color:#91a9b4;}
    `;
    document.head.appendChild(s);
  }
  function restoreLayouts() {
    const hooks = window.IQF_F31_R85_LAYOUT_HOOKS || {};
    for (const key of ['R62','R72','R74','R70','R68']) {
      if (typeof hooks[key] === 'function') hooks[key]();
    }
  }
  function stop() {
    if(frame) cancelAnimationFrame(frame);
    frame=0; previous=0; angle=0;
    if(current && current.rotor.isConnected) css(current.rotor,'transform','rotate(0deg)');
  }
  function ensure() {
    const hostRoot = root();
    if(!hostRoot) {stop(); current=null; return null;}
    if(current && current.root===hostRoot && current.host.isConnected) return current;
    stop(); installStyle();
    if(getComputedStyle(hostRoot).position === 'static') css(hostRoot,'position','relative');
    const host=document.createElement('section');
    attr(host,'data-f31-r85-protect','aku-pump');
    attr(host,'data-f31-r85-widget','aku-pump');
    attr(host,'data-position-ready','0');
    attr(host,'aria-label','Oběhové čerpadlo AKU');
    const shell=document.createElement('div');shell.className='f31-r85-shell';shell.setAttribute('aria-hidden','true');
    const rotor=document.createElement('div');rotor.className='f31-r85-rotor';
    const svg=document.createElementNS(NS,'svg');
    svg.setAttribute('viewBox','0 0 32 32');svg.setAttribute('aria-hidden','true');svg.setAttribute('focusable','false');
    const path=document.createElementNS(NS,'path');
    path.setAttribute('d','M25 16a9 9 0 1 1-2.64-6.36 M22.36 4.64v5h-5');
    svg.appendChild(path);rotor.appendChild(svg);shell.appendChild(rotor);
    const caption=document.createElement('div');caption.className='f31-r85-caption';caption.textContent='Oběhové čerpadlo AKU';
    const row=document.createElement('div');row.className='f31-r85-state-row';
    const label=document.createElement('span');label.className='f31-r85-state-label';label.textContent='STAV';
    const box=document.createElement('span');box.className='f31-r85-state-value';box.textContent='—';
    attr(box,'data-seb01-slot',SLOT);row.append(label,box);host.append(shell,caption,row);hostRoot.appendChild(host);
    current={root:hostRoot,host,shell,rotor,row,box};stats.creates++;
    return current;
  }
  function position(w) {
    const aku=w.root.querySelector('.f29-00012-accumulator');
    const distributor=w.root.querySelector('.f29-00012-distributor');
    if(!aku || !distributor) {attr(w.host,'data-position-ready','0');return false;}
    const rr=w.root.getBoundingClientRect(), ar=aku.getBoundingClientRect(),dr=distributor.getBoundingClientRect();
    if(!rr.width || !rr.height || !ar.width || !dr.width) {attr(w.host,'data-position-ready','0');return false;}
    const sx=rr.width/(w.root.offsetWidth || rr.width), sy=rr.height/(w.root.offsetHeight || rr.height);
    const gap=Math.max(70,(dr.left-ar.right)/sx);
    const offset=parseFloat(getComputedStyle(w.host).getPropertyValue('--f31-r85-offset-x')) || -30;
    const x=(ar.right-rr.left)/sx - w.root.clientLeft + w.root.scrollLeft + gap*.10 + offset;
    const y=(dr.top-rr.top)/sy - w.root.clientTop + w.root.scrollTop + dr.height/sy*.14;
    css(w.host,'left',Math.max(0,x).toFixed(1)+'px');css(w.host,'top',Math.max(0,y).toFixed(1)+'px');
    attr(w.host,'data-position-ready','1');return true;
  }
  function valueOf(entry) {
    const e=entry||{}, status=String(e.status||'').trim().toLowerCase();
    if(e.available===false || ['offline','unavailable'].includes(status)) return {text:'Nedostupné',state:'unavailable'};
    if(e.has_value!==true || ['unknown','unbound','api_stale','snapshot_only','no_context','loading'].includes(status) || /^(http_|request_|wrong_device|context_)/.test(status)) return {text:'—',state:'unknown'};
    const v=e.value;
    if(v===true || v===1 || typeof v==='string' && /^(on|true|1|zapnuto)$/i.test(v.trim())) return {text:'zapnuto',state:'on'};
    if(v===false || v===0 || typeof v==='string' && /^(off|false|0|vypnuto)$/i.test(v.trim())) return {text:'vypnuto',state:'off'};
    return {text:'—',state:'unknown'};
  }
  function tick(now) {
    frame=0;
    if(!current || !current.rotor.isConnected || current.box.getAttribute('data-state')!=='on' || !scopeMatches()) {stop();return;}
    const step=previous?Math.min(100,Math.max(0,now-previous)):0;previous=now;
    angle=(angle+step*360/PERIOD_MS)%360;
    css(current.rotor,'transform',`rotate(${angle.toFixed(2)}deg)`);
    frame=requestAnimationFrame(tick);
  }
  function render(entry) {
    lastEntry=entry || {has_value:false,status:'no_context'};
    const w=ensure();if(!w)return;
    const valid=scopeMatches(), admin=valid && R.isAdmin();
    const value=valueOf(valid?lastEntry:{has_value:false,status:'no_context'});
    if(w.box.tagName !== (admin?'BUTTON':'SPAN')) {
      const box=document.createElement(admin?'button':'span');box.className='f31-r85-state-value';
      attr(box,'data-seb01-slot',SLOT);
      if(admin) {
        box.type='button';
        box.addEventListener('click',ev=>{
          ev.preventDefault();ev.stopPropagation();
          if(!R.isAdmin() || !scopeMatches() || !box.isConnected) return;
          // The runtime itself filters transport/capability and persists the selection.
          Promise.resolve(R.openSourcePicker(SLOT,box)).then(()=>{
            // Older R5 readers do not apply adapter.transport to the initial form.
            // Wait for their own catalogue request; never start another request here.
            const dialog=document.querySelector('dialog[data-seb01-source-dialog="'+SLOT+'"]');
            const network=dialog&&dialog.querySelector('[data-seb01-network-filter="true"]');
            if(!network)return;
            network.value='zigbee';network.dispatchEvent(new Event('change',{bubbles:true}));
            network.addEventListener('change',()=>{if(network.value!=='zigbee')network.value='zigbee';},true);
            network.disabled=true;network.title='Toto místo schématu vybírá Zigbee spínací entitu.';
          }).catch(()=>{stats.lastError='PICKER_FAILED';});
        });
      }
      w.box.replaceWith(box);w.box=box;
    }
    attr(w.box,'data-state',value.state);
    const missing=String(lastEntry.status||'').toLowerCase()==='unbound';
    assignText(w.box,admin && (missing || value.state==='unknown')?'Vybrat':value.text);
    attr(w.box,'title',admin?'Vybrat Zigbee spínací prvek pro zobrazení stavu; bez ovládání zařízení':'Oběhové čerpadlo AKU: '+value.text);
    if(admin) attr(w.box,'aria-label','Vybrat Zigbee spínací entitu čerpadla AKU');
    attr(w.host,'data-live-state',value.state);
    if(value.state==='on') {if(!frame) {previous=0;frame=requestAnimationFrame(tick);}} else stop();
    stats.paints++;
  }
  function locate() {
    const w=ensure(); if(!w)return null;
    restoreLayouts();position(w);
    return {card:w.host,box:w.box};
  }
  function onResize() {
    if(layoutFrame) return;
    layoutFrame=requestAnimationFrame(()=>{
      layoutFrame=0;const w=ensure();if(w){restoreLayouts();position(w);}
    });
  }
  function initialize() {
    if(registered) return;
    R=window.IQF_SEB01_RUNTIME;
    if(!R || !['registerAdapter','view','isAdmin','openSourcePicker','diagnostics'].every(k=>typeof R[k]==='function')) {
      stats.lastError='SHARED_SEB_RUNTIME_NOT_READY';return;
    }
    installStyle();
    try {
      R.registerAdapter({deviceUuid:DEVICE,slot:SLOT,capability:'switch',transport:'zigbee',
        title:'Oběhové čerpadlo AKU / stav',digits:0,locate,paint:render,
        build:()=>{const w=ensure();if(w) position(w);}});
      registered=true;stats.registration=true;stats.lastError='';
      window.addEventListener('resize',onResize,{passive:true});
      document.addEventListener('iqf-f31-r85-layout-ready',onResize);
    } catch(e) {stats.lastError=String(e && e.message || 'ADAPTER_REGISTRATION_FAILED');}
  }
  window.IQF_F31_R85_DIAGNOSTICS=()=>({...stats,rootPresent:!!root(),widgetPresent:!!(current&&current.host.isConnected),
    arrowPresent:!!(current&&current.rotor.querySelector('path')),state:current?current.box.getAttribute('data-state'):'no_root',
    role:R&&scopeMatches()?(R.isAdmin()?'admin':'client'):'no_context',slot:SLOT});
  initialize();
  document.addEventListener('DOMContentLoaded',initialize,{once:true});
  window.addEventListener('load',initialize,{once:true});
})();
