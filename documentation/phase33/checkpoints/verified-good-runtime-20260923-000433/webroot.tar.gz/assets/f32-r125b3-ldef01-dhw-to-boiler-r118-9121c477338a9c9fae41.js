(() => {
  "use strict";

  // R125B — LFB-01 + preferred R118 LDEF-01 visual profile.
  // Direction: heat pump -> boiler, driven by live DHW state slots.
  const VERSION = "F32.4I-R125B-LFB01-LDEF01-HEATPUMP-DHW-TO-BOILER-R118";
  const OVERLAY_ID = "f32-r125b-ldef01-heatpump-dhw-to-boiler";
  const STYLE_ID = "f32-r125b-ldef01-heatpump-dhw-to-boiler-style";

  const SLOT_1 = "heatpump-stage-1-dhw-state";
  const SLOT_2 = "heatpump-stage-2-dhw-state";

  const SOURCE_SELECTORS = [
    ".f29-00012-heatpump",
    ".f30-heatpump-block",
    '[data-phase28-individual-heatpump-power-combined-block="true"]'
  ];

  const TARGET_SELECTORS = [
    ".f29-00012-boiler",
    ".phase28-safe-storage-boiler-v1"
  ];

  const ON_VALUES = new Set([
    "1", "true", "on", "zapnuto",
    "active", "running", "enabled", "open"
  ]);

  let active = false;

  const norm = (value) =>
    String(value ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();

  function isVisible(node) {
    if (!node?.isConnected || typeof node.getBoundingClientRect !== "function") {
      return false;
    }

    const r = node.getBoundingClientRect();
    const s = getComputedStyle(node);

    return r.width > 0 &&
      r.height > 0 &&
      s.display !== "none" &&
      s.visibility !== "hidden" &&
      s.opacity !== "0";
  }

  function firstVisible(selectors) {
    for (const selector of selectors) {
      for (const node of document.querySelectorAll(selector)) {
        if (isVisible(node)) return node;
      }
    }
    return null;
  }

  function stateNode(slot) {
    return firstVisible([
      `[data-f30-schema-element-key="${slot}"]`,
      `[data-seb01-slot="${slot}"]`
    ]);
  }

  function stateOn(node) {
    if (!node) return false;

    return [
      node.getAttribute("data-f31-seb-state"),
      node.getAttribute("data-f31-r16-state"),
      node.getAttribute("data-state"),
      node.textContent
    ].some((value) => ON_VALUES.has(norm(value)));
  }

  function dhwIsOn() {
    return stateOn(stateNode(SLOT_1)) || stateOn(stateNode(SLOT_2));
  }

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${OVERLAY_ID} {
        position: fixed !important;
        inset: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        z-index: 2147482490 !important;
        pointer-events: none !important;
        overflow: visible !important;
        display: none !important;
      }

      #${OVERLAY_ID}[data-active="true"] {
        display: block !important;
      }

      #${OVERLAY_ID} svg {
        position: absolute !important;
        inset: 0 !important;
        width: 100% !important;
        height: 100% !important;
        overflow: visible !important;
        pointer-events: none !important;
      }

      #${OVERLAY_ID} .ldef01-halo {
        fill: none !important;
        stroke: rgba(15, 125, 180, 0.32) !important;
        stroke-width: 18 !important;
        stroke-linecap: round !important;
        stroke-linejoin: round !important;
        filter: url(#f32R125bDhwGlowWide);
      }

      #${OVERLAY_ID} .ldef01-track {
        fill: none !important;
        stroke: rgba(23, 184, 239, 0.84) !important;
        stroke-width: 7 !important;
        stroke-linecap: round !important;
        stroke-linejoin: round !important;
        filter: url(#f32R125bDhwGlow);
      }

      #${OVERLAY_ID} .ldef01-dots {
        fill: none !important;
        stroke: rgba(116, 224, 255, 1) !important;
        stroke-width: 12 !important;
        stroke-linecap: round !important;
        stroke-linejoin: round !important;
        stroke-dasharray: 1 32 !important;
        filter: url(#f32R125bDhwGlowStrong);
        animation: f32R125bDhwDots 1.70s linear infinite !important;
      }

      @keyframes f32R125bDhwDots {
        from { stroke-dashoffset: 0; }
        to { stroke-dashoffset: -66; }
      }
    `;

    document.head.appendChild(style);
  }

  function ensureOverlay() {
    let overlay = document.getElementById(OVERLAY_ID);
    if (overlay) return overlay;

    ensureStyle();

    overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    overlay.dataset.active = "false";
    overlay.dataset.lfb01 = "heatpump-dhw-state";
    overlay.dataset.ldef01 = "heatpump-dhw-to-boiler-r118";

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("preserveAspectRatio", "none");

    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
    defs.innerHTML = `
      <filter id="f32R125bDhwGlowWide" x="-80%" y="-80%" width="260%" height="260%">
        <feGaussianBlur stdDeviation="8" result="blur" />
        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
      </filter>

      <filter id="f32R125bDhwGlow" x="-60%" y="-60%" width="220%" height="220%">
        <feGaussianBlur stdDeviation="4" result="blur" />
        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
      </filter>

      <filter id="f32R125bDhwGlowStrong" x="-100%" y="-100%" width="300%" height="300%">
        <feGaussianBlur stdDeviation="5.5" result="blur" />
        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
      </filter>
    `;
    svg.appendChild(defs);

    for (const className of ["ldef01-halo", "ldef01-track", "ldef01-dots"]) {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
      path.setAttribute("class", className);
      path.setAttribute("points", "");
      svg.appendChild(path);
    }

    overlay.appendChild(svg);
    document.body.appendChild(overlay);
    return overlay;
  }

  function setActive(value) {
    active = Boolean(value);
    ensureOverlay().dataset.active = active ? "true" : "false";
  }

  function updateState() {
    const source = firstVisible(SOURCE_SELECTORS);
    const target = firstVisible(TARGET_SELECTORS);

    // LFB-01: live flow exists only if the real DHW state says ON.
    setActive(
      Boolean(source) &&
      Boolean(target) &&
      dhwIsOn()
    );
  }

  function layout() {
    const overlay = ensureOverlay();
    if (!active) return;

    const source = firstVisible(SOURCE_SELECTORS);
    const target = firstVisible(TARGET_SELECTORS);

    if (!source || !target) {
      setActive(false);
      return;
    }

    const s = source.getBoundingClientRect();
    const t = target.getBoundingClientRect();

    // Same proven R118 geometry model as TČ -> AKU:
    // source right -> horizontal -> target center -> vertical -> target top.
    const startX = Math.round(s.right);
    const startY = Math.round(s.top + s.height * 0.78);
    const targetX = Math.round(t.left + t.width * 0.50);
    const targetY = Math.round(t.top);

    if (targetX <= startX + 12 || targetY <= startY + 12) {
      setActive(false);
      return;
    }

    const points = [
      `${startX},${startY}`,
      `${targetX},${startY}`,
      `${targetX},${targetY}`
    ].join(" ");

    const svg = overlay.querySelector("svg");
    svg.setAttribute(
      "viewBox",
      `0 0 ${window.innerWidth} ${window.innerHeight}`
    );

    overlay.querySelectorAll("polyline").forEach((polyline) => {
      polyline.setAttribute("points", points);
    });
  }

  function boot() {
    ensureStyle();
    ensureOverlay();
    updateState();
    layout();

    // R118 preferred runtime rhythm.
    window.setInterval(updateState, 200);
    window.setInterval(layout, 500);

    window.addEventListener("resize", layout, { passive: true });
    window.addEventListener("scroll", layout, { passive: true });

    const api = Object.freeze({
      version: VERSION,
      slot1: SLOT_1,
      slot2: SLOT_2,
      direction: "HEATPUMP_DHW_TO_BOILER",
      active: () => active,
      updateState,
      layout
    });

    window.IQF_LFB01_R125B_DHW_FLOW = api;
    window.IQF_LDEF01_R125B_DHW_FLOW = api;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
