(() => {
  'use strict';
  const VERSION = 'F32.4K-R127';
  const UUID = '28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc';
  const API = 'https://api.tngiqfanda.cz/api/v1';
  const PANEL = 'f32-r115-settings-workspace';
  const ROOT = '[data-phase28-r177n107-workspace]';
  const STYLE = 'f32-r127-circulation-style';
  const UI_REVISION = 'F32.4K-R127R1-CIRCULATION-ROW-TITLE';
  const DIALOG = 'f32-r127-circulation-dialog';
  if (window.IQF_F32_R127_CIRCULATION) return;
  let box = null, panel = null, panelObserver = null, observer = null, modal = null;
  let status = null, selected = new Set(), editRevision = 0, message = '';
  let busy = false, loading = false, activeContext = null, epoch = 0, controller = null, stopped = false;
  let raf = 0, timer = null, lastRead = 0;
  const isVisible = n => {
    if (!n?.isConnected || n.closest('[hidden],[aria-hidden="true"]')) return false;
    const r = n.getBoundingClientRect(), s = getComputedStyle(n);
    return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
  };
  const node = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };
  function context() {
    const d = window.IQF_F32_R115_SETTINGS?.diagnostics?.();
    if (!d || d.version !== 'F32.2Q-R115-NATIVE-TAB-LIFECYCLE' || !d.open || d.nativeTab !== 'settings') return null;
    const roots = [...document.querySelectorAll(ROOT)].filter(isVisible);
    if (roots.length !== 1) return null;
    const root = roots[0], declared = root.getAttribute('data-device-uuid');
    if (declared && declared !== UUID) return null;
    const source = String(root.getAttribute('data-phase28-r177n107-source') || '').toLowerCase();
    let mode = /customer|client|portal/.test(source) && !/^admin/.test(source) ? 'portal' : /admin/.test(source) ? 'admin' : null;
    if (!mode) mode = /(^|\/)admin(?:\/|$)/.test(location.pathname) ? 'admin' : /(^|\/)(portal|customer|client)(?:\/|$)/.test(location.pathname) ? 'portal' : null;
    if (!mode) return {error: 'Nelze určit účet pracovní plochy.'};
    let token = '';
    try { token = localStorage.getItem('iqfanda_access_token') || sessionStorage.getItem('iqfanda_access_token') || ''; }
    catch (_) { return {error: 'Přihlášení není dostupné.'}; }
    if (!token) return {error: 'Přihlaste se znovu do portálu.'};
    return {mode, token, url: `${API}/${mode}/devices/${UUID}/individual-project/dhw-circulation-v1`};
  }
  const same = (a,b) => a && b && !a.error && !b.error && a.mode === b.mode && a.token === b.token;
  const editable = () => status?.can_save === true && status?.master_enabled === true;
  const errors = {
    DHW_CIRCULATION_MASTER_DISABLED: 'Ohřev teplé vody je vypnutý. Program se nezměnil.',
    DHW_CIRCULATION_SETTINGS_CONFLICT: 'Program mezitím změnil jiný uživatel. Zavřete a znovu otevřete časové nastavení.',
    DHW_CIRCULATION_CONTROL_CONFLICT: 'Čerpadlo již používá jiné řízení. Program nebyl uložen.',
    DHW_CIRCULATION_OTHER_COMMAND_IN_PROGRESS: 'Čerpadlo právě ovládá jiný příkaz. Vyčkejte a uložení opakujte.',
    DHW_CIRCULATION_PUMP_UNAVAILABLE: 'Cirkulační čerpadlo není dostupné.',
    DHW_CIRCULATION_REMOTE_DISABLED: 'Vzdálené ovládání je zakázané.',
    DHW_CIRCULATION_PUMP_IDENTITY_INVALID: 'Identita čerpadla neodpovídá instalaci.',
  };
  const errorText = e => errors[e?.code] || (e?.status === 401 ? 'Přihlaste se znovu.' :
    e?.status === 403 ? 'Účet nemá oprávnění.' : e?.status === 404 ? 'Rozhraní časového programu není dostupné.' :
    'Výsledek nebyl potvrzen. Zkontrolujte připojení a znovu načtěte program.');
  async function api(ctx, method, body, signal) {
    const response = await fetch(ctx.url, {method, signal, cache:'no-store', credentials:'omit', redirect:'error',
      headers:{Authorization:'Bearer '+ctx.token, Accept:'application/json', ...(body ? {'Content-Type':'application/json'} : {})},
      ...(body ? {body:JSON.stringify(body)} : {})});
    const data = await response.json().catch(() => null);
    if (!response.ok) throw {status:response.status, code:data?.detail?.code};
    if (data?.version !== VERSION || data?.device_uuid !== UUID || !Array.isArray(data.hours)) throw {code:'BAD_RESPONSE'};
    return data;
  }
  function ranges(hours) {
    const vals = [...hours].sort((a,b)=>a-b), out = [];
    let begin = null, previous = null;
    const push = () => {if (begin != null) out.push(`${String(begin).padStart(2,'0')}:00–${String(previous+1).padStart(2,'0')}:00`);};
    for (const h of vals) {
      if (begin == null) begin = previous = h;
      else if (h === previous+1) previous = h;
      else {push(); begin = previous = h;}
    }
    push(); return out;
  }
  function render() {
    if (!box) return;
    box.querySelector('button').disabled = !status || !editable() || busy;
    const pump = status?.pump, label = pump?.state === 'on' ? 'Zapnuto' : pump?.state === 'off' ? 'Vypnuto' : 'Nedostupné';
    let detail = message;
    if (!detail && status) {
      detail = !status.configured ? 'Program není nastavený; automatika čerpadlo zatím neovládá.' :
        !status.master_enabled ? 'Neaktivní – Ohřev teplé vody je vypnutý. Program zůstává uložený.' :
        status.fault ? 'Blokace řízení čerpadla: '+status.fault :
        status.pending ? 'Čekám na potvrzení čerpadla…' :
        label+' · '+(status.ranges.length ? status.ranges.join(', ') : 'Vypnuto celý den');
    }
    box.querySelector('.r127-detail').textContent = detail || 'Načítám časový program…';
    box.dataset.inactive = editable() ? 'false' : 'true';
    if (modal?.open) {
      modal.querySelector('.r127-selection').textContent = selected.size ? ranges(selected).join(', ') : 'Žádná vybraná hodina – čerpadlo bude celý den vypnuté.';
      for (const button of modal.querySelectorAll('[data-hour]')) {
        const on = selected.has(Number(button.dataset.hour));
        button.setAttribute('aria-pressed', String(on));
        button.disabled = busy || !editable();
      }
      for (const button of modal.querySelectorAll('[data-edit]')) button.disabled = busy || !editable();
      modal.querySelector('[data-save]').disabled = busy || !editable();
      modal.querySelector('.r127-message').textContent = message || (!editable() ? 'Neaktivní – zapněte Ohřev teplé vody; čerpadlo musí být dostupné.' : 'Vybrané hodiny = zapnuto. Ostatní hodiny = vypnuto.');
    }
  }
  function styles() {
    if (document.getElementById(STYLE)) return;
    const style = node('style'); style.id = STYLE;
    style.textContent = `
      [data-r127-circulation-row]{display:flex;flex-direction:column;justify-content:center;gap:5px;min-width:0;height:100%;box-sizing:border-box;padding:7px 13px;color:#edfaff;font:inherit}
      [data-r127-circulation-row] .r127-line{display:flex;justify-content:flex-end;align-items:center;gap:9px;min-width:0}
      [data-r127-circulation-row] .r127-title{font-size:clamp(12px,.95vw,17px);font-weight:850;line-height:1.2}
      [data-r127-circulation-row] .r127-detail{font-size:10px;color:#a3c5d0;line-height:1.2;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}
      [data-r127-circulation-row] button{font:inherit;font-size:12px;padding:6px 10px;white-space:nowrap;color:#eefcff;background:#092c3a;border:1px solid #3086a1;border-radius:7px;cursor:pointer}
      [data-r127-circulation-row] button:disabled{opacity:.5;cursor:not-allowed}
      [data-r127-circulation-row][data-inactive="true"] .r127-title{opacity:.55}
      #${DIALOG}{box-sizing:border-box;width:min(790px,94vw);max-height:78vh;overflow:auto;padding:24px;border:1px solid #27b9df;border-radius:18px;background:#062331;color:#ecfbff;font:15px/1.45 system-ui,sans-serif;box-shadow:0 20px 90px #0009}
      #${DIALOG}::backdrop{background:#001019c9}
      #${DIALOG} h2{margin:0 0 5px;font-size:23px;font-weight:800}
      #${DIALOG} p{margin:7px 0 14px;color:#b5d1dc}
      #${DIALOG} .r127-hours{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px}
      #${DIALOG} button{font:inherit;border:1px solid #347488;color:#effaff;background:#103440;border-radius:9px;padding:9px 10px;cursor:pointer}
      #${DIALOG} button[data-hour]{padding:12px 3px;font-size:12px;font-weight:650}
      #${DIALOG} button[aria-pressed="true"]{background:#0d857e;border-color:#70f4de;color:white;box-shadow:inset 0 0 0 1px #70f4de}
      #${DIALOG} button[aria-pressed="true"]::before{content:'✓ ';font-weight:900}
      #${DIALOG} button:focus-visible,[data-r127-circulation-row] button:focus-visible{outline:2px solid #77e6ff;outline-offset:3px}
      #${DIALOG} button:disabled{opacity:.45;cursor:not-allowed}
      #${DIALOG} .r127-actions{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-top:18px}
      #${DIALOG} .r127-actions>div{display:flex;gap:8px}
      #${DIALOG} [data-save]{background:#146966;border-color:#50d1c0;font-weight:750}
      #${DIALOG} .r127-selection{margin-top:16px;min-height:24px;font-weight:650}
      #${DIALOG} .r127-message{min-height:20px;font-size:12px;color:#b5d1dc}
      @media(max-width:620px){#${DIALOG}{padding:16px}#${DIALOG} .r127-hours{grid-template-columns:repeat(4,minmax(0,1fr))}}
    `;
    document.head.append(style);
  }
  function ensureModal() {
    if (modal) return;
    modal = node('dialog'); modal.id = DIALOG;
    modal.setAttribute('aria-labelledby', 'f32-r127-dialog-title');
    const heading = node('h2','','Cirkulační čerpadlo'); heading.id = 'f32-r127-dialog-title';
    const help = node('p','','Denní časový program · Europe/Prague. Vyberte hodiny, během kterých má čerpadlo běžet. Program se opakuje každý den.');
    const hours = node('div','r127-hours');
    for (let h=0;h<24;h++) {
      const label = `${String(h).padStart(2,'0')}:00–${String(h+1).padStart(2,'0')}:00`;
      const b = node('button','',label); b.type='button'; b.dataset.hour=String(h);
      b.setAttribute('aria-label',label); b.setAttribute('aria-pressed','false');
      b.addEventListener('click',()=>{if (!busy && editable()) {selected.has(h)?selected.delete(h):selected.add(h);message='';render();}});
      hours.append(b);
    }
    const summary = node('div','r127-selection'), msg = node('div','r127-message'); msg.setAttribute('aria-live','polite');
    const actions = node('div','r127-actions'), bulk = node('div'), submit = node('div');
    const all = node('button','','Celý den'); all.type='button'; all.dataset.edit='all';
    const none = node('button','','Žádná hodina'); none.type='button'; none.dataset.edit='none';
    const cancel = node('button','','Zrušit'); cancel.type='button';
    const save = node('button','','Uložit program'); save.type='button'; save.dataset.save='true';
    all.onclick = ()=>{if(editable()&&!busy){selected=new Set(Array.from({length:24},(_,i)=>i));render();}};
    none.onclick = ()=>{if(editable()&&!busy){selected.clear();render();}};
    cancel.onclick = ()=>modal.close(); save.onclick = saveProgram;
    bulk.append(all,none); submit.append(cancel,save); actions.append(bulk,submit);
    modal.append(heading,help,hours,summary,msg,actions); document.body.append(modal);
    modal.addEventListener('close',()=>{box?.querySelector('button')?.focus();render();});
  }
  function openModal() {
    if (!status || !editable() || busy) return;
    ensureModal(); selected = new Set(status.hours); editRevision=status.revision; message='';
    modal.showModal(); render();
  }
  async function refresh() {
    const ctx = context();
    if (stopped || busy || loading || !ctx || ctx.error || document.hidden) return;
    loading=true; const own=epoch; controller=new AbortController();
    const abort=controller, timeout=setTimeout(()=>abort.abort(),12000);
    try {
      const data = await api(ctx,'GET',null,abort.signal);
      if (own===epoch && same(ctx,context())) {status=data;lastRead=Date.now();if(!modal?.open)message='';render();}
    } catch(e) {
      if (own===epoch && same(ctx,context())) {status=null;message=errorText(e);render();}
    } finally {clearTimeout(timeout);loading=false;}
  }
  async function saveProgram() {
    if (!modal?.open || !editable() || busy || !crypto?.randomUUID) return;
    const ctx=context(); if (!ctx || ctx.error) return;
    epoch++;controller?.abort();busy=true;message='Ukládám…';render();
    const abort=new AbortController(), timeout=setTimeout(()=>abort.abort(),20000), own=epoch;
    try {
      const data=await api(ctx,'PUT',{hours:[...selected].sort((a,b)=>a-b),expected_revision:editRevision,request_id:crypto.randomUUID()},abort.signal);
      if (own===epoch && same(ctx,context())) {status=data;message='Program uložen. Řízení se řídí aktuální hodinou.';modal.close();}
    } catch(e) {if (own===epoch && same(ctx,context())) message=errorText(e);}
    finally {clearTimeout(timeout);busy=false;render();if (same(ctx,context())) setTimeout(refresh,300);}
  }
  function sync() {
    raf=0;if(stopped)return;
    const current=document.getElementById(PANEL);
    if(panel!==current){panelObserver?.disconnect();panel=current;if(panel){panelObserver=new MutationObserver(wake);panelObserver.observe(panel,{attributes:true,attributeFilter:['data-open'],childList:true});}}
    const slot=panel?.querySelector('[data-settings-column="boiler"] [data-setting-slot="boiler-07"]');
    if(slot && box?.parentNode!==slot && [...slot.children].every(c=>c===box)) {
      box?.remove();box=node('div');box.dataset.r127CirculationRow='7';
      const heading=node('div','r127-title','Nastavení cirkulačního čerpadla'), line=node('div','r127-line'), button=node('button','','Časové nastavení');
      button.type='button';button.addEventListener('click',openModal);line.append(button);
      box.append(heading,line,node('div','r127-detail'));slot.append(box);styles();render();
    }
    const ctx=context();
    if (!ctx || ctx.error || document.hidden) {
      if(activeContext){epoch++;controller?.abort();activeContext=null;status=null;message=ctx?.error||'';if(modal?.open)modal.close();render();}
      return;
    }
    if(!same(ctx,activeContext)){epoch++;controller?.abort();activeContext=ctx;status=null;message='';lastRead=0;}
    if(!loading&&!busy&&Date.now()-lastRead>=4000)refresh();
  }
  function wake(){if(!stopped&&!raf)raf=requestAnimationFrame(sync);}
  function boot(){
    observer=new MutationObserver(records=>{if(records.some(r=>[...r.addedNodes,...r.removedNodes].some(n=>n.nodeType===1&&(n.id===PANEL||n.matches?.('[data-setting-slot]')||n.querySelector?.('#'+PANEL)))))wake();});
    observer.observe(document.body,{childList:true,subtree:true});
    timer=setInterval(wake,5000);
    ['pageshow','popstate','hashchange','storage'].forEach(e=>window.addEventListener(e,wake));
    document.addEventListener('visibilitychange',wake);wake();
  }
  window.IQF_F32_R127_CIRCULATION=Object.freeze({version:VERSION,refresh,
    diagnostics:()=>({version:VERSION,mounted:box?.isConnected===true,configured:status?.configured??false,phase:status?.phase??null}),
    dispose:()=>{stopped=true;clearInterval(timer);controller?.abort();observer?.disconnect();panelObserver?.disconnect();box?.remove();modal?.remove();}});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
