(function phase30Seb01BivalenceTemperature00012() {
  "use strict";
  // F30_04C_R4_SHARED_RUNTIME_ADAPTER
  var R = window.IQF_SEB01_RUNTIME;
  if (!R) throw new Error("SEB01_RUNTIME_NOT_LOADED");

  var MARKER = "__F30_03B_SEB01_BIVALENCE_TEMPERATURE_00012__";

  if (window[MARKER]) return;

  window[MARKER] = true;

  var BINDING_URL =
    "/phase30-model00012-bivalence-temperature-seb01-v1.json?v=20260915-022032";

  var STORE_KEY =
    "f30_03b_seb01_model00012_bivalence_temperature";

  var STYLE_ID =
    "f30-03b-seb01-bivalence-temperature-style";

  var cachedData = null;
  var optionByUid = {};
  var selectedPending = null;
  var userInteractingUntil = 0;

  function text(value) {
    return value === null || value === undefined
      ? ""
      : String(value).trim();
  }

  function normalize(value) {
    return text(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  }

  function compact(value) {
    return normalize(value)
      .replace(/[^a-z0-9]+/g, "");
  }

  function isAdminPage() { return R.isAdmin(); }

  function number(value) {
    if (
      typeof value === "number" &&
      Number.isFinite(value)
    ) {
      return value;
    }

    if (typeof value === "string") {
      var match = value
        .replace(",", ".")
        .match(/-?\d+(?:\.\d+)?/);

      if (match) {
        var n = Number(match[0]);

        if (Number.isFinite(n)) {
          return n;
        }
      }
    }

    return null;
  }

  function formatValue(option) { return R.format(option, "\u00b0C", 1); }

  function findSchema() {
    /* F33.R45: true 00012 behavior remains original. */
    if (document.querySelector(
      '[data-phase28-r177n107-workspace="universal-individual-admin-client-clone"]' +
      '[data-f33-r34-current-device-uuid="014a0d23-d440-4131-abb4-28a860595043"]'
    )) { return null; }

    return document.querySelector(
      '[data-f29-00012-schema="svj-blansko-only"], .f29-00012-schema-v2'
    );
  }

  function findBivalenceCard(schema) {
    if (!schema) return null;

    var direct = schema.querySelector(
      ".f29-00012-bivalence,.f29-00012-bivalence-tuv,.f29-00012-bivalence-card"
    );

    if (direct) return direct;

    var nodes = Array.prototype.slice.call(
      schema.querySelectorAll(
        "section,article,div"
      )
    );

    var matches = nodes.filter(function(el) {
      var c = compact(
        el.textContent || ""
      );

      if (
        c.indexOf(
          "bivalencetuvcztblansko"
        ) === -1
      ) {
        return false;
      }

      var r =
        el.getBoundingClientRect();

      return (
        r.width >= 250 &&
        r.width <= 600 &&
        r.height >= 180 &&
        r.height <= 500
      );
    });

    matches.sort(function(a, b) {
      var ar =
        a.getBoundingClientRect();
      var br =
        b.getBoundingClientRect();

      return (
        ar.width * ar.height -
        br.width * br.height
      );
    });

    return matches[0] || null;
  }

  function findTemperatureRow(card) {
    if (!card) return null;

    var direct = card.querySelector(
      '[data-f30-03a-r2="temperature"]'
    );

    if (direct) return direct;

    var nodes = Array.prototype.slice.call(
      card.querySelectorAll("div")
    );

    for (var i = 0; i < nodes.length; i += 1) {
      var c = compact(
        nodes[i].textContent || ""
      );

      if (
        c.indexOf("teplota") !== -1
      ) {
        var r =
          nodes[i].getBoundingClientRect();

        if (
          r.height >= 20 &&
          r.height <= 70
        ) {
          return nodes[i];
        }
      }
    }

    return null;
  }

  function findTemperatureValueNode(row) {
    if (!row) return null;

    var direct = row.querySelector(
      ".f30-03a-r2-temp-value"
    );

    if (direct) return direct;

    var spans = Array.prototype.slice.call(
      row.querySelectorAll(
        "span,strong,b"
      )
    );

    for (var i = 0; i < spans.length; i += 1) {
      var t = text(
        spans[i].textContent
      );

      if (
        t.indexOf("\u00b0C") !== -1 ||
        t.indexOf("\u2014") !== -1
      ) {
        return spans[i];
      }
    }

    return null;
  }

  function ensureStyle() {
    if (
      document.getElementById(STYLE_ID)
    ) {
      return;
    }

    var style =
      document.createElement("style");

    style.id = STYLE_ID;

    style.textContent = [
      ".f30-03b-picker{margin-top:.5rem;padding:.65rem;border:1px solid rgba(93,203,255,.38);border-radius:12px;background:rgba(2,22,34,.96);display:grid;gap:.45rem;position:relative;z-index:6;width:100%;box-sizing:border-box;}",
      ".f30-03b-picker label{display:grid;gap:.35rem;color:#d9f5ff;font-size:.68rem;font-weight:900;letter-spacing:.04em;text-transform:uppercase;}",
      ".f30-03b-picker select{width:100%;min-height:34px;border-radius:9px;border:1px solid rgba(124,221,255,.42);background:#061b28;color:#f1fbff;padding:.4rem .5rem;font-size:.76rem;}",
      ".f30-03b-actions{display:flex;justify-content:flex-end;}",
      ".f30-03b-picker button{border:1px solid rgba(124,221,255,.55);background:rgba(34,184,255,.20);color:#e7fbff;border-radius:9px;padding:.4rem .7rem;font-weight:900;font-size:.72rem;cursor:pointer;}",
      ".f30-03b-picker button:disabled{opacity:.45;cursor:not-allowed;}",
      ".f30-03b-picker small{color:#9dc8d7;font-size:.66rem;line-height:1.25;}",
      ".f30-03b-status{color:#75f0b3!important;}",
      ".f30-03b-warning{color:#ffd47a!important;}"
    ].join("\n");

    document.head.appendChild(style);
  }

  async function loadData() { return cachedData; }

  function loadLocalBinding() {
    try {
      var raw =
        window.localStorage.getItem(
          STORE_KEY
        );

      if (raw) {
        return JSON.parse(raw);
      }
    } catch (error) {}

    return null;
  }

  async function saveLocalBinding(binding) {
    try { await R.save("bivalence-temperature", binding); return true; }
    catch (error) { return false; }
  }

  function selectedOption(
    options,
    binding
  ) {
    if (!binding) return null;

    var uid =
      text(binding.uid);

    if (uid) {
      for (
        var i = 0;
        i < options.length;
        i += 1
      ) {
        if (
          text(options[i].uid) === uid
        ) {
          return options[i];
        }
      }
    }

    var deviceName =
      compact(binding.device_name);

    var entityName =
      compact(binding.entity_name);

    for (
      var j = 0;
      j < options.length;
      j += 1
    ) {
      if (
        deviceName &&
        entityName &&
        compact(
          options[j].device_name
        ) === deviceName &&
        compact(
          options[j].entity_name
        ) === entityName
      ) {
        return options[j];
      }
    }

    return binding;
  }

  function applyValue(option) {
    var card = findBivalenceCard(findSchema());
    var box = findTemperatureRow(card);
    if (!box) return;
    R.paintText(box, findTemperatureValueNode, R.view("bivalence-temperature", "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc"), "\u00b0C", 1, "bivalence-temperature");
  }

  function optionValueText(option) {
    var display =
      text(option.display_value)
      .replace("Ă‚Â°C", "\u00b0C")
      .replace("Ă‚Â°", "\u00b0");

    if (display) {
      return display;
    }

    var value =
      text(option.value);

    return value || "\u2014";
  }

  function addGroup(
    select,
    label,
    options
  ) {
    if (
      !options ||
      !options.length
    ) {
      return;
    }

    var group =
      document.createElement(
        "optgroup"
      );

    group.label = label;

    options.forEach(
      function(option) {
        var uid =
          text(option.uid);

        if (!uid) {
          uid =
            "f30_03b_" +
            Object.keys(
              optionByUid
            ).length;
        }

        optionByUid[uid] =
          option;

        var item =
          document.createElement(
            "option"
          );

        item.value = uid;

        item.textContent = [
          text(
            option.entity_name ||
            "Entita"
          ),
          optionValueText(option)
        ]
          .filter(Boolean)
          .join(" - ");

        group.appendChild(item);
      }
    );

    select.appendChild(group);
  }

  function currentSelected(
    select
  ) {
    if (!select) return null;

    var uid =
      text(select.value);

    if (!uid) return null;

    return optionByUid[uid] || null;
  }

  function buildAdminPicker(
    card,
    data,
    selected
  ) {
    if (
      card.querySelector(
        ".f30-03b-picker"
      )
    ) {
      return;
    }

    ensureStyle();
    optionByUid = {};

    var row =
      findTemperatureRow(card);

    if (!row) return;

    var picker =
      document.createElement(
        "div"
      );

    picker.className =
      "f30-03b-picker";

    picker.setAttribute(
      "data-f30-03b-seb01",
      "bivalence-temperature"
    );

    picker.innerHTML =
      '<label>Teplota bivalence - SEB-01<select></select></label>' +
      '<small>Vyber zdroj z modelu 00012. Doporuceno: Teplota bivalence / Teplota.</small>' +
      '<div class="f30-03b-actions"><button type="button" class="f30-03b-save" disabled>Ulozit</button></div>' +
      '<small class="f30-03b-status"></small>';

    row.insertAdjacentElement(
      "afterend",
      picker
    );

    var select =
      picker.querySelector(
        "select"
      );

    var saveButton =
      picker.querySelector(
        ".f30-03b-save"
      );

    var status =
      picker.querySelector(
        ".f30-03b-status"
      );

    var empty =
      document.createElement(
        "option"
      );

    empty.value = "";

    empty.textContent =
      data.options.length
        ? "Vyber zarizeni / entitu..."
        : "Katalog modelu 00012 je prazdny";

    select.appendChild(empty);

    addGroup(
      select,
      "Doporuceno pro Bivalenci",
      data.recommended || []
    );

    (data.devices || [])
      .forEach(
        function(device) {
          var prefix =
            device.transport === "wifi"
              ? "Wi-Fi"
              : "Zigbee";

          addGroup(
            select,
            prefix +
              " - " +
              text(
                device.device_name ||
                "zarizeni"
              ),
            device.entities || []
          );
        }
      );

    var effective =
      selected ||
      data.selected;

    if (
      effective &&
      text(effective.uid) &&
      optionByUid[
        text(effective.uid)
      ]
    ) {
      select.value =
        text(effective.uid);
    }

    function markInteracting() {
      userInteractingUntil =
        Date.now() + 60000;
    }

    function refreshStatus() {
      var chosen =
        currentSelected(select);

      selectedPending = chosen;

      saveButton.disabled =
        !chosen;

      if (!status) return;

      if (chosen) {
        status.className =
          "f30-03b-status";

        status.textContent =
          "Vybrano: " +
          text(
            chosen.device_name ||
            "zarizeni"
          ) +
          " / " +
          text(
            chosen.entity_name ||
            "entita"
          ) +
          " = " +
          optionValueText(chosen) +
          ". Potvrd tlacitkem Ulozit.";
      } else {
        status.className =
          "f30-03b-status";

        status.textContent =
          "SEB-01: vyber zdroj teploty bivalence.";
      }
    }

    [
      "focus",
      "pointerdown",
      "mousedown",
      "keydown",
      "input",
      "change",
      "click"
    ].forEach(
      function(eventName) {
        select.addEventListener(
          eventName,
          markInteracting
        );
      }
    );

    select.addEventListener(
      "input",
      refreshStatus
    );

    select.addEventListener(
      "change",
      refreshStatus
    );

    saveButton.addEventListener(
      "click",
      async function() {
        markInteracting();

        var chosen =
          currentSelected(select) ||
          selectedPending;

        if (!chosen) {
          refreshStatus();
          return;
        }

        var ok = await saveLocalBinding(chosen);
        if (!ok) {
          if (status) status.textContent = "Ulozeni vazby na server selhalo; vyber nebyl potvrzen.";
          return;
        }

        data.selected = chosen;
        cachedData.selected =
          chosen;

        applyValue(chosen);

        if (status) {
          status.className =
            "f30-03b-status" +
            (
              ok
                ? ""
                : " f30-03b-warning"
            );

          status.textContent = R.saveMessage("bivalence-temperature", "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc");
        }
      }
    );

    if (effective) {
      applyValue(effective);
    }

    refreshStatus();
  }

  R.registerAdapter({
    deviceUuid: "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc", slot: "bivalence-temperature", capability: "temperature",
    digits: 1, legacy: loadLocalBinding,
    pickerSelector: ".f30-03b-picker", statusSelector: ".f30-03b-status",
    locate: function() { var card=findBivalenceCard(findSchema()); return card ? {card:card,box:findTemperatureRow(card)} : null; },
    paint: function(entry) { applyValue(entry); },
    build: function(data,selected) { cachedData=data; var card=findBivalenceCard(findSchema()); if(card) buildAdminPicker(card,data,selected); }
  });
})();

;window.__F33_R45_SCOPED_00012_BIV_TEMP__="F33_R45_SCOPED_00012_BIV_TEMP";
