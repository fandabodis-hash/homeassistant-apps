(() => {
  "use strict";

  const VERSION = "F32.4J-R126";
  const PANEL = "f32-r115-settings-workspace";
  const ROOT = "[data-phase28-r177n107-workspace]";
  const UUID = "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc";
  const API = "https://api.tngiqfanda.cz/api/v1";
  const STYLE_ID = "f32-r126-dhw-disinfection-style";

  if (window.IQF_F32_R126_DHW_DISINFECTION) return;

  let panel = null;
  let boxes = [];
  let observer = null;
  let panelObserver = null;
  let timer = null;
  let request = null;
  let epoch = 0;
  let raf = 0;
  let pending = false;
  let fetching = false;
  let stopped = false;

  let status = null;
  let message = "";
  let dirty = false;
  let draftRevision = 0;

  let draft = {
    disinfection_c: null,
    disinfection_weekday: null,
  };

  const weekdays = [
    "Pondělí",
    "Úterý",
    "Středa",
    "Čtvrtek",
    "Pátek",
    "Sobota",
    "Neděle",
  ];

  function visible(node) {
    if (!node?.isConnected) return false;

    const rect = node.getBoundingClientRect();
    const style = getComputedStyle(node);

    return (
      rect.width > 0 &&
      rect.height > 0 &&
      style.visibility !== "hidden" &&
      style.display !== "none" &&
      !node.closest('[hidden],[aria-hidden="true"]')
    );
  }

  function context() {
    const state =
      window.IQF_F32_R115_SETTINGS?.diagnostics?.();

    if (
      !state ||
      state.version !== "F32.2Q-R115-NATIVE-TAB-LIFECYCLE" ||
      !state.open ||
      state.nativeTab !== "settings"
    ) {
      return null;
    }

    const roots = [
      ...document.querySelectorAll(ROOT),
    ].filter(visible);

    if (roots.length !== 1) return null;

    const root = roots[0];

    const declared =
      root.getAttribute("data-device-uuid");

    if (declared && declared !== UUID) {
      return null;
    }

    const source = String(
      root.getAttribute(
        "data-phase28-r177n107-source"
      ) || ""
    ).toLowerCase();

    let mode = null;

    if (
      /customer|client|portal/.test(source) &&
      !/^admin/.test(source)
    ) {
      mode = "portal";
    } else if (/admin/.test(source)) {
      mode = "admin";
    } else if (
      /(^|\/)admin(?:\/|$)/.test(
        location.pathname
      )
    ) {
      mode = "admin";
    } else if (
      /(^|\/)(portal|customer|client)(?:\/|$)/
        .test(location.pathname)
    ) {
      mode = "portal";
    }

    if (!mode) {
      return {
        error:
          "Nelze určit účet pracovní plochy.",
      };
    }

    let token = "";

    try {
      token =
        localStorage.getItem(
          "iqfanda_access_token"
        ) ||
        sessionStorage.getItem(
          "iqfanda_access_token"
        ) ||
        "";
    } catch (_) {
      return {
        error:
          "Přihlášení není dostupné.",
      };
    }

    if (!token) {
      return {
        error:
          "Přihlaste se znovu do portálu.",
      };
    }

    return {
      mode,
      token,
      base:
        API +
        "/" +
        mode +
        "/devices/" +
        UUID +
        "/individual-project/",
    };
  }

  function same(ctx) {
    const current = context();

    return Boolean(
      current &&
      !current.error &&
      current.mode === ctx.mode &&
      current.token === ctx.token
    );
  }

  async function api(
    ctx,
    method,
    body,
    signal
  ) {
    const response = await fetch(
      ctx.base + "dhw-disinfection-v1",
      {
        method,
        signal,
        cache: "no-store",
        credentials: "omit",
        redirect: "error",
        headers: {
          Authorization:
            "Bearer " + ctx.token,
          Accept: "application/json",
          ...(body
            ? {
                "Content-Type":
                  "application/json",
              }
            : {}),
        },
        ...(body
          ? {
              body: JSON.stringify(body),
            }
          : {}),
      }
    );

    const value =
      await response
        .json()
        .catch(() => null);

    if (!response.ok) {
      throw {
        status: response.status,
        code: value?.detail?.code,
      };
    }

    if (
      value?.version !== VERSION ||
      value?.device_uuid !== UUID
    ) {
      throw {
        code: "BAD_RESPONSE",
      };
    }

    return value;
  }

  const errors = {
    DHW_DISINFECTION_SETTINGS_RANGE:
      "Teplota musí být 55–65 °C a den Pondělí–Neděle.",
    DHW_DISINFECTION_SETTINGS_CONFLICT:
      "Nastavení mezitím změnil jiný uživatel. Obnovuji hodnoty.",
    DHW_DISINFECTION_MASTER_DISABLED:
      "Ohřev teplé vody je vypnutý.",
    DHW_DISINFECTION_BIVALENCE_REQUIRED:
      "Nejdříve nastavte Bod bivalence.",
    DHW_DISINFECTION_BIVALENCE_UNAVAILABLE:
      "Bivalentní spínač není dostupný.",
    DHW_DISINFECTION_CYCLE_ACTIVE:
      "Probíhající cyklus nelze během běhu přenastavit.",
  };

  function errorText(error) {
    return (
      errors[error?.code] ||
      (error?.status === 401
        ? "Přihlaste se znovu."
        : error?.status === 403
          ? "Účet nemá oprávnění."
          : error?.status === 404
            ? "Rozhraní dezinfekce zatím není dostupné."
            : "Nastavení nebylo potvrzeno.")
    );
  }

  function text(node, value) {
    if (
      node &&
      node.textContent !== value
    ) {
      node.textContent = value;
    }
  }

  function node(tag, cls, value) {
    const element =
      document.createElement(tag);

    if (cls) {
      element.className = cls;
    }

    if (value != null) {
      element.textContent = value;
    }

    return element;
  }

  function canEdit() {
    return Boolean(
      status?.master_enabled === true &&
      status?.can_save === true &&
      status?.active !== true
    );
  }

  function ensureStyle() {
    if (
      document.getElementById(
        STYLE_ID
      )
    ) {
      return;
    }

    const style =
      document.createElement("style");

    style.id = STYLE_ID;

    style.textContent = `
      [data-r126-disinfection-row] {
        display:flex;
        flex-direction:column;
        justify-content:center;
        gap:5px;
        height:100%;
        box-sizing:border-box;
        padding:7px 13px;
        color:#edfaff;
        min-width:0;
        font:inherit;
      }

      [data-r126-disinfection-row] .main {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:9px;
        min-width:0;
      }

      [data-r126-disinfection-row] .title {
        font-weight:850;
        font-size:clamp(12px,.95vw,17px);
        line-height:1.2;
      }

      [data-r126-disinfection-row] .detail {
        font-size:10px;
        line-height:1.15;
        color:#a3c5d0;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
      }

      [data-r126-disinfection-row] select {
        font:inherit;
        font-size:13px;
        color:#eefcff;
        background:#092c3a;
        border:1px solid #3086a1;
        border-radius:7px;
        padding:5px 8px;
        width:132px;
        max-width:44%;
        min-width:108px;
        cursor:pointer;
      }

      [data-r126-disinfection-row] select:focus-visible {
        outline:2px solid #69dfff;
        outline-offset:2px;
      }

      [data-r126-disinfection-row] select option {
        background:#092c3a;
        color:#fff;
      }

      [data-r126-disinfection-row] select:disabled {
        opacity:.5;
        cursor:not-allowed;
      }

      [data-r126-disinfection-row][data-inactive="true"] .title {
        opacity:.55;
      }

      @media(max-width:1400px) {
        [data-r126-disinfection-row] {
          padding:6px 9px;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function render() {
    if (boxes.length !== 2) return;

    const [temperatureBox, weekdayBox] =
      boxes;

    const temperatureSelect =
      temperatureBox.querySelector(
        "select"
      );

    const weekdaySelect =
      weekdayBox.querySelector(
        "select"
      );

    const temperatureValue =
      draft.disinfection_c;

    const weekdayValue =
      draft.disinfection_weekday;

    if (
      temperatureSelect.value !==
      (temperatureValue == null
        ? ""
        : String(temperatureValue))
    ) {
      temperatureSelect.value =
        temperatureValue == null
          ? ""
          : String(temperatureValue);
    }

    if (
      weekdaySelect.value !==
      (weekdayValue == null
        ? ""
        : String(weekdayValue))
    ) {
      weekdaySelect.value =
        weekdayValue == null
          ? ""
          : String(weekdayValue);
    }

    const enabled = canEdit();

    for (const box of boxes) {
      box.dataset.inactive =
        enabled ? "false" : "true";

      box.setAttribute(
        "aria-disabled",
        enabled ? "false" : "true"
      );
    }

    temperatureSelect.disabled =
      pending || !enabled;

    weekdaySelect.disabled =
      pending || !enabled;

    if (message) {
      text(
        weekdayBox.querySelector(
          ".detail"
        ),
        message
      );
    } else if (
      status?.active === true
    ) {
      text(
        weekdayBox.querySelector(
          ".detail"
        ),
        "Probíhá vysokoteplotní cyklus · stav: " +
          String(
            status.phase || "aktivní"
          )
      );
    } else if (
      status?.master_enabled !== true
    ) {
      text(
        weekdayBox.querySelector(
          ".detail"
        ),
        "Neaktivní – Ohřev teplé vody je vypnutý."
      );
    } else if (
      draft.disinfection_c != null &&
      draft.disinfection_weekday != null
    ) {
      text(
        weekdayBox.querySelector(
          ".detail"
        ),
        weekdays[
          draft.disinfection_weekday
        ] +
          " v 00:01 · bivalentní zdroj"
      );
    } else {
      text(
        weekdayBox.querySelector(
          ".detail"
        ),
        dirty
          ? "Vyberte obě hodnoty; uloží se společně."
          : "Vyberte teplotu a den."
      );
    }

    const current =
      status?.temperature;

    text(
      temperatureBox.querySelector(
        ".detail"
      ),
      current?.valid === true &&
      typeof current.value_c === "number"
        ? "Aktuální teplota bojleru: " +
            current.value_c.toLocaleString(
              "cs-CZ",
              {
                maximumFractionDigits: 1,
              }
            ) +
            " °C"
        : "Aktuální teplota bojleru: nedostupná"
    );
  }

  function accept(value) {
    status = value;

    if (!dirty) {
      draft = {
        disinfection_c:
          value.disinfection_c ?? null,
        disinfection_weekday:
          value.disinfection_weekday ??
          null,
      };

      draftRevision =
        value.revision;
    }

    render();
  }

  function schedule(ms) {
    clearTimeout(timer);

    timer = setTimeout(
      () => {
        timer = null;
        refresh();
      },
      ms
    );
  }

  async function refresh() {
    if (
      fetching ||
      pending ||
      stopped
    ) {
      return;
    }

    const ctx = context();

    if (!ctx || document.hidden) {
      return;
    }

    if (ctx.error) {
      status = null;
      message = ctx.error;
      render();
      return;
    }

    fetching = true;

    const own = ++epoch;
    request =
      new AbortController();

    const abort = request;

    const timeout = setTimeout(
      () => abort.abort(),
      12000
    );

    try {
      const value = await api(
        ctx,
        "GET",
        null,
        abort.signal
      );

      if (
        own === epoch &&
        same(ctx)
      ) {
        message = "";
        accept(value);
      }
    } catch (error) {
      if (own === epoch) {
        status = null;
        message =
          errorText(error);
        render();
      }
    } finally {
      clearTimeout(timeout);
      fetching = false;

      if (
        own === epoch &&
        !stopped &&
        same(ctx) &&
        !document.hidden
      ) {
        schedule(5000);
      }
    }
  }

  async function save() {
    if (
      pending ||
      !status ||
      !canEdit() ||
      draft.disinfection_c == null ||
      draft.disinfection_weekday == null
    ) {
      return;
    }

    if (!crypto?.randomUUID) {
      message =
        "Ovládání vyžaduje HTTPS.";
      render();
      return;
    }

    const ctx = context();

    if (!ctx || ctx.error) {
      return;
    }

    clearTimeout(timer);
    timer = null;
    epoch++;
    request?.abort();

    pending = true;
    message = "";

    render();

    const abort =
      new AbortController();

    const timeout = setTimeout(
      () => abort.abort(),
      20000
    );

    try {
      const value = await api(
        ctx,
        "PUT",
        {
          disinfection_c:
            draft.disinfection_c,
          disinfection_weekday:
            draft.disinfection_weekday,
          expected_revision:
            draftRevision,
          request_id:
            crypto.randomUUID(),
        },
        abort.signal
      );

      if (same(ctx)) {
        dirty = false;
        message =
          "Nastavení uloženo.";
        accept(value);
      }
    } catch (error) {
      if (same(ctx)) {
        message =
          errorText(error);

        if (
          error?.code ===
          "DHW_DISINFECTION_SETTINGS_CONFLICT"
        ) {
          dirty = false;
        }
      }
    } finally {
      clearTimeout(timeout);
      pending = false;
      render();

      if (same(ctx)) {
        schedule(1000);
      }
    }
  }

  function changeField(
    key,
    value
  ) {
    if (
      !status ||
      pending ||
      !canEdit()
    ) {
      render();
      return;
    }

    if (!dirty) {
      draftRevision =
        status.revision;
    }

    draft[key] =
      value === ""
        ? null
        : Number(value);

    dirty = true;
    message = "";

    render();

    if (
      draft.disinfection_c != null &&
      draft.disinfection_weekday != null
    ) {
      save();
    }
  }

  function build() {
    const tempBox =
      node("div");

    tempBox.dataset.r126DisinfectionRow =
      "5";

    const tempLine =
      node("div", "main");

    const tempLabel =
      node(
        "label",
        "title",
        "Teplota dezinfekce bojleru"
      );

    const tempSelect =
      node("select");

    tempSelect.id =
      "f32-r126-disinfection-temperature";

    tempLabel.htmlFor =
      tempSelect.id;

    tempSelect.setAttribute(
      "aria-label",
      "Teplota dezinfekce bojleru"
    );

    const emptyTemp =
      node(
        "option",
        "",
        "Vyberte…"
      );

    emptyTemp.value = "";
    tempSelect.append(
      emptyTemp
    );

    for (
      let value = 55;
      value <= 65;
      value++
    ) {
      const option =
        node(
          "option",
          "",
          "+" +
            value +
            " °C"
        );

      option.value =
        String(value);

      tempSelect.append(
        option
      );
    }

    tempSelect.addEventListener(
      "change",
      () =>
        changeField(
          "disinfection_c",
          tempSelect.value
        )
    );

    tempLine.append(
      tempLabel,
      tempSelect
    );

    tempBox.append(
      tempLine,
      node("div", "detail")
    );

    const dayBox =
      node("div");

    dayBox.dataset.r126DisinfectionRow =
      "6";

    const dayLine =
      node("div", "main");

    const dayLabel =
      node(
        "label",
        "title",
        "Den v týdnu desinfekce"
      );

    const daySelect =
      node("select");

    daySelect.id =
      "f32-r126-disinfection-weekday";

    dayLabel.htmlFor =
      daySelect.id;

    daySelect.setAttribute(
      "aria-label",
      "Den v týdnu desinfekce"
    );

    const emptyDay =
      node(
        "option",
        "",
        "Vyberte…"
      );

    emptyDay.value = "";
    daySelect.append(
      emptyDay
    );

    weekdays.forEach(
      (weekday, index) => {
        const option =
          node(
            "option",
            "",
            weekday
          );

        option.value =
          String(index);

        daySelect.append(
          option
        );
      }
    );

    daySelect.addEventListener(
      "change",
      () =>
        changeField(
          "disinfection_weekday",
          daySelect.value
        )
    );

    dayLine.append(
      dayLabel,
      daySelect
    );

    dayBox.append(
      dayLine,
      node("div", "detail")
    );

    return [
      tempBox,
      dayBox,
    ];
  }

  function sync() {
    raf = 0;

    if (stopped) return;

    const currentPanel =
      document.getElementById(
        PANEL
      );

    if (panel !== currentPanel) {
      panelObserver?.disconnect();
      panel = currentPanel;

      if (panel) {
        panelObserver =
          new MutationObserver(
            wake
          );

        panelObserver.observe(
          panel,
          {
            attributes: true,
            attributeFilter: [
              "data-open",
            ],
            childList: true,
          }
        );
      }
    }

    if (panel) {
      const targets = [
        panel.querySelector(
          '[data-settings-column="boiler"] ' +
            '[data-setting-slot="boiler-05"]'
        ),
        panel.querySelector(
          '[data-settings-column="boiler"] ' +
            '[data-setting-slot="boiler-06"]'
        ),
      ];

      if (
        targets.every(Boolean) &&
        (
          !boxes.length ||
          boxes.some(
            (box, index) =>
              box.parentNode !==
              targets[index]
          )
        )
      ) {
        const safe =
          targets.every(
            (slot, index) =>
              !slot.children.length ||
              [...slot.children]
                .every(
                  (child) =>
                    child ===
                    boxes[index]
                )
          );

        if (safe) {
          boxes.forEach(
            (box) =>
              box.remove()
          );

          boxes = build();

          targets.forEach(
            (slot, index) =>
              slot.append(
                boxes[index]
              )
          );

          ensureStyle();
          render();
        }
      }
    }

    const ctx = context();

    if (
      ctx &&
      panel?.dataset.open ===
        "true" &&
      !document.hidden
    ) {
      if (
        !timer &&
        !fetching &&
        !pending
      ) {
        refresh();
      }
    } else {
      clearTimeout(timer);
      timer = null;
      epoch++;
      request?.abort();
      status = null;
      message = "";
      dirty = false;
      draft = {
        disinfection_c: null,
        disinfection_weekday: null,
      };
      render();
    }
  }

  function wake() {
    if (
      !stopped &&
      !raf
    ) {
      raf =
        requestAnimationFrame(
          sync
        );
    }
  }

  function boot() {
    observer =
      new MutationObserver(
        (records) => {
          if (
            records.some(
              (record) =>
                [
                  ...record.addedNodes,
                  ...record.removedNodes,
                ].some(
                  (item) =>
                    item.nodeType === 1 &&
                    (
                      item.id === PANEL ||
                      item.querySelector?.(
                        "#" + PANEL
                      ) ||
                      item.matches?.(
                        "[data-setting-slot]"
                      )
                    )
                )
            )
          ) {
            wake();
          }
        }
      );

    observer.observe(
      document.body,
      {
        childList: true,
        subtree: true,
      }
    );

    for (
      const event
      of [
        "pageshow",
        "popstate",
        "hashchange",
        "storage",
      ]
    ) {
      window.addEventListener(
        event,
        wake
      );
    }

    document.addEventListener(
      "visibilitychange",
      wake
    );

    wake();
  }

  const facade =
    Object.freeze({
      version: VERSION,
      refresh,
      diagnostics: () => ({
        version: VERSION,
        mounted:
          boxes.length === 2 &&
          boxes.every(
            (box) =>
              box.isConnected
          ),
        configured:
          status?.configured ??
          false,
        active:
          status?.active ??
          false,
        phase:
          status?.phase ??
          null,
      }),
      dispose: () => {
        stopped = true;
        clearTimeout(timer);
        request?.abort();
        observer?.disconnect();
        panelObserver?.disconnect();

        boxes.forEach(
          (box) =>
            box.remove()
        );
      },
    });

  window.IQF_F32_R126_DHW_DISINFECTION =
    facade;

  if (
    document.readyState ===
    "loading"
  ) {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      {
        once: true,
      }
    );
  } else {
    boot();
  }
})();
