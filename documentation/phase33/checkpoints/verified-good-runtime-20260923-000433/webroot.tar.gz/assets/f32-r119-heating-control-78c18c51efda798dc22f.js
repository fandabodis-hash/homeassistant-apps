(() => {
  'use strict';

  const VERSION='F32.3E-R119';
  const PANEL='f32-r115-settings-workspace';
  const ROOT='[data-phase28-r177n107-workspace]';
  const UUID='28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc';
  const API='https://api.tngiqfanda.cz/api/v1';
  const ID='f32-r119-heating-control';

  if(window.IQF_F32_R119_HEATING) return;

  let box=null, slot=null, panel=null, panelObserver=null, timer=null;
  let controller=null, status=null, sending=false, activeKey='', lastError='', stopped=false;
  let observer=null, raf=0, getEpoch=0;

  function visible(e){
    if(!e||!e.isConnected)return false;
    const r=e.getBoundingClientRect(),s=getComputedStyle(e);
    return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&!e.closest('[hidden],[aria-hidden="true"]');
  }

  function context(){
    const state=window.IQF_F32_R115_SETTINGS?.diagnostics();
    if(!state||state.version!=='F32.2Q-R115-NATIVE-TAB-LIFECYCLE'||!state.open||state.nativeTab!=='settings')return null;

    const roots=[...document.querySelectorAll(ROOT)].filter(visible);
    if(roots.length!==1)return null;

    const root=roots[0], declared=root.getAttribute('data-device-uuid');
    if(declared&&declared!==UUID)return null;

    const source=(root.getAttribute('data-phase28-r177n107-source')||'').toLowerCase();
    let mode=null;

    if(/customer|client|portal/.test(source)&&!/^admin/.test(source))mode='portal';
    else if(/admin/.test(source))mode='admin';
    else if(/(^|\/)admin(?:\/|$)/.test(location.pathname))mode='admin';
    else if(/(^|\/)(portal|customer|client)(?:\/|$)/.test(location.pathname))mode='portal';

    if(!mode)return {error:'Nelze určit účet této pracovní plochy.'};

    const key='iqfanda_access_token';
    let token='';

    try{
      token=localStorage.getItem(key)||sessionStorage.getItem(key)||'';
    }catch(_){
      return {error:'Přihlášení není dostupné.'};
    }

    if(!token)return {error:'Přihlaste se znovu do portálu.'};

    return {
      mode,
      token,
      url:API+'/'+mode+'/devices/'+UUID+'/individual-project/heating-duo-v1'
    };
  }

  const codeText={
    HEATING_MASTER_DISABLED:'Hlavní zdroj tepla je vypnutý.',
    HEATING_REMOTE_COMMANDS_DISABLED:'Vzdálené ovládání není povolené.',
    HEATING_COMMAND_IN_PROGRESS:'Předchozí příkaz vytápění ještě probíhá.',
    HEATING_TELEMETRY_UNAVAILABLE:'Aktuální stav spínače vytápění není dostupný.',
    HEATING_REQUEST_ID_CONFLICT:'Konflikt požadavku. Obnovte stav.'
  };

  function errorText(e){
    return codeText[e.code]||(
      e.status===401?'Přihlaste se znovu.':
      e.status===403?'Pro tento účet nebo zařízení není ovládání povolené.':
      e.status===404?'Rozhraní vytápění není dostupné.':
      e.code&&e.code.startsWith('HEATING_')?'Nesouhlasí zařízení nebo jeho vazba. Ovládání je zablokované.':
      'Spojení se serverem selhalo. Stav požadavku ověřte podle odezvy; příkaz se automaticky neopakuje.'
    );
  }

  async function api(ctx,method,body,signal){
    const r=await fetch(ctx.url,{
      method,
      credentials:'omit',
      cache:'no-store',
      redirect:'error',
      signal,
      headers:{
        'Authorization':'Bearer '+ctx.token,
        'Accept':'application/json',
        ...(body?{'Content-Type':'application/json'}:{})
      },
      ...(body?{body:JSON.stringify(body)}:{})
    });

    const value=await r.json().catch(()=>null);

    if(!r.ok)throw {status:r.status,code:value?.detail?.code};

    if(
      value?.version!==VERSION||
      value?.device_uuid!==UUID||
      !['on','off','unavailable'].includes(value?.observed_state)
    )throw {code:'HEATING_INVALID_RESPONSE'};

    return value;
  }

  function render(){
    if(!box)return;

    const switcher=box.querySelector('[data-heating-switch]');
    const badge=box.querySelector('[data-heating-state]');
    const info=box.querySelector('[data-heating-info]');

    const state=status?.observed_state||'unavailable';
    const busy=sending||status?.pending;

    switcher.checked=state==='on';
    switcher.disabled=!!busy||!status||!(state==='on'?status.can_turn_off:status.can_turn_on);

    box.dataset.observed=state;
    box.dataset.pending=busy?'true':'false';

    badge.hidden=!busy&&(state==='on'||state==='off');
    badge.textContent=busy?'Provádím…':state==='on'?'Zapnuto':state==='off'?'Vypnuto':'Nedostupné';

    let note='';
    if(!status)note='Načítám skutečný stav…';
    else if(!status.remote_commands_enabled)note='Vzdálené ovládání není povolené.';
    else if(!status.master_enabled)note='Hlavní zdroj je vypnutý; zapnutí je blokované.';
    else if(status.operation?.phase==='failed')note='Poslední přepnutí nebylo potvrzeno.';

    const physical='Spínač vytápění DUO: '+(
      state==='on'?'zapnuto':
      state==='off'?'vypnuto':
      'nedostupný'
    );

    info.textContent=lastError||[physical,note].filter(Boolean).join(' · ');
    info.title=info.textContent;
    box.setAttribute('aria-busy',busy?'true':'false');
  }

  function schedulePoll(delay){
    clearTimeout(timer);
    timer=setTimeout(()=>refresh(),delay);
  }

  async function refresh(){
    clearTimeout(timer);
    const ctx=context();

    if(!ctx||document.hidden||stopped){
      status=null;
      render();
      return;
    }

    if(ctx.error){
      lastError=ctx.error;
      status=null;
      render();
      return;
    }

    const key=ctx.mode+'|'+ctx.token;
    if(activeKey!==key){
      activeKey=key;
      status=null;
      lastError='';
    }

    const epoch=++getEpoch;
    if(controller)controller.abort();
    controller=new AbortController();
    const abort=controller;
    const timeout=setTimeout(()=>abort.abort(),12000);

    try{
      const data=await api(ctx,'GET',null,abort.signal);
      const current=context();

      if(
        epoch!==getEpoch||
        !current||
        current.error||
        current.mode!==ctx.mode||
        current.token!==ctx.token
      )return;

      status=data;
      lastError='';
      render();
    }catch(e){
      if(epoch===getEpoch){
        status=null;
        lastError=errorText(e);
        render();
      }
    }finally{
      clearTimeout(timeout);
      if(epoch===getEpoch&&context()&&!document.hidden&&!stopped){
        schedulePoll(status?.pending?2500:12000);
      }
    }
  }

  async function change(enabled){
    const ctx=context();

    if(!ctx||ctx.error||sending||status?.pending)return;
    if(!(enabled?status?.can_turn_on:status?.can_turn_off))return;

    if(!window.crypto?.randomUUID){
      lastError='Pro ovládání je potřeba zabezpečené HTTPS připojení.';
      render();
      return;
    }

    const request_id=crypto.randomUUID();
    clearTimeout(timer);
    timer=null;
    getEpoch++;
    controller?.abort();
    sending=true;
    lastError='';
    render();

    const abort=new AbortController();
    const timeout=setTimeout(()=>abort.abort(),20000);

    try{
      const value=await api(
        ctx,
        'PUT',
        {enabled,request_id},
        abort.signal
      );

      const current=context();
      if(
        current&&
        !current.error&&
        current.mode===ctx.mode&&
        current.token===ctx.token
      )status=value;
    }catch(e){
      lastError=errorText(e);
    }finally{
      clearTimeout(timeout);
      sending=false;
      render();
      schedulePoll(1000);
    }
  }

  function ensureStyle(){
    if(document.getElementById(ID+'-style'))return;

    const s=document.createElement('style');
    s.id=ID+'-style';
    s.textContent=`
      #${ID}{display:flex;flex-direction:column;justify-content:center;gap:6px;height:100%;min-height:0;box-sizing:border-box;padding:8px 13px;font:inherit;color:#edfaff}
      #${ID} .heating-main{display:flex;align-items:center;justify-content:space-between;gap:10px;min-width:0}
      #${ID} .heating-label{font-weight:850;font-size:clamp(12px,0.95vw,17px);line-height:1.2}
      #${ID} .heating-controls{display:flex;align-items:center;gap:6px;flex-shrink:0}
      #${ID} .heating-state{font-size:11px;white-space:nowrap;color:#72e4dd}
      #${ID} .heating-info{font-size:10px;line-height:1.15;color:#9cbcc8;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}
      #${ID} .heating-side{font-size:10px;color:#cae5ed;white-space:nowrap}
      #${ID} .heating-toggle{position:relative;width:48px;height:27px;flex-shrink:0;display:inline-block}
      #${ID} input{position:absolute;inset:0;width:100%;height:100%;margin:0;opacity:0;z-index:2;cursor:pointer}
      #${ID} .heating-track{display:block;width:100%;height:100%;border-radius:20px;background:#24404c;border:1px solid #557786;box-sizing:border-box;transition:background .15s}
      #${ID} .heating-track::after{content:'';display:block;width:19px;height:19px;margin:3px;border-radius:50%;background:#b6d8e3;transition:transform .15s}
      #${ID} input:checked+.heating-track{background:#12675f;border-color:#47d6be}
      #${ID} input:checked+.heating-track::after{transform:translateX(21px);background:#a3fff0}
      #${ID} input:focus-visible+.heating-track{outline:2px solid #67dcff;outline-offset:3px}
      #${ID} input:disabled{cursor:not-allowed}
      #${ID} input:disabled+.heating-track{opacity:.5}
      @media(max-width:1400px){#${ID} .heating-state{display:none}#${ID}{padding:7px 9px}}
    `;
    document.head.appendChild(s);
  }

  function mount(target){
    if(box?.isConnected&&box.parentElement===target)return;
    if(target.children.length&&!target.querySelector('#'+ID))return;

    box=document.createElement('div');
    box.id=ID;
    box.dataset.version=VERSION;

    const main=document.createElement('div');
    main.className='heating-main';

    const title=document.createElement('span');
    title.className='heating-label';
    title.textContent='Vytápění';

    const controls=document.createElement('div');
    controls.className='heating-controls';

    const badge=document.createElement('span');
    badge.className='heating-state';
    badge.dataset.heatingState='';

    const off=document.createElement('span');
    off.className='heating-side';
    off.textContent='Vypnuto';

    const label=document.createElement('label');
    label.className='heating-toggle';

    const input=document.createElement('input');
    input.type='checkbox';
    input.dataset.heatingSwitch='';
    input.setAttribute('aria-label','Vytápění – Spínač vytápění DUO');
    input.disabled=true;
    input.addEventListener('change',()=>{
      const requested=input.checked;
      render();
      change(requested);
    });

    const track=document.createElement('span');
    track.className='heating-track';
    label.append(input,track);

    const on=document.createElement('span');
    on.className='heating-side';
    on.textContent='Zapnuto';

    controls.append(badge,off,label,on);
    main.append(title,controls);

    const detail=document.createElement('div');
    detail.className='heating-info';
    detail.dataset.heatingInfo='';
    detail.setAttribute('role','status');
    detail.setAttribute('aria-live','polite');

    box.append(main,detail);
    target.appendChild(box);
    ensureStyle();
    render();
  }

  function sync(){
    raf=0;
    if(stopped)return;

    const next=document.getElementById(PANEL);

    if(panel!==next){
      panel=next;
      if(panelObserver)panelObserver.disconnect();

      if(panel){
        panelObserver=new MutationObserver(records=>{
          if(records.some(record=>
            record.type==='attributes'||
            [...record.addedNodes,...record.removedNodes].some(node=>
              node.nodeType===1&&(
                node===box||
                node.contains?.(box)||
                node.matches?.('[data-setting-slot]')
              )
            )
          ))wake();
        });

        panelObserver.observe(panel,{
          childList:true,
          subtree:true,
          attributes:true,
          attributeFilter:['data-open']
        });
      }
    }

    slot=panel?.querySelector(
      '[data-settings-column="heating"] [data-setting-slot="heating-01"]'
    );

    if(slot)mount(slot);

    if(context()&&panel?.dataset.open==='true'&&!document.hidden){
      if(!timer&&!sending)refresh();
    }else{
      clearTimeout(timer);
      timer=null;
      getEpoch++;
      controller?.abort();
      activeKey='';
      status=null;
      lastError='';
      render();
    }
  }

  function wake(){
    if(!raf&&!stopped)raf=requestAnimationFrame(sync);
  }

  function boot(){
    observer=new MutationObserver(records=>{
      if(records.some(record=>
        [...record.addedNodes,...record.removedNodes].some(node=>
          node.nodeType===1&&(
            node.id===PANEL||
            node.querySelector?.('#'+PANEL)
          )
        )
      ))wake();
    });

    observer.observe(document.body,{
      childList:true,
      subtree:true
    });

    ['pageshow','popstate','hashchange'].forEach(name=>
      window.addEventListener(name,wake)
    );

    document.addEventListener('visibilitychange',wake);
    window.addEventListener('storage',()=>{
      status=null;
      activeKey='';
      refresh();
    });

    wake();
  }

  window.IQF_F32_R119_HEATING=Object.freeze({
    version:VERSION,
    refresh,
    diagnostics:()=>({
      version:VERSION,
      mounted:!!box?.isConnected,
      state:status?.observed_state||'unknown',
      pending:!!status?.pending,
      sending
    }),
    dispose:()=>{
      stopped=true;
      clearTimeout(timer);
      controller?.abort();
      observer?.disconnect();
      panelObserver?.disconnect();
      box?.remove();
    }
  });

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',boot,{once:true});
  }else{
    boot();
  }
})();
