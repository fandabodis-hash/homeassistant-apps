(() => {
  "use strict";

  const MARK = "__IQF_F31_R87R3_DISTRIBUTOR_UP20__";
  const ROOT =
    '[data-f29-00012-schema="svj-blansko-only"]';

  if (window[MARK]) return;
  window[MARK] = true;

  const style =
    document.createElement(
      "style"
    );

  style.id =
    "f31-r87r3-distributor-up20-style";

  style.textContent = `
    ${ROOT}
    .f29-00012-distributor[data-f31-r87r2-distributor="1"] {
      transform:
        translateY(-20px)
        !important;
    }
  `;

  document.head.appendChild(
    style
  );

  window.dispatchEvent(
    new Event(
      "resize"
    )
  );

  document.dispatchEvent(
    new Event(
      "iqf-f31-r85-layout-ready"
    )
  );
})();