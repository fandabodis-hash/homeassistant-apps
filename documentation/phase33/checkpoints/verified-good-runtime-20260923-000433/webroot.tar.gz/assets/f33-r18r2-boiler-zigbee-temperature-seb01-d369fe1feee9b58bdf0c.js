/*
 * F33_R18_BOILER_ZIGBEE_TEMPERATURE_SEB01
 *
 * UI-only admin selector for one existing SEB-01 slot:
 *   element_key = boiler-temperature
 *
 * Data/binding architecture stays standard:
 * schema-entity-options -> schema_entity_bindings_v1[element_key]
 * -> schema-entity-values -> existing SEB-01B shared reader.
 *
 * No new value poller, no MutationObserver, no device command.
 */
(() => {
  "use strict";

  const MARK = "__F33_R18_BOILER_ZIGBEE_TEMPERATURE_SEB01__";
  if (window[MARK]) return;
  window[MARK] = true;

  const TARGET_UUID =
    "014a0d23-d440-4131-abb4-28a860595043";

  const ELEMENT_KEY =
    "boiler-temperature";

  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]' +
    '[data-f33-r16-clone-00013="true"]';

  const PANEL_ID =
    "f33-r18-boiler-zigbee-temp-picker";

  function isAdmin() {
    return String(
      window.location?.pathname || ""
    )
      .toLowerCase()
      .includes("/admin");
  }

  function token() {
    const keys = [
      "iqfanda_access_token",
      "access_token",
      "accessToken",
      "token",
      "auth_token",
      "authToken",
      "tng_iq_fanda_token",
      "tng_iqfanda_token"
    ];

    for (const key of keys) {
      const value =
        window.localStorage?.getItem(key);

      if (
        value &&
        String(value).trim().length > 16
      ) {
        return String(value).trim();
      }
    }

    return "";
  }

  function normalize(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim()
      .toUpperCase();
  }

  function root() {
    return document.querySelector(
      ROOT_SELECTOR
    );
  }

  function boilerCard() {
    const r = root();
    if (!r) return null;

    const cards = [
      ...r.querySelectorAll(
        "article, section"
      )
    ];

    return (
      cards.find((card) => {
        const title =
          card.querySelector("h3,h2,strong");

        return (
          normalize(title?.textContent)
          === "BOJLER"
        );
      }) ||
      cards.find((card) => {
        const text =
          normalize(card.textContent);

        return (
          text.includes("BOJLER") &&
          text.includes("PRIPRAVA")
        );
      }) ||
      null
    );
  }

  function temperatureAnchor(card) {
    if (!card) return null;

    const canonical =
      card.querySelector(
        '[data-f30-schema-element-key="' +
        ELEMENT_KEY +
        '"]'
      );

    if (canonical) {
      return (
        canonical.closest(
          "div,li,p"
        ) ||
        canonical
      );
    }

    const elements = [
      ...card.querySelectorAll(
        "span,strong,div,p"
      )
    ];

    const label =
      elements.find((node) => {
        const text =
          normalize(node.textContent);

        return (
          text === "TEPLOTA" ||
          text === "TEPLOTA TUV"
        );
      }) || null;

    if (!label) return card;

    return (
      label.parentElement ||
      label
    );
  }

  function setStatus(
    panel,
    message,
    error = false
  ) {
    const node =
      panel.querySelector(
        "[data-f33-r18-status]"
      );

    if (!node) return;

    node.textContent =
      message || "";

    node.style.color =
      error
        ? "#ff9f9f"
        : "#9eeeff";
  }

  async function fetchJson(
    path,
    options = {}
  ) {
    const headers = {
      "Content-Type":
        "application/json",
      ...(options.headers || {})
    };

    const auth = token();
    if (auth) {
      headers.Authorization =
        `Bearer ${auth}`;
    }

    const response = await fetch(
      path,
      {
        credentials: "include",
        ...options,
        headers
      }
    );

    const raw =
      await response.text();

    let data = null;

    try {
      data = raw
        ? JSON.parse(raw)
        : null;
    } catch {
      data = {
        raw
      };
    }

    if (!response.ok) {
      throw new Error(
        data?.detail ||
        data?.message ||
        data?.raw ||
        `HTTP ${response.status}`
      );
    }

    return data;
  }

  function isZigbeeTemperature(
    option
  ) {
    if (
      !option ||
      typeof option !== "object"
    ) {
      return false;
    }

    const transport =
      String(
        option.transport || ""
      )
        .trim()
        .toLowerCase();

    if (
      transport !== "zigbee" &&
      transport !== "zha"
    ) {
      return false;
    }

    const primary =
      String(
        option.capability || ""
      )
        .trim()
        .toLowerCase();

    const caps =
      Array.isArray(
        option.capabilities
      )
        ? option.capabilities.map(
            (x) =>
              String(x)
                .trim()
                .toLowerCase()
          )
        : [];

    return (
      primary === "temperature" ||
      caps.includes("temperature")
    );
  }

  function renderOptions(
    select,
    options
  ) {
    select.innerHTML = "";

    const empty =
      document.createElement(
        "option"
      );

    empty.value = "";
    empty.textContent =
      "— vyber Zigbee teplotu —";

    select.appendChild(empty);

    const groups = new Map();

    for (const option of options) {
      const name =
        String(
          option.device_name ||
          "Zigbee zařízení"
        ).trim();

      if (!groups.has(name)) {
        groups.set(
          name,
          []
        );
      }

      groups.get(name).push(
        option
      );
    }

    for (
      const [
        deviceName,
        entities
      ] of groups.entries()
    ) {
      const group =
        document.createElement(
          "optgroup"
        );

      group.label =
        deviceName;

      for (const entity of entities) {
        const item =
          document.createElement(
            "option"
          );

        item.value =
          JSON.stringify(entity);

        const entityName =
          String(
            entity.entity_name ||
            entity.label ||
            entity.entity_id ||
            "Teplota"
          ).trim();

        const unit =
          String(
            entity.unit || ""
          ).trim();

        item.textContent =
          entityName +
          (unit
            ? ` · ${unit}`
            : "");

        group.appendChild(
          item
        );
      }

      select.appendChild(
        group
      );
    }
  }

  async function loadOptions(
    panel
  ) {
    const select =
      panel.querySelector(
        "[data-f33-r18-select]"
      );

    if (!select) return;

    try {
      setStatus(
        panel,
        "Načítám Zigbee teploty…"
      );

      const data =
        await fetchJson(
          `/api/v1/admin/devices/${encodeURIComponent(
            TARGET_UUID
          )}/individual-project/schema-entity-options?capability=temperature`
        );

      const filtered =
        (data?.options || [])
          .filter(
            isZigbeeTemperature
          );

      renderOptions(
        select,
        filtered
      );

      setStatus(
        panel,
        `Zigbee teploty: ${filtered.length}`
      );
    } catch (error) {
      setStatus(
        panel,
        `Načtení selhalo: ${error.message}`,
        true
      );
    }
  }

  async function save(
    panel
  ) {
    const select =
      panel.querySelector(
        "[data-f33-r18-select]"
      );

    if (
      !select ||
      !select.value
    ) {
      setStatus(
        panel,
        "Nejdřív vyber Zigbee teplotu.",
        true
      );
      return;
    }

    let entity = null;

    try {
      entity =
        JSON.parse(
          select.value
        );
    } catch {
      setStatus(
        panel,
        "Vybraná entita není platná.",
        true
      );
      return;
    }

    try {
      setStatus(
        panel,
        "Ukládám SEB-01 vazbu…"
      );

      await fetchJson(
        `/api/v1/admin/devices/${encodeURIComponent(
          TARGET_UUID
        )}/individual-project/schema-entity-bindings/${encodeURIComponent(
          ELEMENT_KEY
        )}`,
        {
          method: "PUT",
          body: JSON.stringify({
            capability:
              "temperature",
            entity
          })
        }
      );

      setStatus(
        panel,
        "Uloženo. SEB-01B propíše hodnotu do adminu i klienta."
      );

      window.dispatchEvent(
        new CustomEvent(
          "iqf-seb-binding-saved",
          {
            detail: {
              deviceUuid:
                TARGET_UUID,
              elementKey:
                ELEMENT_KEY,
              entityId:
                entity.entity_id ||
                entity.id ||
                ""
            }
          }
        )
      );
    } catch (error) {
      setStatus(
        panel,
        `Uložení selhalo: ${error.message}`,
        true
      );
    }
  }

  function position(
    panel
  ) {
    const card =
      boilerCard();

    if (
      !card ||
      !root() ||
      !isAdmin()
    ) {
      panel.style.display =
        "none";
      return;
    }

    const anchor =
      temperatureAnchor(
        card
      );

    const cardRect =
      card.getBoundingClientRect();

    const anchorRect =
      (anchor || card)
        .getBoundingClientRect();

    const width =
      Math.max(
        190,
        Math.min(
          310,
          cardRect.width - 24
        )
      );

    let left =
      cardRect.left + 12;

    let top =
      anchorRect.bottom + 8;

    const bottomLimit =
      cardRect.bottom - 10;

    if (
      top + 72 >
      bottomLimit
    ) {
      top =
        Math.max(
          cardRect.top + 82,
          bottomLimit - 72
        );
    }

    panel.style.left =
      `${Math.round(left)}px`;

    panel.style.top =
      `${Math.round(top)}px`;

    panel.style.width =
      `${Math.round(width)}px`;

    panel.style.display =
      "block";
  }

  function createPanel() {
    if (!isAdmin()) return null;

    const existing =
      document.getElementById(
        PANEL_ID
      );

    if (existing) {
      position(existing);
      return existing;
    }

    const card =
      boilerCard();

    if (!card) return null;

    const panel =
      document.createElement(
        "section"
      );

    panel.id = PANEL_ID;

    panel.setAttribute(
      "data-f33-r18-boiler-zigbee-temperature-seb01",
      "admin-only"
    );

    Object.assign(
      panel.style,
      {
        position: "fixed",
        zIndex: "2147483000",
        minHeight: "66px",
        boxSizing: "border-box",
        padding: "7px 8px",
        borderRadius: "8px",
        border:
          "1px solid rgba(52,211,255,.72)",
        background:
          "rgba(2,24,34,.96)",
        boxShadow:
          "0 8px 28px rgba(0,0,0,.34)",
        color: "#dff8ff",
        fontFamily: "inherit"
      }
    );

    panel.innerHTML = `
      <div style="
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:8px;
        margin-bottom:5px;
      ">
        <strong style="
          font-size:10px;
          letter-spacing:.04em;
          color:#50ddff;
        ">BOJLER · TEPLOTA · SEB-01</strong>
        <button
          type="button"
          data-f33-r18-reload
          title="Obnovit seznam"
          style="
            border:1px solid rgba(52,211,255,.45);
            border-radius:6px;
            background:#082d3c;
            color:#dff8ff;
            cursor:pointer;
            height:24px;
            min-width:28px;
          "
        >↻</button>
      </div>

      <div style="
        display:grid;
        grid-template-columns:minmax(0,1fr) auto;
        gap:6px;
        align-items:center;
      ">
        <select
          data-f33-r18-select
          style="
            width:100%;
            min-width:0;
            height:28px;
            border:1px solid rgba(52,211,255,.45);
            border-radius:6px;
            background:#031923;
            color:#e9fbff;
            font-size:10px;
            padding:0 6px;
          "
        >
          <option value="">— načítám Zigbee teploty —</option>
        </select>

        <button
          type="button"
          data-f33-r18-save
          style="
            height:28px;
            padding:0 10px;
            border:1px solid rgba(52,211,255,.65);
            border-radius:6px;
            background:#0a4258;
            color:#fff;
            font-size:10px;
            font-weight:800;
            cursor:pointer;
          "
        >Uložit</button>
      </div>

      <div
        data-f33-r18-status
        style="
          margin-top:4px;
          min-height:11px;
          font-size:8.5px;
          line-height:1.2;
          color:#9eeeff;
        "
      ></div>
    `;

    document.body.appendChild(
      panel
    );

    panel
      .querySelector(
        "[data-f33-r18-reload]"
      )
      ?.addEventListener(
        "click",
        (event) => {
          event.preventDefault();
          event.stopPropagation();
          void loadOptions(
            panel
          );
        }
      );

    panel
      .querySelector(
        "[data-f33-r18-save]"
      )
      ?.addEventListener(
        "click",
        (event) => {
          event.preventDefault();
          event.stopPropagation();
          void save(
            panel
          );
        }
      );

    position(panel);
    void loadOptions(panel);

    return panel;
  }

  function mount() {
    const panel =
      createPanel();

    if (panel) {
      position(panel);
    }
  }

  [
    0,
    100,
    350,
    800,
    1600,
    3000
  ].forEach((delay) => {
    window.setTimeout(
      mount,
      delay
    );
  });

  document.addEventListener(
    "click",
    (event) => {
      const tab =
        event.target &&
        event.target.closest
          ? event.target.closest(
              "[data-phase28-r177n107-tab-key]"
            )
          : null;

      if (tab) {
        window.setTimeout(
          mount,
          80
        );
      }
    },
    false
  );

  window.addEventListener(
    "resize",
    () => {
      const panel =
        document.getElementById(
          PANEL_ID
        );

      if (panel) {
        position(panel);
      }
    },
    {
      passive: true
    }
  );

  window.addEventListener(
    "scroll",
    () => {
      const panel =
        document.getElementById(
          PANEL_ID
        );

      if (panel) {
        position(panel);
      }
    },
    {
      passive: true,
      capture: true
    }
  );
})();
