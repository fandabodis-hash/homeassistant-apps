/* __F33_R16_00013_CLONE_P104_EXCLUSION__ */
(function f33R16ExcludeP104FromLinkedClone() {
  "use strict";

  const ROOT =
    '[data-f33-r16-clone-00013="true"]';

  document.addEventListener(
    "click",
    (event) => {
      const root =
        event &&
        event.target &&
        event.target.closest
          ? event.target.closest(ROOT)
          : null;

      if (!root) return;

      event.preventDefault();
      event.stopImmediatePropagation();
    },
    true
  );
})();

/* __F33_R15_00012_TEMPLATE_P104_EXCLUSION__
 * 00012 individual schema and the linked 00013 clone are owned by
 * generic SEB/WIM. P104 must never open its old info modal there.
 */
(function f33R15P104Exclusion() {
  "use strict";
  const ROOT = '[data-f29-00012-schema="svj-blansko-only"]';

  document.addEventListener(
    "click",
    (event) => {
      const root =
        event &&
        event.target &&
        event.target.closest
          ? event.target.closest(ROOT)
          : null;

      if (!root) return;

      event.preventDefault();
      event.stopImmediatePropagation();
    },
    true
  );
})();

/* __F33_R14_00013_SHARED_SCHEMA_P104_EXCLUSION__
 *
 * Model 00013 now uses the same generic SEB ownership principle as model 00012:
 * - generic SEB picker owns admin selection,
 * - shared SEB runtime paints admin/client values,
 * - P104 must not own clicks inside this individual-project schema.
 *
 * IMPORTANT ordering:
 * the generic SEB runtime is loaded before P104, therefore its admin
 * capture handler receives the click first. This guard then prevents
 * later P104 handlers from opening the obsolete information modal.
 */
(function f33R14P104SharedSchemaExclusion() {
  "use strict";

  const ROOT =
    '[data-f33-r8-00013-schema="hpt01-reference"]';

  document.addEventListener(
    "click",
    (event) => {
      const element =
        event &&
        event.target &&
        event.target.closest
          ? event.target.closest(ROOT)
          : null;

      if (!element) {
        return;
      }

      event.preventDefault();
      event.stopImmediatePropagation();
    },
    true
  );
})();

(() => {
  "use strict";

  const VERSION = "TNG-HP-WORKSPACE-P104-ADMIN-CARD-IDENTITY";
  const OLD_TOKEN = "SOLAREAST-HP-MODULE-WORKSPACE-R2";

  const API = "https://api.tngiqfanda.cz/api/v1";

  const ROOT_ID = "iqf-heatpump-module-workspace";
  const STYLE_ID = "iqf-heatpump-module-workspace-style";
  const TOAST_ID = "iqf-heatpump-module-workspace-toast";

  const TABS = [
    ["schema", "⌂", "Schéma"],
    ["settings", "☰", "Nastavení"],
    ["statistics", "▥", "Statistiky"],
    ["system", "⚙", "Systém"],
    ["guide", "?", "Návod"],
    ["users", "○", "Uživatel"],
  ];

  let activeState = null;
  let activeMode = null;
  let currentTab = "schema";
  let requestEpoch = 0;
  let systemData = null;
  let userData = null;
  let weatherData = null;
  let stopped = false;
  let moduleCardObserver = null;
  let moduleCardTimer = null;
  let moduleCardState = null;
  let moduleCardSyncBusy = false;
  let moduleCardLastSync = 0;
  const p104 = {cards:new WeakMap(),pending:null,sync:null,active:null,epoch:0,timer:null};

  if (window.IQF_HEATPUMP_MODULE_WORKSPACE_R3) return;

  function token() {
    try {
      return (
        localStorage.getItem("iqfanda_access_token") ||
        sessionStorage.getItem("iqfanda_access_token") ||
        ""
      );
    } catch (_) {
      return "";
    }
  }

  function normalizeText(value) {
    return String(value ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function mode() {
    const path = String(location.pathname || "").toLowerCase();

    if (/(^|\/)admin(?:\/|$)/.test(path)) {
      return "admin";
    }

    if (/(^|\/)(portal|customer|client)(?:\/|$)/.test(path)) {
      return "portal";
    }

    /*
     * R3R1 architectural guard:
     * the installer detail can be rendered inside an SPA route that does not
     * contain /admin in location.pathname. The admin context is therefore
     * also recognized from the exact installation screen semantics.
     */
    const body = normalizeText(
      document.body?.innerText || ""
    );

    if (
      body.includes("detail zarizeni")
    ) {
      return "admin";
    }

    return activeMode;
  }

  function authHeaders(extra = {}) {
    const auth = token();

    if (!auth) {
      throw new Error("AUTH_MISSING");
    }

    return {
      Authorization: "Bearer " + auth,
      Accept: "application/json",
      ...extra,
    };
  }

  async function jsonFetch(url, options = {}) {
    const response = await fetch(url, {
      cache: "no-store",
      credentials: "omit",
      redirect: "error",
      ...options,
      headers: {
        ...authHeaders(options.headers || {}),
      },
    });

    const value = await response.json().catch(() => null);

    if (!response.ok) {
      const error = new Error(
        value?.detail?.detail ||
        value?.detail ||
        `HTTP ${response.status}`
      );
      error.status = response.status;
      throw error;
    }

    return value;
  }

  function fmt(value, suffix = "") {
    if (
      value === null ||
      value === undefined ||
      value === ""
    ) {
      return "—";
    }

    return String(value) + suffix;
  }

  function number(value, digits = 0) {
    const n = Number(value);

    if (!Number.isFinite(n)) return "—";

    return n.toLocaleString("cs-CZ", {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits,
    });
  }

  function dateTime(value) {
    if (!value) return "—";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) return "—";

    return date.toLocaleString("cs-CZ");
  }

  function seconds(value) {
    const raw = Number(value);

    if (!Number.isFinite(raw) || raw < 0) return "—";

    const total = Math.floor(raw);
    const days = Math.floor(total / 86400);
    const hours = Math.floor((total % 86400) / 3600);
    const minutes = Math.floor((total % 3600) / 60);

    if (days) return `${days} d ${hours} h`;
    if (hours) return `${hours} h ${minutes} min`;

    return `${minutes} min`;
  }

  function element(tag, cls = "", text = null) {
    const node = document.createElement(tag);

    if (cls) node.className = cls;
    if (text !== null) node.textContent = text;

    return node;
  }

  function clear(node) {
    while (node.firstChild) {
      node.firstChild.remove();
    }
  }

  function toast(message, type = "info", timeout = 3200) {
    document.getElementById(TOAST_ID)?.remove();

    const node = element("div");
    node.id = TOAST_ID;
    node.dataset.type = type;
    node.textContent = message;

    document.body.appendChild(node);

    if (timeout > 0) {
      setTimeout(() => node.remove(), timeout);
    }
  }

  function ensureStyle() {
    if (
      document.getElementById(
        STYLE_ID
      )
    ) {
      return;
    }

    const style = document.createElement("style");
    style.id = STYLE_ID;

    style.textContent = `
      #${ROOT_ID} {
        position: fixed !important;
        inset: 0 !important;
        z-index: 2147482000 !important;
        display: grid !important;
        grid-template-rows: minmax(0, 1fr) 118px !important;
        background: #001721 !important;
        color: #eefaff !important;
        font-family: inherit !important;
      }

      #${ROOT_ID} * {
        box-sizing: border-box;
      }

      #${ROOT_ID} .iqf-hp-stage {
        position: relative;
        min-width: 0;
        min-height: 0;
        overflow: auto;
        padding-bottom: 0;
        background:
          radial-gradient(circle at 50% -30%, rgba(0,82,108,.08), transparent 38%),
          #001721;
      }

      #${ROOT_ID} .iqf-hp-stage-inner {
        min-height: 100%;
        padding: 24px 30px 34px;
      }

      #${ROOT_ID} .iqf-hp-stage-inner[data-blank="true"] {
        padding: 0;
      }

      #${ROOT_ID} .iqf-hp-back {
        position: fixed;
        top: 8px;
        right: 14px;
        z-index: 7;
        border: 1px solid #23677e;
        border-radius: 8px;
        background: #0b3040;
        color: #effbff;
        font: inherit;
        font-size: 12px;
        font-weight: 850;
        padding: 10px 15px;
        cursor: pointer;
      }

      #${ROOT_ID} .iqf-hp-back:hover,
      #${ROOT_ID} .iqf-hp-back:focus-visible {
        outline: none;
        border-color: #49d7ff;
        background: #0d4052;
      }

      #${ROOT_ID} .iqf-hp-top-meta {
        position: fixed;
        top: 7px;
        left: 10px;
        z-index: 6;
        color: #66cae6;
        opacity: .72;
        font-size: 9px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: .12em;
        text-transform: uppercase;
        pointer-events: none;
      }

      /* ---------------------------------------------------
         BOTTOM SHELL — reference composition of model 00012
         --------------------------------------------------- */
      #${ROOT_ID} .iqf-hp-bottom-shell {
        position: fixed !important;
        left: 0 !important;
        right: 0 !important;
        bottom: 0 !important;
        width: 100vw !important;
        max-width: none !important;
        min-width: 0 !important;
        margin: 0 !important;
        justify-self: stretch !important;
        align-self: stretch !important;
        z-index: 8;
        display: grid;
        grid-template-columns:
          minmax(540px, 36%)
          minmax(320px, 20%)
          minmax(0, 44%);
        gap: 8px;
        padding: 7px 8px;
        border-top: 1px solid #19566b;
        background: #001923;
      }

      #${ROOT_ID} .iqf-hp-menu-panel,
      #${ROOT_ID} .iqf-hp-identity-panel,
      #${ROOT_ID} .iqf-hp-weather-panel {
        width: 100%;
        max-width: none;
        min-width: 0;
        margin: 0;
        border: 1px solid #18566c;
        border-radius: 15px;
        background: #001c27;
        overflow: hidden;
      }

      #${ROOT_ID} .iqf-hp-menu-panel {
        display: grid;
        grid-template-columns: repeat(6, minmax(0, 1fr));
        padding: 4px 8px;
      }

      #${ROOT_ID} .iqf-hp-nav {
        border: 1px solid transparent;
        border-radius: 13px;
        background: transparent;
        color: #a8bcc5;
        font: inherit;
        cursor: pointer;
        padding: 9px 5px 8px;
        display: grid;
        justify-items: center;
        align-content: center;
        gap: 8px;
        min-width: 0;
      }

      #${ROOT_ID} .iqf-hp-nav:hover,
      #${ROOT_ID} .iqf-hp-nav:focus-visible {
        outline: none;
        color: #f5fdff;
        border-color: #1b637d;
      }

      #${ROOT_ID} .iqf-hp-nav[data-active="true"] {
        color: #fff;
        border-color: #2a7893;
        background: #0e4052;
      }

      #${ROOT_ID} .iqf-hp-nav-icon {
        font-size: 18px;
        line-height: 1;
      }

      #${ROOT_ID} .iqf-hp-nav-label {
        font-size: 12px;
        line-height: 1.1;
        font-weight: 850;
        white-space: nowrap;
      }

      #${ROOT_ID} .iqf-hp-identity-panel {
        padding: 9px 14px 8px;
        display: grid;
        grid-template-rows: minmax(0, 1fr) auto;
        align-items: center;
      }

      #${ROOT_ID} .iqf-hp-identity-main {
        text-align: center;
        color: #f6fcff;
        font-size: clamp(12px, 1vw, 16px);
        line-height: 1.08;
        font-weight: 900;
      }

      #${ROOT_ID} .iqf-hp-identity-sub {
        text-align: center;
        color: #a9c2cc;
        font-size: 10px;
        line-height: 1.2;
      }

      #${ROOT_ID} .iqf-hp-identity-copy {
        margin-top: 5px;
        border-top: 1px solid rgba(40,117,142,.55);
        padding-top: 5px;
        color: #f5fcff;
        text-align: center;
        font-size: 10px;
        line-height: 1.05;
        font-weight: 850;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      #${ROOT_ID} .iqf-hp-weather-panel {
        display: grid;
        grid-template-columns: 28% minmax(0,1fr);
        padding: 8px 12px;
        align-items: stretch;
      }

      #${ROOT_ID} .iqf-weather-main {
        border: 1px solid #15526a;
        border-radius: 13px;
        min-width: 0;
        display: grid;
        grid-template-columns: auto minmax(0,1fr);
        gap: 9px;
        align-items: center;
        padding: 7px 11px;
      }

      #${ROOT_ID} .iqf-weather-icon {
        font-size: 28px;
        line-height: 1;
      }

      #${ROOT_ID} .iqf-weather-temp {
        color: #fff;
        font-size: clamp(21px, 1.7vw, 31px);
        line-height: 1;
        font-weight: 900;
        white-space: nowrap;
      }

      #${ROOT_ID} .iqf-weather-condition {
        margin-top: 4px;
        color: #9fb9c4;
        font-size: 10px;
        font-weight: 750;
      }

      #${ROOT_ID} .iqf-weather-details {
        min-width: 0;
        display: grid;
        grid-template-columns: repeat(4, minmax(0,1fr));
        gap: 5px 13px;
        padding: 3px 0 3px 14px;
        align-content: center;
      }

      #${ROOT_ID} .iqf-weather-detail {
        min-width: 0;
      }

      #${ROOT_ID} .iqf-weather-detail-label {
        color: #7899a7;
        font-size: 8px;
        line-height: 1.1;
        font-weight: 900;
        text-transform: uppercase;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      #${ROOT_ID} .iqf-weather-detail-value {
        margin-top: 2px;
        color: #eefaff;
        font-size: 11px;
        line-height: 1.15;
        font-weight: 900;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      /* ---------------------------------------------------
         SHARED SYSTEM / USER TEMPLATE
         --------------------------------------------------- */
      #${ROOT_ID} .iqf-template-page {
        width: min(1580px, 100%);
        margin: 0 auto;
        padding-top: 42px;
      }

      #${ROOT_ID} .iqf-template-heading {
        margin-bottom: 18px;
      }

      #${ROOT_ID} .iqf-template-kicker {
        color: #57d8ff;
        font-size: 10px;
        font-weight: 900;
        letter-spacing: .16em;
        text-transform: uppercase;
      }

      #${ROOT_ID} .iqf-template-title {
        margin: 5px 0 3px;
        color: #f5fcff;
        font-size: clamp(25px, 2vw, 34px);
        line-height: 1.1;
        font-weight: 900;
      }

      #${ROOT_ID} .iqf-template-subtitle {
        color: #8faab6;
        font-size: 13px;
      }

      #${ROOT_ID} .iqf-card-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0,1fr));
        gap: 14px;
      }

      #${ROOT_ID} .iqf-template-card {
        min-width: 0;
        border: 1px solid #14536a;
        border-radius: 14px;
        background: #032530;
        padding: 17px 18px;
      }

      #${ROOT_ID} .iqf-template-card[data-wide="true"] {
        grid-column: 1 / -1;
      }

      #${ROOT_ID} .iqf-card-title {
        margin: 0 0 13px;
        color: #5adaff;
        font-size: 17px;
        font-weight: 900;
      }

      #${ROOT_ID} .iqf-kv-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0,1fr));
        gap: 8px 18px;
      }

      #${ROOT_ID} .iqf-kv {
        min-width: 0;
        border-bottom: 1px solid rgba(25,83,103,.52);
        padding: 5px 0 7px;
      }

      #${ROOT_ID} .iqf-kv-label {
        color: #7898a5;
        font-size: 9px;
        line-height: 1.1;
        font-weight: 850;
        text-transform: uppercase;
      }

      #${ROOT_ID} .iqf-kv-value {
        margin-top: 3px;
        color: #f0f9fc;
        font-size: 13px;
        line-height: 1.25;
        font-weight: 800;
        overflow-wrap: anywhere;
      }

      #${ROOT_ID} .iqf-list {
        display: grid;
        gap: 8px;
      }

      #${ROOT_ID} .iqf-list-row {
        display: grid;
        grid-template-columns: minmax(0,1fr) auto;
        gap: 12px;
        align-items: center;
        min-width: 0;
        border: 1px solid #104558;
        border-radius: 10px;
        padding: 9px 11px;
        background: #02212c;
      }

      #${ROOT_ID} .iqf-list-main {
        color: #eefaff;
        font-size: 12px;
        font-weight: 800;
        overflow-wrap: anywhere;
      }

      #${ROOT_ID} .iqf-list-sub {
        margin-top: 3px;
        color: #809eab;
        font-size: 10px;
        overflow-wrap: anywhere;
      }

      #${ROOT_ID} .iqf-state {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 72px;
        border-radius: 999px;
        padding: 5px 9px;
        border: 1px solid #33596a;
        color: #b8c8ce;
        font-size: 9px;
        line-height: 1;
        font-weight: 900;
        text-transform: uppercase;
      }

      #${ROOT_ID} .iqf-state[data-good="true"] {
        color: #7effdf;
        border-color: #278a77;
        background: rgba(25,114,94,.16);
      }

      #${ROOT_ID} .iqf-loading,
      #${ROOT_ID} .iqf-error {
        margin: 70px auto;
        width: min(620px, 90%);
        border: 1px solid #16556a;
        border-radius: 13px;
        background: #032530;
        padding: 24px;
        color: #cce4ec;
        text-align: center;
        font-size: 14px;
      }

      #${ROOT_ID} .iqf-error {
        border-color: #8c5151;
        color: #ffd0d0;
      }

      /* USER PROFILE */
      #${ROOT_ID} .iqf-profile-head {
        display: grid;
        grid-template-columns: 76px minmax(0,1fr);
        gap: 15px;
        align-items: center;
      }

      #${ROOT_ID} .iqf-avatar {
        width: 72px;
        height: 72px;
        border-radius: 50%;
        border: 2px solid #39cbf5;
        display: grid;
        place-items: center;
        background: #063444;
        color: #fff;
        font-size: 25px;
        font-weight: 900;
      }

      #${ROOT_ID} .iqf-profile-name {
        color: #fff;
        font-size: 23px;
        line-height: 1.15;
        font-weight: 900;
      }

      #${ROOT_ID} .iqf-profile-email {
        margin-top: 5px;
        color: #9cb4be;
        font-size: 13px;
      }

      #${ROOT_ID} .iqf-password-form {
        display: grid;
        gap: 10px;
      }

      #${ROOT_ID} .iqf-field {
        display: grid;
        gap: 5px;
      }

      #${ROOT_ID} .iqf-field label {
        color: #9bb3bd;
        font-size: 10px;
        font-weight: 850;
        text-transform: uppercase;
      }

      #${ROOT_ID} .iqf-field input {
        width: 100%;
        border: 1px solid #246176;
        border-radius: 8px;
        background: #042a37;
        color: #fff;
        padding: 10px 11px;
        font: inherit;
        font-size: 13px;
      }

      #${ROOT_ID} .iqf-field input:focus {
        outline: 2px solid #43d1fa;
        outline-offset: 1px;
      }

      #${ROOT_ID} .iqf-primary-button {
        justify-self: start;
        border: 1px solid #238b82;
        border-radius: 8px;
        background: #106357;
        color: #effffb;
        padding: 9px 15px;
        font: inherit;
        font-size: 12px;
        font-weight: 900;
        cursor: pointer;
      }

      #${ROOT_ID} .iqf-primary-button:disabled {
        opacity: .55;
        cursor: default;
      }

      #${ROOT_ID} .iqf-form-message {
        min-height: 17px;
        color: #8fdccf;
        font-size: 11px;
      }

      /* ---------------------------------------------------
         R4R3 — JMM / project-standard Installed module card
         --------------------------------------------------- */
      .iqf-hp-jmm-operational-section {
        width: 100%;
        margin: 20px 0 18px;
        padding-top: 18px;
        border-top: 4px solid transparent;
        border-image:
          linear-gradient(
            90deg,
            #3bdcff,
            #27cab2,
            rgba(39,202,178,.08)
          ) 1;
      }

      .iqf-hp-jmm-operational-header {
        display: grid;
        grid-template-columns: minmax(0,1fr) auto;
        align-items: end;
        gap: 14px;
        margin-bottom: 20px;
      }

      .iqf-hp-jmm-kicker {
        color: #56d8ff;
        font-size: 10px;
        font-weight: 900;
        letter-spacing: .17em;
        line-height: 1;
        text-transform: uppercase;
      }

      .iqf-hp-jmm-title {
        margin: 8px 0 5px;
        color: #f8fcff;
        font-size: 19px;
        line-height: 1.1;
        font-weight: 900;
      }

      .iqf-hp-jmm-subtitle {
        color: #8faab5;
        font-size: 12px;
        line-height: 1.35;
      }

      .iqf-hp-jmm-count {
        border: 1px solid #23846f;
        border-radius: 999px;
        background: rgba(18,102,84,.20);
        color: #74f1d5;
        padding: 8px 12px;
        font-size: 10px;
        line-height: 1;
        font-weight: 900;
        white-space: nowrap;
      }

      .iqf-hp-jmm-grid.admin-operational-module-grid {
        display: grid;
        grid-template-columns:
          repeat(auto-fit, minmax(min(340px, 100%), 390px));
        gap: 18px;
        align-items: stretch;
        justify-content: start;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"] {
        width: min(390px, 100%);
        min-height: 255px;
        border: 1px solid #2b8ea9;
        border-radius: 16px;
        background:
          linear-gradient(
            135deg,
            rgba(12,76,92,.98),
            rgba(5,50,64,.98)
          );
        padding: 18px;
        box-shadow:
          inset 0 0 0 1px rgba(70,210,242,.04),
          0 12px 30px rgba(0,0,0,.10);
        color: #eefaff;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-head {
        display: grid;
        grid-template-columns: 54px minmax(0,1fr) auto;
        gap: 13px;
        align-items: center;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-icon {
        width: 52px;
        height: 52px;
        border: 1px solid #36b9dc;
        border-radius: 17px;
        background: #0a556a;
        display: grid;
        place-items: center;
        color: #65e1ff;
        font-size: 14px;
        font-weight: 900;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-type {
        color: #60ddff;
        font-size: 10px;
        font-weight: 900;
        letter-spacing: .15em;
        line-height: 1;
        text-transform: uppercase;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-name {
        margin-top: 8px;
        color: #fff;
        font-size: 22px;
        line-height: 1.14;
        font-weight: 900;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-state {
        border: 1px solid #238b72;
        border-radius: 999px;
        background: rgba(21,113,91,.20);
        color: #6ff1d3;
        padding: 7px 10px;
        font-size: 10px;
        line-height: 1;
        font-weight: 900;
        white-space: nowrap;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-values {
        display: grid;
        grid-template-columns: repeat(2, minmax(0,1fr));
        gap: 10px;
        margin-top: 17px;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-value {
        min-width: 0;
        min-height: 86px;
        border: 1px solid #17576e;
        border-radius: 12px;
        background: #032b38;
        padding: 13px;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-value-label {
        color: #7f9aa5;
        font-size: 11px;
        line-height: 1.1;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-value-main {
        margin-top: 9px;
        color: #f5fbff;
        font-size: 18px;
        line-height: 1.08;
        font-weight: 900;
        overflow-wrap: anywhere;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-footer {
        margin-top: 14px;
        padding-top: 12px;
        border-top: 1px solid rgba(42,111,132,.55);
        display: grid;
        grid-template-columns: minmax(0,1fr) auto;
        gap: 12px;
        align-items: center;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-updated {
        color: #849eaa;
        font-size: 11px;
        line-height: 1.25;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-open {
        border: 1px solid #326779;
        border-radius: 10px;
        background: #173844;
        color: #f3fbff;
        padding: 11px 16px;
        font: inherit;
        font-size: 12px;
        font-weight: 900;
        cursor: pointer;
      }

      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-open:hover,
      .admin-operational-module-card[data-iqf-heat-pump-card="true"]
      .iqf-hp-standard-open:focus-visible {
        outline: none;
        border-color: #43d4ff;
        background: #0c4559;
      }

      @media (max-width: 720px) {
        .admin-operational-module-card[data-iqf-heat-pump-card="true"]
        .iqf-hp-standard-values {
          grid-template-columns: 1fr;
        }

        .admin-operational-module-card[data-iqf-heat-pump-card="true"]
        .iqf-hp-standard-head {
          grid-template-columns: 50px minmax(0,1fr);
        }

        .admin-operational-module-card[data-iqf-heat-pump-card="true"]
        .iqf-hp-standard-state {
          grid-column: 1 / -1;
          justify-self: start;
        }
      }

      #${TOAST_ID} {
        position: fixed;
        z-index: 2147483000;
        top: 23px;
        left: 50%;
        transform: translateX(-50%);
        max-width: min(560px, calc(100vw - 32px));
        border: 1px solid #2c728b;
        border-radius: 9px;
        background: rgba(2,34,46,.98);
        color: #eefaff;
        padding: 11px 15px;
        font: inherit;
        font-size: 12px;
        font-weight: 800;
        box-shadow: 0 14px 38px rgba(0,0,0,.35);
      }

      #${TOAST_ID}[data-type="error"] {
        border-color: #8e5050;
        color: #ffd7d7;
      }

      @media (max-width: 1120px) {
        #${ROOT_ID} .iqf-hp-bottom-shell {
          grid-template-columns: minmax(500px, 46%) minmax(260px, 24%) minmax(0,30%);
        }

        #${ROOT_ID} .iqf-weather-panel {
          grid-template-columns: 1fr;
        }

        #${ROOT_ID} .iqf-weather-details {
          display: none;
        }
      }

      @media (max-width: 920px) {
        #${ROOT_ID} {
          grid-template-rows: minmax(0,1fr) 94px !important;
        }

        #${ROOT_ID} .iqf-hp-bottom-shell {
          grid-template-columns: 1fr;
          padding: 4px;
        }

        #${ROOT_ID} .iqf-hp-identity-panel,
        #${ROOT_ID} .iqf-hp-weather-panel {
          display: none;
        }

        #${ROOT_ID} .iqf-hp-menu-panel {
          border-radius: 12px;
        }

        #${ROOT_ID} .iqf-hp-nav-label {
          font-size: 9px;
        }

        #${ROOT_ID} .iqf-card-grid,
        #${ROOT_ID} .iqf-kv-grid {
          grid-template-columns: 1fr;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function setActiveNav(root) {
    root.querySelectorAll(".iqf-hp-nav").forEach((button) => {
      button.dataset.active =
        button.dataset.tab === currentTab ? "true" : "false";
    });
  }

  function stateBadge(textValue, good) {
    const badge = element("span", "iqf-state", textValue);
    badge.dataset.good = good ? "true" : "false";
    return badge;
  }

  function kv(label, value) {
    const row = element("div", "iqf-kv");
    row.append(
      element("div", "iqf-kv-label", label),
      element("div", "iqf-kv-value", value),
    );
    return row;
  }

  function card(title, wide = false) {
    const node = element("section", "iqf-template-card");
    node.dataset.wide = wide ? "true" : "false";
    node.appendChild(element("h3", "iqf-card-title", title));
    return node;
  }

  function listRow(main, sub, state, good) {
    const row = element("div", "iqf-list-row");
    const copy = element("div");
    copy.append(
      element("div", "iqf-list-main", main),
      element("div", "iqf-list-sub", sub),
    );
    row.append(copy, stateBadge(state, good));
    return row;
  }

  function currentWeatherObject(raw) {
    return (
      raw?.current ||
      raw?.weather?.current ||
      {}
    );
  }

  function weatherPick(obj, keys) {
    for (const key of keys) {
      if (
        obj &&
        obj[key] !== null &&
        obj[key] !== undefined &&
        obj[key] !== ""
      ) {
        return obj[key];
      }
    }

    return null;
  }

  function conditionIcon(condition) {
    const c = String(condition || "").toLowerCase();

    if (/storm|bouř|thunder/.test(c)) return "⛈";
    if (/snow|sníh/.test(c)) return "❄";
    if (/rain|déšť|drizzle/.test(c)) return "🌧";
    if (/cloud|obla|overcast/.test(c)) return "☁";
    if (/clear|jasno|sun/.test(c)) return "☀";

    return "◌";
  }

  function renderWeather(root) {
    const panel = root.querySelector(".iqf-hp-weather-panel");

    if (!panel) return;

    clear(panel);

    const current = currentWeatherObject(weatherData);

    const temperature = weatherPick(current, [
      "temperature",
      "temperature_2m",
      "temperature_c",
      "temp_c",
    ]);

    const apparent = weatherPick(current, [
      "apparent_temperature",
      "feels_like",
      "apparent_temperature_c",
    ]);

    const humidity = weatherPick(current, [
      "relative_humidity",
      "relative_humidity_2m",
      "humidity",
      "humidity_percent",
    ]);

    const pressure = weatherPick(current, [
      "pressure_msl",
      "surface_pressure",
      "pressure",
      "pressure_hpa",
    ]);

    const wind = weatherPick(current, [
      "wind_speed",
      "wind_speed_10m",
      "wind_speed_kmh",
    ]);

    const direction = weatherPick(current, [
      "wind_direction",
      "wind_direction_10m",
      "wind_direction_deg",
    ]);

    const gusts = weatherPick(current, [
      "wind_gusts",
      "wind_gusts_10m",
      "wind_gusts_kmh",
    ]);

    const rain = weatherPick(current, [
      "precipitation_probability",
      "precipitation_probability_percent",
      "precipitation",
    ]);

    const condition = weatherPick(current, [
      "condition",
      "weather_condition",
      "description",
    ]) || "Počasí";

    const warning = weatherPick(current, [
      "warning",
      "warnings",
      "alert",
    ]);

    const main = element("div", "iqf-weather-main");
    main.appendChild(
      element("div", "iqf-weather-icon", conditionIcon(condition))
    );

    const primary = element("div");
    primary.append(
      element(
        "div",
        "iqf-weather-temp",
        temperature === null
          ? "— °C"
          : `${number(temperature, 1)} °C`
      ),
      element(
        "div",
        "iqf-weather-condition",
        String(condition)
      ),
    );
    main.appendChild(primary);

    const details = element("div", "iqf-weather-details");

    const entries = [
      ["Pocitová teplota", apparent === null ? "—" : `${number(apparent,1)} °C`],
      ["Relativní vlhkost", humidity === null ? "—" : `${number(humidity,0)} %`],
      ["Atmosférický tlak", pressure === null ? "—" : `${number(pressure,1)} hPa`],
      ["Vítr", wind === null ? "—" : `${number(wind,1)} km/h`],
      ["Směr větru", direction === null ? "—" : `${number(direction,0)} °`],
      ["Nárazy větru", gusts === null ? "—" : `${number(gusts,1)} km/h`],
      ["Pravděpodobnost srážek", rain === null ? "—" : `${number(rain,0)} %`],
      ["Výstrahy", warning ? String(warning) : "Bez výstrahy"],
    ];

    for (const [label, value] of entries) {
      const item = element("div", "iqf-weather-detail");
      item.append(
        element("div", "iqf-weather-detail-label", label),
        element("div", "iqf-weather-detail-value", value),
      );
      details.appendChild(item);
    }

    panel.append(main, details);
  }

  function normalizeAdminSystem(detail) {
    const comm = (
      detail?.communication_state &&
      typeof detail.communication_state === "object"
    ) ? detail.communication_state : {};

    const network = (
      comm.network_state &&
      typeof comm.network_state === "object"
    ) ? comm.network_state : {};

    const wifi = (
      network.wifi &&
      typeof network.wifi === "object"
    ) ? network.wifi : {};

    const zigbee = (
      comm.zigbee_telemetry &&
      typeof comm.zigbee_telemetry === "object"
    ) ? comm.zigbee_telemetry : {};

    const communicators = Array.isArray(comm.communicators)
      ? comm.communicators
      : [];

    const wifiCandidates = [
      comm.wifi_native_devices,
      comm.native_wifi_devices,
      comm.wifi_devices,
      comm?.wifi?.registry,
    ];

    const wifiDevices =
      wifiCandidates.find(Array.isArray) || [];

    return {
      hardware: {
        model: detail?.model,
        hardware_revision: detail?.hardware_revision,
        hostname: detail?.hostname,
        software_version: detail?.software_version,
        device_status: detail?.device_status,
        last_seen_at: detail?.last_seen_at,
        uptime_seconds: detail?.uptime_seconds,
        cpu_usage_percent: detail?.cpu_usage_percent,
        cpu_temperature_celsius: detail?.cpu_temperature_celsius,
        memory_usage_percent: detail?.memory_usage_percent,
        disk_usage_percent: detail?.disk_usage_percent,
        internet_connected: detail?.internet_connected,
        home_assistant_running: detail?.home_assistant_running,
        home_assistant_version: detail?.home_assistant_version,
        active_modules_count: detail?.active_modules_count,
        health_status: (
          detail?.is_online === true ? "ok" : "unknown"
        ),
      },
      network: {
        connection_type: network.connection_type,
        interface: network.interface,
        ip_address: network.ip_address || detail?.ip_address,
        mac_address: network.mac_address || detail?.mac_address,
        wifi_connected: wifi.connected === true,
        wifi_ssid: wifi.ssid,
        wifi_signal_percent:
          wifi.signal_percent ?? wifi.signal,
      },
      communicators,
      zigbee: {
        available: zigbee.zha_available === true,
        network_initialized: zigbee.network_initialized === true,
        coordinator_name:
          zigbee?.coordinator?.model || null,
        coordinator_manufacturer:
          zigbee?.coordinator?.manufacturer || null,
        device_count:
          Number(zigbee.device_count || 0),
        online_device_count:
          Number(zigbee.online_device_count || 0),
        offline_device_count:
          Number(zigbee.offline_device_count || 0),
        devices: Array.isArray(zigbee.devices)
          ? zigbee.devices
          : [],
      },
      wifi_devices: wifiDevices,
    };
  }

  function normalizePortalSystem(info) {
    return {
      hardware: info?.hardware || {},
      network: info?.network || {},
      communicators: Array.isArray(info?.communicators)
        ? info.communicators
        : [],
      zigbee: info?.zigbee || {},
      wifi_devices: [],
    };
  }

  async function loadWeather(state, userMode) {
    // P101: discard late responses after device/account change, for either entry path.
    const requestState = activeState;
    const requestMode = activeMode;
    const requestAuth = token();
    let received = null;
    try {
      if (userMode === "admin") {
        received = await jsonFetch(
          `${API}/admin/sites/${encodeURIComponent(state.site_id)}/weather`
        );
      } else {
        received = await jsonFetch(
          `${API}/portal/devices/${encodeURIComponent(state.device_uuid)}/system-overview`
        );
      }
    } catch (_) { received = null; }
    if (activeState !== requestState || activeMode !== requestMode || token() !== requestAuth) return;
    weatherData = received;
    const root = document.getElementById(ROOT_ID);
    if (root) renderWeather(root);
  }

  async function loadSystem(state, userMode) {
    if (userMode === "admin") {
      const raw = await jsonFetch(
        `${API}/admin/devices/${encodeURIComponent(state.device_uuid)}`
      );

      return normalizeAdminSystem(raw);
    }

    const raw = await jsonFetch(
      `${API}/portal/devices/${encodeURIComponent(state.device_uuid)}/system-info`
    );

    return normalizePortalSystem(raw);
  }

  async function loadUser(state, userMode) {
    if (userMode === "admin") {
      const raw = await jsonFetch(
        `${API}/admin/devices/${encodeURIComponent(state.device_uuid)}`
      );

      return {
        mode: "admin",
        id: raw.owner_id,
        first_name: raw.owner_first_name,
        last_name: raw.owner_last_name,
        email: raw.owner_email,
        phone: raw.owner_phone,
        contact_person: raw.owner_contact_person,
        site_name: raw.site_name,
        address: [
          raw.address_line1,
          raw.address_line2,
          raw.city,
          raw.postal_code,
        ].filter(Boolean).join(", "),
      };
    }

    const raw = await jsonFetch(
      `${API}/portal/me`
    );

    const site = Array.isArray(raw?.sites)
      ? raw.sites.find(
          (candidate) =>
            String(candidate?.id) === String(state.site_id)
        ) || raw.sites[0]
      : null;

    return {
      mode: "portal",
      ...raw,
      site_name: site?.name,
      address: [
        site?.address_line1,
        site?.address_line2,
        site?.city,
        site?.postal_code,
      ].filter(Boolean).join(", "),
    };
  }

  function renderSystem(root) {
    const stage = root.querySelector(".iqf-hp-stage-inner");

    if (!stage) return;

    stage.dataset.blank = "false";
    clear(stage);

    if (!systemData) {
      stage.appendChild(
        element("div", "iqf-loading", "Načítám systémové informace…")
      );
      return;
    }

    if (systemData.error) {
      stage.appendChild(
        element("div", "iqf-error", systemData.error)
      );
      return;
    }

    const page = element("section", "iqf-template-page");

    const head = element("header", "iqf-template-heading");
    head.append(
      element("div", "iqf-template-kicker", "Systém zařízení"),
      element("h1", "iqf-template-title", "Systém"),
      element(
        "div",
        "iqf-template-subtitle",
        "Aktuální stav instalace, komunikátorů a sítí."
      ),
    );

    const grid = element("div", "iqf-card-grid");

    const hw = systemData.hardware || {};
    const hwCard = card("Hardware a provozní stav");

    const hwKv = element("div", "iqf-kv-grid");
    hwKv.append(
      kv("Model", fmt(hw.model)),
      kv("HW revize", fmt(hw.hardware_revision)),
      kv("Hostname", fmt(hw.hostname)),
      kv("Verze Agentu", fmt(hw.software_version)),
      kv("Stav zařízení", fmt(hw.device_status)),
      kv("Poslední kontakt", dateTime(hw.last_seen_at)),
      kv("Uptime", seconds(hw.uptime_seconds)),
      kv(
        "CPU",
        hw.cpu_usage_percent == null
          ? "—"
          : `${number(hw.cpu_usage_percent,1)} %`
      ),
      kv(
        "Teplota CPU",
        hw.cpu_temperature_celsius == null
          ? "—"
          : `${number(hw.cpu_temperature_celsius,1)} °C`
      ),
      kv(
        "Paměť",
        hw.memory_usage_percent == null
          ? "—"
          : `${number(hw.memory_usage_percent,1)} %`
      ),
      kv(
        "Disk",
        hw.disk_usage_percent == null
          ? "—"
          : `${number(hw.disk_usage_percent,1)} %`
      ),
      kv(
        "Home Assistant",
        hw.home_assistant_running === true
          ? `Běží${hw.home_assistant_version ? ` · ${hw.home_assistant_version}` : ""}`
          : hw.home_assistant_running === false
            ? "Neběží"
            : "—"
      ),
    );
    hwCard.appendChild(hwKv);

    const communicatorCard = card(
      "Připojené komunikátory a senzory"
    );
    const communicatorList = element("div", "iqf-list");

    const communicators = Array.isArray(systemData.communicators)
      ? systemData.communicators
      : [];

    if (!communicators.length) {
      communicatorList.appendChild(
        listRow(
          "Žádný komunikátor zatím není hlášen",
          "Po připojení komunikátoru se zobrazí automaticky.",
          "čeká",
          false
        )
      );
    } else {
      for (const communicator of communicators) {
        const assigned = (
          Array.isArray(communicator.assigned_devices)
            ? communicator.assigned_devices
            : []
        );

        const assignmentText = assigned.length
          ? assigned.map((item) =>
              [
                item.module_name || item.device_type,
                item.manufacturer,
                item.model,
              ].filter(Boolean).join(" · ")
            ).join("; ")
          : "Bez přiřazeného technologického zařízení";

        communicatorList.appendChild(
          listRow(
            communicator.type_name ||
              communicator.product ||
              communicator.communicator_type ||
              communicator.type ||
              "Komunikátor",
            assignmentText,
            communicator.connected === true ||
              communicator.status === "ready"
              ? "online"
              : communicator.status_name ||
                communicator.status ||
                "neznámý",
            communicator.connected === true ||
              communicator.status === "ready"
          )
        );
      }
    }

    communicatorCard.appendChild(communicatorList);

    const zigbeeCard = card("Zigbee síť");
    const z = systemData.zigbee || {};

    const zKv = element("div", "iqf-kv-grid");
    zKv.append(
      kv(
        "Stav sítě",
        z.network_initialized === true
          ? "Inicializována"
          : z.available === true
            ? "Dostupná"
            : "Nedostupná"
      ),
      kv(
        "Koordinátor",
        [
          z.coordinator_manufacturer,
          z.coordinator_name,
        ].filter(Boolean).join(" · ") || "—"
      ),
      kv("Zařízení celkem", fmt(z.device_count)),
      kv("Online", fmt(z.online_device_count)),
      kv("Offline", fmt(z.offline_device_count)),
      kv(
        "Aktuálně známé uzly",
        Array.isArray(z.devices)
          ? String(z.devices.length)
          : "0"
      ),
    );
    zigbeeCard.appendChild(zKv);

    const wifiCard = card("Wi‑Fi zařízení");
    const net = systemData.network || {};
    const wifiKv = element("div", "iqf-kv-grid");
    wifiKv.append(
      kv(
        "Wi‑Fi",
        net.wifi_connected === true
          ? "Připojeno"
          : "Nepřipojeno"
      ),
      kv("SSID", fmt(net.wifi_ssid)),
      kv(
        "Signál",
        net.wifi_signal_percent == null
          ? "—"
          : `${number(net.wifi_signal_percent,0)} %`
      ),
      kv("IP adresa", fmt(net.ip_address)),
      kv("Rozhraní", fmt(net.interface)),
      kv(
        "Zařízení v registru",
        String(
          Array.isArray(systemData.wifi_devices)
            ? systemData.wifi_devices.length
            : 0
        )
      ),
    );
    wifiCard.appendChild(wifiKv);

    grid.append(
      hwCard,
      communicatorCard,
      zigbeeCard,
      wifiCard,
    );

    page.append(head, grid);
    stage.appendChild(page);
  }

  async function changePassword(form, message) {
    const current = form.querySelector("[name='current_password']");
    const next = form.querySelector("[name='new_password']");
    const confirm = form.querySelector("[name='new_password_confirmation']");
    const button = form.querySelector("button");

    const body = {
      current_password: current.value,
      new_password: next.value,
      new_password_confirmation: confirm.value,
    };

    if (
      body.current_password.length < 8 ||
      body.new_password.length < 8 ||
      body.new_password_confirmation.length < 8
    ) {
      message.textContent = "Heslo musí mít alespoň 8 znaků.";
      return;
    }

    button.disabled = true;
    message.textContent = "Ukládám…";

    try {
      const result = await jsonFetch(
        `${API}/auth/change-password`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(body),
        }
      );

      message.textContent =
        result?.detail || "Heslo bylo změněno.";

      form.reset();
    } catch (error) {
      message.textContent =
        error?.message || "Heslo se nepodařilo změnit.";
    } finally {
      button.disabled = false;
    }
  }

  function initials(data) {
    const a = String(data?.first_name || "").trim().charAt(0);
    const b = String(data?.last_name || "").trim().charAt(0);

    return (a + b).toUpperCase() || "U";
  }

  function renderUser(root) {
    const stage = root.querySelector(".iqf-hp-stage-inner");

    if (!stage) return;

    stage.dataset.blank = "false";
    clear(stage);

    if (!userData) {
      stage.appendChild(
        element("div", "iqf-loading", "Načítám uživatelský profil…")
      );
      return;
    }

    if (userData.error) {
      stage.appendChild(
        element("div", "iqf-error", userData.error)
      );
      return;
    }

    const page = element("section", "iqf-template-page");

    const head = element("header", "iqf-template-heading");
    head.append(
      element("div", "iqf-template-kicker", "Profil zákazníka"),
      element("h1", "iqf-template-title", "Uživatel"),
      element(
        "div",
        "iqf-template-subtitle",
        "Kontaktní údaje a zabezpečení uživatelského účtu."
      ),
    );

    const grid = element("div", "iqf-card-grid");

    const profile = card("Profil zákazníka");
    const profileHead = element("div", "iqf-profile-head");

    profileHead.append(
      element("div", "iqf-avatar", initials(userData)),
      (() => {
        const copy = element("div");
        copy.append(
          element(
            "div",
            "iqf-profile-name",
            [
              userData.first_name,
              userData.last_name,
            ].filter(Boolean).join(" ") || "Uživatel"
          ),
          element(
            "div",
            "iqf-profile-email",
            fmt(userData.email)
          ),
        );
        return copy;
      })(),
    );

    const profileKv = element("div", "iqf-kv-grid");
    profileKv.style.marginTop = "15px";
    profileKv.append(
      kv("Telefon", fmt(userData.phone)),
      kv("Lokalita", fmt(userData.site_name)),
      kv("Adresa", fmt(userData.address)),
      kv(
        "Role",
        userData.mode === "admin"
          ? "Klient této instalace"
          : fmt(userData.role)
      ),
    );

    if (userData.contact_person) {
      profileKv.append(
        kv("Kontaktní osoba", fmt(userData.contact_person))
      );
    }

    profile.append(profileHead, profileKv);

    const password = card("Změna hesla");

    if (userData.mode === "portal") {
      const form = element("form", "iqf-password-form");

      const fields = [
        ["current_password", "Současné heslo"],
        ["new_password", "Nové heslo"],
        ["new_password_confirmation", "Potvrzení nového hesla"],
      ];

      for (const [name, label] of fields) {
        const field = element("div", "iqf-field");
        const labelNode = element("label", "", label);
        const input = element("input");
        input.type = "password";
        input.name = name;
        input.autocomplete =
          name === "current_password"
            ? "current-password"
            : "new-password";

        field.append(labelNode, input);
        form.appendChild(field);
      }

      const message = element("div", "iqf-form-message");

      const submit = element(
        "button",
        "iqf-primary-button",
        "Změnit heslo"
      );
      submit.type = "submit";

      form.append(submit, message);

      form.addEventListener("submit", (event) => {
        event.preventDefault();
        changePassword(form, message);
      });

      password.appendChild(form);
    } else {
      password.append(
        element(
          "div",
          "iqf-list-sub",
          "Heslo klienta mění klient po přihlášení do svého portálu. Administrátor zde vidí stejné profilové údaje, ale heslo klienta nemění."
        )
      );
    }

    grid.append(profile, password);
    page.append(head, grid);
    stage.appendChild(page);
  }

/* SE01 -- owned content inside the existing heat_pump workspace.
 * No backend mutation, no Modbus writer, no broad DOM injection.
 */
const SE01_SERIAL = "F800711-TNG-00016";
const SE01_STYLE = "iqf-solareast-se01-style";
const SE01_CATALOG = [{"address":"0x0000","key":"running_state_1","label":"Provozní stav 1","kind":"bits","unit":"","scale":null,"source_page":13,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0001","key":"running_state_2","label":"Provozní stav 2","kind":"bits","unit":"","scale":null,"source_page":13,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0002","key":"fault_0002","label":"Poruchový registr 0x0002","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0003","key":"fault_0003","label":"Poruchový registr 0x0003","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0004","key":"fault_0004","label":"Poruchový registr 0x0004","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0005","key":"fault_0005","label":"Poruchový registr 0x0005","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0006","key":"fault_0006","label":"Poruchový registr 0x0006","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0007","key":"fault_0007","label":"Poruchový registr 0x0007","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0008","key":"fault_0008","label":"Poruchový registr 0x0008","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0009","key":"fault_0009","label":"Poruchový registr 0x0009","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x000A","key":"fault_000a","label":"Poruchový registr 0x000A","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x000B","key":"fault_000b","label":"Poruchový registr 0x000B","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x000C","key":"fault_000c","label":"Poruchový registr 0x000C","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x000D","key":"fault_000d","label":"Poruchový registr 0x000D","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x000E","key":"fault_000e","label":"Poruchový registr 0x000E","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x000F","key":"fault_000f","label":"Poruchový registr 0x000F","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0010","key":"fault_0010","label":"Poruchový registr 0x0010","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0011","key":"fault_0011","label":"Poruchový registr 0x0011","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0012","key":"fault_0012","label":"Poruchový registr 0x0012","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0013","key":"fault_0013","label":"Poruchový registr 0x0013","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0014","key":"fault_0014","label":"Poruchový registr 0x0014","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0015","key":"fault_0015","label":"Poruchový registr 0x0015","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0016","key":"fault_0016","label":"Poruchový registr 0x0016","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0017","key":"fault_0017","label":"Poruchový registr 0x0017","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0018","key":"fault_0018","label":"Poruchový registr 0x0018","kind":"bits","unit":"","scale":null,"source_page":5,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0019","key":"relays_0019","label":"Výstupy relé 1","kind":"bits","unit":"","scale":null,"source_page":20,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x001A","key":"relays_001a","label":"Výstupy relé 2","kind":"bits","unit":"","scale":null,"source_page":20,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x001B","key":"relays_001b","label":"Výstupy relé 3","kind":"bits","unit":"","scale":null,"source_page":21,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x001C","key":"relays_001c","label":"Výstupy relé 4","kind":"bits","unit":"","scale":null,"source_page":21,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x001D","key":"inputs_001d","label":"Digitální vstupy 1","kind":"bits","unit":"","scale":null,"source_page":21,"fault":null,"notes":"Aktivní logika kontaktů: 0 = sepnutý, 1 = rozepnutý. Nezaměňovat s poruchami.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x001E","key":"inputs_001e","label":"Digitální vstupy 2","kind":"bits","unit":"","scale":null,"source_page":21,"fault":null,"notes":"Aktivní logika kontaktů: 0 = sepnutý, 1 = rozepnutý. Nezaměňovat s poruchami.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x001F","key":"inputs_001f","label":"Digitální vstupy 3","kind":"bits","unit":"","scale":null,"source_page":21,"fault":null,"notes":"Aktivní logika kontaktů: 0 = sepnutý, 1 = rozepnutý. Nezaměňovat s poruchami.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0020","key":"inputs_0020","label":"Digitální vstupy 4","kind":"bits","unit":"","scale":null,"source_page":21,"fault":null,"notes":"Aktivní logika kontaktů: 0 = sepnutý, 1 = rozepnutý. Nezaměňovat s poruchami.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0021","key":"fault_code","label":"Kód poruchy","kind":"fault","unit":"","scale":null,"source_page":6,"fault":null,"notes":"0xFFFF = normální stav, nikoli porucha. Nula není univerzální kód bez chyby.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0024","key":"reg_0024","label":"Číslo provedení jednotky","kind":"raw","unit":"","scale":null,"source_page":6,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0027","key":"reg_0027","label":"Cílová frekvence kompresoru 1","kind":"raw","unit":"","scale":null,"source_page":6,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0028","key":"reg_0028","label":"Cílová frekvence kompresoru 2","kind":"raw","unit":"","scale":null,"source_page":6,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0029","key":"reg_0029","label":"Stav kaskádních podřízených jednotek","kind":"raw","unit":"","scale":null,"source_page":6,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x002B","key":"pump_output_pct","label":"Výstup vodního čerpadla","kind":"number","unit":"%","scale":1,"source_page":6,"fault":null,"notes":"Požadovaný výstup, nikoli důkaz skutečného průtoku.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x002C","key":"fault_002c","label":"Poruchový stav 4","kind":"bits","unit":"","scale":null,"source_page":14,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x002D","key":"operating_mode_raw","label":"Aktuální provozní režim – kód","kind":"raw","unit":"","scale":null,"source_page":6,"fault":null,"notes":"Význam čísel této položky není v tabulce uveden. Nekopírovat automaticky enum z 0x0304.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x002E","key":"compressor_runtime_high","label":"Nativní doba kompresoru – horní slovo","kind":"u32_high","unit":"","scale":null,"source_page":6,"fault":null,"notes":"U32 = (0x002E << 16) | 0x002F; jednotka není uvedena.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x002F","key":"compressor_runtime_low","label":"Nativní doba kompresoru – dolní slovo","kind":"u32_low","unit":"","scale":null,"source_page":6,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0040","key":"compressor_frequency","label":"Frekvence kompresoru","kind":"number","unit":"Hz","scale":1,"source_page":7,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0041","key":"fan_speed_raw","label":"Frekvence / otáčky ventilátoru","kind":"raw","unit":"","scale":null,"source_page":7,"fault":null,"notes":"Tabulka rozlišuje frequency/speed bez jednoznačné jednotky pro toto provedení.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0042","key":"eev_steps","label":"Poloha elektronického expanzního ventilu","kind":"number","unit":"kroků","scale":1,"source_page":7,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0043","key":"evi_steps","label":"Poloha ventilu EVI","kind":"number","unit":"kroků","scale":1,"source_page":7,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0044","key":"drive_voltage","label":"Vstupní napětí pohonu","kind":"number","unit":"V","scale":1,"source_page":7,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0045","key":"drive_current","label":"Vstupní proud pohonu","kind":"number","unit":"A","scale":0.1,"source_page":7,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0046","key":"compressor_phase_current","label":"Fázový proud kompresoru","kind":"number","unit":"A","scale":0.1,"source_page":7,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0047","key":"ipm_temp","label":"Teplota IPM","kind":"temperature","unit":"°C","scale":null,"source_page":7,"fault":null,"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0048","key":"high_saturation_temp","label":"Vysokotlaká saturační teplota","kind":"temperature","unit":"°C","scale":null,"source_page":7,"fault":[6,0],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0049","key":"low_saturation_temp","label":"Nízkotlaká saturační teplota","kind":"temperature","unit":"°C","scale":null,"source_page":7,"fault":[6,1],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x004A","key":"outdoor_temp","label":"Venkovní teplota T1","kind":"temperature","unit":"°C","scale":null,"source_page":7,"fault":[2,9],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x004B","key":"coil_temp","label":"Venkovní výměník T2","kind":"temperature","unit":"°C","scale":null,"source_page":7,"fault":[5,7],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x004C","key":"plate_temp","label":"Deskový výměník T3","kind":"temperature","unit":"°C","scale":null,"source_page":7,"fault":null,"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x004D","key":"return_air_temp","label":"Return air temperature T4","kind":"temperature","unit":"°C","scale":null,"source_page":7,"fault":[5,8],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x004E","key":"discharge_temp","label":"Výtlak kompresoru T5","kind":"temperature","unit":"°C","scale":null,"source_page":8,"fault":[5,9],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x004F","key":"return_water_temp","label":"Vratná voda T6","kind":"temperature","unit":"°C","scale":null,"source_page":8,"fault":[2,7],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0050","key":"supply_water_temp","label":"Výstupní voda T7","kind":"temperature","unit":"°C","scale":null,"source_page":8,"fault":[2,13],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0051","key":"economizer_8_temp","label":"Ekonomizér T8","kind":"temperature","unit":"°C","scale":null,"source_page":8,"fault":[5,10],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0052","key":"economizer_9_temp","label":"Ekonomizér T9","kind":"temperature","unit":"°C","scale":null,"source_page":8,"fault":[5,11],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0053","key":"tooling_no","label":"Číslo provedení jednotky","kind":"raw","unit":"","scale":null,"source_page":8,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0054","key":"dhw_temp","label":"Teplota zásobníku TUV","kind":"temperature","unit":"°C","scale":null,"source_page":8,"fault":[2,6],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0055","key":"fluorine_board_temp","label":"Fluorine circuit board replacement temperature","kind":"temperature","unit":"°C","scale":null,"source_page":8,"fault":[4,2],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0056","key":"drive_manufacturer","label":"Výrobce pohonu – kód","kind":"raw","unit":"","scale":null,"source_page":8,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0057","key":"pump_pwm","label":"PWM vodního čerpadla","kind":"raw","unit":"","scale":null,"source_page":8,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0058","key":"flow_legacy_raw","label":"Průtok – původní registr","kind":"raw","unit":"","scale":null,"source_page":8,"fault":null,"notes":"Jednotka/škála nejsou uvedeny; nepoužít pro tepelný výkon bez ověření.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0059","key":"user_return_temp","label":"Uživatelská vratná voda","kind":"temperature","unit":"°C","scale":null,"source_page":8,"fault":[2,10],"notes":"Teplotní škálu porovnat s displejem. Globální pravidlo X10 je na str. 3 přeškrtnuté.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x005A","key":"voltage","label":"Vstupní napětí jednotky","kind":"number","unit":"V","scale":1,"source_page":8,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x005B","key":"current","label":"Vstupní proud jednotky","kind":"number","unit":"A","scale":0.01,"source_page":8,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x005C","key":"input_power_kw","label":"Elektrický příkon jednotky","kind":"number","unit":"kW","scale":0.01,"source_page":8,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x005D","key":"energy_total_kwh","label":"Spotřeba jednotky – čítač","kind":"number","unit":"kWh","scale":1,"source_page":8,"fault":null,"notes":"Dokumentovaná jednotka kWh. Rozlišení, přetečení a kontinuitu ověřit v provozu.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x005E","key":"system2_005e","label":"Frekvence kompresoru 2","kind":"raw","unit":"","scale":null,"source_page":9,"fault":null,"notes":"Volitelné: pouze pokud je skutečně osazen druhý kompresorový systém.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x005F","key":"system2_005f","label":"Otáčky ventilátoru 2","kind":"raw","unit":"","scale":null,"source_page":9,"fault":null,"notes":"Volitelné: pouze pokud je skutečně osazen druhý kompresorový systém.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0060","key":"system2_0060","label":"Kroky EEV 2","kind":"raw","unit":"","scale":null,"source_page":9,"fault":null,"notes":"Volitelné: pouze pokud je skutečně osazen druhý kompresorový systém.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0061","key":"system2_0061","label":"Kroky EVI 2","kind":"raw","unit":"","scale":null,"source_page":9,"fault":null,"notes":"Volitelné: pouze pokud je skutečně osazen druhý kompresorový systém.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0062","key":"system2_0062","label":"Napětí pohonu 2","kind":"raw","unit":"","scale":null,"source_page":9,"fault":null,"notes":"Volitelné: pouze pokud je skutečně osazen druhý kompresorový systém.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0063","key":"system2_0063","label":"Proud pohonu 2","kind":"raw","unit":"","scale":null,"source_page":9,"fault":null,"notes":"Volitelné: pouze pokud je skutečně osazen druhý kompresorový systém.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0064","key":"system2_0064","label":"Fázový proud kompresoru 2","kind":"raw","unit":"","scale":null,"source_page":9,"fault":null,"notes":"Volitelné: pouze pokud je skutečně osazen druhý kompresorový systém.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0065","key":"temp_0065","label":"IPM 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0066","key":"temp_0066","label":"Vysokotlaká saturační teplota 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0067","key":"temp_0067","label":"Nízkotlaká saturační teplota 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0068","key":"temp_0068","label":"Venkovní výměník 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0069","key":"temp_0069","label":"Vnitřní výměník 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x006A","key":"temp_006a","label":"Return air 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x006B","key":"temp_006b","label":"Výtlak 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x006C","key":"temp_006c","label":"Ekonomizér vstup 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x006D","key":"temp_006d","label":"Ekonomizér výstup 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x006E","key":"temp_006e","label":"Teplota za rekuperací 1","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x006F","key":"temp_006f","label":"Teplota za rekuperací 2","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0072","key":"dhw_source_temp","label":"Teplota zdroje TUV","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":[4,6],"notes":"Osazení a fyzické místo čidla ověřit, nesubstituovat jiným čidlem.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0073","key":"heating_source_temp","label":"Teplota zdroje vytápění","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":[4,7],"notes":"Osazení a fyzické místo čidla ověřit, nesubstituovat jiným čidlem.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0074","key":"buffer_temp","label":"Teplota topné akumulační nádrže","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":[4,8],"notes":"Osazení a fyzické místo čidla ověřit, nesubstituovat jiným čidlem.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0075","key":"total_water_temp","label":"Celková teplota vody","kind":"temperature","unit":"°C","scale":null,"source_page":9,"fault":[4,9],"notes":"Osazení a fyzické místo čidla ověřit, nesubstituovat jiným čidlem.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0076","key":"reg_0076","label":"Výkon fáze B","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0077","key":"current_0077","label":"Proud fáze B","kind":"number","unit":"A","scale":0.01,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0078","key":"reg_0078","label":"Výkon fáze C","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0079","key":"current_0079","label":"Proud fáze C","kind":"number","unit":"A","scale":0.01,"source_page":9,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x007A","key":"reg_007a","label":"Smart Grid stav","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x007B","key":"reg_007b","label":"Otevření směšovače zóny 2","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x007C","key":"zone1_mix_temp","label":"Směšovaná teplota zóny 1","kind":"temperature","unit":"°C","scale":null,"source_page":10,"fault":null,"notes":"Osazení a fyzické místo čidla ověřit, nesubstituovat jiným čidlem.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x007D","key":"reg_007d","label":"Otevření směšovače zóny 1","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x007E","key":"reg_007e","label":"Koncentrace chladiva","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x007F","key":"reg_007f","label":"Typ chladiva","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0080","key":"reg_0080","label":"Provozní doba čidla chladiva","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0081","key":"reg_0081","label":"Práh životnosti čidla chladiva","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0082","key":"reg_0082","label":"Životnost čidla chladiva","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0083","key":"reg_0083","label":"Firmware čidla chladiva","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0084","key":"reg_0084","label":"Vysoký tlak","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0085","key":"reg_0085","label":"Nízký tlak","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0086","key":"reg_0086","label":"Dny vysoušení podlahy","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0087","key":"reg_0087","label":"Teplota vysoušení podlahy","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0088","key":"reg_0088","label":"Firmware pohonu 1","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0089","key":"reg_0089","label":"DIP pohonu 1","kind":"raw","unit":"","scale":null,"source_page":10,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x008A","key":"reg_008a","label":"Firmware pohonu 2","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x008B","key":"reg_008b","label":"DIP pohonu 2","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x008C","key":"water_pressure_bar","label":"Tlak vody","kind":"number","unit":"bar","scale":0.01,"source_page":11,"fault":[44,5],"notes":"Ověřit podporu firmware. V1.44 doplňuje konfiguraci a chyby senzorů; nenulová odpověď sama neprokazuje osazení.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x008D","key":"water_flow_lpm","label":"Průtok vody","kind":"number","unit":"l/min","scale":0.1,"source_page":11,"fault":[44,4],"notes":"Ověřit podporu, osazení a platnost před výpočtem tepelného výkonu.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x008E","key":"reg_008e","label":"Model kompresoru 1","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x008F","key":"reg_008f","label":"Model kompresoru 2","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0090","key":"reg_0090","label":"Zbývající doba předehřevu","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00E0","key":"capacity_00e0","label":"Pořadové číslo 6min statistiky","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00E1","key":"capacity_00e1","label":"Elektrická energie za 6 minut [Wh]","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00E2","key":"capacity_00e2","label":"Cooling capacity in 6min [W]","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00E3","key":"capacity_00e3","label":"EER za 6 minut","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00E4","key":"capacity_00e4","label":"Aktuální EER","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00E5","key":"capacity_00e5","label":"Chladicí výkon – horní slovo","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00E6","key":"capacity_00e6","label":"Chladicí výkon – dolní slovo","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00E9","key":"capacity_00e9","label":"Heating capacity in 6min [W]","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00EA","key":"capacity_00ea","label":"COP za 6 minut","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00EB","key":"capacity_00eb","label":"Aktuální COP","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00EC","key":"capacity_00ec","label":"Topný výkon – horní slovo","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00ED","key":"capacity_00ed","label":"Topný výkon – dolní slovo","kind":"raw","unit":"","scale":null,"source_page":11,"fault":null,"notes":"Škála/platnost COP není popsána; bez ověření nevykreslovat jako skutečný COP.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00F8","key":"available_modes","label":"Dostupné režimy","kind":"bits","unit":"","scale":null,"source_page":12,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00FA","key":"heating_max","label":"Horní limit topné teploty","kind":"temperature","unit":"°C","scale":null,"source_page":13,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00FB","key":"heating_min","label":"Dolní limit topné teploty","kind":"temperature","unit":"°C","scale":null,"source_page":13,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00FC","key":"dhw_max","label":"Horní limit TUV","kind":"temperature","unit":"°C","scale":null,"source_page":13,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00FD","key":"dhw_min","label":"Dolní limit TUV","kind":"temperature","unit":"°C","scale":null,"source_page":13,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00FE","key":"cooling_max","label":"Horní limit chlazení","kind":"temperature","unit":"°C","scale":null,"source_page":13,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x00FF","key":"cooling_min","label":"Dolní limit chlazení","kind":"temperature","unit":"°C","scale":null,"source_page":13,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x011A","key":"heating_hysteresis","label":"Hystereze vytápění","kind":"setting","unit":"","scale":null,"source_page":23,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x012D","key":"slave_address","label":"Komunikační adresa","kind":"number","unit":"","scale":1,"source_page":23,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0130","key":"dhw_priority","label":"Povolení čidla / priorita TUV","kind":"setting","unit":"","scale":null,"source_page":23,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0160","key":"dhw_hysteresis","label":"Hystereze TUV","kind":"setting","unit":"","scale":null,"source_page":25,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0167","key":"minimum_mode_time","label":"Minimální doba před změnou režimu","kind":"setting","unit":"","scale":null,"source_page":25,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0172","key":"compressor_count","label":"Počet kompresorů","kind":"setting","unit":"","scale":null,"source_page":25,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0174","key":"water_control_method","label":"Řízení podle vratné / výstupní vody","kind":"setting","unit":"","scale":null,"source_page":25,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0196","key":"secondary_pump_mode","label":"Způsob řízení sekundárního čerpadla","kind":"setting","unit":"","scale":null,"source_page":26,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x01FE","key":"heating_medium","label":"Topné médium","kind":"setting","unit":"","scale":null,"source_page":30,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0201","key":"dual_zone_selection","label":"Dvě teplotní zóny – volba","kind":"setting","unit":"","scale":null,"source_page":30,"fault":null,"notes":"SE01 čte. Žádné změny servisních parametrů.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0301","key":"heating_setpoint","label":"Požadovaná topná teplota","kind":"temperature","unit":"°C","scale":null,"source_page":32,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0302","key":"dhw_setpoint","label":"Požadovaná teplota TUV","kind":"temperature","unit":"°C","scale":null,"source_page":32,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0303","key":"floor_setpoint","label":"Požadovaná podlahová teplota","kind":"temperature","unit":"°C","scale":null,"source_page":32,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0304","key":"requested_mode","label":"Nastavený režim","kind":"setting","unit":"","scale":null,"source_page":32,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0305","key":"controller_on","label":"Povolení jednotky","kind":"setting","unit":"","scale":null,"source_page":32,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0307","key":"performance_mode","label":"Standard / silný / tichý režim","kind":"setting","unit":"","scale":null,"source_page":32,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0309","key":"controller_clock","label":"Hodiny regulátoru","kind":"setting","unit":"","scale":null,"source_page":32,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0314","key":"heating_curve","label":"Výběr topné křivky","kind":"setting","unit":"","scale":null,"source_page":33,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0315","key":"dhw_curve","label":"Výběr křivky TUV","kind":"setting","unit":"","scale":null,"source_page":33,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0317","key":"zone2_target","label":"Cíl zóny 2","kind":"setting","unit":"","scale":null,"source_page":33,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0319","key":"zone1_target","label":"Cíl zóny 1","kind":"setting","unit":"","scale":null,"source_page":33,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0360","key":"identity_0360","label":"Verze programu","kind":"raw","unit":"","scale":null,"source_page":37,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0361","key":"identity_0361","label":"Typ produktu","kind":"raw","unit":"","scale":null,"source_page":37,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0362","key":"identity_0362","label":"Identifikace produktu","kind":"raw","unit":"","scale":null,"source_page":37,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0363","key":"identity_0363","label":"Verze protokolu","kind":"raw","unit":"","scale":null,"source_page":37,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03A1","key":"energy_03a1","label":"Vnitřní jednotka napětí A","kind":"number","unit":"V","scale":0.1,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03A3","key":"energy_03a3","label":"Vnitřní jednotka napětí B","kind":"number","unit":"V","scale":0.1,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03A5","key":"energy_03a5","label":"Vnitřní jednotka napětí C","kind":"number","unit":"V","scale":0.1,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03A7","key":"energy_03a7","label":"Vnitřní jednotka proud A","kind":"number","unit":"A","scale":0.001,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03A9","key":"energy_03a9","label":"Vnitřní jednotka proud B","kind":"number","unit":"A","scale":0.001,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03AB","key":"energy_03ab","label":"Vnitřní jednotka proud C","kind":"number","unit":"A","scale":0.001,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03AC","key":"energy_03ac","label":"Příkon vnitřní – high","kind":"raw","unit":"","scale":null,"source_page":45,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03AD","key":"energy_03ad","label":"Příkon vnitřní – low","kind":"raw","unit":"","scale":null,"source_page":45,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03AE","key":"energy_03ae","label":"Kumulovaná energie vnitřní – high","kind":"raw","unit":"","scale":null,"source_page":45,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03AF","key":"energy_03af","label":"Kumulovaná energie vnitřní – low","kind":"raw","unit":"","scale":null,"source_page":45,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03B3","key":"energy_03b3","label":"Venkovní jednotka napětí A","kind":"number","unit":"V","scale":0.1,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03B5","key":"energy_03b5","label":"Venkovní jednotka napětí B","kind":"number","unit":"V","scale":0.1,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03B7","key":"energy_03b7","label":"Venkovní jednotka napětí C","kind":"number","unit":"V","scale":0.1,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03B9","key":"energy_03b9","label":"Venkovní jednotka proud A","kind":"number","unit":"A","scale":0.001,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03BB","key":"energy_03bb","label":"Venkovní jednotka proud B","kind":"number","unit":"A","scale":0.001,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03BD","key":"energy_03bd","label":"Venkovní jednotka proud C","kind":"number","unit":"A","scale":0.001,"source_page":45,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03BE","key":"energy_03be","label":"Příkon venkovní – high","kind":"raw","unit":"","scale":null,"source_page":45,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03BF","key":"energy_03bf","label":"Příkon venkovní – low","kind":"raw","unit":"","scale":null,"source_page":45,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03C0","key":"energy_03c0","label":"Kumulovaná energie venkovní – high","kind":"raw","unit":"","scale":null,"source_page":45,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03C1","key":"energy_03c1","label":"Kumulovaná energie venkovní – low","kind":"raw","unit":"","scale":null,"source_page":45,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03C9","key":"energy_03c9","label":"Identifikátor platnosti dat","kind":"raw","unit":"","scale":null,"source_page":46,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03CA","key":"energy_03ca","label":"Topná energie – high","kind":"raw","unit":"","scale":null,"source_page":46,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03CB","key":"energy_03cb","label":"Topná energie – low","kind":"raw","unit":"","scale":null,"source_page":46,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03CC","key":"energy_03cc","label":"Chladicí energie – high","kind":"raw","unit":"","scale":null,"source_page":46,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x03CD","key":"energy_03cd","label":"Chladicí energie – low","kind":"raw","unit":"","scale":null,"source_page":46,"fault":null,"notes":"0x03AE/AF a 0x03C0/C1: tabulka uvádí 0.01 kW u kumulované energie; jednotkový rozpor ponechat otevřený. 0x03CA–CD: 0.01 kWh. Význam identifikátoru platnosti není vysvětlen.","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0800","key":"heater_loading_cycle","label":"Cyklus přídavného ohřevu","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0801","key":"disinfection_mode","label":"Vysokoteplotní funkce – režim","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0802","key":"disinfection_interval","label":"Interval vysokoteplotního cyklu","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0803","key":"disinfection_start_raw","label":"Čas vysokoteplotního cyklu – RAW","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0804","key":"disinfection_duration_min","label":"Doba vysokoteplotního cyklu","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0805","key":"disinfection_target","label":"Teplota vysokoteplotního cyklu","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x080B","key":"recirculation_mode","label":"Režim cirkulace TUV","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x080C","key":"recirculation_target","label":"Cíl cirkulace TUV","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x080D","key":"recirculation_hysteresis","label":"Hystereze cirkulace TUV","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x080E","key":"recirculation_cycle","label":"Perioda cirkulace TUV","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x080F","key":"recirculation_run","label":"Doba běhu cirkulace TUV","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0813","key":"capacity_statistics_enable","label":"Povolení statistik výkonu","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0814","key":"external_flow_config","label":"Konfigurovaný externí průtok","kind":"setting","unit":"","scale":null,"source_page":38,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x081E","key":"heating_curve_diy_enable","label":"Vlastní topná křivka HH1","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x081F","key":"diy_081f","label":"Bod topné křivky HH1 1","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0820","key":"diy_0820","label":"Bod topné křivky HH1 2","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0821","key":"diy_0821","label":"Bod topné křivky HH1 3","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0822","key":"diy_0822","label":"Bod topné křivky HH1 4","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0823","key":"diy_0823","label":"Bod topné křivky HH1 5","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0824","key":"diy_0824","label":"Bod topné křivky HH1 6","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0825","key":"diy_0825","label":"Bod topné křivky HH1 7","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0826","key":"diy_0826","label":"Bod topné křivky HH1 8","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0827","key":"diy_0827","label":"Bod topné křivky HH1 9","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"},{"address":"0x0828","key":"diy_0828","label":"Bod topné křivky HH1 10","kind":"setting","unit":"","scale":null,"source_page":39,"fault":null,"notes":"","support":"requires_device_validation","access":"read_only_in_SE01"}];
const SE01_GUIDE = [["start","Jak tento modul používat",["Tento modul je určen pro TNG generace 2, zařízení F800711-TNG-00016. Návrhová sestava obsahuje tepelné čerpadlo, topnou akumulační nádrž, bojler teplé užitkové vody a jeden radiátorový okruh. Zobrazené propojení je návrh hydrauliky, nikoli potvrzení skutečného zapojení potrubí, čerpadel a přepínacího ventilu.","Ve verzi SE01 je připravené uživatelské rozhraní a bezpečný servisní odečet. Běžný provoz tepelného čerpadla nadále zajišťuje jeho vlastní regulátor. FANDA v tomto kroku nepovoluje zápis registrů, nespouští ohřev a nezakládá automatizaci na serveru ani v prohlížeči.","Bez připojeného datového zdroje se zobrazí pomlčka nebo Čeká na data. Nejde o nulu a neznamená to, že zařízení stojí. Servisní JSON lze nahrát na kartě Schéma; takové hodnoty jsou vždy označené jako odečet, nikoli živá telemetrie. Nahrání zůstává pouze v paměti aktuálního prohlížeče a nic neukládá do cloudu."]],["schema","Schéma a hydraulika",["Vlevo je zdroj tepla. Horní větev vede do topné akumulační nádrže a z ní k radiátorům. Dolní větev vede přes výměník bojleru do přípravy teplé vody. Topná voda a užitková voda se v tomto návrhu nemíchají. Šedé siločáry označují navržené potrubní vazby.","Živý směrový tok bude svázán s potvrzeným během zařízení a s fyzicky ověřenou polohou přepínání. Pouhé zapnutí jednotky nebo zvolený režim nestačí k tvrzení, že do konkrétní nádrže proudí teplo. Při chybějících, zastaralých nebo rozporných stavech zůstává animace vypnutá.","Je-li osazené samostatné čidlo akumulační nádrže, kandidátem je registr 0x0074. Pro bojler používáme 0x0054 a jeho poruchový bit. Teplotu aku nikdy nevytváříme z výstupní teploty TČ. Teplota přívodu a zpátečky radiátorového okruhu vyžaduje ověření skutečných senzorů v této větvi."]],["master","Povolení a skutečný běh jednotky",["Povolení jednotky je požadavek na činnost regulátoru, nikoli přímý povel kompresoru. V protokolu odpovídá položce 0x0305: 0 vypnuto, 1 zapnuto. Je normální, že povolené zařízení právě neběží, pokud není potřeba teplo nebo probíhá ochranná prodleva.","Frekvence kompresoru 0x0040 a stav výstupu kompresoru poskytují jiné informace než nastavení zapnuto/vypnuto. Tyto hodnoty nezaměňujeme. Ochrany proti zamrznutí, odmrazování, přehřátí nebo nedostatku průtoku zůstávají v regulátoru výrobce; uživatelské rozhraní je neobchází ani nenabízí jejich vypnutí.","Ve verzi SE01 jsou položky v Nastavení pouze návrhové. Tlačítko Exportovat návrh stáhne JSON pro další implementaci, neodešle povel do čerpadla. Nejde o potvrzení změny skutečného nastavení."]],["mode","Režimy vytápění a TUV",["Dokumentovaný nastavovací registr 0x0304 obsahuje mimo jiné 1 = vytápění, 2 = teplá voda a 5 = teplá voda + vytápění. Pro navrženou sestavu je kandidátem kombinovaný režim 5. Před jeho použitím musí být ověřeno, že jej jednotka nabízí; dostupné režimy popisuje registr 0x00F8.","Aktuální provozní režim se čte z 0x002D. Přiložená tabulka ale u tohoto registru neuvádí převod čísel na režimy. Proto jej nezaměňujeme s nastavením 0x0304. Rovněž bit 5 registru 0x0001 znamená vytápění nebo TUV společně, nikoli jednoznačně jednu konkrétní větev.","Priorita TUV se u této jednotky vztahuje k parametru 0x0130. Hodnota 1 znamená povolené čidlo s prioritou TUV, hodnota 2 prioritu vytápění a hodnota 0 vypnutí čidla. Není to obyčejný dvoustavový přepínač; hodnotu 0 nepoužíváme jako zkratku pro vypnutí priority."]],["heating","Vytápění a ekvitermní křivka",["Pro nastavenou topnou teplotu výrobce uvádí 0x0301 a pro topnou hysterezi parametr 0x011A. Před zápisem se načtou skutečné dolní a horní limity jednotky 0x00FB a 0x00FA a potvrdí se škálování. FANDA nesmí naslepo přepsat výrobcem nastavené meze.","Ekvitermní regulace volí teplotu topné vody podle venkovní teploty. Základní návrh používá nativní křivku regulátoru 0x0314; tabulka uvádí hodnotu 0 pro vypnutí křivky a skupiny vysokoteplotních a nízkoteplotních křivek. Číslo křivky samo o sobě není sklon v °C a nesmí se tak zobrazovat.","Pro vlastní křivku HH1 dokument obsahuje body 0x081F až 0x0828 a povolení 0x081E. Jejich použití vyžaduje další ověření konkrétního firmware. Čerpadlo má regulovat svůj vlastní cíl; nevytváříme druhý nezávislý termostat v prohlížeči, který by se s nativní regulací přetahoval."]],["buffer","Akumulační nádrž a radiátorový okruh",["Akumulační nádrž odděluje výrobu a odběr tepla podle skutečného hydraulického zapojení. Její teplotu lze řídit až po ověření, kde je čidlo umístěno a zda TČ regulaci provádí podle vratné nebo výstupní vody. Parametr 0x0174 rozlišuje právě tyto dva způsoby.","Nezavádíme automaticky dříve navržený přídavek +3 °C k aku. Takový přídavek není univerzální vlastnost této jednotky ani potvrzené nastavení dokumentace. Byl by samostatnou projektovou volbou po ověření hydrauliky.","Pro čerpadlo zóny 1 je v protokolu uveden stav 0x001C bit 4. To je kandidát pro radiátorový okruh, nikoli důkaz, že na tomto výstupu je tento okruh opravdu připojen. Výstup primárního vodního čerpadla v procentech není průtokoměr."]],["dhw","Teplá voda a hystereze",["Nastavovací teplota bojleru je 0x0302, měřená teplota je 0x0054 a hystereze TUV je 0x0160. Hystereze určuje odstup pro opětovné zahájení ohřevu. Přesné chování nativního regulátoru potvrdíme srovnáním požadavku, teploty a skutečného běhu v jednom cyklu.","Příklad návrhu, nikoli uložené nastavení: cíl 50 °C, hystereze 5 °C. Očekávaný návrhový cyklus čeká po dohřátí a znovu žádá teplo při poklesu k 45 °C. Povolení systému při teplotě 48 °C nemá samo o sobě vynucovat ohřev. Po zahájení cyklu je třeba respektovat jeho paměť, ne přepínat pokaždé podle jediného okamžitého porovnání.","Při prioritě TUV zdroj vyrábí teplo pro bojler a následně se může vrátit k vytápění. Radiátorová větev může mezitím odebírat z aku, pokud tomu odpovídá skutečné zapojení a vlastní požadavek. V této instalaci nepoužíváme Zigbee relé z modelu 00012."]],["disinfection","Vysokoteplotní cyklus bojleru",["Protokol již obsahuje vlastní vysokoteplotní funkci: 0x0801 režim, 0x0802 interval ve dnech, 0x0803 čas, 0x0804 dobu v minutách a 0x0805 teplotu. Na rozdíl od modelu 00012 zde tedy nejprve prověříme funkci zabudovanou do čerpadla.","Tabulka nepopisuje význam všech hodnot režimu ani přesné kódování času 0x0803. Návrhové uživatelské pole proto tyto neověřené hodnoty neposílá. Převod týdenního dne na plán navíc nelze odvodit pouze z intervalu ve dnech. Eventuální týdenní plán musí později vykonávat trvale běžící regulace, nikoli otevřený prohlížeč.","Vysokoteplotní cyklus smí být zpřístupněn až po potvrzení teplotních možností zdroje, zapojení dohřevu a ochrany uživatelů před horkou vodou. Dosažení teploty na jednom čidle není samo o sobě potvrzením hygienické účinnosti celého rozvodu. SE01 neaktivuje nucený příkaz dezinfekce."]],["sensor","Teploty a kvalita měření",["Původní obecná věta o násobení všech teplot deseti je na straně 3 PDF přeškrtnuta. Nelze ji převzít z prostého textového exportu. U každého teplotního údaje zachováváme RAW a srovnáme jej s displejem jednotky; UI dovoluje servisně zadat potvrzený dělitel.","Pokud je RAW zásobníku 20, možné interpretace 20 °C a 2 °C odlišíme odečtením skutečného displeje. Samotná pravděpodobnost pokojové teploty nestačí jako důkaz. Nastavení měřítka v SE01 mění pouze způsob zobrazení importovaného souboru.","Poruchový bit čidla má přednost před číselnou hodnotou. Při 0x0002 bit 6 je teplota bojleru neplatná. Připojením čidla na 00016 tato chyba při testu zmizela, ale každý další odečet ji musí kontrolovat znovu. Chybějící hodnota se nikdy nenahrazuje nulou nebo teplotou jiného zařízení."]],["statistics","Teplotní statistiky",["Grafy mají časovou osu X a jednotku na ose Y. Ve verzi SE01 zobrazují pouze vzorky z nahraného servisního záznamu. Neobsahují smyšlenou historii před zahájením záznamu. Samostatná křivka může chybět, pokud senzor není dostupný nebo není potvrzeno měřítko.","Při nasazení trvalého sběru v Agentu se bude historie ukládat na serveru podle zařízení a modulu. Denní, měsíční a roční pohled musí odlišit naměřená data, mezery a rozsah dostupné historie. Data jiné instalace se nesmějí použít jako náhrada.","Rozdíl T7 − T6 ukazuje teplotní rozdíl přes čerpadlo, nikoli samostatně jeho tepelný výkon. Tepelný výkon vyžaduje mimo jiné skutečný průtok a vlastnosti média. COP nebude zobrazován jako potvrzený výsledek, dokud není ověřen jeho registr nebo celý výpočet."]],["runtime","Motohodiny a elektrická energie",["Výrobce uvádí nativní kumulovanou dobu kompresoru ve dvou registrech 0x002E a 0x002F. Složí se v pořadí horní a dolní slovo. Jednotka ale není v této tabulce uvedena, proto výsledek označujeme jako nativní čítač RAW, nikoli h.","Servisní měřenou dobu lze odvodit pouze v úsecích, kde jsou dostupné po sobě jdoucí platné odečty se známým během kompresoru. V SE01 započítáme interval jen při kladné frekvenci na obou koncích, dostatečně malém odstupu a bez neurčitého přechodu. Výsledek je odhad za zaznamenané úseky, ne celkové motohodiny stroje.","Elektrický příkon 0x005C má výslovnou škálu /100 kW. Integrací platných časových úseků získáme odhad elektřiny v kWh za tento záznam. Počítadlo 0x005D je samostatný údaj výrobce. U nového energetického bloku obsahuje tabulka u některých kumulovaných energií rozpor kW versus kWh; bez ověření jej neřešíme tichým přejmenováním."]],["faults","Poruchy a diagnostika",["Normální kód v 0x0021 je 0xFFFF. Předchozí návrh s podmínkou fault_code != 0 byl chybný a v implementaci se nepoužije. Vedle souhrnného kódu sledujeme bitové poruchové registry a obecný alarm 0x0000 bit 3.","Stav výstupního relé není poruchový bit. Digitální vstupy mají podle tabulky logiku 0 = kontakt sepnutý a 1 = rozepnutý. Ne každý rozepnutý vstup je chyba. Neznámý bit zůstane v diagnostice označen adresou a číslem bitu, dokud jeho význam není potvrzen.","Při ztrátě Modbus komunikace zůstává řízení výrobce samostatné. FANDA musí ukázat nedostupnost dat a nesmí ze starých hodnot vyrábět nové povely. SE01 při CRC chybě nebo neočekávaných rámcích ukončí sondu; nerozšiřuje scan na další adresy."]],["service","Servisní uvedení do provozu",["Potvrzený port této konkrétní jednotky je COM1, Modbus RTU, 9600 baud, 8N1, adresa 1. Používá se stabilní USB cesta FTDI BG01FGDW. COM2 a Zigbee koordinátor se tímto krokem nemění. Čtecí program vyžaduje výhradní přístup k portu a při rozpoznaném cizím provozu skončí.","Postup ověření: nejprve načíst verzi a hlavní stavy, potom čidla, meze, nativní čítače a pouze dokumentované volitelné bloky. Každý blok, na který jednotka neodpoví, zůstane nepodporovaný nebo nepotvrzený; nenahrazujeme jej nulovým výsledkem.","Než se povolí regulace z FANDY, musí projít kontrola teplotní škály, smyslu přepínání větví, nativních hysterezí, jednotky motohodin a oprávnění pro zápis. První zápis bude jediný schválený uživatelský parametr s následným přečtením zpět. Nevstupujeme do nuceného běhu kompresoru, továrního resetu, chladivových ventilů ani vypínání ochran."]],["limits","Co je dokončeno a co následuje",["SE01 dodává schéma, návrhovou kartu Nastavení, grafy a servisní statistiky z importovaného záznamu, katalog 215 dokumentovaných registrů a tento návod. Zachovává vstup přes existující modul i původní spodní menu, Systém a Uživatel.","Trvalý přenos RTU → Agent → cloud → obě uživatelské úrovně v tomto kroku ještě není zapojen. Zápisy do regulátoru jsou vypnuté. Žádné zobrazené návrhové nastavení se samo nezačne vykonávat ani po obnovení stránky.","Následuje připojení potvrzeného čtecího profilu do stávajícího jediného Agentu, serverová historie, ověření stavových vazeb LFB-01 a směrového zobrazení LDEF-01/R118. Teprve poté se uvolní vysokoúrovňové řízení přes kontrolovaný seznam parametrů."]]];
let se01Report = null;
let se01Divisor = null;
let se01Resize = null;
let se01LayoutCleanup = null;
let se01Draft = {};
let se01Message = "";

function se01Enabled() {
  return activeState?.serial_number === SE01_SERIAL &&
    activeState?.module_key === "heat_pump" && Number(activeState?.generation) === 2;
}
function se01Node(tag, cls = "", text = null) {
  const n = document.createElement(tag); if (cls) n.className = cls;
  if (text !== null) n.textContent = text; return n;
}
function se01SVG(tag, attrs = {}, text = null) {
  const n = document.createElementNS("http://www.w3.org/2000/svg", tag);
  Object.entries(attrs).forEach(([k,v]) => n.setAttribute(k,String(v)));
  if (text !== null) n.textContent = text; return n;
}
function se01EndView() { se01Resize?.disconnect(); se01Resize = null; if(se01LayoutCleanup){se01LayoutCleanup();se01LayoutCleanup=null;} }
function se01Style() {
  if (document.getElementById(SE01_STYLE)) return;
  const s=document.createElement("style"); s.id=SE01_STYLE;
  s.textContent=`
  .se01-root {box-sizing:border-box;width:100%;min-height:100%;padding:20px 22px 24px;color:#ecf8fc;font-family:inherit;font-size:14px;line-height:1.45;}
  .se01-root * {box-sizing:border-box;}
  .se01-root h1,.se01-root h2,.se01-root h3,.se01-root p {margin-top:0;}
  .se01-root .se01-head {display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin:14px 0 16px;}
  .se01-root .se01-eyebrow {font-size:10px;font-weight:850;letter-spacing:.16em;text-transform:uppercase;color:#5ad8fb;}
  .se01-root h1 {font-size:27px;line-height:1.15;margin:6px 0 7px;}
  .se01-root h2 {font-size:18px;color:#5cddff;margin:0 0 12px;}
  .se01-root h3 {font-size:15px;margin:0 0 9px;}
  .se01-root .se01-muted {color:#91b0bd;font-size:12px;}
  .se01-root .se01-note {border:1px solid #51604b;border-left:3px solid #edc56a;border-radius:9px;background:#202e2b;padding:10px 13px;color:#e4d3a7;font-size:12px;margin-bottom:14px;}
  .se01-root .se01-error {color:#ffc1b7;padding:10px;border:1px solid #9c5c58;border-radius:8px;}
  .se01-root .se01-badge {display:inline-flex;align-items:center;border:1px solid #276578;border-radius:999px;padding:6px 11px;font-size:11px;color:#a7e9f5;white-space:nowrap;}
  .se01-root .se01-kpis {display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;}
  .se01-root .se01-kpi {padding:12px 15px;background:#072935;border:1px solid #16576a;border-radius:12px;min-width:0;}
  .se01-root .se01-kpi-label {font-size:10px;color:#85a9b7;text-transform:uppercase;letter-spacing:.055em;}
  .se01-root .se01-kpi-value {font-size:24px;font-weight:900;line-height:1.2;margin:6px 0 2px;}
  .se01-root .se01-canvas-wrap {overflow:auto;border:1px solid #124457;border-radius:16px;margin:14px 0;background:linear-gradient(150deg,#062630,#001821);}
  .se01-root .se01-canvas {display:block;width:100%;min-width:870px;height:auto;}
  .se01-root svg text {font-family:inherit;}
  .se01-root .se01-bottomline {display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap;color:#7eacbd;font-size:11px;margin:8px 0 18px;}
  .se01-root details {border:1px solid #174f63;border-radius:11px;margin-top:12px;background:#04232f;padding:12px 15px;}
  .se01-root summary {font-weight:850;cursor:pointer;}
  .se01-root .se01-toolbar {display:flex;align-items:center;flex-wrap:wrap;gap:12px;margin:14px 0;}
  .se01-root button,.se01-root select,.se01-root input {font:inherit;color:#edfaff;background:#0b3242;border:1px solid #29718a;border-radius:7px;padding:9px 11px;}
  .se01-root select {min-width:145px;max-width:230px;}
  .se01-root button {cursor:pointer;font-weight:800;}
  .se01-root button:hover {background:#125168;border-color:#48d5ff;}
  .se01-root button:focus-visible,.se01-root select:focus-visible {outline:2px solid #69e4ff;outline-offset:2px;}
  .se01-root button:disabled {opacity:.5;cursor:not-allowed;}
  .se01-root .se01-columns {display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px;}
  .se01-root .se01-panel {border:1px solid #1f6980;border-radius:14px;background:#042531;overflow:hidden;}
  .se01-root .se01-panel-title {font-size:20px;font-weight:900;padding:16px 17px;border-bottom:1px solid #195166;}
  .se01-root .se01-panel-body {padding:12px;display:grid;gap:10px;}
  .se01-root .se01-setting {border:1px solid #15495c;border-radius:10px;padding:13px;background:#03212c;}
  .se01-root .se01-setting-top {display:flex;gap:10px;justify-content:space-between;align-items:center;flex-wrap:wrap;}
  .se01-root .se01-setting-label {font-weight:850;max-width:100%;}
  .se01-root .se01-setting-note {font-size:11px;color:#8fb1c0;margin-top:7px;}
  .se01-root .se01-two {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-top:15px;}
  .se01-root .se01-box {padding:17px;border:1px solid #195f74;border-radius:13px;background:#042531;min-width:0;}
  .se01-root .se01-chart {display:block;width:100%;height:auto;}
  .se01-root .se01-empty {padding:48px 20px;color:#89aebd;text-align:center;border:1px dashed #236176;border-radius:9px;}
  .se01-root table {width:100%;border-collapse:collapse;font-size:12px;margin-top:12px;}
  .se01-root td,.se01-root th {padding:9px 8px;text-align:left;border-bottom:1px solid #174351;vertical-align:top;}
  .se01-root th {color:#62dafa;position:sticky;top:0;background:#052a37;}
  .se01-root .se01-table-wrap {overflow:auto;max-height:460px;}
  .se01-root .se01-doc {display:grid;grid-template-columns:220px minmax(0,1fr);gap:25px;align-items:start;}
  .se01-root .se01-doc-nav {position:sticky;top:0;display:grid;gap:4px;padding:10px;background:#062c3a;border:1px solid #1d5a70;border-radius:11px;}
  .se01-root .se01-doc-nav button {border:0;background:transparent;text-align:left;font-size:12px;padding:8px;}
  .se01-root .se01-doc-nav button:hover {background:#124b60;}
  .se01-root .se01-doc-body {max-width:950px;padding:10px 12px 25px;font-size:15px;line-height:1.7;}
  .se01-root .se01-doc-body section {margin-bottom:32px;border-bottom:1px solid #194759;padding-bottom:23px;scroll-margin-top:20px;}
  .se01-root .se01-doc-body h2 {font-size:23px;}
  .se01-root .se01-legend {display:flex;gap:15px;flex-wrap:wrap;font-size:11px;margin-top:8px;}
  @media (max-width:1100px) {.se01-root .se01-columns {grid-template-columns:1fr;} .se01-root .se01-two {grid-template-columns:1fr;}}
  @media (max-width:700px) {.se01-root{padding:16px 10px;} .se01-root .se01-kpis{grid-template-columns:1fr 1fr;} .se01-root .se01-doc{grid-template-columns:1fr;} .se01-root .se01-doc-nav{position:static;} .se01-root .se01-head{flex-direction:column;} }
  `; document.head.appendChild(s);
}
function se01Last() { return se01Report?.samples?.at(-1) || se01Report?.initial || null; }
function se01Raw(addr, sample = null, fallback = true) {
  const key="0x"+Number(addr).toString(16).toUpperCase().padStart(4,"0");
  const r=sample || se01Last();
  if (r && Object.hasOwn(r.registers||{},key)) return r.registers[key];
  if (!sample && fallback && Object.hasOwn(se01Report?.initial?.registers||{},key)) return se01Report.initial.registers[key];
  return null;
}
function se01Entry(addr) { return SE01_CATALOG.find(x=>parseInt(x.address,16)===addr); }
function se01Fault(addr,sample=null) {
  const e=se01Entry(addr);
  if (!e?.fault) return false;
  const word=se01Raw(e.fault[0],sample);
  return word===null?null:!!(word & (1<<e.fault[1]));
}
function se01Temperature(addr,sample=null) {
  const raw=se01Raw(addr,sample); if(raw===null || se01Divisor===null || se01Fault(addr,sample)===true) return null;
  if (addr===0x54 && se01Raw(0x130)===0) return null;
  return (raw&0x8000 ? raw-65536 : raw)/se01Divisor;
}
function se01Number(n,d=1) {return n===null || !Number.isFinite(n)?"—":n.toLocaleString("cs-CZ",{maximumFractionDigits:d,minimumFractionDigits:d});}
function se01Value(addr) {
  const e=se01Entry(addr),raw=se01Raw(addr); if(raw===null)return "—";
  if(se01Fault(addr)===true)return "Chyba čidla";
  if(addr===0x54 && se01Raw(0x130)===0)return "Čidlo vypnuto";
  if(e?.kind==="temperature")return se01Divisor===null?`RAW ${raw}`:`${se01Number(se01Temperature(addr))} °C`;
  if(e?.kind==="fault") return raw===65535?"Bez chyby":`Kód 0x${raw.toString(16).toUpperCase().padStart(4,"0")}`;
  if(e?.scale!==null && e?.scale!==undefined)return `${se01Number(raw*e.scale,e.unit==="kW"?2:e.scale<1?2:0)} ${e.unit}`.trim();
  return String(raw);
}
function se01Time(s) {return s && Number.isFinite(Date.parse(s))?new Date(s).toLocaleString("cs-CZ"):"nenačteno";}
function se01Kpi(label,value,note) {
  const n=se01Node("div","se01-kpi"); n.append(se01Node("div","se01-kpi-label",label),se01Node("div","se01-kpi-value",value),se01Node("div","se01-muted",note));return n;
}
function se01Head(root,title,subtitle) {
  const h=se01Node("header","se01-head"),left=se01Node("div");
  left.append(se01Node("div","se01-eyebrow","SOLAREAST / TNG GENERACE 2 · 00016 · SE01"),se01Node("h1","",title),se01Node("div","se01-muted",subtitle));
  h.append(left,se01Node("span","se01-badge",se01Report?"Servisní záznam • není živý":"Připraveno • čeká na datový zdroj"));root.append(h);
  root.append(se01Node("div","se01-note","Regulaci zajišťuje jednotka výrobce. SE01 nepíše do Modbusu. Návrhy v Nastavení nejsou provozní povely; trvalý sběr Agent → cloud zatím není zapojen."));
}
function se01DrawSchema(root) {
  const k=se01Node("div","se01-kpis");k.append(
    se01Kpi("Venkovní teplota T1",se01Value(0x4a),"Snímač TČ • nikoli předpověď"),
    se01Kpi("Elektrický příkon",se01Value(0x5c),"Registr 0x005C • /100 kW"),
    se01Kpi("Frekvence kompresoru",se01Value(0x40),"Běh není totéž co povolení"),
    se01Kpi("Kód regulátoru",se01Value(0x21),"0xFFFF = normální stav") );root.append(k);
  const wrap=se01Node("div","se01-canvas-wrap"),svg=se01SVG("svg",{viewBox:"0 0 1440 635",class:"se01-canvas",role:"img","aria-label":"Návrh schématu: tepelné čerpadlo, akumulační nádrž, bojler a radiátorový okruh"});
  const txt=(x,y,t,size=14,fill="#a0c1cc",weight=500)=>svg.appendChild(se01SVG("text",{x,y,fill,"font-size":size,"font-weight":weight},t));
  const rect=(x,y,w,h,rx=15,fill="#062e3c",stroke="#249dc0")=>svg.appendChild(se01SVG("rect",{x,y,width:w,height:h,rx,fill,stroke,"stroke-width":1.5}));
  const line=(d,stroke="#456773",width=6,dash="")=>svg.appendChild(se01SVG("path",{d,fill:"none",stroke,"stroke-width":width,"stroke-linejoin":"round","stroke-linecap":"round",...(dash?{"stroke-dasharray":dash}:{})}));
  line("M385 230 H552 V162 H687");line("M552 230 V410 H687");
  line("M881 162 H1087");line("M1087 340 H935 V300 H881","#315567",4);
  line("M687 298 H610 V550 H414 V382 H385","#315567",4);
  line("M687 533 H630 V550","#315567",4);
  rect(30,132,355,350);txt(54,168,"TEPELNÉ ČERPADLO",22,"#56dbff",900);
  txt(54,193,"Solareast · TNG generace 2",13);
  rect(55,212,110,93,7,"#073948");
  svg.appendChild(se01SVG("circle",{cx:110,cy:258,r:32,fill:"none",stroke:"#42ccef","stroke-width":2}));
  [0,120,240].forEach(a=>svg.appendChild(se01SVG("path",{d:"M110 258 C70 226 96 217 111 229 C126 241 117 254 110 258",fill:"#45d5f5",transform:`rotate(${a} 110 258)`})));
  txt(184,236,"VÝSTUP T7",11);txt(184,265,se01Value(0x50),25,"#effbff",850);
  txt(184,290,"VRATNÁ T6",11);txt(184,317,se01Value(0x4f),23,"#effbff",850);
  txt(55,351,`Napětí / proud: ${se01Value(0x5a)} · ${se01Value(0x5b)}`,14);
  txt(55,380,`Výstup čerpadla: ${se01Value(0x2b)}`,14);
  const a=se01Temperature(0x50),b=se01Temperature(0x4f);
  txt(55,409,`Rozdíl T7 − T6: ${a!==null&&b!==null?se01Number(a-b)+" K":"—"}`,14);
  txt(55,448,"COM1 • RS485 • 9600 / 8N1 • ID 1",12,"#6ba7bc",800);
  svg.appendChild(se01SVG("circle",{cx:552,cy:230,r:18,fill:"#083544",stroke:"#54808e","stroke-width":2}));
  txt(448,89,"PŘEPÍNÁNÍ TUV / VYTÁPĚNÍ",11,"#9bc0cb",850);
  txt(444,110,"Fyzická vazba ventilu čeká na ověření",11,"#dfc785");
  rect(687,58,194,251,30);txt(708,93,"AKUMULAČNÍ",17,"#58d9ff",900);txt(708,116,"NÁDRŽ",17,"#58d9ff",900);
  line("M711 139 H856","#1a5365",1);
  txt(711,173,"TEPLOTA NÁDRŽE",11);txt(711,209,se01Value(0x74),27,"#fff",900);
  txt(711,244,"0x0074 · osazení ověřit",11);txt(711,282,"Topná voda",12);
  rect(687,373,194,223,30);txt(711,410,"BOJLER TUV",20,"#58d9ff",900);
  txt(711,446,"TEPLOTA VODY",11);txt(711,481,se01Value(0x54),27,"#fff",900);
  line("M714 512 C739 492 758 530 782 512 C806 494 825 530 852 512","#3398b7",3);
  txt(711,552,`Cíl: ${se01Value(0x302)}`,13);txt(711,575,`Hystereze RAW: ${se01Value(0x160)}`,11);
  rect(1087,109,322,275);txt(1110,145,"RADIÁTOROVÝ OKRUH",20,"#58d9ff",900);
  for(let i=0;i<7;i++)rect(1120+i*33,172,21,62,5,"#0a3e4f","#409eb7");
  txt(1110,267,`Zóna 1: ${se01Value(0x7c)}`,17,"#ecf9ff",800);
  txt(1110,291,"Čidlo přívodu / zpátečky: ověřit",12);
  const rel=se01Raw(0x1c);txt(1110,320,`Výstup čerpadla zóny 1: ${rel===null?"—":rel&(1<<4)?"zapnuto":"vypnuto"}`,13);
  txt(1110,350,"0x001C bit 4 • zatím bez vazby na potrubí",10);
  txt(960,463,"LEGENDA",12,"#64dafa",900);
  line("M960 488 H1005","#456773",5);txt(1017,493,"Návrhová hydraulická vazba",12);
  txt(960,521,"Bez ověřené živé entity není animovaný tok.",11);
  txt(960,542,"LFB-01 → stav / LDEF-01 R118 → směr toku",11);
  txt(33,581,"PRIMÁRNÍ A SEKUNDÁRNÍ ČERPADLO NEJSOU ZAMĚNITELNÉ",11,"#7bb5c5",850);
  txt(33,605,"Schéma je návrh sestavy. Neověřené čidlo, provozní režim ani průtok se nedopočítávají z jiné veličiny.",11);
  wrap.append(svg);root.append(wrap);
  const foot=se01Node("div","se01-bottomline");foot.append(se01Node("span","",`Čas záznamu: ${se01Time(se01Last()?.captured_at)}`),se01Node("span","",`Teploty: ${se01Divisor===null?"škála nepotvrzena – RAW":`dělitel ${se01Divisor}, zadáno obsluhou`}`));root.append(foot);
  se01ImportPanel(root);se01Diagnostics(root);
}
function se01ValidateReport(r) {
  if(!r || r.schema!=="iqf.solareast.commissioning.v1" || r.serial_number!==SE01_SERIAL)throw Error("Soubor není servisní záznam Solareast 00016.");
  if(r.transport?.function!==3 || r.transport?.slave_id!==1)throw Error("Nesouhlasí kontrakt read-only / slave 1.");
  if(!Array.isArray(r.samples)||r.samples.length>1000)throw Error("Neplatný nebo příliš dlouhý seznam vzorků.");
  let last=-Infinity;
  for(const sample of [r.initial,...r.samples]) {
    if(!sample || !sample.registers || typeof sample.registers!=="object")throw Error("Chybí raw registry.");
    for(const [k,v] of Object.entries(sample.registers))if(!/^0x[0-9A-F]{4}$/.test(k)||!Number.isInteger(v)||v<0||v>65535)throw Error("Neplatná adresa nebo 16bit hodnota.");
  }
  for(const sample of r.samples) {
    const t=Date.parse(sample.captured_at); if(!Number.isFinite(t)||t<=last)throw Error("Časové značky vzorků nejsou platné a vzestupné.");last=t;
  }
  const id=r.initial.registers;
  if([id['0x0360'],id['0x0361'],id['0x0362'],id['0x0363']].join(',')!=="446,0,1,143")throw Error("Nesouhlasí dříve ověřený podpis řídicí jednotky. Nutná kontrola servisem.");
  return r;
}
function se01ImportPanel(root) {
  const d=se01Node("details");d.append(se01Node("summary","","Servisní odečet a ověření teplotní škály"));
  d.append(se01Node("p","se01-muted","Import nemění cloud ani zařízení. Záznam se zobrazí pouze v této relaci prohlížeče; nejde o živá data. Označení 00016 v souboru je doplněno obsluhou, místní výrobní identita není sondou nezávisle ověřena."));
  const bar=se01Node("div","se01-toolbar"),input=se01Node("input");input.type="file";input.accept=".json,application/json";input.setAttribute('aria-label','Nahrát servisní JSON');
  const scale=se01Node("select");scale.setAttribute('aria-label','Potvrzená škála teplot');
  [["","Škála nepotvrzena"],["1","RAW = °C (ověřeno obsluhou)"],["10","RAW / 10 = °C (ověřeno obsluhou)"]].forEach(([v,t])=>{const o=se01Node('option','',t);o.value=v;scale.append(o);});scale.value=se01Divisor===null?"":String(se01Divisor);
  scale.addEventListener('change',()=>{se01Divisor=scale.value?Number(scale.value):null;se01Render(document.getElementById(ROOT_ID),currentTab);});
  input.addEventListener('change',async()=>{
    const file=input.files?.[0]; if(!file)return;
    try {if(file.size>5*1024*1024)throw Error("Maximální velikost je 5 MB.");const r=se01ValidateReport(JSON.parse(await file.text()));if(!se01Enabled())return;se01Report=r;se01Message="Servisní záznam načten. Čas a zdroj jsou uvedeny výše; data nejsou živá.";}
    catch(e){se01Message="Import odmítnut: "+String(e.message||e);}
    if(se01Enabled())se01Render(document.getElementById(ROOT_ID),currentTab);
  });
  bar.append(input,scale);d.append(bar);if(se01Message)d.append(se01Node('p',se01Message.startsWith('Import odmítnut')?'se01-error':'se01-muted',se01Message));root.append(d);
}
function se01Diagnostics(root) {
  const d=se01Node('details');d.append(se01Node('summary','',`Katalog a servisní registry (${SE01_CATALOG.length} položek)`));
  d.append(se01Node('p','se01-muted','Jde o dokumentované kandidáty. Odpověď registru sama nepotvrzuje osazení čidla ani podporu konkrétní funkce. Neověřené jednotky zůstávají RAW.'));
  const w=se01Node('div','se01-table-wrap'),table=se01Node('table'),head=se01Node('thead'),tr=se01Node('tr');
  ['Adresa','Veličina','RAW','Zobrazení','Zdroj a omezení'].forEach(x=>tr.append(se01Node('th','',x)));head.append(tr);table.append(head);const body=se01Node('tbody');
  for(const e of SE01_CATALOG){const a=parseInt(e.address,16),row=se01Node('tr');[e.address,e.label,se01Raw(a)===null?'—':String(se01Raw(a)),se01Value(a),`PDF str. ${e.source_page}. ${e.notes||'Podporu ověřit na zařízení.'}`].forEach(x=>row.append(se01Node('td','',x)));body.append(row);}
  table.append(body);w.append(table);d.append(w);root.append(d);
}
function se01SelectSetting(body,label,key,options,addr,description) {
  const row=se01Node('div','se01-setting'),top=se01Node('div','se01-setting-top'),select=se01Node('select');select.setAttribute('aria-label',label);
  [['','Beze změny'],...options].forEach(([v,t])=>{const o=se01Node('option','',t);o.value=String(v);select.append(o);});select.value=se01Draft[key]??'';
  select.addEventListener('change',()=>{if(select.value==='')delete se01Draft[key];else se01Draft[key]=select.value;});
  top.append(se01Node('span','se01-setting-label',label),select);row.append(top,se01Node('div','se01-setting-note',`Odečet: ${addr===null?'není přímé mapování':se01Value(addr)}. ${description}`));body.append(row);
}
function se01Range(a,b,suffix) {return Array.from({length:b-a+1},(_,i)=>[a+i,`${a+i} ${suffix}`]);}
function se01Settings(root) {
  root.append(se01Node('div','se01-note','NÁVRH KONFIGURACE. Pole níže lze připravit a exportovat, ale neukládají provozní hodnoty. Po obnovení stránky se návrh ztratí. Žádný ovladač zde fyzicky nespíná jednotku.'));
  const cols=se01Node('div','se01-columns');
  const panel=t=>{const p=se01Node('section','se01-panel'),b=se01Node('div','se01-panel-body');p.append(se01Node('div','se01-panel-title',t),b);cols.append(p);return b;};
  const base=panel('Základní nastavení'),heat=panel('Nastavení vytápění'),dhw=panel('Nastavení bojleru');
  se01SelectSetting(base,'Povolení jednotky','controller_enabled',[[0,'Vypnuto'],[1,'Zapnuto']],0x305,'Povolení regulátoru, ne nucený start kompresoru.');
  se01SelectSetting(base,'Provozní režim','requested_mode',[[1,'Jen vytápění'],[2,'Jen teplá voda'],[5,'Vytápění + TUV']],0x304,'Dostupnost musí potvrdit registr 0x00F8.');
  se01SelectSetting(base,'Výkonový režim','performance_mode',[[0,'Standardní'],[1,'Silný'],[2,'Tichý']],0x307,'Nativní režim regulátoru.');
  const protect=se01Node('div','se01-setting');protect.append(se01Node('strong','','Ochrany výrobce zůstávají aktivní'),se01Node('div','se01-setting-note','Žádné vypínání průtoku, tlakových ochran, odmrazování nebo ochrany proti zamrznutí.'));base.append(protect);
  se01SelectSetting(heat,'Teplota topné vody','heating_target_c',se01Range(20,60,'°C'),0x301,'Při implementaci omezit na skutečné 0x00FB…0x00FA.');
  se01SelectSetting(heat,'Hystereze vytápění','heating_hysteresis_k',se01Range(0,10,'K'),0x11a,'Ověřit význam v konkrétním režimu a měřítko.');
  se01SelectSetting(heat,'Nativní topná křivka','heating_curve',[[0,'Vypnutá / pevná teplota'],...se01Range(1,8,'– vysokoteplotní'),...se01Range(11,18,'– nízkoteplotní')],0x314,'Číslo křivky není číselný sklon.');
  const sensor=se01Node('div','se01-setting');sensor.append(se01Node('strong','','Vazby nádrže a radiátorového okruhu'),se01Node('div','se01-setting-note','Aku: 0x0074; přívod zóny 1: 0x007C; čerpadlo: 0x001C bit 4. Osazení a smysl vazby zatím nejsou potvrzené.'));heat.append(sensor);
  se01SelectSetting(dhw,'Teplota TUV','dhw_target_c',se01Range(20,75,'°C'),0x302,'Při implementaci omezit na skutečné 0x00FD…0x00FC.');
  se01SelectSetting(dhw,'Hystereze TUV','dhw_hysteresis_k',se01Range(0,10,'K'),0x160,'Nativní regulace, ne paralelní termostat v prohlížeči.');
  se01SelectSetting(dhw,'Priorita s povoleným čidlem','dhw_priority',[[1,'Priorita TUV'],[2,'Priorita vytápění']],0x130,'Hodnota 0 vypíná čidlo; není nabízena jako vypnutí priority.');
  const high=se01Node('div','se01-setting');high.append(se01Node('strong','','Vysokoteplotní cyklus – zatím jen čtení'),se01Node('div','se01-setting-note',`Teplota RAW: ${se01Value(0x805)} · doba: ${se01Value(0x804)} · interval: ${se01Value(0x802)}. Režim a kódování času vyžadují ověření, cyklus se nespouští.`));dhw.append(high);
  root.append(cols);const bar=se01Node('div','se01-toolbar'),exportBtn=se01Node('button','','Exportovat návrh (neodeslat do TČ)');
  exportBtn.onclick=()=>{const obj={schema:'iqf.solareast.proposal.v1',serial_number:SE01_SERIAL,module_key:'heat_pump',proposal_only:true,apply:false,created_at:new Date().toISOString(),parameters:{...se01Draft},temperature_divisor:se01Divisor,write_gate:'not_commissioned'};const url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}));const a=se01Node('a');a.href=url;a.download='Solareast_00016_navarh_nastaveni.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);};
  bar.append(exportBtn,se01Node('span','se01-muted','Export nemění aktuální nastavení.'));root.append(bar);
}
function se01Chart(parent,title,series,yLabel) {
  const box=se01Node('section','se01-box');box.append(se01Node('h2','',title));const all=series.flatMap(s=>s.points.filter(p=>p.v!==null&&Number.isFinite(p.v)));
  if(!all.length){box.append(se01Node('div','se01-empty','Čeká na časovou řadu z odečtu. Žádná historie se negeneruje.'));parent.append(box);return;}
  const svg=se01SVG('svg',{viewBox:'0 0 620 260',class:'se01-chart',role:'img','aria-label':title});
  const minT=Math.min(...all.map(p=>p.t)),maxT=Math.max(...all.map(p=>p.t));let lo=Math.min(...all.map(p=>p.v)),hi=Math.max(...all.map(p=>p.v));const pad=(hi-lo||2)*.13;lo-=pad;hi+=pad;
  const x=t=>60+(t-minT)/(maxT-minT||1)*536, y=v=>216-(v-lo)/(hi-lo)*176;
  for(let i=0;i<5;i++){const v=lo+(hi-lo)*i/4,Y=y(v);svg.append(se01SVG('line',{x1:60,x2:598,y1:Y,y2:Y,stroke:'#224a5b'}),se01SVG('text',{x:52,y:Y+4,'text-anchor':'end',fill:'#8fb1c0','font-size':11},se01Number(v,1)));}
  svg.append(se01SVG('text',{x:60,y:18,fill:'#a6d4e4','font-size':11},yLabel));
  for(let i=0;i<4;i++){const t=minT+(maxT-minT)*i/3;svg.append(se01SVG('text',{x:x(t),y:242,'text-anchor':i===0?'start':i===3?'end':'middle',fill:'#90afbd','font-size':10},new Date(t).toLocaleTimeString('cs-CZ',{hour:'2-digit',minute:'2-digit',second:'2-digit'})));}
  for(const s of series){let d='',prev=null;for(const p of s.points){if(p.v===null||!Number.isFinite(p.v)){prev=null;continue;}const gap=prev===null||p.t-prev>15000;d+=`${gap?'M':'L'}${x(p.t).toFixed(2)} ${y(p.v).toFixed(2)} `;prev=p.t;}svg.append(se01SVG('path',{d,fill:'none',stroke:s.color,'stroke-width':2.5}));s.points.filter(p=>p.v!==null).forEach(p=>svg.append(se01SVG('circle',{cx:x(p.t),cy:y(p.v),r:2,fill:s.color})));}
  box.append(svg);const legend=se01Node('div','se01-legend');series.forEach(s=>{const item=se01Node('span','',s.label);item.style.color=s.color;legend.append(item);});box.append(legend);parent.append(box);
}
function se01Statistics(root) {
  const samples=se01Report?.samples||[];let runtime=0,coverage=0,energy=0,starts=0,unknown=0;
  for(let i=1;i<samples.length;i++){const a=samples[i-1],b=samples[i],dt=(Date.parse(b.captured_at)-Date.parse(a.captured_at))/1000;const fa=se01Raw(0x40,a),fb=se01Raw(0x40,b),pa=se01Raw(0x5c,a),pb=se01Raw(0x5c,b);
    if(dt<=0||dt>15){unknown+=Math.max(0,dt);continue;}
    if(pa!==null&&pb!==null){energy+=(pa+pb)/2/100*dt/3600;coverage+=dt;}
    if(fa!==null&&fb!==null){if(fa>0&&fb>0)runtime+=dt;else if(fa===0&&fb>0)starts++;}
  }
  const hi=se01Raw(0x2e),lo=se01Raw(0x2f),counter=hi===null||lo===null?null:hi*65536+lo;
  const k=se01Node('div','se01-kpis');k.append(se01Kpi('Nativní čítač kompresoru',counter===null?'—':counter.toLocaleString('cs-CZ'),'RAW • jednotka ještě není ověřena'),se01Kpi('Zaznamenaný běh',samples.length?se01Number(runtime/3600,3)+' h':'—','Odhad jen mezi dvěma platnými ON vzorky'),se01Kpi('Elektrická energie záznamu',coverage?se01Number(energy,4)+' kWh':'—','Integrace příkonu • není celková spotřeba'),se01Kpi('Zachycené starty',samples.length?String(starts):'—','Pouze pozorované přechody 0 → běh'));root.append(k);
  root.append(se01Node('p','se01-muted',`Vzorků: ${samples.length}. Pokrytí integrace: ${Math.round(coverage)} s. Vynechané dlouhé mezery: ${Math.round(unknown)} s. Celkové, měsíční a roční statistiky vyžadují trvalý sběr; tento krok je nenahrazuje.`));
  const graphs=se01Node('div','se01-two');
  const tempSeries=(addr,label,color)=>({label,color,points:samples.map(s=>({t:Date.parse(s.captured_at),v:se01Temperature(addr,s)}))});
  se01Chart(graphs,'Teploty – topná voda',[tempSeries(0x50,'Výstup T7','#4bdafa'),tempSeries(0x4f,'Vratná T6','#95aafa'),tempSeries(0x4a,'Venkovní T1','#f4cd78')],'°C · měřítko potvrzené obsluhou');
  se01Chart(graphs,'Teplota bojleru',[tempSeries(0x54,'TUV','#57e0bc')],'°C');
  se01Chart(graphs,'Elektrický příkon',[{label:'Příkon',color:'#4bdafa',points:samples.map(s=>({t:Date.parse(s.captured_at),v:se01Raw(0x5c,s)===null?null:se01Raw(0x5c,s)/100}))}],'kW');
  se01Chart(graphs,'Frekvence kompresoru',[{label:'Kompresor',color:'#beacfb',points:samples.map(s=>({t:Date.parse(s.captured_at),v:se01Raw(0x40,s)}))}],'Hz');root.append(graphs);
  root.append(se01Node('div','se01-note','Rozdělení motohodin na vytápění a TUV se zatím neprovádí: společný provozní bit nerozlišuje obě větve. COP ani topný výkon nejsou odhadovány bez ověřeného průtoku / nativního měřítka.'));
}
function se01Guide(root) {
  const layout=se01Node('div','se01-doc'),nav=se01Node('nav','se01-doc-nav'),body=se01Node('article','se01-doc-body');nav.setAttribute('aria-label','Obsah návodu');
  for(const [id,title,paras] of SE01_GUIDE){const b=se01Node('button','',title),section=se01Node('section');section.id='se01-guide-'+id;section.append(se01Node('h2','',title));paras.forEach(p=>section.append(se01Node('p','',p)));b.onclick=()=>section.scrollIntoView({behavior:'smooth',block:'start'});nav.append(b);body.append(section);}
  body.append(se01Node('p','se01-muted','Zdroj: přiložený Solareast Communication Protocol of Master Controller and Wire Controller, tabulky str. 6–15, 20–26, 32–40 a 45–46. Obecné X10 na str. 3 je přeškrtnuté. Referenční postupy projektu: WIM-01, EUG-01; živé toky po ověření AFI-01 / LFB-01 / LDEF-01 R118.'));
  layout.append(nav,body);root.append(layout);
}
function se01Render(root,tab) {
  if(!root||!se01Enabled()||!['schema','settings','statistics','guide'].includes(tab))return false;
  se01EndView();se01Style();const stage=root.querySelector('.iqf-hp-stage-inner');if(!stage)return false;
  const priorStageStyle=stage.getAttribute('style');const pane0=stage.parentElement;const priorPaneStyle=pane0.getAttribute('style');
  se01LayoutCleanup=()=>{if(priorStageStyle===null)stage.removeAttribute('style');else stage.setAttribute('style',priorStageStyle);if(priorPaneStyle===null)pane0.removeAttribute('style');else pane0.setAttribute('style',priorPaneStyle);};
  stage.replaceChildren();stage.dataset.blank='false';stage.style.padding='8px 0 0';
  const content=se01Node('div','se01-root');content.dataset.serial=SE01_SERIAL;content.dataset.phase='SE01';stage.append(content);
  const title={schema:'Tepelné čerpadlo · akumulace · teplá voda',settings:'Nastavení regulace',statistics:'Statistiky odečtu',guide:'Návod k obsluze tepelného čerpadla'}[tab];
  se01Head(content,title,'Existující modul Tepelné čerpadlo • žádné nové založení modulu');
  ({schema:se01DrawSchema,settings:se01Settings,statistics:se01Statistics,guide:se01Guide}[tab])(content);
  // Keep all new content above the existing footer without changing its layout.
  const pane=stage.parentElement,footer=root.querySelector('.iqf-hp-bottom-shell');
  const fit=()=>{if(!pane.isConnected||!footer?.isConnected)return;const h=footer.getBoundingClientRect().top-pane.getBoundingClientRect().top-4;if(h>100){pane.style.maxHeight=h+'px';pane.style.overflowY='auto';const canvas=content.querySelector('.se01-canvas');if(canvas){const available=footer.getBoundingClientRect().top-canvas.parentElement.getBoundingClientRect().top-30;canvas.style.height=Math.max(300,Math.min(580,available))+'px';}}};
  fit();if(typeof ResizeObserver!=='undefined'){se01Resize=new ResizeObserver(fit);if(footer)se01Resize.observe(footer);se01Resize.observe(root);}
  return true;
}


/* G101 START — model 00016 / generation 1 / Schema only. WIM-01. */
const G101_ID = "iqf-g101-schema";
const G101_STYLE = "iqf-g101-schema-style";
let g101Cleanup = null;

function g101EndView() {
  if (g101Cleanup) { const cleanup = g101Cleanup; g101Cleanup = null; cleanup(); }
}
function g101Eligible(tab) {
  return tab === "schema" && activeState?.serial_number === "F800711-TNG-00016" &&
    activeState?.module_key === "heat_pump" && Number(activeState?.generation) === 1;
}
function g101SVG(tag, attributes = {}, text = null) {
  const node = document.createElementNS("http://www.w3.org/2000/svg", tag);
  Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, String(value)));
  if (text !== null) node.textContent = text;
  return node;
}
function g101Style() {
  if (document.getElementById(G101_STYLE)) return;
  const style = document.createElement("style"); style.id = G101_STYLE;
  style.textContent = `
    #${G101_ID} {position:relative;display:block;width:100%;height:100%;min-width:0;min-height:0;
      overflow:auto;background:#03171f;color:#eaf9ff;box-sizing:border-box;font-family:inherit;}
    #${G101_ID} * {box-sizing:border-box;}
    #${G101_ID} .g101-svg {display:block;width:100%;height:100%;min-width:1040px;min-height:455px;}
    #${G101_ID} svg text {font-family:Arial,Helvetica,sans-serif;}
    #${G101_ID} .g101-heading {fill:#47d8fc;font-size:25px;font-weight:900;letter-spacing:.25px;}
    #${G101_ID} .g101-subtitle {fill:#95bdcb;font-size:11px;font-weight:800;letter-spacing:1.1px;}
    #${G101_ID} .g101-label {fill:#48d4f8;font-size:11px;font-weight:800;letter-spacing:.35px;}
    #${G101_ID} .g101-value {fill:#e9f8fd;font-size:15px;font-weight:800;}
    #${G101_ID} .g101-muted {fill:#8eb1bf;font-size:12px;}
    #${G101_ID} .g101-device {cursor:pointer;outline:none;}
    #${G101_ID} .g101-device:focus-visible > .g101-panel {stroke:#b7f3ff;stroke-width:3;}
    #${G101_ID} .g101-device:hover > .g101-panel {stroke:#85e9ff;}
    #${G101_ID} .g101-connection {fill:none;stroke:#87979b;stroke-width:4;stroke-linejoin:round;stroke-linecap:round;}
    #${G101_ID} .g101-connection-return {stroke:#546b77;stroke-width:3;}
    #${G101_ID} .g101-detail {position:absolute;inset:0;z-index:3;display:flex;align-items:center;justify-content:center;
      background:rgba(0,10,17,.8);padding:24px;}
    #${G101_ID} .g101-detail[hidden] {display:none;}
    #${G101_ID} .g101-dialog {width:min(570px,100%);max-height:100%;overflow:auto;background:#082631;border:1px solid #267b94;
      border-radius:16px;padding:24px;box-shadow:0 18px 55px #0006;}
    #${G101_ID} .g101-dialog h2 {font-size:23px;color:#4ddcff;margin:0 0 12px;}
    #${G101_ID} .g101-dialog p {font-size:14px;line-height:1.55;color:#b4d1dc;margin:12px 0;}
    #${G101_ID} .g101-dialog dl {margin:16px 0;}
    #${G101_ID} .g101-dialog dl > div {display:grid;grid-template-columns:1fr auto;gap:18px;padding:9px 0;border-bottom:1px solid #184455;}
    #${G101_ID} .g101-dialog dt {font-size:13px;color:#9ac0cf;}
    #${G101_ID} .g101-dialog dd {font-size:13px;color:#e8faff;margin:0;}
    #${G101_ID} .g101-close {display:block;margin:18px 0 0 auto;background:#123e4f;border:1px solid #3886a0;border-radius:9px;
      padding:10px 18px;color:#effbff;font:inherit;font-weight:800;cursor:pointer;}
    #${G101_ID} .g101-close:focus-visible {outline:2px solid #8decff;outline-offset:3px;}
  `;
  document.head.append(style);
}
function g101Render(root, tab) {
  if (!root || !g101Eligible(tab)) return false;
  const stage = root.querySelector(".iqf-hp-stage-inner");
  const pane = stage?.parentElement;
  const footer = root.querySelector(".iqf-hp-bottom-shell");
  if (!stage || !pane || !footer) return false;
  g101EndView(); g101Style();
  // The original application controls identity, authorization, tabs and menu.
  // Only this tab's content area and its temporary dimensions are changed.
  const saved = [stage, pane].map(node => [node, node.getAttribute("style")]);
  const previousBlank = stage.getAttribute("data-blank");
  stage.replaceChildren(); stage.dataset.blank = "false";
  const content = document.createElement("div"); content.id = G101_ID;
  content.dataset.serial = activeState.serial_number;
  content.dataset.generation = "1"; content.dataset.moduleKey = "heat_pump";
  content.dataset.dataMode = "unbound";
  stage.append(content);
  const set = (node, key, value) => {
    if (node.style.getPropertyValue(key) !== value) node.style.setProperty(key, value, "important");
  };
  const fixedStyles = {position:"absolute",left:"0px",right:"0px",top:"32px",width:"100%","max-width":"none",margin:"0px",padding:"0px","min-height":"0px",overflow:"hidden"};
  Object.entries(fixedStyles).forEach(([key, value]) => set(pane,key,value));
  Object.entries({width:"100%",height:"100%","min-height":"0px","max-width":"none",margin:"0px",padding:"0px",overflow:"hidden"}).forEach(([key,value])=>set(stage,key,value));
  const fit = () => {
    if (!root.isConnected || !content.isConnected || !footer.isConnected) return;
    const available = Math.floor(footer.getBoundingClientRect().top - root.getBoundingClientRect().top - 38);
    if (available > 70) { set(pane,"height",available+"px"); set(pane,"max-height",available+"px"); }
  };
  fit();
  let resize = null;
  if (typeof ResizeObserver !== "undefined") { resize = new ResizeObserver(fit); resize.observe(root); resize.observe(footer); }
  window.addEventListener("resize",fit);

  const svg = g101SVG("svg", {class:"g101-svg",viewBox:"0 0 1600 700",preserveAspectRatio:"xMidYMid meet",role:"img","aria-labelledby":"g101-title g101-desc"});
  svg.append(g101SVG("title",{id:"g101-title"},"Schéma: jedno tepelné čerpadlo, bojler, akumulační nádrž, jeden radiátorový okruh a krb"));
  svg.append(g101SVG("desc",{id:"g101-desc"},"Pracovní vizualizace pro 00016, generace 1. Tepelné čerpadlo má samostatnou větev do bojleru a do akumulace. Radiátorový okruh je přímo z akumulační nádrže, bez rozdělovače. Krb je v návrhu připojen k akumulaci. Provozní entity zatím nejsou přiřazené."));
  content.append(svg);
  const defs=g101SVG("defs");
  const gradient=(id,stops,attrs={})=>{const g=g101SVG("linearGradient",{id,...attrs});stops.forEach(([offset,color])=>g.append(g101SVG("stop",{offset,"stop-color":color})));defs.append(g);};
  gradient("g101-bg",[["0%","#08232e"],["100%","#02121a"]],{x1:"0",y1:"0",x2:"1",y2:"1"});
  gradient("g101-card",[["0%","#052834"],["100%","#021923"]],{x1:"0",y1:"0",x2:"0",y2:"1"});
  gradient("g101-tank",[["0%","#05232e"],["48%","#124a5c"],["100%","#05212c"]]);
  const glow=g101SVG("filter",{id:"g101-glow",x:"-30%",y:"-30%",width:"160%",height:"160%"});
  glow.append(g101SVG("feGaussianBlur",{stdDeviation:"4",result:"blur"}));
  const merge=g101SVG("feMerge");merge.append(g101SVG("feMergeNode",{in:"blur"}),g101SVG("feMergeNode",{in:"SourceGraphic"}));glow.append(merge);defs.append(glow);
  svg.append(defs);
  svg.append(g101SVG("rect",{x:6,y:5,width:1588,height:683,rx:18,fill:"url(#g101-bg)",stroke:"#153d4a","stroke-width":1}));
  const text=(parent,x,y,value,cls="g101-value",extra={})=>{const t=g101SVG("text",{x,y,class:cls,...extra},value);parent.append(t);return t;};
  const value=(parent,x,y,slot,unit="",extra={})=>{
    const v=text(parent,x,y,"—"+(unit?" "+unit:""),"g101-value",{"data-g101-slot":slot,"data-quality":"unbound",...extra});
    v.append(g101SVG("title",{},"Hodnota není přiřazená. Pomlčka neznamená nulu ani vypnuto."));return v;
  };
  const row=(parent,x,y,w,label,slot,unit="")=>{
    parent.append(g101SVG("rect",{x,y,width:w,height:30,rx:8,fill:"#011c26",stroke:"#1d5366"}));
    text(parent,x+10,y+19,label,"g101-label");value(parent,x+w-10,y+20,slot,unit,{"text-anchor":"end"});
  };
  const wire=(id,d,from,to,isReturn=false)=>{
    svg.append(g101SVG("path",{id,d,class:"g101-connection"+(isReturn?" g101-connection-return":""),"data-source":from,"data-target":to,"data-flow-state":"unbound"}));
  };
  // Logical energy links. Grey lines are NOT live flow and do not claim pipe sizing/safety design.
  wire("g101-hp-buffer","M 600 269 H 1037 V 410","heatpump","buffer");
  wire("g101-hp-dhw","M 731 269 V 410","heatpump","boiler");
  wire("g101-buffer-radiators","M 1178 524 H 1276","buffer","radiators");
  wire("g101-radiators-return","M 1276 570 H 1178","radiators","buffer",true);
  wire("g101-fire-buffer","M 480 585 H 528 V 657 H 1008 V 646","fireplace","buffer");
  svg.append(g101SVG("circle",{cx:731,cy:269,r:5,fill:"#a6b4b7"}));
  text(svg,779,257,"VYTÁPĚNÍ → AKUMULACE","g101-subtitle");
  text(svg,744,352,"OHŘEV TUV","g101-subtitle");

  let detailTrigger=null;
  const overlay=document.createElement("div");overlay.className="g101-detail";overlay.hidden=true;
  const dialog=document.createElement("section");dialog.className="g101-dialog";dialog.setAttribute("role","dialog");dialog.setAttribute("aria-modal","true");dialog.setAttribute("aria-labelledby","g101-detail-title");
  const closeDetail=()=>{overlay.hidden=true;if(detailTrigger?.isConnected)detailTrigger.focus();};
  const showDetail=(name,slots,trigger)=>{
    detailTrigger=trigger;dialog.replaceChildren();
    const h=document.createElement("h2");h.id="g101-detail-title";h.textContent=name;
    const p=document.createElement("p");p.textContent="Tento blok je součástí pracovního schématu 00016. Měřené hodnoty a provozní stavy zatím nejsou připojené. Pomlčka znamená nepřiřazený údaj, nikoli nulovou hodnotu.";
    const dl=document.createElement("dl");slots.forEach(label=>{const r=document.createElement("div"),dt=document.createElement("dt"),dd=document.createElement("dd");dt.textContent=label;dd.textContent="Nepřiřazeno";r.append(dt,dd);dl.append(r);});
    const note=document.createElement("p");note.textContent=name==="Krb"?"Krb je v tomto návrhu logicky veden do akumulační nádrže. Skutečné hydraulické zapojení a bezpečnostní prvky se tím nemění.":"Tato obrazovka neposílá povely do zařízení. Provozní regulaci tento krok nemění.";
    const button=document.createElement("button");button.type="button";button.className="g101-close";button.textContent="Zavřít ×";button.addEventListener("click",closeDetail);
    dialog.append(h,p,dl,note,button);overlay.hidden=false;button.focus();
  };
  overlay.append(dialog);content.append(overlay);
  overlay.addEventListener("click",event=>{if(event.target===overlay)closeDetail();});
  const keyHandler=event=>{if(overlay.hidden)return;if(event.key==="Escape"){event.preventDefault();event.stopPropagation();closeDetail();}if(event.key==="Tab"){event.preventDefault();dialog.querySelector("button")?.focus();}};
  content.addEventListener("keydown",keyHandler);
  const panel=(id,x,y,w,h,name,slots)=>{
    const g=g101SVG("g",{class:"g101-device","data-g101-component":id,role:"button",tabindex:0,"aria-label":name+" – přehled připravených hodnot"});
    g.append(g101SVG("rect",{x,y,width:w,height:h,rx:15,class:"g101-panel",fill:"url(#g101-card)",stroke:"#33bfdf","stroke-width":1.3}));
    const open=()=>showDetail(name,slots,g);g.addEventListener("click",open);g.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open();}});
    svg.append(g);return g;
  };
  const hp=panel("heatpump",20,33,580,329,"Tepelné čerpadlo",["Elektrický příkon","Dnešní spotřeba","Relativní výkon","Vytápění","Ohřev vody","Výstupní a vratná voda","Motohodiny"]);
  row(hp,38,52,250,"ELEKTRICKÝ PŘÍKON","hp.power","kW");
  row(hp,38,88,250,"DNEŠNÍ SPOTŘEBA","hp.energy_today","kWh");
  text(hp,38,149,"TEPELNÉ ČERPADLO","g101-heading",{"font-size":"21"});
  text(hp,38,168,"TNG GENERACE 1 · JEDNA JEDNOTKA","g101-subtitle");
  // One outdoor unit, drawn as vector UI rather than an external picture.
  hp.append(g101SVG("rect",{x:43,y:190,width:221,height:106,rx:8,fill:"#082d3a",stroke:"#49d0f1","stroke-width":1.2}));
  hp.append(g101SVG("rect",{x:181,y:198,width:71,height:86,rx:3,fill:"#03202d",stroke:"#276777"}));
  for(let y=208;y<282;y+=7) hp.append(g101SVG("line",{x1:186,y1:y,x2:247,y2:y,stroke:"#327688","stroke-width":1}));
  hp.append(g101SVG("circle",{cx:111,cy:242,r:41,fill:"#06202b",stroke:"#338da7","stroke-width":2}));
  for(let i=0;i<6;i++)hp.append(g101SVG("path",{d:"M 111 241 C 90 224 92 212 104 213 C 113 214 118 228 111 241",fill:"#23819a",stroke:"#51cfe9","stroke-width":.8,transform:`rotate(${i*60} 111 242)`}));
  hp.append(g101SVG("circle",{cx:111,cy:242,r:8,fill:"#46d0ed"}));
  text(hp,221,291,"TNG","g101-label",{"text-anchor":"middle","font-size":10});
  text(hp,38,319,"Vytápění","g101-value");value(hp,282,319,"hp.heating","",{"text-anchor":"end"});
  text(hp,38,343,"Ohřev vody","g101-value");value(hp,282,343,"hp.dhw","",{"text-anchor":"end"});
  const gauge=g101SVG("g",{"data-g101-gauge":"unbound"});hp.append(gauge);
  gauge.append(g101SVG("circle",{cx:450,cy:182,r:127,fill:"#06242f",stroke:"#1a4d5e","stroke-width":2}));
  gauge.append(g101SVG("circle",{cx:450,cy:182,r:105,fill:"#0a3341"}));
  gauge.append(g101SVG("path",{d:"M 361 188 A 92 92 0 0 1 539 188",fill:"none",stroke:"#306a7d","stroke-width":12,"stroke-linecap":"round"}));
  gauge.append(g101SVG("circle",{cx:450,cy:184,r:7,fill:"#80c9dc"}));
  value(gauge,450,245,"hp.relative_power","%",{"text-anchor":"middle",style:"font-size:42px;font-weight:900"});
  text(gauge,450,275,"RELATIVNÍ VÝKON","g101-subtitle",{"text-anchor":"middle"});
  text(hp,450,337,"Výkon zatím není přiřazen","g101-muted",{"text-anchor":"middle"});

  // Text wordmark only; no generated image or invented photographic unit model.
  const word=g101SVG("g",{"aria-label":"TNG IQ FANDA"});svg.append(word);
  word.append(g101SVG("path",{d:"M 779 65 L 805 49 L 831 65 L 831 96 L 805 112 L 779 96 Z",fill:"#04212f",stroke:"#39cffe","stroke-width":2}));
  word.append(g101SVG("path",{d:"M 805 61 V 99 M 790 70 L 805 82 L 820 70 M 790 92 L 805 86 L 820 92",stroke:"#bceaff",fill:"none","stroke-width":2}));
  [[805,61],[790,70],[820,70],[790,92],[820,92]].forEach(([cx,cy])=>word.append(g101SVG("circle",{cx,cy,r:2.8,fill:"#d0f5ff"})));
  text(word,848,83,"TNG IQ FANDA","g101-value",{style:"font-size:27px;font-weight:900"});
  text(word,848,104,"TEPELNÉ ČERPADLO · GENERACE 1","g101-subtitle",{style:"font-size:10px"});
  text(svg,911,171,"Pracovní schéma · entity nepřiřazeny","g101-muted",{"text-anchor":"middle"});

  const tank=(g,x,y)=>{
    g.append(g101SVG("path",{d:`M ${x} ${y+12} C ${x} ${y-3} ${x+60} ${y-3} ${x+60} ${y+12} V ${y+100} C ${x+60} ${y+117} ${x} ${y+117} ${x} ${y+100} Z`,fill:"url(#g101-tank)",stroke:"#64d6ef","stroke-width":1.6}));
    g.append(g101SVG("ellipse",{cx:x+30,cy:y+12,rx:30,ry:10,fill:"#0a3545",stroke:"#64d6ef","stroke-width":1.5}));
    g.append(g101SVG("path",{d:`M ${x+27} ${y+43} V ${y+64} A 7 7 0 1 0 ${x+34} ${y+64} V ${y+43} A 3.5 3.5 0 0 0 ${x+27} ${y+43}`,fill:"none",stroke:"#83cadc","stroke-width":2}));
  };
  const boiler=panel("boiler",612,410,256,235,"Bojler",["Teplota TUV","Nastavená teplota TUV","Stav ohřevu"]);
  text(boiler,740,448,"BOJLER","g101-heading",{"text-anchor":"middle"});
  text(boiler,740,469,"PŘÍPRAVA TEPLÉ VODY","g101-subtitle",{"text-anchor":"middle"});
  tank(boiler,633,490);
  text(boiler,711,514,"TEPLOTA TUV","g101-label");value(boiler,711,543,"dhw.temperature","°C",{style:"font-size:25px"});
  text(boiler,711,572,"STAV OHŘEVU","g101-label");value(boiler,711,595,"dhw.state");
  row(boiler,626,610,228,"NASTAVENO","dhw.target","°C");
  const buffer=panel("buffer",902,410,276,235,"Akumulační nádrž",["Teplota akumulace","Cílová teplota","Stav nabíjení"]);
  text(buffer,1040,448,"AKU NÁDRŽ","g101-heading",{"text-anchor":"middle"});
  text(buffer,1040,469,"AKUMULACE TEPLA","g101-subtitle",{"text-anchor":"middle"});
  tank(buffer,923,490);
  text(buffer,1002,514,"TEPLOTA NÁDRŽE","g101-label");value(buffer,1002,543,"buffer.temperature","°C",{style:"font-size:25px"});
  text(buffer,1002,572,"STAV NÁDRŽE","g101-label");value(buffer,1002,595,"buffer.state");
  row(buffer,916,610,248,"CÍLOVÁ TEPLOTA","buffer.target","°C");

  const fireplace=panel("fireplace",20,418,460,226,"Krb",["Teplota výstupu krbu","Stav krbu","Motohodiny čerpadla krbu"]);
  fireplace.append(g101SVG("rect",{x:71,y:448,width:49,height:27,rx:3,fill:"#0b3240",stroke:"#4ba9c0"}));
  fireplace.append(g101SVG("rect",{x:43,y:474,width:106,height:121,rx:6,fill:"#103a47",stroke:"#5fcde7","stroke-width":2}));
  fireplace.append(g101SVG("rect",{x:54,y:486,width:84,height:94,rx:3,fill:"#04202a",stroke:"#37788c","stroke-width":1.5}));
  fireplace.append(g101SVG("path",{d:"M 79 563 C 67 547 90 536 91 513 C 112 529 104 542 116 536 C 136 557 110 579 96 579 C 86 579 80 573 79 563 Z",fill:"#174556",stroke:"#5ac8df","stroke-width":1.8}));
  fireplace.append(g101SVG("rect",{x:35,y:598,width:122,height:9,rx:3,fill:"#143e4b",stroke:"#59aac0"}));
  text(fireplace,307,451,"KRB","g101-heading",{"text-anchor":"middle"});
  text(fireplace,307,474,"TEPLO DO AKUMULACE","g101-subtitle",{"text-anchor":"middle"});
  row(fireplace,175,493,286,"TEPLOTA VÝSTUPU","fireplace.temperature","°C");
  row(fireplace,175,534,286,"STAV","fireplace.state");
  row(fireplace,175,575,286,"MOTOHODINY","fireplace.pump_hours","h");
  text(fireplace,307,628,"Napojení krbu je návrhové","g101-muted",{"text-anchor":"middle"});

  const indoor=g101SVG("g",{"data-g101-component":"room-display"});svg.append(indoor);
  indoor.append(g101SVG("circle",{cx:1416,cy:162,r:91,fill:"#03202a",stroke:"#29c9fc","stroke-width":2.5}));
  text(indoor,1416,119,"Vnitřní teplota","g101-value",{"text-anchor":"middle"});value(indoor,1416,147,"room.temperature","°C",{"text-anchor":"middle",style:"font-size:21px"});
  text(indoor,1416,172,"TOPNÝ OKRUH","g101-value",{"text-anchor":"middle"});
  indoor.append(g101SVG("line",{x1:1346,y1:183,x2:1486,y2:183,stroke:"#96b7c3"}));
  text(indoor,1416,207,"Nastavená teplota","g101-value",{"text-anchor":"middle"});value(indoor,1416,235,"room.target","°C",{"text-anchor":"middle"});

  const radiators=panel("radiators",1276,332,298,312,"Radiátorový okruh",["Teplota přívodu okruhu","Teplota zpátečky okruhu","Stav oběhového čerpadla","Požadavek vytápění"]);
  text(radiators,1425,370,"TOPNÝ OKRUH","g101-heading",{"text-anchor":"middle"});
  text(radiators,1425,391,"JEDEN RADIÁTOROVÝ OKRUH","g101-subtitle",{"text-anchor":"middle"});
  radiators.append(g101SVG("line",{x1:1337,y1:438,x2:1513,y2:438,stroke:"#73d3eb","stroke-width":4}));
  radiators.append(g101SVG("line",{x1:1337,y1:484,x2:1513,y2:484,stroke:"#73d3eb","stroke-width":4}));
  for(let x=1344;x<1509;x+=23)radiators.append(g101SVG("rect",{x,y:425,width:14,height:72,rx:6,fill:"#0c3140",stroke:"#73d3eb","stroke-width":2.5}));
  row(radiators,1291,513,268,"TEPLOTA PŘÍVODU","heating.supply","°C");
  row(radiators,1291,553,268,"TEPLOTA ZPÁTEČKY","heating.return","°C");
  row(radiators,1291,593,268,"OBĚHOVÉ ČERPADLO","heating.pump");
  text(radiators,1425,637,"Přímo z akumulační nádrže","g101-muted",{"text-anchor":"middle"});
  const pump=g101SVG("g",{"data-g101-component":"heating-pump-symbol"});svg.append(pump);
  pump.append(g101SVG("circle",{cx:1227,cy:480,r:22,fill:"#052532",stroke:"#42c9ee","stroke-width":2}));
  pump.append(g101SVG("path",{d:"M 1218 489 L 1227 471 L 1236 489 Z",fill:"none",stroke:"#68d8f2","stroke-width":2}));
  // No rotors, flames or flow animations indicate operation before entity binding.
  text(svg,26,20,"SCHÉMA TECHNOLOGIE","g101-subtitle",{style:"font-size:10px"});
  text(svg,798,679,"Šedé siločáry = navržené vazby • „—“ = nepřiřazená hodnota • kliknutím na blok zobrazíte připravené údaje","g101-muted",{"text-anchor":"middle",style:"font-size:11px"});

  g101Cleanup=()=>{
    resize?.disconnect();window.removeEventListener("resize",fit);
    content.removeEventListener("keydown",keyHandler);content.remove();
    saved.forEach(([node,style])=>{if(style===null)node.removeAttribute("style");else node.setAttribute("style",style);});
    if(previousBlank===null)stage.removeAttribute("data-blank");else stage.setAttribute("data-blank",previousBlank);
  };
  return true;
}
/* G101 END */

/* P103 START -- stored module schema -> one active rendering branch for both roles. */
const P103_STYLE = 'iqf-p103-schema-style';
const p103 = {epoch:0, controller:null, timer:null, rendered:null};
function p103EndView() {
  p103.epoch++; p103.controller?.abort(); p103.controller=null;
  clearTimeout(p103.timer); p103.timer=null; p103.rendered=null;
  p103hptEndView();
}
function p103Eligible() {
  return activeState?.module_key === 'heat_pump' && activeState?.module_type === 'heat_pump' &&
    [1,2].includes(Number(activeState?.generation)) && ['admin','portal'].includes(activeMode);
}
function p103Context(root) {
  return {root,state:activeState,mode:activeMode,auth:token(),route:location.pathname+location.search,epoch:p103.epoch};
}
function p103Current(c) {
  return c.root.isConnected && document.getElementById(ROOT_ID)===c.root && activeState===c.state &&
    activeMode===c.mode && currentTab==='schema' && token()===c.auth && Boolean(c.auth) &&
    p103.epoch===c.epoch && location.pathname+location.search===c.route;
}
function p103Envelope(data,c) {
  if (!data || data.contract!=='heat-pump-schema/1') throw new Error('SCHEMA_CONTRACT');
  for (const key of ['serial_number','device_uuid','site_id','module_id']) {
    if (data[key]!==c.state[key]) throw new Error('SCHEMA_IDENTITY');
  }
  if (data.generation!==Number(c.state.generation)) throw new Error('SCHEMA_GENERATION');
  if (!['assigned','unassigned','unsupported','identity_mismatch'].includes(data.state)) throw new Error('SCHEMA_STATE');
  if (data.state==='assigned' && (data.schema?.template_id!=='HPT-01' || data.schema?.template_version!=='1.0.0' || data.schema?.data_mode!=='unbound'))
    throw new Error('SCHEMA_TEMPLATE');
  return data;
}
function p103CanUseTemplate(tab) {
  const r=p103.rendered;
  return tab==='schema' && r && p103Current(r.context) && r.document.state==='assigned' && r.document.schema.template_id==='HPT-01';
}
function p103Style() {
  if(document.getElementById(P103_STYLE))return;
  const s=document.createElement('style');s.id=P103_STYLE;
  s.textContent=`
    #${ROOT_ID} .p103-panel{width:min(800px,calc(100% - 40px));margin:72px auto 24px;padding:28px;border:1px solid #286b82;border-radius:16px;background:#072733;color:#eaf9ff;box-sizing:border-box;}
    #${ROOT_ID} .p103-panel h2{color:#58d8fa;font-size:24px;margin:0 0 16px;}
    #${ROOT_ID} .p103-panel p{font-size:15px;line-height:1.6;margin:10px 0;}
    #${ROOT_ID} .p103-panel .p103-scope{color:#8fbdca;font-size:12px;overflow-wrap:anywhere;}
    #${ROOT_ID} .p103-panel button{font:inherit;border:1px solid #3f9eb5;border-radius:9px;padding:12px 18px;margin:12px 12px 0 0;background:#125166;color:#f2fcff;cursor:pointer;}
    #${ROOT_ID} .p103-panel button:disabled{opacity:.6;cursor:wait;}
    #${ROOT_ID} .p103-panel button:focus-visible{outline:2px solid #97eeff;outline-offset:3px;}
    #${ROOT_ID} .p103-panel[data-status=error]{border-color:#b26c69;}
  `;document.head.append(s);
}
function p103Panel(c,title,text,status='info') {
  if(!p103Current(c))return null;
  p103Style();p103hptEndView();
  const stage=c.root.querySelector('.iqf-hp-stage-inner');if(!stage)return null;
  stage.replaceChildren();stage.dataset.blank='false';
  const panel=element('section','p103-panel');panel.dataset.status=status;
  const heading=element('h2','',title), message=element('p','',text), scope=element('p','p103-scope',`${c.state.serial_number} · ${c.state.generation_name || c.state.model}`);
  panel.append(heading,message,scope);stage.append(panel);return panel;
}
function p103Button(panel,label,action) {
  const b=element('button','',label);b.type='button';b.addEventListener('click',action);panel.append(b);return b;
}
async function p103Request(c,body=null) {
  if(!p103Current(c))throw new Error('STALE_CONTEXT');
  if(body && c.mode!=='admin')throw new Error('CLIENT_WRITE_FORBIDDEN');
  const ctrl=new AbortController();p103.controller=ctrl;
  const timeout=setTimeout(()=>ctrl.abort(),12000);
  try {
    const r=await fetch(`${API}/${c.mode}/heat-pump-module/by-serial/${encodeURIComponent(c.state.serial_number)}/schema`,{
      method:body?'PUT':'GET',headers:{Authorization:'Bearer '+c.auth,Accept:'application/json',...(body?{'Content-Type':'application/json'}:{})},
      credentials:'omit',cache:'no-store',redirect:'error',signal:ctrl.signal,...(body?{body:JSON.stringify(body)}:{})
    });
    if(!r.ok){const e=new Error('SCHEMA_HTTP');e.status=r.status;throw e;}
    return p103Envelope(await r.json(),c);
  } finally {clearTimeout(timeout);if(p103.controller===ctrl)p103.controller=null;}
}
function p103Error(c,error) {
  if(!p103Current(c))return;
  p103.rendered=null;
  const code=Number.isInteger(error?.status)?` HTTP ${error.status}.`:'';
  const panel=p103Panel(c,'Schéma se nepodařilo načíst',`Nebylo možné ověřit schéma tohoto modulu.${code} Schéma jiného zákazníka se nepoužije.`,'error');
  if(panel)p103Button(panel,'Zkusit znovu',()=>{void showTab('schema');});
}
function p103Draw(c,doc) {
  if(!p103Current(c))return;
  if(doc.state==='assigned') {
    p103.rendered={context:c,document:doc};
    if(!p103hptRender(c.root,'schema'))throw new Error('SCHEMA_MOUNT_FAILED');
    return;
  }
  p103.rendered=null;
  // Preserve the original, explicitly scoped 00016 implementations. They are not templates for other accounts.
  if(doc.state==='unassigned' && c.state.serial_number==='F800711-TNG-00016' &&
      ((typeof g101Eligible==='function' && g101Eligible('schema')) ||
       (typeof se01Render==='function' && Number(c.state.generation)===2))) {
    renderBlank(c.root);return;
  }
  if(doc.state!=='unassigned') {
    const text=doc.state==='identity_mismatch'?
      'Uložené schéma má jinou identitu zařízení nebo modulu. Automaticky se nepoužije ani nepřepíše.':
      'V modulu je uložené vlastní schéma v jiném formátu. Nebude nahrazeno vzorem HPT-01. Pro jeho zobrazení je potřeba připojit jeho konkrétní renderer.';
    p103Panel(c,'Uložené schéma vyžaduje kontrolu',text,'error');return;
  }
  const admin=c.mode==='admin';
  const panel=p103Panel(c,'Modul zatím nemá přiřazené schéma',admin?
    'Modul je založený, ale nemá uložený rozpoznaný obsah schématu. Z katalogu můžete přiřadit HPT-01: jedno TČ, bojler, AKU, jeden radiátorový okruh a krb. Přiřazení platí pouze pro tento modul; nevytvoří vazby na čidla ani regulaci.':
    'K tomuto modulu zatím nebylo přiřazeno schéma. Administrátor je musí uložit ve Schématu stejného zařízení. Po uložení se zde automaticky načte.');
  if(panel && admin && doc.can_assign===true) {
    const button=p103Button(panel,'Přiřadit HPT-01 tomuto modulu',async()=>{
      if(!p103Current(c))return;
      const message=`Přiřadit šablonu HPT-01 pouze k ${c.state.serial_number}, ${c.state.generation_name || c.state.model}?\n\nTČ + bojler + AKU + jeden radiátorový okruh + krb.\nHodnoty zůstanou nepřiřazené. Fyzická zařízení se nezapínají. Krb → AKU je návrhové zapojení.\n\nNejde o kopii dat jiného klienta.`;
      if(!window.confirm(message))return;
      if(!p103Current(c))return;
      clearTimeout(p103.timer);button.disabled=true;button.textContent='Ukládám přiřazení…';
      try{
        const saved=await p103Request(c,{template_id:'HPT-01',device_uuid:c.state.device_uuid,site_id:c.state.site_id,
          module_id:c.state.module_id,generation:Number(c.state.generation),expected_revision:doc.revision});
        if(!p103Current(c))return;
        p103Draw(c,saved);p103Poll(c,saved);
      }catch(e){p103Error(c,e);}
    });
  }
}
function p103Poll(c,last) {
  clearTimeout(p103.timer);
  p103.timer=setTimeout(async()=>{
    if(!p103Current(c))return;
    if(document.hidden){p103Poll(c,last);return;}
    try{
      const next=await p103Request(c);
      if(!p103Current(c))return;
      if(next.revision!==last.revision || next.state!==last.state)p103Draw(c,next);
      p103Poll(c,next);
    }catch(e){p103Error(c,e);}
  },15000);
}
async function p103ShowSchema(root) {
  const c=p103Context(root);
  p103Panel(c,'Načítám schéma modulu','Ověřuji obsah uložený pro toto zařízení.');
  try{
    const doc=await p103Request(c);if(!p103Current(c))return;
    p103Draw(c,doc);p103Poll(c,doc);
  }catch(e){p103Error(c,e);}
}
/* P103 END */

/* HPT-01 SVG derived from G101; assignment+identity are checked by P103. */
const P103HPT_ID = "iqf-p103hpt-schema";
const P103HPT_STYLE = "iqf-p103hpt-schema-style";
let p103hptCleanup = null;

function p103hptEndView() {
  if (p103hptCleanup) { const cleanup = p103hptCleanup; p103hptCleanup = null; cleanup(); }
}
function p103hptEligible(tab) { return p103CanUseTemplate(tab); }
function p103hptSVG(tag, attributes = {}, text = null) {
  const node = document.createElementNS("http://www.w3.org/2000/svg", tag);
  Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, String(value)));
  if (text !== null) node.textContent = text;
  return node;
}
function p103hptStyle() {
  if (document.getElementById(P103HPT_STYLE)) return;
  const style = document.createElement("style"); style.id = P103HPT_STYLE;
  style.textContent = `
    #${P103HPT_ID} {position:relative;display:block;width:100%;height:100%;min-width:0;min-height:0;
      overflow:auto;background:#03171f;color:#eaf9ff;box-sizing:border-box;font-family:inherit;}
    #${P103HPT_ID} * {box-sizing:border-box;}
    #${P103HPT_ID} .p103hpt-svg {display:block;width:100%;height:100%;min-width:1040px;min-height:455px;}
    #${P103HPT_ID} svg text {font-family:Arial,Helvetica,sans-serif;}
    #${P103HPT_ID} .p103hpt-heading {fill:#47d8fc;font-size:25px;font-weight:900;letter-spacing:.25px;}
    #${P103HPT_ID} .p103hpt-subtitle {fill:#95bdcb;font-size:11px;font-weight:800;letter-spacing:1.1px;}
    #${P103HPT_ID} .p103hpt-label {fill:#48d4f8;font-size:11px;font-weight:800;letter-spacing:.35px;}
    #${P103HPT_ID} .p103hpt-value {fill:#e9f8fd;font-size:15px;font-weight:800;}
    #${P103HPT_ID} .p103hpt-muted {fill:#8eb1bf;font-size:12px;}
    #${P103HPT_ID} .p103hpt-device {cursor:pointer;outline:none;}
    #${P103HPT_ID} .p103hpt-device:focus-visible > .p103hpt-panel {stroke:#b7f3ff;stroke-width:3;}
    #${P103HPT_ID} .p103hpt-device:hover > .p103hpt-panel {stroke:#85e9ff;}
    #${P103HPT_ID} .p103hpt-connection {fill:none;stroke:#87979b;stroke-width:4;stroke-linejoin:round;stroke-linecap:round;}
    #${P103HPT_ID} .p103hpt-connection-return {stroke:#546b77;stroke-width:3;}
    #${P103HPT_ID} .p103hpt-detail {position:absolute;inset:0;z-index:3;display:flex;align-items:center;justify-content:center;
      background:rgba(0,10,17,.8);padding:24px;}
    #${P103HPT_ID} .p103hpt-detail[hidden] {display:none;}
    #${P103HPT_ID} .p103hpt-dialog {width:min(570px,100%);max-height:100%;overflow:auto;background:#082631;border:1px solid #267b94;
      border-radius:16px;padding:24px;box-shadow:0 18px 55px #0006;}
    #${P103HPT_ID} .p103hpt-dialog h2 {font-size:23px;color:#4ddcff;margin:0 0 12px;}
    #${P103HPT_ID} .p103hpt-dialog p {font-size:14px;line-height:1.55;color:#b4d1dc;margin:12px 0;}
    #${P103HPT_ID} .p103hpt-dialog dl {margin:16px 0;}
    #${P103HPT_ID} .p103hpt-dialog dl > div {display:grid;grid-template-columns:1fr auto;gap:18px;padding:9px 0;border-bottom:1px solid #184455;}
    #${P103HPT_ID} .p103hpt-dialog dt {font-size:13px;color:#9ac0cf;}
    #${P103HPT_ID} .p103hpt-dialog dd {font-size:13px;color:#e8faff;margin:0;}
    #${P103HPT_ID} .p103hpt-close {display:block;margin:18px 0 0 auto;background:#123e4f;border:1px solid #3886a0;border-radius:9px;
      padding:10px 18px;color:#effbff;font:inherit;font-weight:800;cursor:pointer;}
    #${P103HPT_ID} .p103hpt-close:focus-visible {outline:2px solid #8decff;outline-offset:3px;}
  `;
  document.head.append(style);
}
function p103hptRender(root, tab) {
  if (!root || !p103hptEligible(tab)) return false;
  const stage = root.querySelector(".iqf-hp-stage-inner");
  const pane = stage?.parentElement;
  const footer = root.querySelector(".iqf-hp-bottom-shell");
  if (!stage || !pane || !footer) return false;
  p103hptEndView(); p103hptStyle();
  // The original application controls identity, authorization, tabs and menu.
  // Only this tab's content area and its temporary dimensions are changed.
  const saved = [stage, pane].map(node => [node, node.getAttribute("style")]);
  const previousBlank = stage.getAttribute("data-blank");
  stage.replaceChildren(); stage.dataset.blank = "false";
  const content = document.createElement("div"); content.id = P103HPT_ID;
  content.dataset.serial = activeState.serial_number;
  content.dataset.generation = String(activeState.generation); content.dataset.moduleKey = "heat_pump";
  content.dataset.dataMode = "unbound";
  stage.append(content);
  const set = (node, key, value) => {
    if (node.style.getPropertyValue(key) !== value) node.style.setProperty(key, value, "important");
  };
  const fixedStyles = {position:"absolute",left:"0px",right:"0px",top:"32px",width:"100%","max-width":"none",margin:"0px",padding:"0px","min-height":"0px",overflow:"hidden"};
  Object.entries(fixedStyles).forEach(([key, value]) => set(pane,key,value));
  Object.entries({width:"100%",height:"100%","min-height":"0px","max-width":"none",margin:"0px",padding:"0px",overflow:"hidden"}).forEach(([key,value])=>set(stage,key,value));
  const fit = () => {
    if (!root.isConnected || !content.isConnected || !footer.isConnected) return;
    const available = Math.floor(footer.getBoundingClientRect().top - root.getBoundingClientRect().top - 38);
    if (available > 70) { set(pane,"height",available+"px"); set(pane,"max-height",available+"px"); }
  };
  fit();
  let resize = null;
  if (typeof ResizeObserver !== "undefined") { resize = new ResizeObserver(fit); resize.observe(root); resize.observe(footer); }
  window.addEventListener("resize",fit);

  const svg = p103hptSVG("svg", {class:"p103hpt-svg",viewBox:"0 0 1600 700",preserveAspectRatio:"xMidYMid meet",role:"img","aria-labelledby":"p103hpt-title p103hpt-desc"});
  svg.append(p103hptSVG("title",{id:"p103hpt-title"},"Schéma: jedno tepelné čerpadlo, bojler, akumulační nádrž, jeden radiátorový okruh a krb"));
  svg.append(p103hptSVG("desc",{id:"p103hpt-desc"},"Šablona HPT-01 přiřazená tomuto konkrétnímu modulu. Tepelné čerpadlo má samostatnou větev do bojleru a do akumulace. Radiátorový okruh je přímo z akumulační nádrže, bez rozdělovače. Krb je v návrhu připojen k akumulaci. Provozní entity zatím nejsou přiřazené."));
  content.append(svg);
  const defs=p103hptSVG("defs");
  const gradient=(id,stops,attrs={})=>{const g=p103hptSVG("linearGradient",{id,...attrs});stops.forEach(([offset,color])=>g.append(p103hptSVG("stop",{offset,"stop-color":color})));defs.append(g);};
  gradient("p103hpt-bg",[["0%","#08232e"],["100%","#02121a"]],{x1:"0",y1:"0",x2:"1",y2:"1"});
  gradient("p103hpt-card",[["0%","#052834"],["100%","#021923"]],{x1:"0",y1:"0",x2:"0",y2:"1"});
  gradient("p103hpt-tank",[["0%","#05232e"],["48%","#124a5c"],["100%","#05212c"]]);
  const glow=p103hptSVG("filter",{id:"p103hpt-glow",x:"-30%",y:"-30%",width:"160%",height:"160%"});
  glow.append(p103hptSVG("feGaussianBlur",{stdDeviation:"4",result:"blur"}));
  const merge=p103hptSVG("feMerge");merge.append(p103hptSVG("feMergeNode",{in:"blur"}),p103hptSVG("feMergeNode",{in:"SourceGraphic"}));glow.append(merge);defs.append(glow);
  svg.append(defs);
  svg.append(p103hptSVG("rect",{x:6,y:5,width:1588,height:683,rx:18,fill:"url(#p103hpt-bg)",stroke:"#153d4a","stroke-width":1}));
  const text=(parent,x,y,value,cls="p103hpt-value",extra={})=>{const t=p103hptSVG("text",{x,y,class:cls,...extra},value);parent.append(t);return t;};
  const value=(parent,x,y,slot,unit="",extra={})=>{
    const v=text(parent,x,y,"—"+(unit?" "+unit:""),"p103hpt-value",{"data-p103hpt-slot":slot,"data-quality":"unbound",...extra});
    v.append(p103hptSVG("title",{},"Hodnota není přiřazená. Pomlčka neznamená nulu ani vypnuto."));return v;
  };
  const row=(parent,x,y,w,label,slot,unit="")=>{
    parent.append(p103hptSVG("rect",{x,y,width:w,height:30,rx:8,fill:"#011c26",stroke:"#1d5366"}));
    text(parent,x+10,y+19,label,"p103hpt-label");value(parent,x+w-10,y+20,slot,unit,{"text-anchor":"end"});
  };
  const wire=(id,d,from,to,isReturn=false)=>{
    svg.append(p103hptSVG("path",{id,d,class:"p103hpt-connection"+(isReturn?" p103hpt-connection-return":""),"data-source":from,"data-target":to,"data-flow-state":"unbound"}));
  };
  // Logical energy links. Grey lines are NOT live flow and do not claim pipe sizing/safety design.
  wire("p103hpt-hp-buffer","M 600 269 H 1037 V 410","heatpump","buffer");
  wire("p103hpt-hp-dhw","M 731 269 V 410","heatpump","boiler");
  wire("p103hpt-buffer-radiators","M 1178 524 H 1276","buffer","radiators");
  wire("p103hpt-radiators-return","M 1276 570 H 1178","radiators","buffer",true);
  wire("p103hpt-fire-buffer","M 480 585 H 528 V 657 H 1008 V 646","fireplace","buffer");
  svg.append(p103hptSVG("circle",{cx:731,cy:269,r:5,fill:"#a6b4b7"}));
  text(svg,779,257,"VYTÁPĚNÍ → AKUMULACE","p103hpt-subtitle");
  text(svg,744,352,"OHŘEV TUV","p103hpt-subtitle");

  let detailTrigger=null;
  const overlay=document.createElement("div");overlay.className="p103hpt-detail";overlay.hidden=true;
  const dialog=document.createElement("section");dialog.className="p103hpt-dialog";dialog.setAttribute("role","dialog");dialog.setAttribute("aria-modal","true");dialog.setAttribute("aria-labelledby","p103hpt-detail-title");
  const closeDetail=()=>{overlay.hidden=true;if(detailTrigger?.isConnected)detailTrigger.focus();};
  const showDetail=(name,slots,trigger)=>{
    detailTrigger=trigger;dialog.replaceChildren();
    const h=document.createElement("h2");h.id="p103hpt-detail-title";h.textContent=name;
    const p=document.createElement("p");p.textContent="Tento blok je součástí schématu tohoto modulu. Měřené hodnoty a provozní stavy zatím nejsou připojené. Pomlčka znamená nepřiřazený údaj, nikoli nulovou hodnotu.";
    const dl=document.createElement("dl");slots.forEach(label=>{const r=document.createElement("div"),dt=document.createElement("dt"),dd=document.createElement("dd");dt.textContent=label;dd.textContent="Nepřiřazeno";r.append(dt,dd);dl.append(r);});
    const note=document.createElement("p");note.textContent=name==="Krb"?"Krb je v tomto návrhu logicky veden do akumulační nádrže. Skutečné hydraulické zapojení a bezpečnostní prvky se tím nemění.":"Tato obrazovka neposílá povely do zařízení. Provozní regulaci tento krok nemění.";
    const button=document.createElement("button");button.type="button";button.className="p103hpt-close";button.textContent="Zavřít ×";button.addEventListener("click",closeDetail);
    dialog.append(h,p,dl,note,button);overlay.hidden=false;button.focus();
  };
  overlay.append(dialog);content.append(overlay);
  overlay.addEventListener("click",event=>{if(event.target===overlay)closeDetail();});
  const keyHandler=event=>{if(overlay.hidden)return;if(event.key==="Escape"){event.preventDefault();event.stopPropagation();closeDetail();}if(event.key==="Tab"){event.preventDefault();dialog.querySelector("button")?.focus();}};
  content.addEventListener("keydown",keyHandler);
  const panel=(id,x,y,w,h,name,slots)=>{
    const g=p103hptSVG("g",{class:"p103hpt-device","data-p103hpt-component":id,role:"button",tabindex:0,"aria-label":name+" – přehled připravených hodnot"});
    g.append(p103hptSVG("rect",{x,y,width:w,height:h,rx:15,class:"p103hpt-panel",fill:"url(#p103hpt-card)",stroke:"#33bfdf","stroke-width":1.3}));
    const open=()=>showDetail(name,slots,g);g.addEventListener("click",open);g.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open();}});
    svg.append(g);return g;
  };
  const hp=panel("heatpump",20,33,580,329,"Tepelné čerpadlo",["Elektrický příkon","Dnešní spotřeba","Relativní výkon","Vytápění","Ohřev vody","Výstupní a vratná voda","Motohodiny"]);
  row(hp,38,52,250,"ELEKTRICKÝ PŘÍKON","hp.power","kW");
  row(hp,38,88,250,"DNEŠNÍ SPOTŘEBA","hp.energy_today","kWh");
  text(hp,38,149,"TEPELNÉ ČERPADLO","p103hpt-heading",{"font-size":"21"});
  text(hp,38,168,"TNG · JEDNA JEDNOTKA","p103hpt-subtitle");
  // One outdoor unit, drawn as vector UI rather than an external picture.
  hp.append(p103hptSVG("rect",{x:43,y:190,width:221,height:106,rx:8,fill:"#082d3a",stroke:"#49d0f1","stroke-width":1.2}));
  hp.append(p103hptSVG("rect",{x:181,y:198,width:71,height:86,rx:3,fill:"#03202d",stroke:"#276777"}));
  for(let y=208;y<282;y+=7) hp.append(p103hptSVG("line",{x1:186,y1:y,x2:247,y2:y,stroke:"#327688","stroke-width":1}));
  hp.append(p103hptSVG("circle",{cx:111,cy:242,r:41,fill:"#06202b",stroke:"#338da7","stroke-width":2}));
  for(let i=0;i<6;i++)hp.append(p103hptSVG("path",{d:"M 111 241 C 90 224 92 212 104 213 C 113 214 118 228 111 241",fill:"#23819a",stroke:"#51cfe9","stroke-width":.8,transform:`rotate(${i*60} 111 242)`}));
  hp.append(p103hptSVG("circle",{cx:111,cy:242,r:8,fill:"#46d0ed"}));
  text(hp,221,291,"TNG","p103hpt-label",{"text-anchor":"middle","font-size":10});
  text(hp,38,319,"Vytápění","p103hpt-value");value(hp,282,319,"hp.heating","",{"text-anchor":"end"});
  text(hp,38,343,"Ohřev vody","p103hpt-value");value(hp,282,343,"hp.dhw","",{"text-anchor":"end"});
  const gauge=p103hptSVG("g",{"data-p103hpt-gauge":"unbound"});hp.append(gauge);
  gauge.append(p103hptSVG("circle",{cx:450,cy:182,r:127,fill:"#06242f",stroke:"#1a4d5e","stroke-width":2}));
  gauge.append(p103hptSVG("circle",{cx:450,cy:182,r:105,fill:"#0a3341"}));
  gauge.append(p103hptSVG("path",{d:"M 361 188 A 92 92 0 0 1 539 188",fill:"none",stroke:"#306a7d","stroke-width":12,"stroke-linecap":"round"}));
  gauge.append(p103hptSVG("circle",{cx:450,cy:184,r:7,fill:"#80c9dc"}));
  value(gauge,450,245,"hp.relative_power","%",{"text-anchor":"middle",style:"font-size:42px;font-weight:900"});
  text(gauge,450,275,"RELATIVNÍ VÝKON","p103hpt-subtitle",{"text-anchor":"middle"});
  text(hp,450,337,"Výkon zatím není přiřazen","p103hpt-muted",{"text-anchor":"middle"});

  // Text wordmark only; no generated image or invented photographic unit model.
  const word=p103hptSVG("g",{"aria-label":"TNG IQ FANDA"});svg.append(word);
  word.append(p103hptSVG("path",{d:"M 779 65 L 805 49 L 831 65 L 831 96 L 805 112 L 779 96 Z",fill:"#04212f",stroke:"#39cffe","stroke-width":2}));
  word.append(p103hptSVG("path",{d:"M 805 61 V 99 M 790 70 L 805 82 L 820 70 M 790 92 L 805 86 L 820 92",stroke:"#bceaff",fill:"none","stroke-width":2}));
  [[805,61],[790,70],[820,70],[790,92],[820,92]].forEach(([cx,cy])=>word.append(p103hptSVG("circle",{cx,cy,r:2.8,fill:"#d0f5ff"})));
  text(word,848,83,"TNG IQ FANDA","p103hpt-value",{style:"font-size:27px;font-weight:900"});
  text(word,848,104,`TEPELNÉ ČERPADLO · GENERACE ${Number(activeState.generation)}`,"p103hpt-subtitle",{style:"font-size:10px"});
  text(svg,911,171,"Pracovní schéma · entity nepřiřazeny","p103hpt-muted",{"text-anchor":"middle"});

  const tank=(g,x,y)=>{
    g.append(p103hptSVG("path",{d:`M ${x} ${y+12} C ${x} ${y-3} ${x+60} ${y-3} ${x+60} ${y+12} V ${y+100} C ${x+60} ${y+117} ${x} ${y+117} ${x} ${y+100} Z`,fill:"url(#p103hpt-tank)",stroke:"#64d6ef","stroke-width":1.6}));
    g.append(p103hptSVG("ellipse",{cx:x+30,cy:y+12,rx:30,ry:10,fill:"#0a3545",stroke:"#64d6ef","stroke-width":1.5}));
    g.append(p103hptSVG("path",{d:`M ${x+27} ${y+43} V ${y+64} A 7 7 0 1 0 ${x+34} ${y+64} V ${y+43} A 3.5 3.5 0 0 0 ${x+27} ${y+43}`,fill:"none",stroke:"#83cadc","stroke-width":2}));
  };
  const boiler=panel("boiler",612,410,256,235,"Bojler",["Teplota TUV","Nastavená teplota TUV","Stav ohřevu"]);
  text(boiler,740,448,"BOJLER","p103hpt-heading",{"text-anchor":"middle"});
  text(boiler,740,469,"PŘÍPRAVA TEPLÉ VODY","p103hpt-subtitle",{"text-anchor":"middle"});
  tank(boiler,633,490);
  text(boiler,711,514,"TEPLOTA TUV","p103hpt-label");value(boiler,711,543,"dhw.temperature","°C",{style:"font-size:25px"});
  text(boiler,711,572,"STAV OHŘEVU","p103hpt-label");value(boiler,711,595,"dhw.state");
  row(boiler,626,610,228,"NASTAVENO","dhw.target","°C");
  const buffer=panel("buffer",902,410,276,235,"Akumulační nádrž",["Teplota akumulace","Cílová teplota","Stav nabíjení"]);
  text(buffer,1040,448,"AKU NÁDRŽ","p103hpt-heading",{"text-anchor":"middle"});
  text(buffer,1040,469,"AKUMULACE TEPLA","p103hpt-subtitle",{"text-anchor":"middle"});
  tank(buffer,923,490);
  text(buffer,1002,514,"TEPLOTA NÁDRŽE","p103hpt-label");value(buffer,1002,543,"buffer.temperature","°C",{style:"font-size:25px"});
  text(buffer,1002,572,"STAV NÁDRŽE","p103hpt-label");value(buffer,1002,595,"buffer.state");
  row(buffer,916,610,248,"CÍLOVÁ TEPLOTA","buffer.target","°C");

  const fireplace=panel("fireplace",20,418,460,226,"Krb",["Teplota výstupu krbu","Stav krbu","Motohodiny čerpadla krbu"]);
  fireplace.append(p103hptSVG("rect",{x:71,y:448,width:49,height:27,rx:3,fill:"#0b3240",stroke:"#4ba9c0"}));
  fireplace.append(p103hptSVG("rect",{x:43,y:474,width:106,height:121,rx:6,fill:"#103a47",stroke:"#5fcde7","stroke-width":2}));
  fireplace.append(p103hptSVG("rect",{x:54,y:486,width:84,height:94,rx:3,fill:"#04202a",stroke:"#37788c","stroke-width":1.5}));
  fireplace.append(p103hptSVG("path",{d:"M 79 563 C 67 547 90 536 91 513 C 112 529 104 542 116 536 C 136 557 110 579 96 579 C 86 579 80 573 79 563 Z",fill:"#174556",stroke:"#5ac8df","stroke-width":1.8}));
  fireplace.append(p103hptSVG("rect",{x:35,y:598,width:122,height:9,rx:3,fill:"#143e4b",stroke:"#59aac0"}));
  text(fireplace,307,451,"KRB","p103hpt-heading",{"text-anchor":"middle"});
  text(fireplace,307,474,"TEPLO DO AKUMULACE","p103hpt-subtitle",{"text-anchor":"middle"});
  row(fireplace,175,493,286,"TEPLOTA VÝSTUPU","fireplace.temperature","°C");
  row(fireplace,175,534,286,"STAV","fireplace.state");
  row(fireplace,175,575,286,"MOTOHODINY","fireplace.pump_hours","h");
  text(fireplace,307,628,"Napojení krbu je návrhové","p103hpt-muted",{"text-anchor":"middle"});

  const indoor=p103hptSVG("g",{"data-p103hpt-component":"room-display"});svg.append(indoor);
  indoor.append(p103hptSVG("circle",{cx:1416,cy:162,r:91,fill:"#03202a",stroke:"#29c9fc","stroke-width":2.5}));
  text(indoor,1416,119,"Vnitřní teplota","p103hpt-value",{"text-anchor":"middle"});value(indoor,1416,147,"room.temperature","°C",{"text-anchor":"middle",style:"font-size:21px"});
  text(indoor,1416,172,"TOPNÝ OKRUH","p103hpt-value",{"text-anchor":"middle"});
  indoor.append(p103hptSVG("line",{x1:1346,y1:183,x2:1486,y2:183,stroke:"#96b7c3"}));
  text(indoor,1416,207,"Nastavená teplota","p103hpt-value",{"text-anchor":"middle"});value(indoor,1416,235,"room.target","°C",{"text-anchor":"middle"});

  const radiators=panel("radiators",1276,332,298,312,"Radiátorový okruh",["Teplota přívodu okruhu","Teplota zpátečky okruhu","Stav oběhového čerpadla","Požadavek vytápění"]);
  text(radiators,1425,370,"TOPNÝ OKRUH","p103hpt-heading",{"text-anchor":"middle"});
  text(radiators,1425,391,"JEDEN RADIÁTOROVÝ OKRUH","p103hpt-subtitle",{"text-anchor":"middle"});
  radiators.append(p103hptSVG("line",{x1:1337,y1:438,x2:1513,y2:438,stroke:"#73d3eb","stroke-width":4}));
  radiators.append(p103hptSVG("line",{x1:1337,y1:484,x2:1513,y2:484,stroke:"#73d3eb","stroke-width":4}));
  for(let x=1344;x<1509;x+=23)radiators.append(p103hptSVG("rect",{x,y:425,width:14,height:72,rx:6,fill:"#0c3140",stroke:"#73d3eb","stroke-width":2.5}));
  row(radiators,1291,513,268,"TEPLOTA PŘÍVODU","heating.supply","°C");
  row(radiators,1291,553,268,"TEPLOTA ZPÁTEČKY","heating.return","°C");
  row(radiators,1291,593,268,"OBĚHOVÉ ČERPADLO","heating.pump");
  text(radiators,1425,637,"Přímo z akumulační nádrže","p103hpt-muted",{"text-anchor":"middle"});
  const pump=p103hptSVG("g",{"data-p103hpt-component":"heating-pump-symbol"});svg.append(pump);
  pump.append(p103hptSVG("circle",{cx:1227,cy:480,r:22,fill:"#052532",stroke:"#42c9ee","stroke-width":2}));
  pump.append(p103hptSVG("path",{d:"M 1218 489 L 1227 471 L 1236 489 Z",fill:"none",stroke:"#68d8f2","stroke-width":2}));
  // No rotors, flames or flow animations indicate operation before entity binding.
  text(svg,26,20,"SCHÉMA TECHNOLOGIE","p103hpt-subtitle",{style:"font-size:10px"});
  text(svg,798,679,"Šedé siločáry = navržené vazby • „—“ = nepřiřazená hodnota • kliknutím na blok zobrazíte připravené údaje","p103hpt-muted",{"text-anchor":"middle",style:"font-size:11px"});

  p103hptCleanup=()=>{
    resize?.disconnect();window.removeEventListener("resize",fit);
    content.removeEventListener("keydown",keyHandler);content.remove();
    saved.forEach(([node,style])=>{if(style===null)node.removeAttribute("style");else node.setAttribute("style",style);});
    if(previousBlank===null)stage.removeAttribute("data-blank");else stage.setAttribute("data-blank",previousBlank);
  };
  return true;
}
/* P103HPT END */

  function renderBlank(root) {
    if (g101Render(root, currentTab)) return;
    if (se01Render(root, currentTab)) return;
    const stage = root.querySelector(".iqf-hp-stage-inner");

    if (!stage) return;

    stage.dataset.blank = "true";
    clear(stage);
  }

  async function showTab(tab) {
    p103EndView();
    g101EndView();
    se01EndView();
    currentTab = tab;

    const root = document.getElementById(ROOT_ID);

    if (!root || !activeState) return;

    setActiveNav(root);

    if (tab === "schema" && p103Eligible()) { await p103ShowSchema(root); return; }

    if (tab === "system") {
      systemData = null;
      renderSystem(root);

      const epoch = ++requestEpoch;

      try {
        const value = await loadSystem(activeState, activeMode);

        if (
          epoch === requestEpoch &&
          currentTab === "system"
        ) {
          systemData = value;
          renderSystem(root);
        }
      } catch (error) {
        if (
          epoch === requestEpoch &&
          currentTab === "system"
        ) {
          systemData = {
            error:
              "Systémové informace se nepodařilo načíst."
          };
          renderSystem(root);
        }
      }

      return;
    }

    if (tab === "users") {
      userData = null;
      renderUser(root);

      const epoch = ++requestEpoch;

      try {
        const value = await loadUser(activeState, activeMode);

        if (
          epoch === requestEpoch &&
          currentTab === "users"
        ) {
          userData = value;
          renderUser(root);
        }
      } catch (_) {
        if (
          epoch === requestEpoch &&
          currentTab === "users"
        ) {
          userData = {
            error:
              "Uživatelský profil se nepodařilo načíst."
          };
          renderUser(root);
        }
      }

      return;
    }

    requestEpoch++;
    renderBlank(root);
  }

  function closeWorkspace() {
    p104OnWorkspaceClose();
    p103EndView();
    p101OnWorkspaceClosed();
    g101EndView();
    se01EndView();
    requestEpoch++;
    document.getElementById(ROOT_ID)?.remove();
    activeState = null;
    activeMode = null;
    systemData = null;
    userData = null;
    weatherData = null;
  }

  function buildShell(state, userMode) {
    ensureStyle();

    const old = document.getElementById(ROOT_ID);
    if (old) old.remove();

    const root = element("section");
    root.id = ROOT_ID;
    root.dataset.version = VERSION;
    root.dataset.template =
      "universal-individual-admin-client-clone";
    root.dataset.menu =
      "schema-settings-statistics-system-manual-user";

    const meta = element(
      "div",
      "iqf-hp-top-meta",
      `Tepelné čerpadlo · ${state.generation_name || state.model || ""} · ${state.serial_number}`
    );

    const back = element(
      "button",
      "iqf-hp-back",
      userMode === "admin"
        ? "← Zpět na kartu klienta"
        : "← Zpět na zařízení"
    );
    back.type = "button";
    back.addEventListener("click", closeWorkspace);

    const stage = element("main", "iqf-hp-stage");
    const stageInner = element("div", "iqf-hp-stage-inner");
    stageInner.dataset.blank = "true";
    stage.appendChild(stageInner);

    const bottom = element("footer", "iqf-hp-bottom-shell");

    const menu = element("nav", "iqf-hp-menu-panel");
    menu.setAttribute(
      "aria-label",
      "Menu modulu tepelného čerpadla"
    );

    for (const [tab, icon, label] of TABS) {
      const button = element("button", "iqf-hp-nav");
      button.type = "button";
      button.dataset.tab = tab;
      button.dataset.active =
        tab === currentTab ? "true" : "false";

      button.append(
        element("span", "iqf-hp-nav-icon", icon),
        element("span", "iqf-hp-nav-label", label),
      );

      button.addEventListener("click", () => showTab(tab));

      menu.appendChild(button);
    }

    const identity = element("section", "iqf-hp-identity-panel");
    identity.append(
      element(
        "div",
        "iqf-hp-identity-main",
        "Řídicí systém tepelného čerpadla"
      ),
      element(
        "div",
        "iqf-hp-identity-sub",
        `${state.generation_name || state.model || "TNG"} · ${state.serial_number}`
      ),
      element(
        "div",
        "iqf-hp-identity-copy",
        "TNG IQ FANDA, Copyright (©) TNG Air"
      ),
    );

    const weather = element("section", "iqf-hp-weather-panel");

    bottom.append(menu, identity, weather);
    root.append(meta, back, stage, bottom);

    document.body.appendChild(root);

    renderWeather(root);

    return root;
  }

  function openWorkspace(state, userMode) {
    if (!p104BeforeWorkspaceOpen(state,userMode)) return;
    activeState = state;
    activeMode = userMode;
    currentTab = "schema";
    systemData = null;
    userData = null;
    weatherData = null;

    buildShell(state, userMode);
    showTab("schema");

    loadWeather(state, userMode);
    p101OnWorkspaceOpened(state, userMode);
  }

  async function moduleState(userMode, serial) {
  /* __F33_R7_00013_TRUE_INDIVIDUAL_CLONE__: model 00013 is rendered by the real cloned individual_project. */
  if (String(serial || "").trim().toUpperCase() === "F800711-TNG-00013") {
    return {
      active: false,
      serial_number: "F800711-TNG-00013",
      module_key: "heat_pump",
      module_type: "heat_pump",
      generation: 1,
      f33_r7_individual_clone: true
    };
  }

    return jsonFetch(
      `${API}/${userMode}/heat-pump-module/by-serial/${encodeURIComponent(serial)}`
    );
  }

  function selectorStatus(message) {
    const selector = document.getElementById(
      "iqf-solareast-hp-generation-choice"
    );

    const status = selector?.querySelector(
      ".iqf-hp-generation-status"
    );

    if (status) {
      status.textContent = message;
    }
  }

  function findButtonByText(fragment) {
    const wanted = normalizeText(fragment);

    return [
      ...document.querySelectorAll(
        "button,a,[role='button']"
      ),
    ].find(
      (node) =>
        normalizeText(node.textContent)
          .includes(wanted)
    ) || null;
  }

  function isVisible(node) {
    if (
      !node ||
      !node.isConnected ||
      typeof node.getBoundingClientRect !== "function"
    ) {
      return false;
    }

    const rect =
      node.getBoundingClientRect();

    const style =
      getComputedStyle(node);

    return (
      rect.width > 0 &&
      rect.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden"
    );
  }

  function leafContainingTextWithin(
    root,
    fragment
  ) {
    if (!root) return null;

    const wanted =
      normalizeText(fragment);

    return [
      ...root.querySelectorAll(
        "div,section,article,h1,h2,h3,h4,p,span"
      ),
    ].find((node) => {
      if (!isVisible(node)) {
        return false;
      }

      const text =
        normalizeText(
          node.textContent
        );

      if (!text.includes(wanted)) {
        return false;
      }

      return ![
        ...node.children,
      ].some(
        (child) =>
          normalizeText(
            child.textContent
          ).includes(wanted)
      );
    }) || null;
  }

  function currentAdminClientDetail() { return p104CurrentDetail(); }

  function removeLegacyHeatPumpBridge(
    root = document
  ) {
    root
      .querySelectorAll(
        [
          "#iqf-heat-pump-installed-modules-section",
          "#iqf-heat-pump-installed-module-card",
          "[data-iqf-heat-pump-card='true']",
          "[data-iqf-heat-pump-section='true']",
        ].join(",")
      )
      .forEach(
        (node) => node.remove()
      );
  }

  function moduleSectionAnchor(
    root
  ) {
    if (!root) return null;

    const installButton = [
      ...root.querySelectorAll(
        "button,a,[role='button']"
      ),
    ].find(
      (node) =>
        normalizeText(
          node.textContent
        ).includes(
          "otevrit instalacni"
        )
    );

    if (!installButton) {
      return null;
    }

    /*
     * Find the whole rounded "Konfigurace zařízení / Instalační proces"
     * card, not one of its internal grid columns.
     */
    let node = installButton;

    for (
      let depth = 0;
      depth < 10 && node;
      depth += 1
    ) {
      const text =
        normalizeText(
          node.textContent
        );

      if (
        text.includes(
          "konfigurace zarizeni"
        ) &&
        text.includes(
          "instalacni proces"
        ) &&
        text.includes(
          "otevrit instalacni"
        )
      ) {
        const rect =
          node.getBoundingClientRect();

        /*
         * The real configuration card spans most of the client detail.
         * Reject narrow internal button/title columns.
         */
        if (
          rect.width >
          Math.min(
            620,
            root.getBoundingClientRect().width * 0.62
          )
        ) {
          return node;
        }
      }

      node =
        node.parentElement;
    }

    return null;
  }

  function existingInstalledModulesSection(
    root
  ) {
    const label =
      leafContainingTextWithin(
        root,
        "instalovane moduly"
      );

    if (!label) {
      return null;
    }

    let node = label;

    for (
      let depth = 0;
      depth < 9 && node;
      depth += 1
    ) {
      const text =
        normalizeText(
          node.textContent
        );

      if (
        text.includes(
          "instalovane moduly"
        ) &&
        text.includes(
          "provozni prehled systemu"
        )
      ) {
        return node;
      }

      node =
        node.parentElement;
    }

    return null;
  }

  function standardModuleGrid(
    section
  ) {
    if (!section) return null;

    const projectGrid =
      section.querySelector(
        ".admin-operational-module-grid"
      );

    if (projectGrid) {
      return projectGrid;
    }

    const standardCards = [
      ...section.querySelectorAll(
        ".admin-operational-module-card"
      ),
    ];

    if (
      standardCards.length &&
      standardCards[0].parentElement
    ) {
      return standardCards[0]
        .parentElement;
    }

    const openButton = [
      ...section.querySelectorAll(
        "button,a,[role='button']"
      ),
    ].find(
      (node) =>
        normalizeText(
          node.textContent
        ).includes(
          "otevrit modul"
        )
    );

    if (!openButton) {
      return null;
    }

    let card = openButton;

    for (
      let depth = 0;
      depth < 8 && card;
      depth += 1
    ) {
      const text =
        normalizeText(
          card.textContent
        );

      if (
        text.includes(
          "otevrit modul"
        ) &&
        card.parentElement
      ) {
        const siblingButtons = [
          ...card.parentElement
            .querySelectorAll(
              "button,a,[role='button']"
            ),
        ];

        if (
          siblingButtons.includes(
            openButton
          )
        ) {
          break;
        }
      }

      card =
        card.parentElement;
    }

    return (
      card?.parentElement ||
      null
    );
  }

  function refreshModuleCount(
    section
  ) {
    if (!section) return;

    const count = section
      .querySelectorAll(
        [
          ".admin-operational-module-card",
          "[data-iqf-heat-pump-card='true']",
        ].join(",")
      )
      .length;

    if (!count) return;

    const countNode = [
      ...section.querySelectorAll(
        "div,span,p"
      ),
    ].find(
      (node) =>
        /^\s*\d+\s+aktivni(ch)?\s+modul/i.test(
          normalizeText(
            node.textContent
          )
        )
    );

    if (countNode) {
      countNode.textContent =
        count === 1
          ? "1 aktivní modul"
          : `${count} aktivní moduly`;
    }
  }

  function formatModuleUpdatedAt(
    value
  ) {
    if (!value) {
      return "";
    }

    const date = new Date(
      value
    );

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return "";
    }

    return date.toLocaleString(
      "cs-CZ"
    );
  }

  function buildHeatPumpModuleCard(
    state,
    userMode
  ) {
    const card = element(
      "article",
      "admin-operational-module-card"
    );

    card.dataset.iqfHeatPumpCard =
      "true";

    card.dataset.moduleKey =
      "heat_pump";

    card.dataset.moduleId =
      String(
        state?.module_id || ""
      );

    p104BindCard(card,state,userMode);

    const head = element(
      "div",
      "iqf-hp-standard-head"
    );

    const icon = element(
      "div",
      "iqf-hp-standard-icon",
      "TČ"
    );

    const copy = element("div");

    copy.append(
      element(
        "div",
        "iqf-hp-standard-type",
        "Vytápění"
      ),
      element(
        "div",
        "iqf-hp-standard-name",
        "Tepelné čerpadlo"
      ),
    );

    const status = element(
      "div",
      "iqf-hp-standard-state",
      "V provozu"
    );

    head.append(
      icon,
      copy,
      status
    );

    const values = element(
      "div",
      "iqf-hp-standard-values"
    );

    const typeValue = element(
      "div",
      "iqf-hp-standard-value"
    );

    typeValue.append(
      element(
        "div",
        "iqf-hp-standard-value-label",
        "Typ modulu"
      ),
      element(
        "div",
        "iqf-hp-standard-value-main",
        state?.generation_name ||
          state?.model ||
          "TNG"
      ),
    );

    const stateValue = element(
      "div",
      "iqf-hp-standard-value"
    );

    stateValue.append(
      element(
        "div",
        "iqf-hp-standard-value-label",
        "Stav modulu"
      ),
      element(
        "div",
        "iqf-hp-standard-value-main",
        "V provozu"
      ),
    );

    values.append(
      typeValue,
      stateValue
    );

    const footer = element(
      "div",
      "iqf-hp-standard-footer"
    );

    const updatedText =
      formatModuleUpdatedAt(
        state?.updated_at
      );

    footer.append(
      element(
        "div",
        "iqf-hp-standard-updated",
        updatedText
          ? `Aktualizováno ${updatedText}`
          : ""
      )
    );

    const open = element(
      "button",
      "iqf-hp-standard-open",
      "Otevřít modul →"
    );

    open.type = "button";

    // P104: exactly one delegated capture handler owns this button (moduleClick).

    footer.appendChild(open);

    card.append(
      head,
      values,
      footer
    );

    return card;
  }

  function buildInstalledModulesSection(
    state,
    userMode
  ) {
    const section = element(
      "section",
      "iqf-hp-jmm-operational-section"
    );

    section.dataset.iqfHeatPumpSection =
      "true";

    const header = element(
      "div",
      "iqf-hp-jmm-operational-header"
    );

    const title = element("div");

    title.append(
      element(
        "div",
        "iqf-hp-jmm-kicker",
        "Instalované moduly"
      ),
      element(
        "h2",
        "iqf-hp-jmm-title",
        "Provozní přehled systému"
      ),
      element(
        "div",
        "iqf-hp-jmm-subtitle",
        "Základní stav nainstalovaných a dokončených modulů zařízení."
      ),
    );

    const count = element(
      "div",
      "iqf-hp-jmm-count",
      "1 aktivní modul"
    );

    header.append(
      title,
      count
    );

    const grid = element(
      "div",
      "admin-operational-module-grid iqf-hp-jmm-grid"
    );

    grid.appendChild(
      buildHeatPumpModuleCard(
        state,
        userMode
      )
    );

    section.append(
      header,
      grid
    );

    return section;
  }

  function ensureHeatPumpModuleCard(
    state,
    userMode = "admin",
    detail = currentAdminClientDetail()
  ) {
    if (
      !state ||
      state.module_key !== "heat_pump" ||
      state.active !== true ||
      !detail ||
      !detail.root
    ) {
      return false;
    }

    /*
     * JMM scope guard:
     * the backend module and the currently opened client must be the same
     * concrete device/site context. Never reuse a module state globally.
     */
    if (
      String(
        state.serial_number || ""
      ).toUpperCase() !==
      String(
        detail.serial || ""
      ).toUpperCase()
    ) {
      return false;
    }

    const detailText =
      normalizeText(
        detail.root.textContent
      );

    if (
      detailText.includes(
        "vyber generaci tng"
      ) ||
      detailText.includes(
        "instalace tepelneho cerpadla"
      )
    ) {
      return false;
    }

    /*
     * JMM visual contract must be active already on the client detail.
     * Previously CSS was only mounted after opening the module workspace.
     */
    ensureStyle();
    if (p104CardAlreadyCurrent(detail.root,state,userMode)) return true;

    /*
     * Remove only obsolete bridge elements from this current client detail.
     */
    removeLegacyHeatPumpBridge(
      detail.root
    );

    const existing =
      existingInstalledModulesSection(
        detail.root
      );

    if (existing) {
      const grid =
        standardModuleGrid(
          existing
        );

      if (grid) {
        const existingHp =
          grid.querySelector(
            "[data-iqf-heat-pump-card='true']"
          );

        if (!existingHp) {
          grid.appendChild(
            buildHeatPumpModuleCard(
              state,
              userMode
            )
          );
        }

        refreshModuleCount(
          existing
        );

        return true;
      }
    }

    const anchor =
      moduleSectionAnchor(
        detail.root
      );

    if (
      !anchor ||
      !anchor.parentElement
    ) {
      return false;
    }

    const placementParent =
      anchor.parentElement;

    if (!placementParent) {
      return false;
    }

    placementParent.insertBefore(
      buildInstalledModulesSection(
        state,
        userMode
      ),
      anchor
    );

    return true;
  }

  function scheduleModuleCard(
    state,
    userMode = "admin"
  ) {
    moduleCardState = state;

    let attempts = 0;

    const tryMount = () => {
      moduleCardTimer = null;
      attempts += 1;

      const detail =
        currentAdminClientDetail();

      if (
        detail &&
        ensureHeatPumpModuleCard(
          state,
          userMode,
          detail
        )
      ) {
        return;
      }

      if (attempts < 28) {
        moduleCardTimer =
          setTimeout(
            tryMount,
            180
          );
      }
    };

    clearTimeout(
      moduleCardTimer
    );

    moduleCardTimer =
      setTimeout(
        tryMount,
        120
      );
  }

  function returnToClientCard(
    state
  ) {
    const back = findButtonByText(
      "zpět na kartu klienta"
    );

    if (back) {
      back.click();

      scheduleModuleCard(
        state,
        "admin"
      );

      return;
    }

    const close = [
      ...document.querySelectorAll(
        "button"
      ),
    ].find(
      (node) =>
        normalizeText(
          node.textContent
        ) === "×"
    );

    if (close) {
      close.click();

      scheduleModuleCard(
        state,
        "admin"
      );
    }
  }


  async function activateSelectedGeneration(detail) {
    const serial = String(
      detail?.deviceSerial || ""
    ).trim().toUpperCase();

    const generation = Number(
      detail?.generation
    );

    if (
      !/^F800711-TNG-\d{5}$/.test(serial) ||
      ![1, 2].includes(generation)
    ) {
      return;
    }

    /*
     * Fundamental FANDA architecture:
     * installer selection is only the gate. It must persist/activate the real
     * InstallationModule first; workspace opens only from the confirmed API
     * response. A localStorage selection alone is never a module.
     */
    selectorStatus(
      "Zakládám modul Tepelné čerpadlo…"
    );

    try {
      const state = await jsonFetch(
        `${API}/admin/heat-pump-module/by-serial/${encodeURIComponent(serial)}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            generation,
          }),
        }
      );

      if (
        state?.active !== true ||
        state?.module_key !== "heat_pump" ||
        state?.serial_number !== serial ||
        Number(state?.generation) !== generation
      ) {
        throw new Error(
          "MODULE_ACTIVATION_CONTRACT_MISMATCH"
        );
      }

      selectorStatus(
        `Vybráno: ${state.generation_name} · modul Tepelné čerpadlo založen`
      );

      /*
       * Standard FANDA architecture:
       * installer creates the module and exits. The operational workspace is
       * entered only later through the module card.
       */
      setTimeout(
        () => returnToClientCard(
          state
        ),
        450
      );
    } catch (error) {
      console.error(
        "[HP-MODULE] activation failed",
        error
      );

      selectorStatus(
        "Modul se nepodařilo založit."
      );

      toast(
        "Modul Tepelné čerpadlo se nepodařilo založit.",
        "error"
      );
    }
  }

  // P104: whole-page serial lookup removed; module card/context carries identity.

/* P101 START — authenticated CUSTOMER landing only; existing workspace reused. */
const P101_ID = "iqf-p101-customer-entry";
const P101_STYLE = "iqf-p101-customer-entry-style";
const p101 = {
  auth: "", route: "", epoch: 0, controller: null, busy: false,
  next: 0, choice: null, dismissed: false, entries: [], internalClose: false,
  accountTimer: null, hidden: new Map(), failure: null, stopped: false,
};

function p101IsPortalRoute() {
  return /^\/(portal|customer|client)(\/|$)/i.test(location.pathname);
}
function p101ContextKey() {
  return location.pathname + location.search; // A real navigation resets the local choice.
}
function p101Current(epoch, auth, route) {
  return !stopped && !p101.stopped && p101IsPortalRoute() &&
    p101.epoch === epoch && token() === auth && p101ContextKey() === route;
}
function p101Identity(s) {
  return s ? [s.device_uuid, s.site_id, s.module_id, s.generation].join(":") : "";
}
function p101RemovePanel() { document.getElementById(P101_ID)?.remove(); }
function p101RestoreBackground() {
  for (const [node, original] of p101.hidden) {
    if (!node.isConnected) continue;
    if (original.inert === null) node.removeAttribute("inert");
    else node.setAttribute("inert", original.inert);
    if (original.aria === null) node.removeAttribute("aria-hidden");
    else node.setAttribute("aria-hidden", original.aria);
  }
  p101.hidden.clear();
}
function p101LockBackground() {
  // Only while the existing customer TČ workspace is actually open.
  if (!p101IsPortalRoute() || activeMode !== "portal") return;
  for (const node of document.body.children) {
    if ([ROOT_ID, P101_ID, TOAST_ID].includes(node.id) ||
        ["SCRIPT", "STYLE", "LINK"].includes(node.tagName)) continue;
    if (!p101.hidden.has(node)) {
      p101.hidden.set(node, {inert: node.getAttribute("inert"), aria: node.getAttribute("aria-hidden")});
    }
    node.setAttribute("inert", ""); node.setAttribute("aria-hidden", "true");
  }
}
function p101CloseInternal() {
  p101.internalClose = true;
  try { if (activeMode === "portal") closeWorkspace(); }
  finally { p101.internalClose = false; p101RestoreBackground(); }
}
function p101OnWorkspaceClosed() {
  if (activeMode !== "portal") return;
  p101RestoreBackground();
  if (!p101.internalClose && p101IsPortalRoute() && token() === p101.auth) {
    p101.dismissed = true;
    p101ShowLauncher();
  }
}
function p101Style() {
  if (document.getElementById(P101_STYLE)) return;
  const node = document.createElement("style"); node.id = P101_STYLE;
  node.textContent = `
  #${P101_ID} {position:fixed;right:14px;top:52px;z-index:2147482500;box-sizing:border-box;
    max-width:calc(100vw - 28px);color:#edfbff;background:#072835;border:1px solid #27758a;
    border-radius:12px;padding:14px;font-family:inherit;box-shadow:0 14px 42px #0007;}
  #${P101_ID}[data-view="picker"] {left:50%;right:auto;top:15vh;transform:translateX(-50%);
    width:min(700px,calc(100vw - 28px));max-height:70vh;overflow:auto;padding:22px;}
  #${P101_ID} h2 {font-size:22px;margin:0 0 12px;color:#55d6fc;}
  #${P101_ID} p {font-size:14px;line-height:1.5;margin:0 0 12px;}
  #${P101_ID} button, #${ROOT_ID} .p101-logout {border:1px solid #3487a0;border-radius:8px;
    background:#104051;color:#f1fcff;padding:10px 14px;font:inherit;font-size:13px;cursor:pointer;}
  #${P101_ID} button:focus-visible, #${ROOT_ID} .p101-logout:focus-visible {outline:2px solid #72e9ff;outline-offset:2px;}
  #${P101_ID} .p101-device {display:block;width:100%;text-align:left;margin:10px 0;}
  #${P101_ID} .p101-back {margin-top:8px;background:transparent;}
  #${ROOT_ID}[data-p101-customer="true"] .iqf-hp-back {right:126px;}
  #${ROOT_ID} .p101-logout {position:fixed;top:8px;right:14px;z-index:9;}
  @media(max-width:600px) {#${ROOT_ID}[data-p101-customer="true"] .iqf-hp-top-meta {display:none;}}
  `;
  document.head.appendChild(node);
}
function p101Panel(view) {
  p101RemovePanel(); p101Style();
  const node = document.createElement("aside"); node.id = P101_ID; node.dataset.view = view;
  node.setAttribute("role", view === "error" ? "alert" : "region");
  node.setAttribute("aria-label", "Modul tepelného čerpadla");
  document.body.appendChild(node); return node;
}
function p101Button(text, onClick, cls = "") {
  const button = document.createElement("button"); button.type = "button";
  button.textContent = text; button.className = cls; button.addEventListener("click", onClick);
  return button;
}
function p101ShowLauncher() {
  if (!p101.entries.length || !p101IsPortalRoute() || !token()) return;
  const panel = p101Panel("launcher");
  panel.appendChild(p101Button("Otevřít modul Tepelné čerpadlo →", () => {
    p101.dismissed = false; p101.failure = null; p101.next = 0;
    p101RemovePanel(); void autoOpen();
  }));
}
function p101ShowError(status) {
  p101.failure = status;
  const panel = p101Panel("error");
  const text = document.createElement("p");
  text.textContent = "Přiřazený modul se nepodařilo ověřit. " +
    (Number.isInteger(status) ? `HTTP ${status}. ` : "") +
    "Přístup do jiného zařízení se nezkouší.";
  panel.append(text, p101Button("Zkusit znovu", () => {
    p101.next = 0; p101.failure = null; p101RemovePanel(); void autoOpen();
  }));
}
function p101ShowPicker() {
  if (p101.failure || p101.dismissed) return;
  const existing = document.getElementById(P101_ID);
  const signature = p101.entries.map(x => p101Identity(x.state)).join("|");
  if (existing?.dataset.signature === signature && existing.dataset.view === "picker") return;
  const panel = p101Panel("picker"); panel.dataset.signature = signature;
  const heading = document.createElement("h2"); heading.textContent = "Vyberte tepelné čerpadlo";
  const text = document.createElement("p");
  text.textContent = "Účet má přístup k více zařízením. Vyberte konkrétní modul; systém za vás žádné zařízení nevybere.";
  panel.append(heading, text);
  for (const entry of p101.entries) {
    panel.appendChild(p101Button(
      `${entry.device.site_name || entry.device.name || "Zařízení"} · ${entry.state.generation_name || entry.state.model} · ${entry.device.serial_number}`,
      () => {p101.choice = entry.device.device_uuid; p101.next = 0; p101RemovePanel(); void autoOpen();},
      "p101-device"));
  }
  panel.appendChild(p101Button("← Přehled zařízení", () => {
    p101.dismissed = true; p101RemovePanel(); p101ShowLauncher();
  }, "p101-back"));
}
function p101OnWorkspaceOpened(state, userMode) {
  if (userMode !== "portal" || !p101IsPortalRoute()) return;
  p101RemovePanel(); p101Style();
  const root = document.getElementById(ROOT_ID); if (!root) return;
  root.dataset.p101Customer = "true";
  const back = root.querySelector(".iqf-hp-back");
  if (back) back.textContent = "← Přehled zařízení";
  // Invoke the already existing application's own logout handler; do not invent a logout API.
  const originalLogout = [...document.querySelectorAll("button,a,[role='button']")].filter(node =>
    !root.contains(node) && !node.closest(`#${P101_ID}`) && /^odhlasit\s*$/.test(normalizeText(node.textContent)));
  const logout = p101Button("Odhlásit", () => {
    p101.dismissed = true; p101.entries = []; p101.choice = null;
    p101.controller?.abort(); p101.epoch++; p101.busy = false;
    p101CloseInternal(); p101RemovePanel();
    if (originalLogout.length === 1 && originalLogout[0].isConnected) originalLogout[0].click();
    // With ambiguous original controls, return to the native portal rather than clearing credentials incorrectly.
  }, "p101-logout");
  root.appendChild(logout); p101LockBackground();
}
function p101Reset() {
  p101.controller?.abort(); p101.controller = null;
  p101.epoch++; p101.busy = false; p101.next = 0;
  p101.entries = []; p101.choice = null; p101.dismissed = false; p101.failure = null;
  p101CloseInternal(); p101RemovePanel();
}
async function p101Get(path, auth, signal) {
  // All automatic entry requests are read-only portal requests. No admin fallback.
  if (!path.startsWith("/portal/")) throw new Error("P101_PORTAL_PATH_REQUIRED");
  const response = await fetch(API + path, {
    method: "GET", headers: {Authorization: "Bearer " + auth, Accept: "application/json"},
    credentials: "omit", redirect: "error", cache: "no-store", signal,
  });
  if (!response.ok) {const error = new Error("P101_HTTP"); error.status = response.status; throw error;}
  return response.json();
}
function p101Devices(data) {
  if (!Array.isArray(data)) throw new Error("P101_DEVICES_CONTRACT");
  const uuids = new Set(), serials = new Set();
  for (const item of data) {
    if (!item || !/^[a-f0-9]{8}-[a-f0-9-]{27}$/i.test(item.device_uuid || "") ||
        !/^F800711-TNG-\d{5}$/.test(item.serial_number || "") || typeof item.site_id !== "string" ||
        uuids.has(item.device_uuid) || serials.has(item.serial_number)) {
      throw new Error("P101_AMBIGUOUS_DEVICE_CONTRACT");
    }
    uuids.add(item.device_uuid); serials.add(item.serial_number);
  }
  return data;
}
function p101ValidateModule(state, device) {
  if (!state || state.serial_number !== device.serial_number ||
      state.device_uuid !== device.device_uuid || state.site_id !== device.site_id ||
      typeof state.module_id !== "string" || !state.module_id) {
    throw new Error("P101_DEVICE_MODULE_IDENTITY_MISMATCH");
  }
  return state.active === true && state.module_key === "heat_pump" && state.module_type === "heat_pump" &&
    [1, 2].includes(state.generation) && ["configured", "verified"].includes(state.status) &&
    state.client_visibility === true;
}
async function autoOpen() {
  if (stopped || p101.stopped || !p101IsPortalRoute()) return;
  const auth = token(), route = p101ContextKey();
  if (!auth) return;
  if (auth !== p101.auth || route !== p101.route) {
    p101Reset(); p101.auth = auth; p101.route = route;
  }
  if (p101.busy || Date.now() < p101.next) return;
  p101.busy = true;
  const epoch = p101.epoch;
  const controller = new AbortController(); p101.controller = controller;
  const timeout = setTimeout(() => controller.abort(), 18000);
  const isCurrent = () => p101Current(epoch, auth, route);
  try {
    const devices = p101Devices(await p101Get("/portal/devices", auth, controller.signal));
    if (!isCurrent()) return;
    const results = new Array(devices.length);
    let cursor = 0;
    // Bound concurrency on accounts with several permitted devices.
    const workers = Array.from({length: Math.min(3, devices.length)}, async () => {
      while (cursor < devices.length) {
        const index = cursor++; const device = devices[index];
        let state;
        try {state = await p101Get("/portal/heat-pump-module/by-serial/" + encodeURIComponent(device.serial_number), auth, controller.signal);}
        catch (error) {if (error.status === 404) {results[index] = null; continue;} throw error;}
        if (!isCurrent()) return;
        results[index] = p101ValidateModule(state, device) ? {device, state} : null;
      }
    });
    await Promise.all(workers);
    if (!isCurrent()) return;
    p101.entries = results.filter(Boolean); p101.failure = null; p101.next = Date.now() + 30000;
    if (!p101.entries.length) {
      p101CloseInternal(); p101RemovePanel(); p101.choice = null;
      return; // PV / individual clients without their own eligible heat_pump are unchanged.
    }
    const selected = devices.length === 1 ? p101.entries[0] :
      p101.entries.find(entry => entry.device.device_uuid === p101.choice);
    if (p101.dismissed) {
      if (document.getElementById(P101_ID)?.dataset.view !== "launcher") p101ShowLauncher();
      return;
    }
    if (!selected) {p101CloseInternal(); p101ShowPicker(); return;}
    p101.choice = selected.device.device_uuid;
    if (activeMode === "portal" && p101Identity(activeState) === p101Identity(selected.state) && document.getElementById(ROOT_ID)) {
      p101RemovePanel(); return; // Preserve the currently selected tab and controls.
    }
    p101CloseInternal(); p101RemovePanel();
    // The SAME existing workspace and generation-specific render branch as in admin.
    openWorkspace(selected.state, "portal");
  } catch (error) {
    controller.abort();
    if (!isCurrent()) return;
    p101.next = Date.now() + 10000;
    if (error.status === 401 || error.status === 403) {
      p101CloseInternal(); p101.entries = []; p101.choice = null;
    }
    p101ShowError(error.status || null);
  } finally {
    clearTimeout(timeout);
    if (p101.epoch === epoch) {p101.busy = false; p101.controller = null;}
  }
}
function p101Tick() {
  if (stopped || p101.stopped) return;
  const isPortal = p101IsPortalRoute(), auth = isPortal ? token() : "", route = isPortal ? p101ContextKey() : "";
  if (auth !== p101.auth || route !== p101.route) {
    p101Reset(); p101.auth = auth; p101.route = route;
  }
  if (isPortal && auth) void autoOpen();
}
function p101Dispose() {
  p101.stopped = true; clearInterval(p101.accountTimer);
  window.removeEventListener("storage", p101Tick);
  window.removeEventListener("pageshow", p101Tick);
  p101Reset(); document.getElementById(P101_STYLE)?.remove();
}
function p101Start() {
  if (p101.accountTimer !== null) return;
  window.addEventListener("storage", p101Tick);
  window.addEventListener("pageshow", p101Tick);
  p101.accountTimer = setInterval(p101Tick, 500);
  p101Tick();
}
/* P101 END */

/* P104 ADMIN IDENTITY START — one clicked card, one validated module, no global serial. */
function p104Serial(value) {
  const s = String(value ?? '').trim().toUpperCase();
  return /^F800711-TNG-\d{5}$/.test(s) ? s : null;
}
function p104Uuid(value) {
  const s = String(value ?? '').trim().toLowerCase();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(s) ? s : null;
}
function p104Identity(state) {
  if (!state || state.active !== true || state.module_key !== 'heat_pump' ||
      state.module_type !== 'heat_pump' || ![1, 2].includes(state.generation) ||
      !['configured', 'verified'].includes(state.status)) return null;
  const id = {serial: p104Serial(state.serial_number), device: p104Uuid(state.device_uuid),
    site: p104Uuid(state.site_id), module: p104Uuid(state.module_id), generation: state.generation};
  return Object.values(id).every(v => v !== null) ? Object.freeze(id) : null;
}
function p104Same(a, b) {
  return Boolean(a && b && ['serial','device','site','module','generation'].every(k => a[k] === b[k]));
}
function p104Route() { return location.pathname + location.search; }
function p104Visible(node) {
  if (!(node instanceof Element) || !node.isConnected || node.closest('[hidden],[inert],[aria-hidden="true"]')) return false;
  for (let n = node; n && n !== document.documentElement; n = n.parentElement) {
    const css = getComputedStyle(n);
    if (css.display === 'none' || css.visibility === 'hidden' || css.visibility === 'collapse') return false;
  }
  const r = node.getBoundingClientRect();
  return r.width > 0 && r.height > 0;
}
function p104DetailFrom(start) {
  // Only ancestors of the actual click/installation button; never document.body.
  if (!p104Visible(start)) return null;
  for (let node = start; node && node !== document.body && node !== document.documentElement; node = node.parentElement) {
    if (!p104Visible(node)) return null;
    const text = String(node.innerText || ''), normal = normalizeText(text);
    const serials = [...new Set((text.match(/F800711-TNG-\d{5}/gi) || []).map(p104Serial))];
    if (serials.length === 1 && (normal.includes('detail zarizeni') ||
        (normal.includes('konfigurace zarizeni') && normal.includes('instalacni proces')))) {
      return {root: node, serial: serials[0]};
    }
    // A dialog is an explicit context boundary, even when its contents are incomplete.
    if (node.matches('[role="dialog"],dialog')) return null;
  }
  return null;
}
function p104CurrentDetail() {
  if (p101IsPortalRoute() || mode() !== 'admin') return null;
  const found = [];
  for (const b of document.querySelectorAll('button,a,[role="button"]')) {
    if (!normalizeText(b.textContent).includes('otevrit instalacni') || !p104Visible(b)) continue;
    const c = p104DetailFrom(b);
    if (c && !found.some(x => x.root === c.root)) found.push(c);
  }
  // Nested aliases of the same detail are reduced, different visible clients are not guessed.
  const details = found.filter(a => !found.some(b => a !== b && a.serial === b.serial && a.root.contains(b.root)));
  return details.length === 1 ? details[0] : null;
}
function p104ContextCurrent(context, auth, route) {
  if (stopped || !auth || token() !== auth || route !== p104Route() || p101IsPortalRoute() || mode() !== 'admin') return false;
  if (!context || !p104Visible(context.root)) return false;
  const live = p104CurrentDetail();
  return Boolean(live && live.root === context.root && live.serial === context.serial);
}
function p104Message(card, text) {
  if (!card?.isConnected) return;
  let panel = card.querySelector('[data-p104-error]');
  if (!panel) {
    panel = document.createElement('p'); panel.dataset.p104Error = 'true'; panel.setAttribute('role','alert');
    panel.style.cssText = 'grid-column:1/-1;margin:10px 0 0;color:#ffcfad;font:inherit;font-size:13px;line-height:1.5';
    (card.querySelector('.iqf-hp-standard-footer') || card).appendChild(panel);
  }
  panel.textContent = text;
}
function p104BindCard(card, state, userMode) {
  const identity = p104Identity(state);
  p104.cards.set(card, {identity, mode:userMode, auth:token()});
  if (!identity) return;
  // Display/diagnostic metadata only; WeakMap and authenticated API are authoritative.
  card.dataset.p104Serial = identity.serial;
  card.dataset.p104DeviceUuid = identity.device;
  card.dataset.p104SiteId = identity.site;
  card.dataset.p104ModuleId = identity.module;
  if (String(identity.module || "") === "5a028e34-335f-4cae-803e-d6bce775d4f2") {
    card.dataset.f33R7IndividualClone = "true";
    card.style.display = "none";
    return;
  }
  card.dataset.p104Generation = String(identity.generation);
}
function p104CardAlreadyCurrent(root, state, userMode) {
  const expected = p104Identity(state);
  for (const card of root.querySelectorAll('[data-iqf-heat-pump-card="true"]')) {
    const bound = p104.cards.get(card);
    if (bound && bound.auth === token() && bound.mode === userMode && p104Same(expected, bound.identity)) return true;
  }
  return false;
}
function p104CancelOpen() {
  const req = p104.pending; p104.pending = null; p104.epoch += 1;
  if (!req) return;
  req.controller.abort(); clearTimeout(req.timeout);
  if (req.button.isConnected) {req.button.disabled = false; req.button.textContent = req.label;}
}
async function p104ReadModule(serial, auth, controller) {
  const r = await fetch(`${API}/admin/heat-pump-module/by-serial/${encodeURIComponent(serial)}`, {
    method:'GET', headers:{Authorization:'Bearer '+auth,Accept:'application/json'}, cache:'no-store',
    credentials:'omit', redirect:'error', signal:controller.signal,
  });
  if (!r.ok) {const e = new Error('MODULE_HTTP'); e.status = r.status; throw e;}
  return r.json();
}
function p104PendingCurrent(req) {
  return p104.pending === req && p104ContextCurrent(req.context, req.auth, req.route) &&
    req.card.isConnected && req.context.root.contains(req.card) && p104Visible(req.card) &&
    p104.cards.get(req.card) === req.binding;
}
async function p104OpenCard(card, button) {
  const binding = p104.cards.get(card), context = p104DetailFrom(button), selected = p104CurrentDetail();
  if (!binding || binding.mode !== 'admin' || !binding.identity || !context || !selected ||
      selected.root !== context.root || context.serial !== binding.identity.serial || binding.auth !== token() ||
      !p104ContextCurrent(context, binding.auth, p104Route())) {
    p104Message(card, 'Modul nebyl otevřen: nesouhlasí identita karty a právě otevřeného zařízení. Zavřete detail a otevřete jej znovu.');
    return;
  }
  if (p104.pending?.card === card) return; // one request per repeated/double click
  p104CancelOpen();
  const req = {card,button,binding,context,auth:binding.auth,route:p104Route(),controller:new AbortController(),
    label:button.textContent,timeout:null,epoch:p104.epoch};
  p104.pending = req; button.disabled = true; button.textContent = 'Ověřuji modul…';
  card.querySelector('[data-p104-error]')?.remove();
  req.timeout = setTimeout(()=>req.controller.abort(),12000);
  try {
    const state = await p104ReadModule(context.serial,req.auth,req.controller);
    if (!p104PendingCurrent(req)) return;
    if (!p104Same(binding.identity,p104Identity(state))) throw new Error('IDENTITY_MISMATCH');
    // The renderer receives the authenticated state of this card; no secondary lookup.
    p104.pending = null;
    openWorkspace(state,'admin');
  } catch (e) {
    if (!p104PendingCurrent(req)) return;
    const detail = e.message === 'IDENTITY_MISMATCH' ? 'Odpověď serveru neodpovídá zařízení, lokalitě, modulu nebo generaci této karty.' :
      e.name === 'AbortError' ? 'Ověření modulu překročilo časový limit.' :
      Number.isInteger(e.status) ? `Modul se nepodařilo načíst (HTTP ${e.status}).` : 'Modul se nepodařilo ověřit.';
    p104Message(card, detail + ' Jiné zařízení se neotevře.');
  } finally {
    clearTimeout(req.timeout);
    if (p104.pending === req) p104.pending = null;
    if (button.isConnected) {button.disabled = false; button.textContent = req.label;}
  }
}
function p104BeforeWorkspaceOpen(state, userMode) {
  if (userMode !== 'admin') return true; // P101 retains its own customer permission/identity guards.
  const identity = p104Identity(state), context = p104CurrentDetail(), auth = token();
  if (!identity || !context || context.serial !== identity.serial || !p104ContextCurrent(context,auth,p104Route())) {
    toast('Modul nebyl otevřen: neodpovídá právě vybranému zařízení.','error',6500); return false;
  }
  p104.active = {context,identity,auth,route:p104Route()};
  return true;
}
function p104OnWorkspaceClose() { p104CancelOpen(); p104.active = null; }
function p104CheckLifetime() {
  if (p104.pending && !p104PendingCurrent(p104.pending)) p104CancelOpen();
  if (p104.sync && !p104ContextCurrent(p104.sync.context,p104.sync.auth,p104.sync.route)) {
    p104.sync.controller.abort(); p104.sync = null; moduleCardSyncBusy = false; moduleCardLastSync = 0;
  }
  const active = p104.active;
  if (active && activeMode === 'admin' && !p104ContextCurrent(active.context,active.auth,active.route)) {
    p104.active = null; closeWorkspace();
  }
}
function p104Dispose() {
  p104CancelOpen(); p104.sync?.controller.abort(); p104.sync = null; p104.active = null;
  clearInterval(p104.timer); p104.cards = new WeakMap();
}
function moduleClick(event) {
  if (p101IsPortalRoute() || mode() !== 'admin' || document.getElementById(ROOT_ID)) return;
  const button = event.target?.closest?.('button.iqf-hp-standard-open');
  const card = button?.closest('[data-iqf-heat-pump-card="true"]');
  if (!button || !card) return; // unrelated modules and installer buttons keep their own handlers
  event.preventDefault(); event.stopImmediatePropagation();
  void p104OpenCard(card,button);
}
async function syncHeatPumpModuleCard() {
  if (stopped || p101IsPortalRoute() || mode() !== 'admin' || document.getElementById(ROOT_ID) || moduleCardSyncBusy) return;
  if (Date.now() - moduleCardLastSync < 700) return;
  const context = p104CurrentDetail(), auth = token(), route = p104Route();
  if (!context || !auth || normalizeText(context.root.innerText).includes('vyber generaci tng')) return;
  moduleCardLastSync = Date.now(); moduleCardSyncBusy = true;
  const req = {context,auth,route,controller:new AbortController()}; p104.sync = req;
  const timeout = setTimeout(()=>req.controller.abort(),12000);
  try {
    const state = await p104ReadModule(context.serial,auth,req.controller);
    if (p104.sync !== req || !p104ContextCurrent(context,auth,route)) return;
    const identity = p104Identity(state);
    if (!identity || identity.serial !== context.serial) {removeLegacyHeatPumpBridge(context.root); return;}
    moduleCardState = state;
    ensureHeatPumpModuleCard(state,'admin',context);
  } catch (e) {
    if (p104.sync === req && p104ContextCurrent(context,auth,route) && e.status === 404) removeLegacyHeatPumpBridge(context.root);
  } finally {
    clearTimeout(timeout);
    if (p104.sync === req) {p104.sync = null; moduleCardSyncBusy = false;}
  }
}
/* P104 ADMIN IDENTITY END */


  moduleCardObserver =
    new MutationObserver(
      () => {
        p104CheckLifetime();
        if (
          moduleCardTimer
        ) {
          return;
        }

        moduleCardTimer = setTimeout(
          () => {
            moduleCardTimer = null;
            syncHeatPumpModuleCard();
          },
          180
        );
      }
    );

  moduleCardObserver.observe(
    document.documentElement,
    {
      childList: true,
      subtree: true,
    }
  );

  setTimeout(
    syncHeatPumpModuleCard,
    250
  );

  setTimeout(
    syncHeatPumpModuleCard,
    900
  );

  window.addEventListener(
    "iqfanda:heatpump-generation-selected",
    (event) => {
      activateSelectedGeneration(
        event.detail
      );
    }
  );

  document.addEventListener(
    "click",
    moduleClick,
    true
  );
  p104.timer = setInterval(p104CheckLifetime,400);

  window.addEventListener("pageshow", () => {
    // Module-first: no automatic workspace opening.
  });

  window.addEventListener("popstate", () => {
    closeWorkspace();
  });

  window.addEventListener("hashchange", () => {
    closeWorkspace();
  });

  const facade = Object.freeze({
    portalEntry: Object.freeze({
      version: "P101",
      refresh: () => { p101.next = 0; p101Tick(); },
      diagnostics: () => ({route: p101IsPortalRoute() ? "portal" : "other", busy: p101.busy,
        moduleCount: p101.entries.length, dismissed: p101.dismissed, failure: p101.failure}),
    }),
    version: VERSION,
    adminEntry: Object.freeze({version:"P104", diagnostics:()=>({pending:!!p104.pending, serial:p104.active?.identity.serial || null})}),
    open: openWorkspace,
    close: closeWorkspace,
    tab: showTab,
    diagnostics: () => ({
      version: VERSION,
      active: Boolean(
        document.getElementById(ROOT_ID)
      ),
      mode: activeMode,
      tab: currentTab,
      serial: activeState?.serial_number || null,
      generation:
        activeState?.generation_name || null,
      template:
        "universal-individual-admin-client-clone",
    }),
    dispose: () => {
      p104Dispose();
      p101Dispose();
      stopped = true;
      clearTimeout(moduleCardTimer);
      moduleCardObserver?.disconnect();
      closeWorkspace();
      document
        .getElementById(
          "iqf-heat-pump-installed-modules-section"
        )
        ?.remove();
      document
        .getElementById(
          "iqf-heat-pump-installed-module-card"
        )
        ?.remove();
      document.getElementById(STYLE_ID)?.remove();
      document.getElementById(TOAST_ID)?.remove();
    },
  });

  window.IQF_HEATPUMP_MODULE_WORKSPACE_R4R3 = facade;
  window.IQF_HEATPUMP_MODULE_WORKSPACE = facade;

  // P101: customer portal bootstrap; admin module-first flow is left unchanged.
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", p101Start, {once: true});
  } else {
    p101Start();
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      () => {},
      { once: true }
    );
  }
})();
