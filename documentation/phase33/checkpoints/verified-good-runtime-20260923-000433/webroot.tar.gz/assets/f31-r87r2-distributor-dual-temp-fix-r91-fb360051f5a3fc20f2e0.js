(() => {
  "use strict";

  const MARK = "__IQF_F31_R87R2_DISTRIBUTOR_DUAL_TEMP_FIX__";
  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  const runtime = window.IQF_SEB01_RUNTIME;
  const EXPECTED_RUNTIME =
    "F30.4C-R5-PERSISTED-READER";
  const DEVICE_UUID =
    "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc";

  const SLOTS = Object.freeze({
    supply: {
      id:
        "heating-distributor-temperature",

      label:
        "P\u0158\u00cdVOD",

      title:
        "Rozd\u011blova\u010d \u00daT / P\u0159\u00edvod"
    },

    return: {
      id:
        "heating-distributor-return-temperature",

      label:
        "ZP\u00c1TE\u010cKA",

      title:
        "Rozd\u011blova\u010d \u00daT / Zp\u00e1te\u010dka"
    }
  });

  if (window[MARK]) return;
  window[MARK] = true;

  let registered = false;
  let current = null;

  function root() {
    return (
      Array.from(
        document.querySelectorAll(
          ROOT_SELECTOR
        )
      ).find(
        (el) =>
          el.isConnected &&
          el.getClientRects().length
      ) ||
      null
    );
  }

  function scopeMatches() {
    return !!(
      runtime &&
      runtime.diagnostics &&
      runtime.diagnostics().deviceUuid ===
        DEVICE_UUID
    );
  }

  function setText(
    node,
    value
  ) {
    if (
      node &&
      node.textContent !== value
    ) {
      node.textContent =
        value;
    }
  }

  function setAttr(
    node,
    key,
    value
  ) {
    if (
      node &&
      node.getAttribute(key) !==
        String(value)
    ) {
      node.setAttribute(
        key,
        String(value)
      );
    }
  }

  function installStyle() {
    const id =
      "f31-r87r2-distributor-style";

    if (
      document.getElementById(id)
    ) {
      return;
    }

    const style =
      document.createElement(
        "style"
      );

    style.id =
      id;

    style.textContent = `
      ${ROOT_SELECTOR}
      .f29-00012-distributor[data-f31-r87r2-distributor="1"] {
        transform:
          translateY(-30px)
          !important;

        border-bottom-color:
          transparent
          !important;

        border-bottom-left-radius:
          0
          !important;

        border-bottom-right-radius:
          0
          !important;

        overflow:
          visible
          !important;
      }

      ${ROOT_SELECTOR}
      .f29-00012-distributor >
      [data-f31-r86-footer="temperature"],

      ${ROOT_SELECTOR}
      .f29-00012-distributor >
      [data-f31-r87-footer="dual-temperature"] {
        display:
          none
          !important;
      }

      ${ROOT_SELECTOR}
      .f29-00012-distributor >
      .f31-r87r2-footer {
        position:
          absolute
          !important;

        top:
          calc(100% - 1px)
          !important;

        left:
          -1px
          !important;

        right:
          -1px
          !important;

        height:
          62px
          !important;

        box-sizing:
          border-box
          !important;

        margin:
          0
          !important;

        padding:
          4px 12px 8px 14px
          !important;

        display:
          grid
          !important;

        grid-template-columns:
          1fr
          !important;

        grid-template-rows:
          repeat(
            2,
            minmax(
              22px,
              1fr
            )
          )
          !important;

        gap:
          5px
          !important;

        border:
          1px solid
          rgba(
            72,
            216,
            255,
            .84
          )
          !important;

        border-top:
          0
          !important;

        border-radius:
          0 0 16px 16px
          !important;

        background:
          linear-gradient(
            145deg,
            rgba(
              5,
              34,
              47,
              .98
            ),
            rgba(
              2,
              20,
              30,
              .98
            )
          )
          !important;

        color:
          #dff8ff
          !important;

        pointer-events:
          none
          !important;

        z-index:
          5
          !important;
      }

      ${ROOT_SELECTOR}
      .f31-r87r2-row {
        min-width:
          0
          !important;

        display:
          flex
          !important;

        align-items:
          center
          !important;

        justify-content:
          space-between
          !important;

        gap:
          8px
          !important;

        pointer-events:
          none
          !important;
      }

      ${ROOT_SELECTOR}
      .f31-r87r2-label {
        font-size:
          10px
          !important;

        font-weight:
          900
          !important;

        letter-spacing:
          .04em
          !important;

        line-height:
          1
          !important;

        white-space:
          nowrap
          !important;

        color:
          #41cfff
          !important;

        pointer-events:
          none
          !important;
      }

      ${ROOT_SELECTOR}
      .f31-r87r2-value {
        display:
          inline-flex
          !important;

        align-items:
          center
          !important;

        justify-content:
          center
          !important;

        min-width:
          96px
          !important;

        max-width:
          145px
          !important;

        height:
          22px
          !important;

        box-sizing:
          border-box
          !important;

        padding:
          0 7px
          !important;

        margin:
          0
          !important;

        font-size:
          11px
          !important;

        font-family:
          inherit
          !important;

        font-weight:
          900
          !important;

        line-height:
          1
          !important;

        white-space:
          nowrap
          !important;

        border-radius:
          6px
          !important;

        color:
          #dff8ff
          !important;

        text-transform:
          none
          !important;

        letter-spacing:
          0
          !important;
      }

      ${ROOT_SELECTOR}
      button.f31-r87r2-value {
        border:
          1px solid
          rgba(
            72,
            215,
            255,
            .66
          )
          !important;

        background:
          #001620
          !important;

        pointer-events:
          auto
          !important;

        cursor:
          pointer
          !important;
      }

      ${ROOT_SELECTOR}
      button.f31-r87r2-value:hover {
        background:
          #003d56
          !important;
      }

      ${ROOT_SELECTOR}
      button.f31-r87r2-value:focus-visible {
        outline:
          2px solid
          #41cfff
          !important;

        outline-offset:
          2px
          !important;
      }

      ${ROOT_SELECTOR}
      span.f31-r87r2-value {
        border:
          0
          !important;

        background:
          transparent
          !important;

        pointer-events:
          none
          !important;
      }

      ${ROOT_SELECTOR}
      .f31-r87r2-value[data-state="unavailable"] {
        color:
          #91a9b4
          !important;
      }

      ${ROOT_SELECTOR}
      [data-f31-r85-protect="aku-pump"] {
        --f31-r85-offset-x:
          -35px
          !important;
      }
    `;

    document.head.appendChild(
      style
    );
  }

  function ensure() {
    const hostRoot =
      root();

    const card =
      hostRoot &&
      hostRoot.querySelector(
        ".f29-00012-distributor"
      );

    if (!card) {
      current = null;
      return null;
    }

    if (
      current &&
      current.card === card &&
      current.footer &&
      current.footer.isConnected &&
      current.rows.supply.box.isConnected &&
      current.rows.return.box.isConnected
    ) {
      return current;
    }

    installStyle();

    let footer =
      card.querySelector(
        ':scope > [data-f31-r87r2-footer="dual-temperature"]'
      );

    let rows = {};

    if (!footer) {
      footer =
        document.createElement(
          "div"
        );

      footer.className =
        "f31-r87r2-footer";

      setAttr(
        footer,
        "data-f31-r87r2-footer",
        "dual-temperature"
      );

      for (
        const key
        of [
          "supply",
          "return"
        ]
      ) {
        const row =
          document.createElement(
            "div"
          );

        row.className =
          "f31-r87r2-row";

        setAttr(
          row,
          "data-f31-r87r2-row",
          key
        );

        const label =
          document.createElement(
            "span"
          );

        label.className =
          "f31-r87r2-label";

        label.textContent =
          SLOTS[key].label;

        const box =
          document.createElement(
            "span"
          );

        box.className =
          "f31-r87r2-value";

        box.textContent =
          "\u2014 \u00b0C";

        setAttr(
          box,
          "data-state",
          "unknown"
        );

        setAttr(
          box,
          "data-seb01-slot",
          SLOTS[key].id
        );

        row.append(
          label,
          box
        );

        footer.appendChild(
          row
        );

        rows[key] = {
          row,
          label,
          box
        };
      }

      card.appendChild(
        footer
      );
    } else {
      for (
        const key
        of [
          "supply",
          "return"
        ]
      ) {
        const row =
          footer.querySelector(
            `[data-f31-r87r2-row="${key}"]`
          );

        rows[key] = {
          row,

          label:
            row &&
            row.querySelector(
              ".f31-r87r2-label"
            ),

          box:
            row &&
            row.querySelector(
              ".f31-r87r2-value"
            )
        };
      }
    }

    if (
      !rows.supply.box ||
      !rows.return.box
    ) {
      return null;
    }

    setAttr(
      card,
      "data-f31-r87r2-distributor",
      "1"
    );

    current = {
      root:
        hostRoot,

      card,
      footer,
      rows
    };

    return current;
  }

  function display(entry) {
    const e =
      entry || {};

    const status =
      String(
        e.status || ""
      )
        .trim()
        .toLowerCase();

    if (
      e.available === false ||
      [
        "unavailable",
        "offline"
      ].includes(status)
    ) {
      return {
        text:
          "Nedostupn\u00e9",

        state:
          "unavailable"
      };
    }

    if (
      e.has_value !== true ||
      [
        "unknown",
        "unbound",
        "snapshot_only",
        "api_stale",
        "no_context",
        "loading"
      ].includes(status) ||
      /^(http_|request_|wrong_device|context_)/
        .test(status)
    ) {
      return {
        text:
          "\u2014 \u00b0C",

        state:
          "unknown"
      };
    }

    const raw =
      e.value;

    const number =
      typeof raw ===
        "number"
        ? raw
        : Number(
            String(raw)
              .trim()
              .replace(
                ",",
                "."
              )
          );

    if (
      !Number.isFinite(
        number
      )
    ) {
      return {
        text:
          "\u2014 \u00b0C",

        state:
          "unknown"
      };
    }

    return {
      text:
        number.toLocaleString(
          "cs-CZ",
          {
            minimumFractionDigits:
              1,

            maximumFractionDigits:
              1
          }
        ) +
        " \u00b0C",

      state:
        "value"
    };
  }

  function forceZigbee(
    slotId
  ) {
    queueMicrotask(
      () => {
        const dialog =
          document.querySelector(
            'dialog[data-seb01-source-dialog="' +
            slotId +
            '"]'
          );

        if (!dialog) return;

        const network =
          dialog.querySelector(
            '[data-seb01-network-filter="true"]'
          );

        if (!network) return;

        network.value =
          "zigbee";

        network.dispatchEvent(
          new Event(
            "change",
            {
              bubbles:
                true
            }
          )
        );

        network.disabled =
          true;
      }
    );
  }

  function bindPicker(
    key,
    box
  ) {
    box.type =
      "button";

    box.addEventListener(
      "click",
      (event) => {
        event.preventDefault();
        event.stopPropagation();

        if (
          !scopeMatches() ||
          !runtime.isAdmin() ||
          !box.isConnected
        ) {
          return;
        }

        Promise.resolve(
          runtime.openSourcePicker(
            SLOTS[key].id,
            box
          )
        )
          .then(
            () => {
              forceZigbee(
                SLOTS[key].id
              );
            }
          )
          .catch(
            () => {}
          );
      }
    );
  }

  function ensureBoxKind(
    key,
    admin
  ) {
    const w =
      ensure();

    if (!w) return null;

    const holder =
      w.rows[key];

    if (
      holder.box.tagName ===
      (
        admin
          ? "BUTTON"
          : "SPAN"
      )
    ) {
      return holder.box;
    }

    const box =
      document.createElement(
        admin
          ? "button"
          : "span"
      );

    box.className =
      "f31-r87r2-value";

    setAttr(
      box,
      "data-seb01-slot",
      SLOTS[key].id
    );

    if (admin) {
      bindPicker(
        key,
        box
      );
    }

    holder.box.replaceWith(
      box
    );

    holder.box =
      box;

    return box;
  }

  function paint(
    key,
    entry
  ) {
    const w =
      ensure();

    if (!w) return;

    const valid =
      scopeMatches();

    const admin =
      valid &&
      runtime.isAdmin();

    const box =
      ensureBoxKind(
        key,
        admin
      );

    if (!box) return;

    const value =
      display(
        valid
          ? entry
          : {
              has_value:
                false,

              status:
                "no_context"
            }
      );

    setAttr(
      box,
      "data-state",
      value.state
    );

    const text =
      admin &&
      value.state ===
        "unknown"
        ? "Vybrat"
        : value.text;

    setText(
      box,
      text
    );

    setAttr(
      box,
      "title",
      admin
        ? (
            "Vybrat Zigbee teplotn\u00ed entitu: " +
            SLOTS[key].title
          )
        : (
            SLOTS[key].title +
            ": " +
            value.text
          )
    );
  }

  function locate(
    key
  ) {
    const w =
      ensure();

    return w
      ? {
          card:
            w.card,

          box:
            w.rows[key].box
        }
      : null;
  }

  function initialize() {
    if (registered) return;

    if (
      !runtime ||
      ![
        "registerAdapter",
        "isAdmin",
        "openSourcePicker",
        "diagnostics"
      ].every(
        (key) =>
          typeof runtime[key] ===
            "function"
      )
    ) {
      return;
    }

    try {
      runtime.registerAdapter({
        deviceUuid:
          DEVICE_UUID,

        slot:
          SLOTS.supply.id,

        capability:
          "temperature",

        transport:
          "zigbee",

        title:
          SLOTS.supply.title,

        digits:
          1,

        locate:
          () =>
            locate(
              "supply"
            ),

        paint:
          (entry) =>
            paint(
              "supply",
              entry
            ),

        build:
          ensure
      });

      runtime.registerAdapter({
        deviceUuid:
          DEVICE_UUID,

        slot:
          SLOTS.return.id,

        capability:
          "temperature",

        transport:
          "zigbee",

        title:
          SLOTS.return.title,

        digits:
          1,

        locate:
          () =>
            locate(
              "return"
            ),

        paint:
          (entry) =>
            paint(
              "return",
              entry
            ),

        build:
          ensure
      });

      registered =
        true;

      ensure();

      window.dispatchEvent(
        new Event(
          "resize"
        )
      );

      document.dispatchEvent(
        new Event(
          "iqf-f31-r85-layout-ready"
        )
      );
    } catch (
      error
    ) {
      console.warn(
        "R87R2 adapter registration failed",
        error
      );
    }
  }

  initialize();

  document.addEventListener(
    "DOMContentLoaded",
    initialize,
    {
      once:
        true
    }
  );

  window.addEventListener(
    "load",
    initialize,
    {
      once:
        true
    }
  );
})();
