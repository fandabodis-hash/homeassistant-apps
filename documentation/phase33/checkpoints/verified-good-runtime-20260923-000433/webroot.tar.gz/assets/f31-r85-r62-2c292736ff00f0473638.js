(() => {
  "use strict";

  const MARK = "__IQF_F31_R62_MANIFOLD_HALF_WIDTH__";
  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  if (window[MARK]) return;
  window[MARK] = true;

  function norm(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function ensureStyle() {
    const id = "f31-r62-manifold-half-width-style";

    if (document.getElementById(id)) return;

    const style = document.createElement("style");
    style.id = id;

    style.textContent = `
      ${ROOT_SELECTOR} .f31-r62-manifold-half-width {
        width: 50% !important;
        max-width: 50% !important;
        min-width: 0 !important;
        justify-self: center !important;
        margin-left: auto !important;
        margin-right: auto !important;
      }
    `;

    document.head.appendChild(style);
  }

  function findManifold(root) {
    const direct=root.querySelector(".f29-00012-distributor");
    if(direct) return direct;
    const candidates = Array.from(
      root.querySelectorAll("article,section,div")
    ).filter((el) => {
      const text = norm(el.textContent);

      if (!text.includes("ROZDĚLOVAČ ÚT")) return false;

      const r = el.getBoundingClientRect();

      return (
        r.width >= 220 &&
        r.width <= 800 &&
        r.height >= 70 &&
        r.height <= 260
      );
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      return (
        (ar.width * ar.height) -
        (br.width * br.height)
      );
    });

    return candidates[0];
  }

  function apply() {
    ensureStyle();

    const root = document.querySelector(ROOT_SELECTOR);
    if (!root) return false;

    const card = findManifold(root);
    if (!card) return false;

    card.classList.add(
      "f31-r62-manifold-half-width"
    );

    card.setAttribute(
      "data-f31-r62-width",
      "50-percent"
    );

    return true;
  }

  function boot() {
    if (apply()) return;

    let attempts = 0;

    const timer = window.setInterval(() => {
      attempts += 1;

      if (apply() || attempts >= 24) {
        window.clearInterval(timer);
      }
    }, 250);
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }

  // F31_R85_LIFECYCLE_PATCH: replay the existing visual operation on each schema mount.
  window.IQF_F31_R85_LAYOUT_HOOKS=window.IQF_F31_R85_LAYOUT_HOOKS||{};
  window.IQF_F31_R85_LAYOUT_HOOKS["R62"]=apply;
  document.dispatchEvent(new Event('iqf-f31-r85-layout-ready'));
})();
