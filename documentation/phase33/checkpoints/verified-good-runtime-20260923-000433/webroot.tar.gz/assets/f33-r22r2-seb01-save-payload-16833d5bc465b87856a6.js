(function f33R20ExactF302JBoilerSelector() {
  "use strict";

  var MARKER =
    "__F33_R20_EXACT_F30_02J_BOILER_SELECTOR__";

  if (window[MARKER]) return;
  window[MARKER] = true;

  var API_BASE_URL =
    "https://api.tngiqfanda.cz";

  var DEVICE_UUID =
    "014a0d23-d440-4131-abb4-28a860595043";

  var ELEMENT_KEY =
    "boiler-temperature";

  var STYLE_ID =
    "f33-r20-boiler-temperature-style";

  var PICKER_CLASS =
    "f33-r20-boiler-temp-picker";

  var busy = false;
  var lastRender = 0;

  function text(value) {
    return (
      value === null ||
      value === undefined
        ? ""
        : String(value).trim()
    );
  }

  function normalize(value) {
    return text(value)
      .normalize("NFD")
      .replace(
        /[\u0300-\u036f]/g,
        ""
      )
      .toLowerCase();
  }

  function compact(value) {
    return normalize(value)
      .replace(
        /[^a-z0-9]+/g,
        ""
      );
  }

  function token() {
    try {
      return text(
        window.localStorage.getItem(
          "iqfanda_access_token"
        )
      );
    } catch (error) {
      return "";
    }
  }

  function headers() {
    var result = {
      Accept: "application/json",
      "Content-Type":
        "application/json"
    };

    var value = token();

    if (value) {
      result.Authorization =
        "Bearer " + value;
    }

    return result;
  }

  async function apiJson(
    url,
    options
  ) {
    /*
     * IMPORTANT:
     * Same transport as main React frontend:
     * absolute API_BASE_URL + Bearer token.
     * No credentials:"include".
     */
    var response =
      await fetch(
        url,
        {
          ...(options || {}),
          headers: {
            ...headers(),
            ...(
              options &&
              options.headers
                ? options.headers
                : {}
            )
          },
          cache: "no-store"
        }
      );

    var raw =
      await response.text();

    var data = null;

    try {
      data =
        raw
          ? JSON.parse(raw)
          : {};
    } catch (error) {
      throw new Error(
        "API nevrátilo JSON."
      );
    }

    if (!response.ok) {
      throw new Error(
        (
          data &&
          (
            data.detail ||
            data.message
          )
        ) ||
        ("HTTP " + response.status)
      );
    }

    return data;
  }

  function findSchema() {
    var schema =
      document.querySelector(
        '[data-f29-00012-schema="svj-blansko-only"]' +
        '[data-f33-r16-clone-00013="true"]'
      );

    if (!schema) return null;

    if (
      compact(
        schema.textContent || ""
      ).indexOf("bojler") === -1
    ) {
      return null;
    }

    return schema;
  }

  function findBoilerCard(schema) {
    if (!schema) return null;

    return (
      schema.querySelector(
        ".f29-00012-boiler"
      ) ||
      Array.from(
        schema.querySelectorAll(
          "article,section"
        )
      ).find(
        function (card) {
          return (
            compact(
              card.textContent || ""
            ).indexOf("bojler") !== -1
          );
        }
      ) ||
      null
    );
  }

  function findTemperatureBox(
    boiler
  ) {
    if (!boiler) return null;

    return (
      boiler.querySelector(
        ".f29-00012-temperature"
      ) ||
      (
        boiler.querySelector(
          '[data-f30-schema-element-key="' +
          ELEMENT_KEY +
          '"]'
        ) || {}
      ).parentElement ||
      boiler
    );
  }

  function isAdminPage() {
    var path =
      String(
        window.location.pathname || ""
      ).toLowerCase();

    if (
      path.indexOf("/admin") !== -1
    ) {
      return true;
    }

    try {
      var role =
        String(
          window.localStorage.getItem(
            "iqfanda_role"
          ) || ""
        ).toLowerCase();

      return (
        role === "admin" ||
        role === "superadmin" ||
        role.indexOf("admin") !== -1
      );
    } catch (error) {
      return false;
    }
  }

  function ensureStyle() {
    if (
      document.getElementById(
        STYLE_ID
      )
    ) {
      return;
    }

    var style =
      document.createElement(
        "style"
      );

    style.id = STYLE_ID;

    style.textContent = [
      ".f33-r20-boiler-temp-picker{margin-top:7px;padding:7px;border:1px solid rgba(72,216,255,.38);border-radius:9px;background:rgba(2,22,34,.92);display:grid;gap:5px;position:relative;z-index:9;width:100%;box-sizing:border-box}",
      ".f33-r20-boiler-temp-picker label{display:grid;gap:4px;color:#d9f5ff;font-size:9px;font-weight:900;letter-spacing:.04em;text-transform:uppercase}",
      ".f33-r20-boiler-temp-picker select{width:100%;min-width:0;height:29px;border-radius:7px;border:1px solid rgba(124,221,255,.42);background:#061b28;color:#f1fbff;padding:2px 6px;font-size:10px}",
      ".f33-r20-boiler-temp-picker .f33-r20-actions{display:flex;align-items:center;gap:6px}",
      ".f33-r20-boiler-temp-picker button{height:27px;padding:0 10px;border-radius:7px;border:1px solid rgba(72,216,255,.62);background:#0b4054;color:#fff;font-size:9px;font-weight:900;cursor:pointer}",
      ".f33-r20-boiler-temp-picker small{font-size:8px;line-height:1.2;color:#9dc8d7}",
      ".f33-r20-boiler-temp-picker .f33-r20-status[data-error='1']{color:#ffaaaa}",
      ".f33-r20-boiler-temp-picker .f33-r20-status[data-error='0']{color:#78efb3}"
    ].join("\n");

    document.head.appendChild(
      style
    );
  }

  function ensurePickerShell(
    boiler
  ) {
    if (!isAdminPage()) {
      boiler
        .querySelectorAll(
          "." + PICKER_CLASS
        )
        .forEach(
          function (node) {
            node.remove();
          }
        );

      return null;
    }

    ensureStyle();

    var target =
      findTemperatureBox(
        boiler
      );

    if (!target) return null;

    var picker =
      target.querySelector(
        "." + PICKER_CLASS
      );

    if (!picker) {
      picker =
        document.createElement(
          "div"
        );

      picker.className =
        PICKER_CLASS;

      picker.setAttribute(
        "data-f33-r20",
        "exact-f30-02j-seb01"
      );

      picker.innerHTML =
        '<label>Zdroj teploty bojleru' +
        '<select data-f33-r20-select>' +
        '<option value="">— načítám Zigbee teploty —</option>' +
        '</select></label>' +
        '<div class="f33-r20-actions">' +
        '<button type="button" data-f33-r20-save>Uložit</button>' +
        '<button type="button" data-f33-r20-reload>Obnovit</button>' +
        '</div>' +
        '<small>SEB-01 · výběr se ukládá automaticky · Uložit = opakovat zápis</small>' +
        '<small class="f33-r20-status" data-error="0">Načítám seznam…</small>';

      target.appendChild(
        picker
      );
    }

    return picker;
  }

  function setStatus(
    picker,
    message,
    error
  ) {
    if (!picker) return;

    var node =
      picker.querySelector(
        ".f33-r20-status"
      );

    if (!node) return;

    node.textContent =
      message || "";

    node.setAttribute(
      "data-error",
      error ? "1" : "0"
    );
  }

  function isZigbeeTemperature(
    option
  ) {
    if (
      !option ||
      typeof option !== "object"
    ) {
      return false;
    }

    var transport =
      text(
        option.transport
      ).toLowerCase();

    if (
      transport !== "zigbee" &&
      transport !== "zha"
    ) {
      return false;
    }

    var capability =
      text(
        option.capability
      ).toLowerCase();

    var capabilities =
      Array.isArray(
        option.capabilities
      )
        ? option.capabilities.map(
            function (item) {
              return text(item)
                .toLowerCase();
            }
          )
        : [];

    return (
      capability === "temperature" ||
      capabilities.indexOf(
        "temperature"
      ) !== -1
    );
  }

  function identity(option) {
    return [
      text(option.transport),
      text(option.device_id),
      text(option.entity_id),
      text(option.path)
    ].join("|");
  }

  function optionLabel(option) {
    return (
      (
        text(option.device_name)
        || "Zigbee zařízení"
      )
      + " → "
      + (
        text(option.entity_name)
        || text(option.label)
        || text(option.entity_id)
        || "Teplota"
      )
    );
  }

  function mergeOptions(
    target,
    source
  ) {
    (source || []).forEach(
      function (item) {
        if (
          !isZigbeeTemperature(
            item
          )
        ) {
          return;
        }

        var id =
          identity(item);

        if (!id) return;

        if (
          !target.some(
            function (existing) {
              return (
                identity(existing)
                === id
              );
            }
          )
        ) {
          target.push(item);
        }
      }
    );
  }

  async function loadOptionsWithDebug() {
    var all = [];
    var diagnostics = [];

    var primary =
      API_BASE_URL +
      "/api/v1/admin/devices/" +
      encodeURIComponent(
        DEVICE_UUID
      ) +
      "/individual-project/schema-entity-options?capability=temperature";

    try {
      var data =
        await apiJson(
          primary
        );

      mergeOptions(
        all,
        Array.isArray(
          data.options
        )
          ? data.options
          : []
      );

      diagnostics.push(
        "schema-entity-options=OK("
        + (
          Array.isArray(
            data.options
          )
            ? data.options.length
            : 0
        )
        + ")"
      );

      return {
        options: all,
        bindings:
          (
            data &&
            typeof data.bindings
              === "object"
          )
            ? data.bindings
            : {},
        diagnostics:
          diagnostics
      };
    } catch (error) {
      diagnostics.push(
        "schema-entity-options="
        + error.message
      );
    }

    /*
     * Proven UZV fallback from Phase 30.1B9.
     * Same device_uuid, same capability, admin-only.
     */
    var fallback =
      API_BASE_URL +
      "/api/v1/admin/individual-project/uzv/entity-options" +
      "?capability=temperature" +
      "&device_uuid=" +
      encodeURIComponent(
        DEVICE_UUID
      );

    try {
      var uzv =
        await apiJson(
          fallback
        );

      mergeOptions(
        all,
        Array.isArray(
          uzv.options
        )
          ? uzv.options
          : []
      );

      diagnostics.push(
        "uzv-entity-options=OK("
        + (
          Array.isArray(
            uzv.options
          )
            ? uzv.options.length
            : 0
        )
        + ")"
      );

      return {
        options: all,
        bindings:
          (
            uzv &&
            typeof uzv.bindings
              === "object"
          )
            ? uzv.bindings
            : {},
        diagnostics:
          diagnostics
      };
    } catch (error) {
      diagnostics.push(
        "uzv-entity-options="
        + error.message
      );
    }

    return {
      options: all,
      bindings: {},
      diagnostics:
        diagnostics
    };
  }

  function findSelected(
    options,
    binding
  ) {
    if (!binding) return null;

    var entityId =
      text(
        binding.entity_id
      );

    var path =
      text(
        binding.path
      );

    return (
      options.find(
        function (item) {
          return (
            entityId &&
            text(
              item.entity_id
            ) === entityId
          );
        }
      ) ||
      options.find(
        function (item) {
          return (
            path &&
            text(
              item.path
            ) === path
          );
        }
      ) ||
      null
    );
  }

  function populatePicker(
    picker,
    data
  ) {
    var select =
      picker.querySelector(
        "[data-f33-r20-select]"
      );

    if (!select) return;

    select.innerHTML = "";

    var empty =
      document.createElement(
        "option"
      );

    empty.value = "";

    empty.textContent =
      data.options.length
        ? "— vyber Zigbee zařízení / teplotu —"
        : "— seznam zatím není dostupný —";

    select.appendChild(
      empty
    );

    data.options
      .slice()
      .sort(
        function (a, b) {
          return optionLabel(a)
            .localeCompare(
              optionLabel(b),
              "cs"
            );
        }
      )
      .forEach(
        function (option) {
          var node =
            document.createElement(
              "option"
            );

          node.value =
            identity(option);

          node.textContent =
            optionLabel(option);

          node._sebOption =
            option;

          select.appendChild(
            node
          );
        }
      );

    var binding =
      data.bindings &&
      data.bindings[
        ELEMENT_KEY
      ];

    var selected =
      findSelected(
        data.options,
        binding
      );

    if (selected) {
      select.value =
        identity(selected);
    }

    setStatus(
      picker,
      data.options.length
        ? (
            "Načteno Zigbee teplot: "
            + data.options.length
            + (
              selected
                ? " · aktuální: "
                  + optionLabel(selected)
                : ""
            )
          )
        : (
            "Seznam je prázdný. "
            + data.diagnostics.join(
                " | "
              )
          ),
      data.options.length === 0
    );
  }

  async function saveSelected(
    picker
  ) {
    var select =
      picker.querySelector(
        "[data-f33-r20-select]"
      );

    if (
      !select ||
      select.selectedIndex < 0
    ) {
      setStatus(
        picker,
        "Nejdřív vyber Zigbee teplotu.",
        true
      );
      return;
    }

    var node =
      select.options[
        select.selectedIndex
      ];

    var option =
      node &&
      node._sebOption;

    if (!option) {
      setStatus(
        picker,
        "Nejdřív vyber Zigbee teplotu.",
        true
      );
      return;
    }

    setStatus(
      picker,
      "Ukládám SEB-01 vazbu…",
      false
    );

    var url =
      API_BASE_URL +
      "/api/v1/admin/devices/" +
      encodeURIComponent(
        DEVICE_UUID
      ) +
      "/individual-project/schema-entity-bindings/" +
      encodeURIComponent(
        ELEMENT_KEY
      );

    var saved =
      await apiJson(
        url,
        {
          method: "PUT",
          body: JSON.stringify({
            /* F33_R22R2_SEB01_SAVE_PAYLOAD_COMPAT */
            element_key:
              ELEMENT_KEY,
            capability:
              "temperature",

            entity:
              option,

            binding:
              option,
            selected_entity:
              option,
            selectedEntity:
              option,

            source:
              "F33.R22R2",
            target_model:
              "00013",
            target_card:
              "boiler",
            target_value:
              "boiler_temperature",

            source_device_uuid:
              DEVICE_UUID,
            id:
              option.id || "",
            transport:
              option.transport || "",
            entity_id:
              option.entity_id || "",
            device_id:
              option.device_id || "",
            device_name:
              option.device_name || "",
            entity_name:
              option.entity_name || "",
            capabilities:
              Array.isArray(
                option.capabilities
              )
                ? option.capabilities
                : ["temperature"],
            unit:
              option.unit || "",
            label:
              option.label || "",
            path:
              option.path || ""
          })
        }
      );

    var savedEntity =
      text(
        saved &&
        saved.binding &&
        saved.binding.entity_id
      );

    if (
      savedEntity &&
      savedEntity !==
        text(option.entity_id)
    ) {
      throw new Error(
        "Server uložil jinou entitu."
      );
    }

    setStatus(
      picker,
      "Uloženo do 00013: "
      + optionLabel(option)
      + " · klient zobrazí hodnotu přes SEB-01B.",
      false
    );

    picker.setAttribute(
      "data-f33-r20-saved",
      savedEntity ||
      text(option.entity_id)
    );
  }

  function wirePicker(
    picker
  ) {
    /* F33_R22_F30_02J_CHANGE_AUTOSAVE */
    var select =
      picker.querySelector(
        "[data-f33-r20-select]"
      );

    if (
      select &&
      !select.__f33R22ChangeSave
    ) {
      select.__f33R22ChangeSave = true;

      select.addEventListener(
        "change",
        async function (event) {
          event.stopPropagation();
          setStatus(
            picker,
            "Ukládám výběr…",
            false
          );
          try {
            await saveSelected(picker);
          } catch (error) {
            setStatus(
              picker,
              "Uložení selhalo: " + error.message,
              true
            );
          }
        }
      );
    }

    var save =
      picker.querySelector(
        "[data-f33-r20-save]"
      );

    var reload =
      picker.querySelector(
        "[data-f33-r20-reload]"
      );

    if (
      save &&
      !save.__f33R22PointerSave
    ) {
      save.__f33R22PointerSave = true;

      save.addEventListener(
        "pointerdown",
        async function (event) {
          event.preventDefault();
          event.stopPropagation();
          save.disabled = true;
          try {
            await saveSelected(picker);
          } catch (error) {
            setStatus(
              picker,
              "Uložení selhalo: " + error.message,
              true
            );
          } finally {
            save.disabled = false;
          }
        }
      );
    }

    if (
      save &&
      !save.__f33R20Wired
    ) {
      save.__f33R20Wired =
        true;

      save.addEventListener(
        "click",
        async function (event) {
          event.preventDefault();
          event.stopPropagation();

          save.disabled = true;

          try {
            await saveSelected(
              picker
            );
          } catch (error) {
            setStatus(
              picker,
              "Uložení selhalo: "
              + error.message,
              true
            );
          } finally {
            save.disabled = false;
          }
        }
      );
    }

    if (
      reload &&
      !reload.__f33R20Wired
    ) {
      reload.__f33R20Wired =
        true;

      reload.addEventListener(
        "click",
        function (event) {
          event.preventDefault();
          event.stopPropagation();
          schedule(true);
        }
      );
    }
  }

  async function update(force) {
    var schema =
      findSchema();

    if (!schema) return;

    var boiler =
      findBoilerCard(
        schema
      );

    if (!boiler) return;

    /*
     * Exact durable F30.2J behavior:
     * render the admin picker shell BEFORE any network call.
     * Therefore a temporary API/CORS/auth error cannot make
     * the selector disappear from the BOJLER card.
     */
    var picker =
      ensurePickerShell(
        boiler
      );

    if (!picker) return;

    wirePicker(
      picker
    );

    var now =
      Date.now();

    if (
      !force &&
      now - lastRender < 5000
    ) {
      return;
    }

    if (busy) return;

    busy = true;

    try {
      setStatus(
        picker,
        "Načítám Zigbee teploty…",
        false
      );

      var data =
        await loadOptionsWithDebug();

      populatePicker(
        picker,
        data
      );

      lastRender =
        Date.now();
    } catch (error) {
      setStatus(
        picker,
        "Načtení selhalo: "
        + error.message,
        true
      );
    } finally {
      busy = false;
    }
  }

  function schedule(force) {
    update(
      !!force
    ).catch(
      function (error) {
        console.error(
          "F33.R20 update failed:",
          error
        );
      }
    );
  }

  if (
    document.readyState
    === "loading"
  ) {
    document.addEventListener(
      "DOMContentLoaded",
      function () {
        schedule(true);
      }
    );
  } else {
    schedule(true);
  }

  /*
   * Same lifecycle proven by F30.2J on model 00012.
   * These mechanisms only re-mount/update the admin picker.
   * Live values remain exclusively owned by SEB-01B.
   */
  var observer =
    new MutationObserver(
      function () {
        schedule(false);
      }
    );

  observer.observe(
    document.documentElement ||
    document.body,
    {
      childList: true,
      subtree: true
    }
  );

  window.setInterval(
    function () {
      if (findSchema()) {
        schedule(true);
      }
    },
    15000
  );
})();
