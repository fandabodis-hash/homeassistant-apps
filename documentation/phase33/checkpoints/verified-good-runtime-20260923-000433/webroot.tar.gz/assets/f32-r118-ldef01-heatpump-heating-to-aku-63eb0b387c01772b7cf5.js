(() => {
  "use strict";

  const VERSION = "F32.3D-R118-LDEF01-HEATPUMP-HEATING-TO-AKU";
  const OVERLAY_ID = "f32-r118-ldef01-heatpump-heating-to-aku";
  const STYLE_ID = "f32-r118-ldef01-heatpump-heating-to-aku-style";

  const SLOT_1 = "heatpump-stage-1-heating-state";
  const SLOT_2 = "heatpump-stage-2-heating-state";

  const SOURCE_SELECTORS = [
    ".f29-00012-heatpump",
    ".f30-heatpump-block",
    '[data-phase28-individual-heatpump-power-combined-block="true"]'
  ];

  const TARGET_SELECTORS = [
    ".f29-00012-accumulator",
    ".phase28-safe-storage-aku-v1"
  ];

  const ON_VALUES = new Set([
    "1",
    "true",
    "on",
    "zapnuto",
    "active",
    "running",
    "enabled",
    "open"
  ]);

  let active = false;

  function norm(value) {
    return String(value ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function isVisible(node) {
    if (
      !node ||
      !node.isConnected ||
      typeof node.getBoundingClientRect !== "function"
    ) {
      return false;
    }

    const r = node.getBoundingClientRect();
    const s = getComputedStyle(node);

    return (
      r.width > 0 &&
      r.height > 0 &&
      s.display !== "none" &&
      s.visibility !== "hidden"
    );
  }

  function firstVisible(selectors) {
    for (const selector of selectors) {
      const nodes = document.querySelectorAll(selector);

      for (const node of nodes) {
        if (isVisible(node)) {
          return node;
        }
      }
    }

    return null;
  }

  function stateNode(slot) {
    return firstVisible([
      `[data-f30-schema-element-key="${slot}"]`,
      `[data-seb01-slot="${slot}"]`
    ]);
  }

  function stateOn(node) {
    if (!node) {
      return false;
    }

    const candidates = [
      node.getAttribute("data-f31-seb-state"),
      node.getAttribute("data-f31-r16-state"),
      node.getAttribute("data-state"),
      node.textContent
    ];

    return candidates.some(
      (value) => ON_VALUES.has(norm(value))
    );
  }

  function heatingIsOn() {
    return (
      stateOn(stateNode(SLOT_1)) ||
      stateOn(stateNode(SLOT_2))
    );
  }

  function ensureStyle() {
    let style = document.getElementById(STYLE_ID);

    if (style) {
      return style;
    }

    style = document.createElement("style");
    style.id = STYLE_ID;

    style.textContent = `
      #${OVERLAY_ID} {
        position: fixed !important;
        inset: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        z-index: 2147482500 !important;
        pointer-events: none !important;
        overflow: visible !important;
        display: none !important;
      }

      #${OVERLAY_ID}[data-active="true"] {
        display: block !important;
      }

      #${OVERLAY_ID} svg {
        position: absolute !important;
        inset: 0 !important;
        width: 100% !important;
        height: 100% !important;
        overflow: visible !important;
        pointer-events: none !important;
      }

      #${OVERLAY_ID} .ldef01-halo {
        fill: none !important;
        stroke: rgba(15, 125, 180, 0.32) !important;
        stroke-width: 18 !important;
        stroke-linecap: round !important;
        stroke-linejoin: round !important;
        filter: url(#f32R118Ldef01GlowWide);
      }

      #${OVERLAY_ID} .ldef01-track {
        fill: none !important;
        stroke: rgba(23, 184, 239, 0.84) !important;
        stroke-width: 7 !important;
        stroke-linecap: round !important;
        stroke-linejoin: round !important;
        filter: url(#f32R118Ldef01Glow);
      }

      #${OVERLAY_ID} .ldef01-dots {
        fill: none !important;
        stroke: rgba(116, 224, 255, 1) !important;
        stroke-width: 12 !important;
        stroke-linecap: round !important;
        stroke-linejoin: round !important;
        stroke-dasharray: 1 32 !important;
        filter: url(#f32R118Ldef01GlowStrong);
        animation:
          f32R118Ldef01Dots
          1.70s
          linear
          infinite !important;
      }

      @keyframes f32R118Ldef01Dots {
        from { stroke-dashoffset: 0; }
        to   { stroke-dashoffset: -66; }
      }
    `;

    document.head.appendChild(style);
    return style;
  }

  function ensureOverlay() {
    let overlay = document.getElementById(OVERLAY_ID);

    if (overlay) {
      return overlay;
    }

    ensureStyle();

    overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    overlay.setAttribute("data-active", "false");
    overlay.setAttribute(
      "data-ldef01",
      "heatpump-heating-to-aku"
    );

    const svg = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "svg"
    );

    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("preserveAspectRatio", "none");

    const defs = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "defs"
    );

    defs.innerHTML = `
      <filter id="f32R118Ldef01GlowWide" x="-80%" y="-80%" width="260%" height="260%">
        <feGaussianBlur stdDeviation="8" result="blur" />
        <feMerge>
          <feMergeNode in="blur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>

      <filter id="f32R118Ldef01Glow" x="-60%" y="-60%" width="220%" height="220%">
        <feGaussianBlur stdDeviation="4" result="blur" />
        <feMerge>
          <feMergeNode in="blur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>

      <filter id="f32R118Ldef01GlowStrong" x="-100%" y="-100%" width="300%" height="300%">
        <feGaussianBlur stdDeviation="5.5" result="blur" />
        <feMerge>
          <feMergeNode in="blur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    `;

    svg.appendChild(defs);

    for (
      const className
      of [
        "ldef01-halo",
        "ldef01-track",
        "ldef01-dots"
      ]
    ) {
      const polyline = document.createElementNS(
        "http://www.w3.org/2000/svg",
        "polyline"
      );

      polyline.setAttribute("class", className);
      polyline.setAttribute("points", "");
      svg.appendChild(polyline);
    }

    overlay.appendChild(svg);
    document.body.appendChild(overlay);

    return overlay;
  }

  function setActive(value) {
    active = Boolean(value);

    ensureOverlay().setAttribute(
      "data-active",
      active ? "true" : "false"
    );
  }

  function updateState() {
    const source = firstVisible(SOURCE_SELECTORS);
    const target = firstVisible(TARGET_SELECTORS);

    setActive(
      Boolean(source) &&
      Boolean(target) &&
      heatingIsOn()
    );
  }

  function layout() {
    const overlay = ensureOverlay();

    if (!active) {
      return;
    }

    const source = firstVisible(SOURCE_SELECTORS);
    const target = firstVisible(TARGET_SELECTORS);

    if (!source || !target) {
      setActive(false);
      return;
    }

    const s = source.getBoundingClientRect();
    const t = target.getBoundingClientRect();

    const startX = Math.round(s.right);
    const startY = Math.round(
      s.top + (s.height * 0.78)
    );

    const targetX = Math.round(
      t.left + (t.width * 0.50)
    );

    const targetY = Math.round(t.top);

    if (
      targetX <= startX + 12 ||
      targetY <= startY + 12
    ) {
      setActive(false);
      return;
    }

    const points = [
      `${startX},${startY}`,
      `${targetX},${startY}`,
      `${targetX},${targetY}`
    ].join(" ");

    const svg = overlay.querySelector("svg");

    svg.setAttribute(
      "viewBox",
      `0 0 ${window.innerWidth} ${window.innerHeight}`
    );

    overlay
      .querySelectorAll("polyline")
      .forEach((polyline) => {
        polyline.setAttribute(
          "points",
          points
        );
      });
  }

  function boot() {
    ensureStyle();
    ensureOverlay();

    updateState();
    layout();

    // Proven LDEF-01 operational rhythm:
    window.setInterval(updateState, 200);
    window.setInterval(layout, 500);

    window.addEventListener(
      "resize",
      layout,
      { passive: true }
    );

    window.addEventListener(
      "scroll",
      layout,
      { passive: true }
    );

    window.IQF_LDEF01_R118 = Object.freeze({
      version: VERSION,
      slot1: SLOT_1,
      slot2: SLOT_2,
      direction: "HEATPUMP_TO_AKU_NADRZ",
      updateState,
      layout
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }
})();