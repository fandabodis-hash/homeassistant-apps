(() => {
  "use strict";

  const MARK = "__IQF_F31_R60_AKU_LINE_STUB__";

  if (window[MARK]) return;
  window[MARK] = true;

  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  function norm(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function findAkuCard(root) {
    const candidates = Array.from(
      root.querySelectorAll("article,section,div")
    ).filter((el) => {
      const text = norm(el.textContent);

      if (!text.includes("AKU NÁDRŽ")) return false;

      const r = el.getBoundingClientRect();

      return (
        r.width >= 180 &&
        r.width <= 520 &&
        r.height >= 140 &&
        r.height <= 420
      );
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      return (
        (ar.width * ar.height) -
        (br.width * br.height)
      );
    });

    return candidates[0];
  }

  function hideAkuStub() {
    const root = document.querySelector(ROOT_SELECTOR);
    if (!root) return false;

    const aku = findAkuCard(root);
    if (!aku) return false;

    const a = aku.getBoundingClientRect();

    let hidden = 0;

    for (const el of root.querySelectorAll("*")) {
      if (!(el instanceof HTMLElement)) continue;

      if (
        el === aku ||
        aku.contains(el)
      ) {
        continue;
      }

      if (norm(el.textContent)) continue;

      const r = el.getBoundingClientRect();

      if (r.width <= 0 || r.height <= 0) continue;

      /*
        The remaining artifact is the short horizontal cyan segment
        immediately to the right of the AKU card.
      */
      const horizontal =
        r.width >= 35 &&
        r.width <= 180 &&
        r.height <= 12;

      const startsAtAkuRight =
        r.left >= a.right - 12 &&
        r.left <= a.right + 30;

      const verticalBand =
        r.top >= a.top + (a.height * 0.25) &&
        r.top <= a.bottom - 20;

      if (
        horizontal &&
        startsAtAkuRight &&
        verticalBand
      ) {
        el.style.setProperty(
          "display",
          "none",
          "important"
        );

        el.setAttribute(
          "data-f31-r60-hidden-aku-stub",
          "1"
        );

        hidden += 1;
      }
    }

    root.setAttribute(
      "data-f31-r60-hidden-count",
      String(hidden)
    );

    return hidden > 0;
  }

  function boot() {
    if (hideAkuStub()) return;

    let attempts = 0;

    const timer = window.setInterval(() => {
      attempts += 1;

      if (
        hideAkuStub() ||
        attempts >= 24
      ) {
        window.clearInterval(timer);
      }
    }, 250);
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }
})();
