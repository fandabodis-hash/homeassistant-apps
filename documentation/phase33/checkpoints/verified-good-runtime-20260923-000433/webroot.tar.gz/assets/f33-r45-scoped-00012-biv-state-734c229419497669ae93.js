(function phase30Seb01BivalenceState00012() {
  "use strict";
  // F30_04C_R4_SHARED_RUNTIME_ADAPTER
  var R = window.IQF_SEB01_RUNTIME;
  if (!R) throw new Error("SEB01_RUNTIME_NOT_LOADED");

  var MARKER = "__F30_03C_SEB01_BIVALENCE_STATE_00012__";
  if (window[MARKER]) return;
  window[MARKER] = true;

  var BINDING_URL =
    "/phase30-model00012-bivalence-state-seb01-v1.json?v=20260915-022655";

  var STORE_KEY =
    "f30_03c_seb01_model00012_bivalence_state";

  var STYLE_ID =
    "f30-03c-seb01-bivalence-state-style";

  var cachedData = null;
  var optionByUid = {};
  var selectedPending = null;
  var userInteractingUntil = 0;

  function text(value) {
    return value === null || value === undefined
      ? ""
      : String(value).trim();
  }

  function normalize(value) {
    return text(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  }

  function compact(value) {
    return normalize(value)
      .replace(/[^a-z0-9]+/g, "");
  }

  function stateText(value) {
    var raw = text(value);
    var c = compact(raw);

    if (
      c === "on" ||
      c === "zapnuto" ||
      c === "true" ||
      c === "1" ||
      c === "open" ||
      c === "opened"
    ) {
      return "ZAPNUTO";
    }

    if (
      c === "off" ||
      c === "vypnuto" ||
      c === "false" ||
      c === "0" ||
      c === "closed" ||
      c === "close"
    ) {
      return "VYPNUTO";
    }

    if (
      c === "unavailable" ||
      c === "unknown" ||
      c === "offline"
    ) {
      return raw || "unavailable";
    }

    return raw || "\u2014";
  }

  function displayState(option) { return R.format(option, "", 0); }

  function isAdminPage() { return R.isAdmin(); }

  function findSchema() {
    /* F33.R45: true 00012 behavior remains original. */
    if (document.querySelector(
      '[data-phase28-r177n107-workspace="universal-individual-admin-client-clone"]' +
      '[data-f33-r34-current-device-uuid="014a0d23-d440-4131-abb4-28a860595043"]'
    )) { return null; }

    return document.querySelector(
      '[data-f29-00012-schema="svj-blansko-only"], .f29-00012-schema-v2'
    );
  }

  function findBivalenceCard(schema) {
    if (!schema) return null;

    var direct = schema.querySelector(
      ".f29-00012-bivalence,.f29-00012-bivalence-tuv,.f29-00012-bivalence-card"
    );

    if (direct) return direct;

    var nodes = Array.prototype.slice.call(
      schema.querySelectorAll("section,article,div")
    );

    var matches = nodes.filter(function(el) {
      var c = compact(el.textContent || "");

      if (
        c.indexOf("bivalencetuvcztblansko") === -1
      ) {
        return false;
      }

      var r = el.getBoundingClientRect();

      return (
        r.width >= 250 &&
        r.width <= 600 &&
        r.height >= 180 &&
        r.height <= 600
      );
    });

    matches.sort(function(a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();

      return (
        ar.width * ar.height -
        br.width * br.height
      );
    });

    return matches[0] || null;
  }

  function findStateRow(card) {
    if (!card) return null;

    var nodes = Array.prototype.slice.call(
      card.querySelectorAll("div")
    );

    var matches = nodes.filter(function(el) {
      if (
        el.closest(".f30-03c-picker")
      ) {
        return false;
      }

      var c = compact(el.textContent || "");

      if (c.indexOf("stavzapvyp") === -1) {
        return false;
      }

      var r = el.getBoundingClientRect();

      return (
        r.width > 150 &&
        r.height >= 20 &&
        r.height <= 80
      );
    });

    matches.sort(function(a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();

      return (
        ar.width * ar.height -
        br.width * br.height
      );
    });

    return matches[0] || null;
  }

  function findStateValueNode(row) {
    if (!row) return null;

    var nodes = Array.prototype.slice.call(
      row.querySelectorAll("span,strong,b,div")
    );

    for (var i = 0; i < nodes.length; i += 1) {
      var c = compact(nodes[i].textContent || "");

      if (
        c === "stavzapvyp"
      ) {
        continue;
      }

      var t = text(nodes[i].textContent);

      if (
        t === "\u2014" ||
        t === "-" ||
        c === "zapnuto" ||
        c === "vypnuto" ||
        c === "unavailable" ||
        c === "unknown" ||
        c === "offline"
      ) {
        return nodes[i];
      }
    }

    return null;
  }

  function ensureStyle() {
    if (
      document.getElementById(STYLE_ID)
    ) {
      return;
    }

    var style = document.createElement("style");
    style.id = STYLE_ID;

    style.textContent = [
      ".f30-03c-picker{margin:.45rem 0;padding:.6rem;border:1px solid rgba(93,203,255,.38);border-radius:10px;background:rgba(2,22,34,.96);display:grid;gap:.4rem;position:relative;z-index:7;width:100%;box-sizing:border-box;}",
      ".f30-03c-picker label{display:grid;gap:.3rem;color:#d9f5ff;font-size:.66rem;font-weight:900;letter-spacing:.04em;text-transform:uppercase;}",
      ".f30-03c-picker select{width:100%;min-height:32px;border-radius:8px;border:1px solid rgba(124,221,255,.42);background:#061b28;color:#f1fbff;padding:.35rem .45rem;font-size:.72rem;}",
      ".f30-03c-actions{display:flex;justify-content:flex-end;}",
      ".f30-03c-picker button{border:1px solid rgba(124,221,255,.55);background:rgba(34,184,255,.20);color:#e7fbff;border-radius:8px;padding:.35rem .65rem;font-weight:900;font-size:.70rem;cursor:pointer;}",
      ".f30-03c-picker button:disabled{opacity:.45;cursor:not-allowed;}",
      ".f30-03c-picker small{color:#9dc8d7;font-size:.63rem;line-height:1.25;}",
      ".f30-03c-status{color:#75f0b3!important;}",
      ".f30-03c-warning{color:#ffd47a!important;}"
    ].join("\n");

    document.head.appendChild(style);
  }

  async function loadData() { return cachedData; }

  function loadLocalBinding() {
    try {
      var raw = window.localStorage.getItem(STORE_KEY);

      if (raw) {
        return JSON.parse(raw);
      }
    } catch (error) {}

    return null;
  }

  async function saveLocalBinding(binding) {
    try { await R.save("bivalence-state", binding); return true; }
    catch (error) { return false; }
  }

  function selectedOption(options, binding) {
    if (!binding) return null;

    var uid = text(binding.uid);

    if (uid) {
      for (var i = 0; i < options.length; i += 1) {
        if (text(options[i].uid) === uid) {
          return options[i];
        }
      }
    }

    var deviceName = compact(binding.device_name);
    var entityName = compact(binding.entity_name);

    for (var j = 0; j < options.length; j += 1) {
      if (
        deviceName &&
        entityName &&
        compact(options[j].device_name) === deviceName &&
        compact(options[j].entity_name) === entityName
      ) {
        return options[j];
      }
    }

    return binding;
  }

  function applyState(option) {
    var card = findBivalenceCard(findSchema());
    var box = findStateRow(card);
    if (!box) return;
    R.paintText(box, findStateValueNode, R.view("bivalence-state", "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc"), "", 0, "bivalence-state");
  }

  function optionValueText(option) {
    return stateText(
      option.display_value ||
      option.value ||
      option.state ||
      "\u2014"
    );
  }

  function addGroup(select, label, options) {
    if (!options || !options.length) return;

    var group = document.createElement("optgroup");
    group.label = label;

    options.forEach(function(option) {
      var uid = text(option.uid);

      if (!uid) {
        uid =
          "f30_03c_" +
          Object.keys(optionByUid).length;
      }

      optionByUid[uid] = option;

      var item = document.createElement("option");
      item.value = uid;

      item.textContent = [
        text(option.entity_name || "Entita"),
        optionValueText(option)
      ].filter(Boolean).join(" - ");

      group.appendChild(item);
    });

    select.appendChild(group);
  }

  function currentSelected(select) {
    if (!select) return null;

    var uid = text(select.value);

    if (!uid) return null;

    return optionByUid[uid] || null;
  }

  function buildAdminPicker(card, data, selected) {
    if (card.querySelector(".f30-03c-picker")) {
      return;
    }

    ensureStyle();
    optionByUid = {};

    var stateRow = findStateRow(card);
    if (!stateRow) return;

    var picker = document.createElement("div");
    picker.className = "f30-03c-picker";

    picker.setAttribute(
      "data-f30-03c-seb01",
      "bivalence-state"
    );

    picker.innerHTML =
      '<label>Stav bivalence - SEB-01<select></select></label>' +
      '<small>Vyber pouze zdroj stavu. Tento prvek neposila zadny povel do spinace.</small>' +
      '<div class="f30-03c-actions"><button type="button" class="f30-03c-save" disabled>Ulozit</button></div>' +
      '<small class="f30-03c-status"></small>';

    stateRow.insertAdjacentElement(
      "afterend",
      picker
    );

    var select = picker.querySelector("select");
    var saveButton = picker.querySelector(".f30-03c-save");
    var status = picker.querySelector(".f30-03c-status");

    var empty = document.createElement("option");
    empty.value = "";

    empty.textContent =
      data.options.length
        ? "Vyber zarizeni / entitu..."
        : "Katalog modelu 00012 je prazdny";

    select.appendChild(empty);

    addGroup(
      select,
      "Doporuceno pro stav bivalence",
      data.recommended || []
    );

    (data.devices || []).forEach(function(device) {
      var prefix =
        device.transport === "wifi"
          ? "Wi-Fi"
          : "Zigbee";

      addGroup(
        select,
        prefix + " - " +
        text(device.device_name || "zarizeni"),
        device.entities || []
      );
    });

    var effective = selected || data.selected;

    if (
      effective &&
      text(effective.uid) &&
      optionByUid[text(effective.uid)]
    ) {
      select.value = text(effective.uid);
    }

    function markInteracting() {
      userInteractingUntil =
        Date.now() + 60000;
    }

    function refreshStatus() {
      var chosen = currentSelected(select);

      selectedPending = chosen;
      saveButton.disabled = !chosen;

      if (!status) return;

      if (chosen) {
        status.className = "f30-03c-status";

        status.textContent =
          "Vybrano: " +
          text(chosen.device_name || "zarizeni") +
          " / " +
          text(chosen.entity_name || "entita") +
          " = " +
          optionValueText(chosen) +
          ". Potvrd tlacitkem Ulozit.";
      } else {
        status.className = "f30-03c-status";
        status.textContent =
          "SEB-01: vyber zdroj stavu ZAP/VYP.";
      }
    }

    [
      "focus",
      "pointerdown",
      "mousedown",
      "keydown",
      "input",
      "change",
      "click"
    ].forEach(function(eventName) {
      select.addEventListener(
        eventName,
        markInteracting
      );
    });

    select.addEventListener("input", refreshStatus);
    select.addEventListener("change", refreshStatus);

    saveButton.addEventListener(
      "click",
      async function() {
        markInteracting();

        var chosen =
          currentSelected(select) ||
          selectedPending;

        if (!chosen) {
          refreshStatus();
          return;
        }

        var ok = await saveLocalBinding(chosen);
        if (!ok) {
          if (status) status.textContent = "Ulozeni vazby na server selhalo; vyber nebyl potvrzen.";
          return;
        }

        data.selected = chosen;
        cachedData.selected = chosen;

        applyState(chosen);

        if (status) {
          status.className =
            "f30-03c-status" +
            (ok ? "" : " f30-03c-warning");

          status.textContent = R.saveMessage("bivalence-state", "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc");
        }
      }
    );

    if (effective) {
      applyState(effective);
    }

    refreshStatus();
  }

  R.registerAdapter({
    deviceUuid: "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc", slot: "bivalence-state", capability: "switch",
    digits: 0, legacy: loadLocalBinding,
    pickerSelector: ".f30-03c-picker", statusSelector: ".f30-03c-status",
    locate: function() { var card=findBivalenceCard(findSchema()); return card ? {card:card,box:findStateRow(card)} : null; },
    paint: function(entry) { applyState(entry); },
    build: function(data,selected) { cachedData=data; var card=findBivalenceCard(findSchema()); if(card) buildAdminPicker(card,data,selected); }
  });
})();

;window.__F33_R45_SCOPED_00012_BIV_STATE__="F33_R45_SCOPED_00012_BIV_STATE";
