(() => {
  "use strict";

  const MARK = "__IQF_F31_R79_INDOOR_TEMP_PICKER__";
  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  const runtime = window.IQF_SEB01_RUNTIME;

  if (window[MARK]) return;
  window[MARK] = true;

  if (
    !runtime ||
    runtime.version !== "F30.4C-R5-PERSISTED-READER"
  ) {
    console.warn("R79: shared SEB runtime unavailable");
    return;
  }

  const CONFIG = Object.freeze([
    {
      zone: "east",
      slot: "heating-zone-east-indoor-temperature",
      title: "VÝCHOD / Vnitřní teplota"
    },
    {
      zone: "west",
      slot: "heating-zone-west-indoor-temperature",
      title: "ZÁPAD / Vnitřní teplota"
    }
  ]);

  function root() {
    return document.querySelector(ROOT_SELECTOR);
  }

  function findCircle(cfg) {
    const rootEl = root();
    if (!rootEl) return null;

    return rootEl.querySelector(
      `[data-f31-r70-zone="${cfg.zone}"]`
    );
  }

  function findValue(cfg) {
    const circle = findCircle(cfg);
    if (!circle) return null;

    return circle.querySelector(
      `[data-f31-r70-slot="${cfg.slot}"]`
    );
  }

  function setPickerToZigbee() {
    queueMicrotask(() => {
      const dialog = document.querySelector(
        'dialog[data-seb01-source-dialog]'
      );

      if (!dialog) return;

      const network = dialog.querySelector(
        '[data-seb01-network-filter="true"]'
      );

      if (!network) return;

      if (network.value !== "zigbee") {
        network.value = "zigbee";

        network.dispatchEvent(
          new Event(
            "change",
            { bubbles: true }
          )
        );
      }
    });
  }

  function ensureStyle() {
    const id = "f31-r79-indoor-temp-picker-style";

    if (document.getElementById(id)) return;

    const style = document.createElement("style");
    style.id = id;

    style.textContent = `
      ${ROOT_SELECTOR}
      button.f31-r79-temp-picker {
        min-width: 86px;
        height: 24px;
        padding: 0 8px;

        border: 1px solid rgba(72,215,255,.68);
        border-radius: 6px;

        background: rgba(0,31,46,.96);
        color: #dff8ff;

        font-size: 10px;
        font-weight: 900;
        line-height: 1;

        cursor: pointer;
        pointer-events: auto;

        box-shadow: 0 0 8px rgba(72,215,255,.12);
      }

      ${ROOT_SELECTOR}
      button.f31-r79-temp-picker:hover {
        background: rgba(0,65,91,.98);
        box-shadow: 0 0 10px rgba(72,215,255,.20);
      }

      ${ROOT_SELECTOR}
      span.f31-r79-temp-value {
        min-width: 86px;
        text-align: center;
        color: #fff;
        font-weight: 900;
        pointer-events: none;
      }
    `;

    document.head.appendChild(style);
  }

  function enhance(cfg) {
    const node = findValue(cfg);
    if (!node) return false;

    const admin = runtime.isAdmin();
    const desiredTag = admin ? "BUTTON" : "SPAN";

    let current = node;

    if (current.tagName !== desiredTag) {
      const replacement = document.createElement(
        admin ? "button" : "span"
      );

      replacement.setAttribute(
        "data-f31-r70-slot",
        cfg.slot
      );

      replacement.setAttribute(
        "data-seb01-slot",
        cfg.slot
      );

      if (admin) {
        replacement.type = "button";
        replacement.className =
          "f31-r70-value f31-r79-temp-picker";

        replacement.textContent =
          current.textContent &&
          !/^[—–-]\s*°?C?$/i.test(
            current.textContent.trim()
          )
            ? current.textContent
            : "Vybrat";

        replacement.addEventListener(
          "click",
          (event) => {
            event.preventDefault();
            event.stopPropagation();

            if (!runtime.isAdmin()) return;

            void runtime.openSourcePicker(
              cfg.slot,
              replacement
            );

            setPickerToZigbee();
          }
        );

        replacement.title =
          "UZV / SEB-01B — vybrat Zigbee teplotní entitu: " +
          cfg.title;
      } else {
        replacement.className =
          "f31-r70-value f31-r79-temp-value";

        replacement.textContent =
          current.textContent || "— °C";
      }

      current.replaceWith(replacement);
      current = replacement;
    } else {
      if (admin) {
        current.classList.add(
          "f31-r79-temp-picker"
        );

        if (
          !current.dataset.f31R79ClickBound
        ) {
          current.dataset.f31R79ClickBound = "1";

          current.addEventListener(
            "click",
            (event) => {
              event.preventDefault();
              event.stopPropagation();

              if (!runtime.isAdmin()) return;

              void runtime.openSourcePicker(
                cfg.slot,
                current
              );

              setPickerToZigbee();
            }
          );
        }
      } else {
        current.classList.add(
          "f31-r79-temp-value"
        );
      }
    }

    return true;
  }

  function apply() {
    ensureStyle();

    let count = 0;

    for (const cfg of CONFIG) {
      if (enhance(cfg)) {
        count += 1;
      }
    }

    const rootEl = root();

    if (rootEl) {
      rootEl.setAttribute(
        "data-f31-r79-indoor-temp-pickers",
        String(count)
      );
    }

    return count === CONFIG.length;
  }

  function boot() {
    apply();

    let attempts = 0;

    const timer = window.setInterval(() => {
      attempts += 1;

      if (
        apply() ||
        attempts >= 20
      ) {
        window.clearInterval(timer);
      }
    }, 250);
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }
})();