(() => {
  "use strict";

  const MARK = "__IQF_F31_R68_POWERLINES_ROBUST__";
  const ROOT_SELECTOR = '[data-f29-00012-schema="svj-blansko-only"]';

  if (window[MARK]) return;
  window[MARK] = true;

  const NS = "http://www.w3.org/2000/svg";

  function norm(v) {
    return String(v || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function root() {
    return document.querySelector(ROOT_SELECTOR);
  }

  function rectArea(el) {
    const r = el.getBoundingClientRect();
    return r.width * r.height;
  }

  function findByText(rootEl, include, exclude = []) {
    const wanted = include.map(norm);
    const banned = exclude.map(norm);

    const nodes = Array.from(
      rootEl.querySelectorAll("article,section,div")
    ).filter((el) => {
      const t = norm(el.textContent);

      if (!wanted.every((x) => t.includes(x))) return false;
      if (banned.some((x) => t.includes(x))) return false;

      const r = el.getBoundingClientRect();

      return (
        r.width >= 120 &&
        r.height >= 70 &&
        r.width <= 900 &&
        r.height <= 620
      );
    });

    if (!nodes.length) return null;

    nodes.sort((a, b) => rectArea(a) - rectArea(b));

    return nodes[0];
  }

  function findHeatPump(rootEl) {
    return (
      rootEl.querySelector(".f29-00012-heatpump") ||
      findByText(
        rootEl,
        ["TNG HE1500SI DUO 38KW", "AKTUÁLNÍ ELEKTRICKÝ PŘÍKON"]
      )
    );
  }

  function findBivalence(rootEl) {
    const direct=rootEl.querySelector(".f29-00012-bivalence");
    if(direct) return direct;
    return findByText(rootEl, ["BIVALENCE", "BLANSKO"]);
  }

  function findBoiler(rootEl) {
    const direct=rootEl.querySelector(".f29-00012-boiler");
    if(direct) return direct;
    return findByText(rootEl, ["BOJLER"], ["BIVALENCE"]);
  }

  function findAku(rootEl) {
    const direct=rootEl.querySelector(".f29-00012-accumulator");
    if(direct) return direct;
    return findByText(rootEl, ["AKU NÁDRŽ"]);
  }

  function findManifold(rootEl) {
    const direct=rootEl.querySelector(".f29-00012-distributor");
    if(direct) return direct;
    return findByText(rootEl, ["ROZDĚLOVAČ ÚT"]);
  }

  function findCircuit(rootEl, n) {
    const direct=rootEl.querySelectorAll(".f29-00012-zone-card")[n-1];
    if(direct) return direct;
    return findByText(rootEl, [`TOPNÝ OKRUH ${n}`]);
  }

  function ensureStyle() {
    const id = "f31-r68-powerlines-style";
    if (document.getElementById(id)) return;

    const style = document.createElement("style");
    style.id = id;

    style.textContent = `
      .f31-r68-powerline-svg {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        overflow: visible;
        pointer-events: none;
        z-index: 12;
      }

      .f31-r68-line {
        fill: none;
        stroke: #b8b8b8;
        stroke-width: 6;
        stroke-linecap: butt;
        stroke-linejoin: miter;
        vector-effect: non-scaling-stroke;
        opacity: .92;
        filter: drop-shadow(0 0 1px rgba(255,255,255,.10));
      }
    `;

    document.head.appendChild(style);
  }

  function ensureSvg(rootEl) {
    let svg = rootEl.querySelector(":scope > .f31-r68-powerline-svg");

    if (svg) return svg;

    if (getComputedStyle(rootEl).position === "static") {
      rootEl.style.position = "relative";
    }

    svg = document.createElementNS(NS, "svg");
    svg.classList.add("f31-r68-powerline-svg");
    svg.setAttribute("aria-hidden", "true");

    rootEl.appendChild(svg);

    return svg;
  }

  function line(svg, key, d) {
    let p = svg.querySelector(`[data-f31-r68="${key}"]`);

    if (!p) {
      p = document.createElementNS(NS, "path");
      p.setAttribute("class", "f31-r68-line");
      p.setAttribute("data-f31-r68", key);
      svg.appendChild(p);
    }

    p.setAttribute("d", d);
    p.style.display = "";
  }

  function hideUnused(svg, activeKeys) {
    for (const p of svg.querySelectorAll("[data-f31-r68]")) {
      if (!activeKeys.has(p.getAttribute("data-f31-r68"))) {
        p.style.display = "none";
      }
    }
  }

  function localRect(el, rr) {
    const r=el.getBoundingClientRect(), sx=rr._sx||1, sy=rr._sy||1;
    const left=(r.left-rr.left)/sx-(rr._bx||0), top=(r.top-rr.top)/sy-(rr._by||0);
    const width=r.width/sx, height=r.height/sy;
    return {left,top,right:left+width,bottom:top+height,cx:left+width/2,cy:top+height/2,width,height};
  }

  function sync() {
    ensureStyle();

    const rootEl = root();
    if (!rootEl) return false;

    const svg = ensureSvg(rootEl);
    const rr = rootEl.getBoundingClientRect();
    if(!rr.width || !rr.height) return false;
    rr._sx=rr.width/(rootEl.offsetWidth||rr.width);
    rr._sy=rr.height/(rootEl.offsetHeight||rr.height);
    rr._bx=rootEl.clientLeft-rootEl.scrollLeft; rr._by=rootEl.clientTop-rootEl.scrollTop;

    const hpEl = findHeatPump(rootEl);
    const bivEl = findBivalence(rootEl);
    const bojEl = findBoiler(rootEl);
    const akuEl = findAku(rootEl);
    const manEl = findManifold(rootEl);
    const c1El = findCircuit(rootEl, 1);
    const c2El = findCircuit(rootEl, 2);

    const active = new Set();

    const hp = hpEl ? localRect(hpEl, rr) : null;
    const biv = bivEl ? localRect(bivEl, rr) : null;
    const boj = bojEl ? localRect(bojEl, rr) : null;
    const aku = akuEl ? localRect(akuEl, rr) : null;
    const man = manEl ? localRect(manEl, rr) : null;
    const c1 = c1El ? localRect(c1El, rr) : null;
    const c2 = c2El ? localRect(c2El, rr) : null;

    /*
      USER REFERENCE:
      HP right edge -> horizontal bus to AKU centre.
      Drops down to BOJLER and AKU.
    */
    if (hp && (boj || aku)) {
      const busY = hp.top + hp.height * 0.78;
      const busStartX = hp.right;

      let busEndX = busStartX + 250;

      if (aku) busEndX = aku.cx;
      else if (boj) busEndX = boj.cx;

      line(
        svg,
        "hp-bus",
        `M ${busStartX.toFixed(1)} ${busY.toFixed(1)} H ${busEndX.toFixed(1)}`
      );
      active.add("hp-bus");

      if (boj) {
        line(
          svg,
          "hp-boiler-drop",
          `M ${boj.cx.toFixed(1)} ${busY.toFixed(1)} V ${boj.top.toFixed(1)}`
        );
        active.add("hp-boiler-drop");
      }

      if (aku) {
        line(
          svg,
          "hp-aku-drop",
          `M ${aku.cx.toFixed(1)} ${busY.toFixed(1)} V ${aku.top.toFixed(1)}`
        );
        active.add("hp-aku-drop");
      }
    }

    /* BIVALENCE -> BOJLER, edge to edge */
    if (biv && boj) {
      const y = biv.top + biv.height * 0.60;

      line(
        svg,
        "biv-boiler",
        `M ${biv.right.toFixed(1)} ${y.toFixed(1)} H ${boj.left.toFixed(1)}`
      );
      active.add("biv-boiler");
    }

    /* AKU -> ROZDĚLOVAČ, edge to edge */
    if (aku && man) {
      const y = aku.top + aku.height * 0.66;

      line(
        svg,
        "aku-manifold",
        `M ${aku.right.toFixed(1)} ${y.toFixed(1)} H ${man.left.toFixed(1)}`
      );
      active.add("aku-manifold");
    }

    /* TOPNÝ OKRUH 1 -> ROZDĚLOVAČ */
    if (c1 && man) {
      const x = Math.max(
        man.left + 12,
        Math.min(c1.cx, man.right - 12)
      );

      line(
        svg,
        "c1-manifold",
        `M ${x.toFixed(1)} ${c1.bottom.toFixed(1)} V ${man.top.toFixed(1)}`
      );
      active.add("c1-manifold");
    }

    /* TOPNÝ OKRUH 2 -> ROZDĚLOVAČ */
    if (c2 && man) {
      const x = Math.max(
        man.left + 12,
        Math.min(c2.cx, man.right - 12)
      );

      line(
        svg,
        "c2-manifold",
        `M ${x.toFixed(1)} ${c2.bottom.toFixed(1)} V ${man.top.toFixed(1)}`
      );
      active.add("c2-manifold");
    }

    hideUnused(svg, active);

    rootEl.setAttribute(
      "data-f31-r68-lines",
      String(active.size)
    );

    return active.size > 0;
  }

  let raf = 0;

  function schedule() {
    if (raf) return;

    raf = requestAnimationFrame(() => {
      raf = 0;
      sync();
    });
  }

  function boot() {
    sync();

    let attempts = 0;

    const timer = setInterval(() => {
      attempts += 1;

      if (sync() || attempts >= 30) {
        clearInterval(timer);
      }
    }, 250);

    window.addEventListener(
      "resize",
      schedule,
      { passive: true }
    );
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }

  // F31_R85_LIFECYCLE_PATCH: replay the existing visual operation on each schema mount.
  window.IQF_F31_R85_LAYOUT_HOOKS=window.IQF_F31_R85_LAYOUT_HOOKS||{};
  window.IQF_F31_R85_LAYOUT_HOOKS["R68"]=sync;
  document.dispatchEvent(new Event('iqf-f31-r85-layout-ready'));
})();
