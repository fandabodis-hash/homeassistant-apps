(() => {
  'use strict';
  const VERSION='F32.4F-R123';
  const API_VERSION='F32.4B-R120B';
  const PANEL='f32-r115-settings-workspace';
  const ROOT='[data-phase28-r177n107-workspace]';
  const UUID='28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc';
  const API='https://api.tngiqfanda.cz/api/v1';
  const ID='f32-r116-dhw-control';
  const FIELD_ID='f32-r120b-dhw-fields';
  if(window.IQF_F32_R123_DHW)return;
  // Replace only our existing DHW view; no menu/telemetry/heat-flow layer.
  if(window.IQF_F32_R120C_DHW?.dispose)window.IQF_F32_R120C_DHW.dispose();
  else if(window.IQF_F32_R120B_DHW?.dispose)window.IQF_F32_R120B_DHW.dispose();
  let panel=null, boxes=[], panelObserver=null, observer=null;
  let status=null, pending=false, fetching=false, timer=null, request=null, epoch=0, raf=0, stopped=false;
  let message='', dirty=false, draft={target_c:null,hysteresis_c:null,bivalence_c:null}, draftRevision=0, saveError=false;
  function visible(e){if(!e?.isConnected)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&!e.closest('[hidden],[aria-hidden="true"]');}
  // R116 / R119 / R115 context selection is deliberately unchanged.
  function context(){
    const state=window.IQF_F32_R115_SETTINGS?.diagnostics();
    if(!state||state.version!=='F32.2Q-R115-NATIVE-TAB-LIFECYCLE'||!state.open||state.nativeTab!=='settings')return null;
    const roots=[...document.querySelectorAll(ROOT)].filter(visible);if(roots.length!==1)return null;
    const root=roots[0],declared=root.getAttribute('data-device-uuid');if(declared&&declared!==UUID)return null;
    const source=(root.getAttribute('data-phase28-r177n107-source')||'').toLowerCase();let mode=null;
    if(/customer|client|portal/.test(source)&&!/^admin/.test(source))mode='portal';
    else if(/admin/.test(source))mode='admin';
    else if(/(^|\/)admin(?:\/|$)/.test(location.pathname))mode='admin';
    else if(/(^|\/)(portal|customer|client)(?:\/|$)/.test(location.pathname))mode='portal';
    if(!mode)return {error:'Nelze určit účet pracovní plochy.'};
    let token='';try{token=localStorage.getItem('iqfanda_access_token')||sessionStorage.getItem('iqfanda_access_token')||'';}catch(_){return {error:'Přihlášení není dostupné.'};}
    if(!token)return {error:'Přihlaste se znovu do portálu.'};
    return {mode,token,base:API+'/'+mode+'/devices/'+UUID+'/individual-project/'};
  }
  function same(ctx){const c=context();return c&&!c.error&&c.mode===ctx.mode&&c.token===ctx.token;}
  const phases={not_configured:'Automatika povolena – vyberte teplotu a hysterezi.',disabled:'Automatika vypnutá',
    disabling:'Vypínám ohřev…',evaluating:'Vyhodnocuji teplotu…',heating:'Ohřívá',waiting:'Čeká na pokles teploty',
    starting:'Zapínám oba stupně…',stopping:'Vypínám zdroj TUV…',restart_hold:'Čeká na ochrannou prodlevu',
    heating_bivalence:'Ohřívá bivalentní zdroj',source_switch_on:'Zapínám vybraný zdroj…',source_switch_off:'Vypínám zdroj…',source_break_before_make:'Bezpečně přepínám zdroj…',weather_wait:'Čekám na aktuální Open-Meteo',
    sensor_fault:'Teplota není aktuální – ohřev blokován',fault:'Porucha regulace – zkontrolujte stav',
    external_control:'Jiné řízení převzalo spínače',remote_disabled:'Vzdálené ovládání zakázáno',
    off_not_confirmed:'Vypnutí nebylo potvrzeno – ověřte zařízení'};
  const errors={DHW_AUTOMATION_DISABLED:'Ohřev teplé vody je vypnutý. Nastavení zůstává uložené.',DHW_SETTINGS_REQUIRED:'Nejprve vyberte teplotu a hysterezi.',DHW_SETTINGS_RANGE:'Teplota musí být 5–50 °C a hystereze 1–10 °C.',
    DHW_SETTINGS_CONFLICT:'Nastavení mezitím změnil jiný uživatel. Obnovuji hodnoty.',
    DHW_FIRST_SETUP_REQUIRES_OFF:'První nastavení vyžaduje oba stupně vypnuté.',
    DHW_SENSOR_UNAVAILABLE:'Čidlo nemá platnou aktuální teplotu; zapnutí je blokované.',
    DHW_MASTER_DISABLED:'Hlavní zdroj tepla je vypnutý.',DHW_REMOTE_COMMANDS_DISABLED:'Vzdálené ovládání není povolené.',
    DHW_COMMAND_IN_PROGRESS:'Předchozí příkaz stále probíhá.',DHW_CONTROL_CONFLICT:'Stejné spínače už používá jiné řízení.',
    DHW_BIVALENCE_RANGE:'Bod bivalence musí být od -8 do +8 °C.',DHW_BIVALENCE_UNAVAILABLE:'Spínač bivalence není dostupný.',DHW_BIVALENCE_IDENTITY_CHANGED:'Nesouhlasí identita spínače bivalence.',DHW_BIVALENCE_ENTITY_CHANGED:'Nesouhlasí ovládací entita bivalence.'};
  function errorText(e){return errors[e?.code]||(e?.status===401?'Přihlaste se znovu.':e?.status===403?'Účet nemá oprávnění k ovládání.':
    e?.status===404?'Rozhraní regulace zatím není dostupné.':'Požadavek nebyl potvrzen. Neopakuje se automaticky; zkontrolujte stav.');}
  async function api(ctx,path,method,body,signal){
    const r=await fetch(ctx.base+path,{method,signal,cache:'no-store',credentials:'omit',redirect:'error',
      headers:{Authorization:'Bearer '+ctx.token,Accept:'application/json',...(body?{'Content-Type':'application/json'}:{})},
      ...(body?{body:JSON.stringify(body)}:{})});
    const v=await r.json().catch(()=>null);if(!r.ok)throw {status:r.status,code:v?.detail?.code};
    if(![API_VERSION,VERSION,'F32.3B-R116'].includes(v?.version)||v?.device_uuid!==UUID||typeof v.enabled!=='boolean'||!Array.isArray(v.stages))throw {code:'BAD_RESPONSE'};
    return v;
  }
  function text(e,value){if(e&&e.textContent!==value)e.textContent=value;}
  function fmt(n){return typeof n==='number'&&Number.isFinite(n)?n.toLocaleString('cs-CZ',{maximumFractionDigits:1})+' °C':'Nedostupná';}
  function childrenEnabled(){return status?.enabled===true&&status?.can_save===true;}
  function render(){
    if(boxes.length!==4)return;
    const [first,second,third,fourth]=boxes;
    const sw=first.querySelector('input');sw.checked=status?.enabled===true;sw.indeterminate=false;
    sw.disabled=pending||!status||(sw.checked?!status.can_turn_off:(!status.can_turn_on||dirty));
    first.querySelector('[data-off]').disabled=pending||!status?.can_turn_off;
    first.querySelector('[data-on]').disabled=pending||!status?.can_turn_on||dirty;
    const physical=(status?.stages||[]).map(r=>r.stage+'. stupeň: '+(r.state==='on'?'zapnuto':r.state==='off'?'vypnuto':'nedostupný')).join(' · ');
    const biv=status?.bivalence;
    const bivText=status?.bivalence_regulation?' · bivalence: '+(biv?.state==='on'?'zapnuto':biv?.state==='off'?'vypnuto':'nedostupná'):'';
    text(first.querySelector('.status'),message||(pending?'Ukládám…':phases[status?.phase]||'Načítám regulaci…'));
    text(first.querySelector('.physical'),physical+bivText);
    for(const [key,box] of [['target_c',second],['hysteresis_c',third],['bivalence_c',fourth]]){
      const select=box.querySelector('select'),value=draft[key];
      if(select.value!==(value==null?'':String(value)))select.value=value==null?'':String(value);
      select.disabled=pending||!childrenEnabled();
      box.dataset.dhwInactive=childrenEnabled()?'false':'true';
      box.setAttribute('aria-disabled',childrenEnabled()?'false':'true');
      select.title=childrenEnabled()?'':'Neaktivní – zapněte Ohřev teplé vody.';
    }
    const actual=status?.temperature;
    text(second.querySelector('.detail'),'Aktuální teplota: '+fmt(actual?.value_c)+(actual&&!actual.valid?' · údaj není platný/aktuální':''));
    text(third.querySelector('.detail'),dirty?'Výběr ještě není uložen.':status?.configured?
      'Dohřát na '+fmt(status.target_c)+' · znovu zapnout při '+fmt(status.restart_temperature_c):
      status?.enabled?'Vyberte teplotu a hysterezi; uloží se společně.':'Nejprve zapněte Ohřev teplé vody.');
    const weather=status?.outdoor_temperature;
    const source=status?.selected_source==='bivalence'?'Bivalence':status?.selected_source==='heat_pump'?'Tepelné čerpadlo':'Čekám';
    text(fourth.querySelector('.detail'),dirty?'Výběr ještě není uložen.':
      status?.bivalence_c==null?'Vyberte bod bivalence.':
      weather?.valid?'Open-Meteo: '+fmt(weather.value_c)+' · zdroj TUV: '+source:
      'Open-Meteo není aktuální – zdroj se nepřepíná.');
    if(status&&!status.enabled){
      text(third.querySelector('.detail'),'Neaktivní – Ohřev teplé vody je vypnutý.'+(status.configured?' Nastavení zůstává uložené.':''));
      text(fourth.querySelector('.detail'),'Neaktivní – Ohřev teplé vody je vypnutý.'+(status?.bivalence_c!=null?' Bod bivalence zůstává uložený.':''));
    }
    const retry=third.querySelector('button');retry.hidden=!(childrenEnabled()&&saveError&&dirty&&draft.target_c!=null&&draft.hysteresis_c!=null);
    retry.disabled=pending||!childrenEnabled();
    for(const box of boxes)box.setAttribute('aria-busy',pending?'true':'false');
  }
  function accept(value){
    // OFF from any authorized tab wins over an unsaved local draft. Saved
    // server values are retained; they never become zeros/defaults on OFF.
    if(!value.enabled){dirty=false;saveError=false;}
    status=value;if(!dirty){draft={target_c:value.target_c,hysteresis_c:value.hysteresis_c,bivalence_c:value.bivalence_c??null};draftRevision=value.revision;}render();
  }
  function schedule(ms){clearTimeout(timer);timer=setTimeout(()=>{timer=null;refresh();},ms);}
  async function refresh(){
    if(fetching||pending||stopped)return;
    const ctx=context();if(!ctx||document.hidden)return;
    if(ctx.error){status=null;message=ctx.error;render();return;}
    fetching=true;const own=++epoch;request=new AbortController();const abort=request;
    const timeout=setTimeout(()=>abort.abort(),12000);
    try{const v=await api(ctx,'dhw-thermostat-v1','GET',null,abort.signal);if(own===epoch&&same(ctx)){message='';accept(v);}}
    catch(e){if(own===epoch){status=null;message=errorText(e);render();}}
    finally{clearTimeout(timeout);fetching=false;if(own===epoch&&!stopped&&same(ctx)&&!document.hidden)schedule(5000);else if(!stopped&&context()&&!document.hidden&&!pending)wake();}
  }
  async function write(path,body,kind){
    const ctx=context();if(!ctx||ctx.error||pending||!status)return;
    if(kind==='settings'&&!childrenEnabled())return;
    if(!crypto?.randomUUID){message='Ovládání vyžaduje HTTPS.';render();return;}
    clearTimeout(timer);timer=null;epoch++;request?.abort();pending=true;message='';render();
    const abort=new AbortController(),timeout=setTimeout(()=>abort.abort(),20000);
    try{
      const v=await api(ctx,path,'PUT',{...body,request_id:crypto.randomUUID()},abort.signal);
      if(same(ctx)){
        if(kind==='settings'){dirty=false;saveError=false;message='Nastavení uloženo.';}
        else message=v.enabled?'Automatika zapnutá.':'Automatika vypnutá; čekám na potvrzení relé.';
        accept(v);
      }
    }catch(e){
      if(same(ctx)){message=errorText(e);saveError=kind==='settings';
        if(e?.code==='DHW_SETTINGS_CONFLICT'){dirty=false;saveError=false;}}
    }finally{clearTimeout(timeout);pending=false;render();if(same(ctx))schedule(1000);}
  }
  function changeEnabled(enabled){
    if(pending||!status||!(enabled?status.can_turn_on&&!dirty:status.can_turn_off))return;
    write('dhw-two-stage-v1',{enabled},'enabled');
  }
  function changeField(key,value){
    if(!status||pending||!childrenEnabled()){render();return;}
    if(!dirty)draftRevision=status.revision;
    draft[key]=value===''?null:Number(value);dirty=true;saveError=false;message='';render();
    if(draft.target_c!=null&&draft.hysteresis_c!=null)save();
  }
  function save(){if(childrenEnabled()&&draft.target_c!=null&&draft.hysteresis_c!=null){
    const body={target_c:draft.target_c,hysteresis_c:draft.hysteresis_c,expected_revision:draftRevision};
    if(draft.bivalence_c!=null)body.bivalence_c=draft.bivalence_c;
    write('dhw-thermostat-v1',body,'settings');
  }}
  function node(tag,cls,value){const n=document.createElement(tag);if(cls)n.className=cls;if(value!=null)n.textContent=value;return n;}
  function style(){
    if(document.getElementById(FIELD_ID+'-style'))return;
    const s=node('style');s.id=FIELD_ID+'-style';s.textContent=`
      [data-r120b-row]{display:flex;flex-direction:column;justify-content:center;gap:5px;height:100%;box-sizing:border-box;padding:7px 13px;color:#edfaff;min-width:0;font:inherit}
      [data-r120b-row] .main{display:flex;align-items:center;justify-content:space-between;gap:9px;min-width:0}
      [data-r120b-row] .title{font-weight:850;font-size:clamp(12px,.95vw,17px);line-height:1.2}
      [data-r120b-row] .controls{display:flex;align-items:center;gap:6px;flex-shrink:0}
      [data-r120b-row] .detail,[data-r120b-row] .status,[data-r120b-row] .physical{font-size:10px;line-height:1.15;color:#a3c5d0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      [data-r120b-row] .status{color:#7edbce}
      [data-r120b-row] select{font:inherit;font-size:13px;color:#eefcff;background:#092c3a;border:1px solid #3086a1;border-radius:7px;padding:5px 8px;width:122px;max-width:42%;min-width:100px;cursor:pointer}
      [data-r120b-row] select:focus-visible{outline:2px solid #69dfff;outline-offset:2px}
      [data-r120b-row] select option{background:#092c3a;color:#fff}
      [data-r120b-row] .toggle{position:relative;width:48px;height:27px;display:inline-block;flex-shrink:0}
      [data-r120b-row] input{position:absolute;inset:0;width:100%;height:100%;margin:0;opacity:0;z-index:2;cursor:pointer}
      [data-r120b-row] .track{display:block;width:100%;height:100%;border-radius:20px;background:#24404c;border:1px solid #557786;box-sizing:border-box}
      [data-r120b-row] .track::after{content:'';display:block;width:19px;height:19px;margin:3px;border-radius:50%;background:#b6d8e3;transition:transform .15s}
      [data-r120b-row] input:checked+.track{background:#12675f;border-color:#47d6be}
      [data-r120b-row] input:checked+.track::after{transform:translateX(21px);background:#a3fff0}
      [data-r120b-row] input:focus-visible+.track{outline:2px solid #67dcff;outline-offset:3px}
      [data-r120b-row] input:disabled{cursor:not-allowed}
      [data-r120b-row] input:disabled+.track{opacity:.5}
      [data-r120b-row] button{font:inherit;font-size:10px;color:#cae5ed;border:0;background:transparent;cursor:pointer;padding:4px 2px}
      [data-r120b-row] button:disabled,[data-r120b-row] select:disabled{opacity:.5;cursor:not-allowed}
      [data-r120b-row][data-dhw-inactive="true"] .title{opacity:.55}
      [data-r120b-row][data-dhw-inactive="true"] .detail{opacity:.7}
      @media(max-width:1400px){[data-r120b-row]{padding:6px 9px}}
    `;document.head.appendChild(s);
  }
  function build(){
    const first=node('div');first.id=ID;first.dataset.r120bRow='1';first.dataset.version=VERSION;
    const main=node('div','main'),controls=node('div','controls');
    const off=node('button','','Vypnuto');off.type='button';off.dataset.off='';off.addEventListener('click',()=>changeEnabled(false));
    const on=node('button','','Zapnuto');on.type='button';on.dataset.on='';on.addEventListener('click',()=>changeEnabled(true));
    const lab=node('label','toggle'),sw=node('input');sw.type='checkbox';sw.setAttribute('aria-label','Ohřev teplé vody – automatická regulace');sw.disabled=true;
    sw.addEventListener('change',()=>{const value=sw.checked;render();changeEnabled(value);});lab.append(sw,node('span','track'));
    controls.append(off,lab,on);main.append(node('span','title','Ohřev teplé vody'),controls);
    const st=node('div','status');st.setAttribute('role','status');st.setAttribute('aria-live','polite');
    first.append(main,st,node('div','physical'));
    const extra=[];
    for(const [row,title,key,lo,hi] of [[2,'Nastavení teploty','target_c',5,50],[3,'Hystereze','hysteresis_c',1,10],[4,'Bod bivalence','bivalence_c',-8,8]]){
      const box=node('div');box.id=FIELD_ID+'-'+row;box.dataset.r120bRow=String(row);
      const line=node('div','main'),lbl=node('label','title',title),select=node('select');select.id=FIELD_ID+'-'+key;
      select.name=key;lbl.htmlFor=select.id;select.setAttribute('aria-label',title);
      const empty=node('option','','Vyberte…');empty.value='';select.append(empty);
      for(let i=lo;i<=hi;i++){const prefix=key==='target_c'?'+':key==='bivalence_c'&&i>0?'+':'';const op=node('option','',prefix+i+' °C');op.value=String(i);select.append(op);}
      select.addEventListener('change',()=>changeField(key,select.value));line.append(lbl,select);box.append(line,node('div','detail'));
      if(row===3){const retry=node('button','','Uložit znovu');retry.type='button';retry.hidden=true;retry.addEventListener('click',save);box.append(retry);}
      extra.push(box);
    }
    return [first,...extra];
  }
  function sync(){
    raf=0;if(stopped)return;
    const p=document.getElementById(PANEL);
    if(panel!==p){panelObserver?.disconnect();panel=p;if(panel){panelObserver=new MutationObserver(wake);panelObserver.observe(panel,{attributes:true,attributeFilter:['data-open'],childList:true});}}
    if(panel){
      const targets=[1,2,3,4].map(n=>panel.querySelector('[data-settings-column="boiler"] [data-setting-slot="boiler-0'+n+'"]'));
      if(targets.every(Boolean)&&(!boxes.length||boxes.some((box,i)=>box.parentNode!==targets[i]))){
        // Never overwrite unrelated slot content, the menu or heating control.
        if(targets.every((slot,i)=>!slot.children.length||[...slot.children].every(c=>c===boxes[i]))){
          boxes.forEach(b=>b.remove());boxes=build();targets.forEach((slot,i)=>slot.append(boxes[i]));style();render();
        }
      }
    }
    const ctx=context();
    if(ctx&&panel?.dataset.open==='true'&&!document.hidden){if(!timer&&!fetching&&!pending)refresh();}
    else{clearTimeout(timer);timer=null;epoch++;request?.abort();status=null;message='';dirty=false;draft={target_c:null,hysteresis_c:null,bivalence_c:null};render();}
  }
  function wake(){if(!stopped&&!raf)raf=requestAnimationFrame(sync);}
  function boot(){
    observer=new MutationObserver(records=>{if(records.some(r=>[...r.addedNodes,...r.removedNodes].some(n=>n.nodeType===1&&
      (n.id===PANEL||n.querySelector?.('#'+PANEL)||n.matches?.('[data-setting-slot]')))))wake();});
    observer.observe(document.body,{childList:true,subtree:true});
    for(const e of ['pageshow','popstate','hashchange','storage'])window.addEventListener(e,wake);
    document.addEventListener('visibilitychange',wake);wake();
  }
  const facade=Object.freeze({version:VERSION,refresh,diagnostics:()=>({version:VERSION,mounted:boxes.every(b=>b.isConnected)&&boxes.length===4,
    enabled:status?.enabled??null,phase:status?.phase||null,configured:status?.configured??false}),
    dispose:()=>{stopped=true;clearTimeout(timer);request?.abort();observer?.disconnect();panelObserver?.disconnect();boxes.forEach(b=>b.remove());}});
  window.IQF_F32_R123_DHW=facade;window.IQF_F32_R120C_DHW=facade;window.IQF_F32_R120B_DHW=facade;window.IQF_F32_R116_DHW=facade;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
