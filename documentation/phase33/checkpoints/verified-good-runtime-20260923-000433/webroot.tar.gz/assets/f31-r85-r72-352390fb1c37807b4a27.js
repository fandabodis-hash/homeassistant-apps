(() => {
  "use strict";

  const MARK = "__IQF_F31_R72_HEATING_CIRCUITS_EAST_WEST__";
  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  if (window[MARK]) return;
  window[MARK] = true;

  const CONFIG = Object.freeze([
    {
      oldTitle: "TOPNÝ OKRUH 1",
      newTitle: "TOPNÝ OKRUH VÝCHOD"
    },
    {
      oldTitle: "TOPNÝ OKRUH 2",
      newTitle: "TOPNÝ OKRUH ZÁPAD"
    }
  ]);

  function norm(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function root() {
    return document.querySelector(ROOT_SELECTOR);
  }

  function findCard(rootEl, title) {
    const direct=Array.from(rootEl.querySelectorAll(".f29-00012-zone-card")).find(el=>norm(el.textContent).includes(norm(title)));
    if(direct) return direct;
    const wanted = norm(title);

    const candidates = Array.from(
      rootEl.querySelectorAll("article,section,div")
    ).filter((el) => {
      const text = norm(el.textContent);

      if (!text.includes(wanted)) return false;

      const r = el.getBoundingClientRect();

      return (
        r.width >= 140 &&
        r.width <= 430 &&
        r.height >= 100 &&
        r.height <= 350
      );
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      return (
        (ar.width * ar.height) -
        (br.width * br.height)
      );
    });

    return candidates[0];
  }

  function replaceExactText(rootEl, oldText, newText) {
    const wanted = norm(oldText);

    const walker = document.createTreeWalker(
      rootEl,
      NodeFilter.SHOW_TEXT
    );

    let node = walker.nextNode();

    while (node) {
      if (norm(node.nodeValue) === wanted) {
        node.nodeValue = newText;
        return true;
      }

      node = walker.nextNode();
    }

    return false;
  }

  function removeFlameGlyphs(card) {
    const walker = document.createTreeWalker(
      card,
      NodeFilter.SHOW_TEXT
    );

    const nodes = [];

    let node = walker.nextNode();

    while (node) {
      if (
        /🔥|♨|♨️/u.test(
          String(node.nodeValue || "")
        )
      ) {
        nodes.push(node);
      }

      node = walker.nextNode();
    }

    for (const textNode of nodes) {
      textNode.nodeValue =
        String(textNode.nodeValue || "")
          .replace(/🔥|♨️?|♨/gu, "");
    }
  }

  function headingElement(card, title) {
    const wanted = norm(title);

    const candidates = Array.from(
      card.querySelectorAll(
        "h1,h2,h3,h4,strong,b,div,span"
      )
    ).filter((el) => {
      const text = norm(el.textContent);

      return text === wanted;
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      return (
        (ar.width * ar.height) -
        (br.width * br.height)
      );
    });

    return candidates[0];
  }

  function findTopIconBox(card, heading) {
    const direct=card.querySelector(".f29-00012-zone-icon");
    if(direct) return direct;
    const cr = card.getBoundingClientRect();
    const hr = heading
      ? heading.getBoundingClientRect()
      : null;

    const candidates = Array.from(
      card.querySelectorAll("button,div,span")
    ).filter((el) => {
      if (
        heading &&
        (
          el === heading ||
          el.contains(heading)
        )
      ) {
        return false;
      }

      const r = el.getBoundingClientRect();

      const compact =
        r.width >= 30 &&
        r.width <= 100 &&
        r.height >= 20 &&
        r.height <= 70;

      const nearTop =
        r.top >= cr.top + 5 &&
        r.top <= cr.top + 95;

      const aboveHeading =
        !hr ||
        r.bottom <= hr.top + 10;

      const nearCenter =
        Math.abs(
          (r.left + r.width / 2) -
          (cr.left + cr.width / 2)
        ) <= cr.width * 0.34;

      return (
        compact &&
        nearTop &&
        aboveHeading &&
        nearCenter
      );
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      const cardCx =
        cr.left + cr.width / 2;

      const da =
        Math.abs(
          ar.left +
          ar.width / 2 -
          cardCx
        );

      const db =
        Math.abs(
          br.left +
          br.width / 2 -
          cardCx
        );

      if (da !== db) return da - db;

      return ar.top - br.top;
    });

    return candidates[0];
  }

  function ensureStyle() {
    const id =
      "f31-r72-heating-circuit-style";

    if (document.getElementById(id)) return;

    const style =
      document.createElement("style");

    style.id = id;

    style.textContent = `
      ${ROOT_SELECTOR}
      .f31-r72-pump-icon-box {
        width: 48px !important;
        height: 48px !important;
        min-width: 48px !important;
        min-height: 48px !important;
        max-width: 48px !important;
        max-height: 48px !important;

        box-sizing: border-box !important;

        display: grid !important;
        place-items: center !important;

        border: 1px solid #63dbff !important;
        border-radius: 50% !important;

        background: rgba(2,31,47,.88) !important;

        color: #63dbff !important;

        overflow: hidden !important;
        position: relative !important;

        box-shadow:
          0 0 12px rgba(72,216,255,.18),
          inset 0 0 9px rgba(72,216,255,.07) !important;
      }

      ${ROOT_SELECTOR}
      .f31-r72-pump-icon-box > * {
        display: none !important;
      }

      ${ROOT_SELECTOR}
      .f31-r72-pump-icon-box::before {
        content: "\\21BB";

        display: grid;
        place-items: center;

        width: 100%;
        height: 100%;

        color: #63dbff;

        font-size: 1.55rem;
        font-weight: 900;
        line-height: 1;

        text-shadow:
          0 0 7px rgba(72,216,255,.36);

        pointer-events: none;
      }

      ${ROOT_SELECTOR}
      [data-f31-r72-card="east"],
      ${ROOT_SELECTOR}
      [data-f31-r72-card="west"] {
        overflow: visible !important;
      }
    `;

    document.head.appendChild(style);
  }

  function cleanupOldPumpPseudo(card) {
    /*
      R71 created the pump through a class on the previous
      flame icon box. Reuse the same box, but remove the
      old class so only R72 controls its appearance.
    */
    for (
      const el of card.querySelectorAll(
        ".f31-r71-circuit-pump-icon-box"
      )
    ) {
      el.classList.remove(
        "f31-r71-circuit-pump-icon-box"
      );
    }
  }

  function applyCard(card, cfg, key) {
    if (!card) return false;

    cleanupOldPumpPseudo(card);
    removeFlameGlyphs(card);

    replaceExactText(
      card,
      cfg.oldTitle,
      cfg.newTitle
    );

    let heading =
      headingElement(
        card,
        cfg.newTitle
      );

    if (!heading) {
      heading =
        headingElement(
          card,
          cfg.oldTitle
        );
    }

    const iconBox =
      findTopIconBox(
        card,
        heading
      );

    if (!iconBox) return false;

    /*
      Completely clear the old flame content.
      The surrounding box itself is reused so its placement
      stays identical to the original card layout.
    */
    if (iconBox.childNodes.length) iconBox.replaceChildren();

    iconBox.classList.add(
      "f31-r72-pump-icon-box"
    );

    iconBox.setAttribute(
      "data-f31-r72-icon",
      "circulation-pump"
    );

    card.setAttribute(
      "data-f31-r72-card",
      key
    );

    return true;
  }

  function apply() {
    ensureStyle();

    const rootEl = root();

    if (!rootEl) return false;

    let count = 0;

    const east =
      findCard(
        rootEl,
        CONFIG[0].oldTitle
      ) ||
      findCard(
        rootEl,
        CONFIG[0].newTitle
      );

    const west =
      findCard(
        rootEl,
        CONFIG[1].oldTitle
      ) ||
      findCard(
        rootEl,
        CONFIG[1].newTitle
      );

    if (
      applyCard(
        east,
        CONFIG[0],
        "east"
      )
    ) {
      count += 1;
    }

    if (
      applyCard(
        west,
        CONFIG[1],
        "west"
      )
    ) {
      count += 1;
    }

    rootEl.setAttribute(
      "data-f31-r72-cards",
      String(count)
    );

    return count === 2;
  }

  function boot() {
    apply();

    let attempts = 0;

    const timer =
      window.setInterval(() => {
        attempts += 1;

        if (
          apply() ||
          attempts >= 24
        ) {
          window.clearInterval(timer);
        }
      }, 250);
  }

  if (
    document.readyState === "loading"
  ) {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }

  // F31_R85_LIFECYCLE_PATCH: replay the existing visual operation on each schema mount.
  window.IQF_F31_R85_LAYOUT_HOOKS=window.IQF_F31_R85_LAYOUT_HOOKS||{};
  window.IQF_F31_R85_LAYOUT_HOOKS["R72"]=apply;
  document.dispatchEvent(new Event('iqf-f31-r85-layout-ready'));
})();
