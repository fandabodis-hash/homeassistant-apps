/* F30.4C R4. Compatibility export; all slots use the shared SEB-01 reader.
 * This changes data subscriptions only, not the existing span/card structure.
 */
export const R34_TARGET_UUID = '28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc';
const SLOT = 'current-electric-power';
export function decodeR34Value(data) {
  const e=data&&data.values&&data.values[SLOT];
  if(!data||String(data.device_uuid).toLowerCase()!==R34_TARGET_UUID) throw new Error('WRONG_DEVICE');
  if(!e||e.has_value!==true||e.available===false) throw new Error('VALUE_UNAVAILABLE');
  const v=typeof e.value==='number'?e.value:typeof e.value==='string'&&/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:e[+-]?\d+)?$/i.test(e.value.trim())?Number(e.value.replace(',','.')):NaN;
  if(!Number.isFinite(v)||!['W','kW'].includes(e.unit)) throw new Error('VALUE_INVALID');
  return {kw:e.unit==='W'?v/1000:v,updatedAt:String(e.updated_at||''),status:e.status};
}
export function F30R34BoundPower({React,token,deviceUuid,apiBase,source}) {
  const identity=String(deviceUuid||'').trim();
  const uuid=identity.toUpperCase()==='F800711-TNG-00012'?R34_TARGET_UUID:identity.toLowerCase();
  const admin=String(source||'').toLowerCase().includes('admin') ||
    (typeof window!=='undefined' && /(?:^|\/)admin(?:\/|$)/i.test(window.location.pathname));
  const access=typeof token==='string'?token.trim().replace(/^Bearer\s+/i,''):'';
  const base=typeof apiBase==='string'?apiBase.trim().replace(/\/+$/,''):null;
  const [snapshot,setSnapshot]=React.useState(null);
  const node=React.useRef(null), generation=React.useRef(0);
  const runtime=typeof window!=='undefined'?window.IQF_SEB01_RUNTIME:null;
  React.useEffect(()=>{
    let stop=null,disposed=false; const n=++generation.current;
    setSnapshot(null);
    try {
      if(!runtime||runtime.version!=='F30.4C-R5-PERSISTED-READER') throw new Error('RUNTIME_NOT_LOADED');
      stop=runtime.acquire({deviceUuid:uuid,token:access,apiBase:base,admin},s=>{
        if(!disposed&&generation.current===n) setSnapshot({state:s,uuid,access,base});
      });
    } catch(e) {
      setSnapshot({state:{error:e.message,values:{}},uuid,access,base});
    }
    return()=>{disposed=true;generation.current+=1;if(stop) stop();};
  },[runtime,uuid,access,base,admin]);
  const validContext=snapshot&&snapshot.uuid===uuid&&snapshot.access===access&&snapshot.base===base;
  const state=validContext?snapshot.state:null;
  const entry=state&&state.values&&state.values[SLOT]||{has_value:false,value:null,status:state&&state.error||'unbound'};
  const label=runtime?runtime.format(entry,'kW',3):'\u2014 kW';
  const hint=runtime?runtime.hint(entry):'SEB-01: datov\u00e1 slu\u017eba nen\u00ed na\u010dtena.';
  function download(event) {
    if(!admin||!runtime) return;event.preventDefault();event.stopPropagation();
    const details={...runtime.diagnostics(),renderedPower:node.current?node.current.textContent:null,
      browserRendered:true,physicalMeasurementAndEndToEnd20sVerified:false};
    const blob=new Blob([JSON.stringify(details,null,2)],{type:'text/plain;charset=utf-8'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;
    a.download='F30_04C_R4_BROWSER_'+new Date().toISOString().replace(/[:.]/g,'-')+'.txt';
    a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function openPicker(event) {
    event.preventDefault();event.stopPropagation();
    if(runtime&&admin) runtime.openSourcePicker(SLOT,event.currentTarget);
  }
  return React.createElement('span',{ref:node,title:hint,'data-f30-r34-bound-power':SLOT,
    'data-f30-r34-status':String(entry.status||''),onDoubleClick:admin?download:undefined},
    React.createElement('span',{'data-seb01-power-value':'true'},label),
    admin ? React.createElement('button',{type:'button',onClick:openPicker,
      'data-seb01-power-source':'true',title:'Vybrat elektrom\u011br / entitu \u010dinn\u00e9ho v\u00fdkonu',
      style:{font:'inherit',fontSize:'0.7em',marginLeft:6,padding:'2px 4px',border:'1px solid currentColor',
        borderRadius:4,color:'inherit',background:'transparent',cursor:'pointer'}},'Elektrom\u011br') : null);

}
