(() => {
  "use strict";

  const runtime = window.IQF_SEB01_RUNTIME;
  const EXPECTED_RUNTIME = "F30.4C-R5-PERSISTED-READER";
  const DEVICE_UUID = "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc";

  if (!runtime || runtime.version !== EXPECTED_RUNTIME) {
    console.warn("R43: shared SEB-01 runtime is not available");
    return;
  }

  const CONFIG = Object.freeze([
    {
      domSlot: "heatpump-stage-1-heating",
      slot: "heatpump-stage-1-heating-state",
      title: "Tepelné čerpadlo 1 / Vytápění"
    },
    {
      domSlot: "heatpump-stage-1-dhw",
      slot: "heatpump-stage-1-dhw-state",
      title: "Tepelné čerpadlo 1 / Ohřev vody"
    },
    {
      domSlot: "heatpump-stage-2-heating",
      slot: "heatpump-stage-2-heating-state",
      title: "Tepelné čerpadlo 2 / Vytápění"
    },
    {
      domSlot: "heatpump-stage-2-dhw",
      slot: "heatpump-stage-2-dhw-state",
      title: "Tepelné čerpadlo 2 / Ohřev vody"
    }
  ]);

  function normalizeState(entry) {
    const e = entry && typeof entry === "object" ? entry : {};
    const status = String(e.status || "").trim().toLowerCase();

    if (e.available === false || status === "unavailable" || status === "offline") {
      return { text: "Nedostupné", state: "unavailable" };
    }

    if (
      e.has_value !== true ||
      [
        "unknown",
        "unbound",
        "snapshot_only",
        "api_stale",
        "no_context",
        "loading"
      ].includes(status) ||
      /^(http_|request_|wrong_device|context_)/.test(status)
    ) {
      return { text: "—", state: "unknown" };
    }

    const v = e.value;

    if (
      v === true ||
      v === 1 ||
      (typeof v === "string" && /^(on|true|1|zapnuto)$/i.test(v.trim()))
    ) {
      return { text: "zapnuto", state: "on" };
    }

    if (
      v === false ||
      v === 0 ||
      (typeof v === "string" && /^(off|false|0|vypnuto)$/i.test(v.trim()))
    ) {
      return { text: "vypnuto", state: "off" };
    }

    return { text: "—", state: "unknown" };
  }

  function locate(cfg) {
    const box = document.querySelector(
      '[data-f29-00012-schema="svj-blansko-only"] ' +
      '[data-f31-r40-future-seb-slot="' + cfg.domSlot + '"]'
    );

    const card = box && box.closest(".f29-00012-heatpump");
    return card ? { card, box } : null;
  }

  function ensureStyle() {
    const id = "f31-r43-heatpump-uzv-seb01b-style";
    if (document.getElementById(id)) return;

    const style = document.createElement("style");
    style.id = id;
    style.textContent = `
      [data-f31-r43-seb01b-value] {
        box-sizing: border-box;
      }

      button[data-f31-r43-seb01b-value] {
        min-width: 66px;
        max-width: 74px;
        height: 25px;
        padding: 0 6px;
        border: 1px solid rgba(78, 216, 255, .7);
        border-radius: 6px;
        background: rgba(2, 35, 52, .96);
        color: #dff8ff;
        font: inherit;
        font-size: 10px;
        font-weight: 900;
        line-height: 1;
        cursor: pointer;
        white-space: nowrap;
      }

      button[data-f31-r43-seb01b-value]:hover {
        background: rgba(5, 63, 88, .98);
        box-shadow: 0 0 10px rgba(45, 208, 255, .22);
      }

      strong[data-f31-r43-seb01b-value] {
        min-width: 66px;
        text-align: right;
        color: #dff8ff;
        font: inherit;
        font-weight: 900;
        white-space: nowrap;
      }

      [data-f31-r43-state="on"] {
        color: #ff4d59 !important;
      }

      [data-f31-r43-state="off"] {
        color: #dff8ff !important;
      }

      [data-f31-r43-state="unavailable"] {
        color: #91a9b4 !important;
      }
    `;
    document.head.appendChild(style);
  }

  function renderValue(cfg, entry) {
    const target = locate(cfg);
    if (!target) return;

    const box = target.box;
    const value = normalizeState(entry);
    const admin = runtime.isAdmin();

    const desiredTag = admin ? "BUTTON" : "STRONG";
    let node = box.querySelector("[data-f31-r43-seb01b-value]");

    if (!node || node.tagName !== desiredTag) {
      const replacement = document.createElement(admin ? "button" : "strong");

      if (admin) {
        replacement.type = "button";
        replacement.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();

          if (!runtime.isAdmin()) return;
          void runtime.openSourcePicker(cfg.slot, replacement);
        });
      }

      replacement.setAttribute("data-f31-r43-seb01b-value", cfg.slot);
      box.replaceChildren(replacement);
      node = replacement;
    }

    node.setAttribute("data-f31-r43-state", value.state);
    node.setAttribute("data-seb01-slot", cfg.slot);

    if (admin) {
      const isUnbound = String((entry && entry.status) || "").toLowerCase() === "unbound";
      const label = isUnbound ? "Vybrat" : value.text;

      if (node.textContent !== label) node.textContent = label;

      node.title =
        "UZV / SEB-01B — vybrat nebo změnit Zigbee entitu: " + cfg.title;

      node.setAttribute(
        "aria-label",
        "Vybrat Zigbee entitu — " + cfg.title
      );
    } else {
      if (node.textContent !== value.text) node.textContent = value.text;
      node.title = cfg.title + ": " + value.text;
    }
  }

  ensureStyle();

  for (const cfg of CONFIG) {
    try {
      runtime.registerAdapter({
        deviceUuid: DEVICE_UUID,
        slot: cfg.slot,
        capability: "switch",
        transport: "zigbee",
        title: cfg.title,
        digits: 0,

        locate: () => locate(cfg),

        paint: (entry) => {
          renderValue(cfg, entry);
        },

        build: () => {
          // Picker and persistence are owned by shared SEB-01 runtime.
        }
      });
    } catch (error) {
      console.warn("R43 adapter registration failed", cfg.slot, error);
    }
  }
})();
