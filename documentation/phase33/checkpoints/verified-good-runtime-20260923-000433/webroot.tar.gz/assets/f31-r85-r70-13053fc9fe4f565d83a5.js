(() => {
  "use strict";

  const MARK = "__IQF_F31_R70_INDOOR_TEMP_CIRCLES__";
  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  const runtime = window.IQF_SEB01_RUNTIME;
  const EXPECTED_RUNTIME = "F30.4C-R5-PERSISTED-READER";
  const DEVICE_UUID = "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc";

  if (window[MARK]) return;
  window[MARK] = true;

  const ZONES = Object.freeze([
    {
      key: "east",
      circuit: 1,
      title: "VÝCHOD",
      currentSlot: "heating-zone-east-indoor-temperature",
      setSlot: "heating-zone-east-set-temperature"
    },
    {
      key: "west",
      circuit: 2,
      title: "ZÁPAD",
      currentSlot: "heating-zone-west-indoor-temperature",
      setSlot: "heating-zone-west-set-temperature"
    }
  ]);

  function norm(v) {
    return String(v || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function root() {
    return document.querySelector(ROOT_SELECTOR);
  }

  function findCircuit(rootEl, number) {
    const direct=rootEl.querySelectorAll(".f29-00012-zone-card")[number-1];
    if(direct) return direct;
    const wanted = `TOPNÝ OKRUH ${number}`;

    const candidates = Array.from(
      rootEl.querySelectorAll("article,section,div")
    ).filter((el) => {
      const t = norm(el.textContent);
      if (!t.includes(wanted)) return false;

      const r = el.getBoundingClientRect();

      return (
        r.width >= 140 &&
        r.width <= 430 &&
        r.height >= 100 &&
        r.height <= 350
      );
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      return (
        (ar.width * ar.height) -
        (br.width * br.height)
      );
    });

    return candidates[0];
  }

  function ensureStyle() {
    const id = "f31-r70-indoor-temp-style";

    if (document.getElementById(id)) return;

    const style = document.createElement("style");
    style.id = id;

    style.textContent = `
      ${ROOT_SELECTOR} {
        --f31-r70-circle-size: clamp(170px, 11vw, 205px);
      }

      .f31-r70-temp-circle {
        position: absolute;
        width: var(--f31-r70-circle-size);
        height: var(--f31-r70-circle-size);
        box-sizing: border-box;

        display: grid;
        grid-template-rows: auto auto auto 1px auto auto;
        align-content: center;
        justify-items: center;
        row-gap: 6px;

        border: 3px solid #26bfff;
        border-radius: 50%;

        background: rgba(0, 21, 32, .12);
        color: #dff8ff;

        z-index: 18;
        pointer-events: none;

        box-shadow:
          0 0 13px rgba(38,191,255,.12),
          inset 0 0 14px rgba(38,191,255,.035);
      }

      .f31-r70-current-label,
      .f31-r70-set-label {
        font-size: clamp(.70rem, .72vw, .92rem);
        font-weight: 850;
        line-height: 1.1;
        color: #c8efff;
        text-align: center;
        white-space: nowrap;
      }

      .f31-r70-zone-title {
        font-size: clamp(.78rem, .86vw, 1.05rem);
        font-weight: 950;
        line-height: 1.05;
        color: #dff8ff;
        letter-spacing: .025em;
        text-align: center;
      }

      .f31-r70-divider {
        width: 82%;
        height: 1px;
        background: rgba(225,248,255,.92);
        box-shadow: 0 0 4px rgba(225,248,255,.18);
      }

      .f31-r70-value {
        min-width: 78px;
        min-height: 23px;
        padding: 0 7px;
        box-sizing: border-box;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 6px;
        color: #ffffff;
        font-size: clamp(.70rem, .72vw, .92rem);
        font-weight: 900;
        line-height: 1;
        white-space: nowrap;
      }

      button.f31-r70-value {
        pointer-events: auto;
        cursor: pointer;

        border: 1px solid rgba(72,215,255,.62);
        background: rgba(0,39,57,.92);
      }

      button.f31-r70-value:hover {
        background: rgba(0,66,91,.96);
        box-shadow: 0 0 9px rgba(72,215,255,.19);
      }

      span.f31-r70-value {
        pointer-events: none;
      }

      .f31-r70-value[data-state="unavailable"] {
        color: #91a9b4;
      }

      @media (max-width: 1200px) {
        ${ROOT_SELECTOR} {
          --f31-r70-circle-size: 160px;
        }

        .f31-r70-temp-circle {
          row-gap: 4px;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function ensureCircle(zone) {
    const rootEl = root();
    if (!rootEl) return null;

    let circle = rootEl.querySelector(
      `[data-f31-r70-zone="${zone.key}"]`
    );

    if (!circle) {
      circle = document.createElement("div");
      circle.className = "f31-r70-temp-circle";
      circle.setAttribute("data-f31-r70-zone", zone.key);

      const currentLabel = document.createElement("div");
      currentLabel.className = "f31-r70-current-label";
      currentLabel.textContent = "Vnitřní teplota";

      const currentValue = document.createElement("span");
      currentValue.className = "f31-r70-value";
      currentValue.setAttribute(
        "data-f31-r70-slot",
        zone.currentSlot
      );
      currentValue.textContent = "— °C";

      const title = document.createElement("div");
      title.className = "f31-r70-zone-title";
      title.textContent = zone.title;

      const divider = document.createElement("div");
      divider.className = "f31-r70-divider";

      const setLabel = document.createElement("div");
      setLabel.className = "f31-r70-set-label";
      setLabel.textContent = "Nastavená teplota";

      const setValue = document.createElement("span");
      setValue.className = "f31-r70-value";
      setValue.setAttribute(
        "data-f31-r70-slot",
        zone.setSlot
      );
      setValue.textContent = "— °C";

      circle.appendChild(currentLabel);
      circle.appendChild(currentValue);
      circle.appendChild(title);
      circle.appendChild(divider);
      circle.appendChild(setLabel);
      circle.appendChild(setValue);

      rootEl.appendChild(circle);
    }

    return circle;
  }

  function positionCircle(zone) {
    const rootEl=root(), circuit=rootEl&&findCircuit(rootEl,zone.circuit), circle=rootEl&&ensureCircle(zone);
    if(!rootEl||!circuit||!circle)return false;
    const rr=rootEl.getBoundingClientRect(), cr=circuit.getBoundingClientRect(), wr=circle.getBoundingClientRect();
    if(!rr.width||!rr.height)return false;
    const sx=rr.width/(rootEl.offsetWidth||rr.width), sy=rr.height/(rootEl.offsetHeight||rr.height);
    const x=(cr.left-rr.left+cr.width/2-wr.width/2)/sx-rootEl.clientLeft+rootEl.scrollLeft;
    const y=(cr.top-rr.top-wr.height)/sy-26-rootEl.clientTop+rootEl.scrollTop;
    circle.style.left=Math.max(8,x).toFixed(1)+'px'; circle.style.top=Math.max(8,y).toFixed(1)+'px';
    return true;
  }

  function positionAll() {
    ensureStyle();

    let count = 0;

    for (const zone of ZONES) {
      ensureCircle(zone);

      if (positionCircle(zone)) {
        count += 1;
      }
    }

    return count === ZONES.length;
  }

  function formatTemperature(entry) {
    const e =
      entry && typeof entry === "object"
        ? entry
        : {};

    const status = String(
      e.status || ""
    ).toLowerCase();

    if (
      e.available === false ||
      status === "unavailable" ||
      status === "offline"
    ) {
      return {
        text: "Nedostupné",
        state: "unavailable"
      };
    }

    if (e.has_value !== true) {
      return {
        text: "— °C",
        state: "unknown"
      };
    }

    if (
      runtime &&
      typeof runtime.format === "function"
    ) {
      return {
        text: runtime.format(
          e,
          "°C",
          1
        ),
        state: "value"
      };
    }

    const n = Number(e.value);

    return {
      text: Number.isFinite(n)
        ? `${n.toFixed(1).replace(".", ",")} °C`
        : "— °C",
      state: Number.isFinite(n)
        ? "value"
        : "unknown"
    };
  }

  function locate(zone, slot) {
    const rootEl = root();

    if (!rootEl) return null;

    const circle = ensureCircle(zone);

    if (!circle) return null;

    const box = circle.querySelector(
      `[data-f31-r70-slot="${slot}"]`
    );

    return box
      ? {
          card: circle,
          box
        }
      : null;
  }

  function renderValue(zone, slot, title, entry) {
    const target = locate(zone, slot);

    if (!target) return;

    const value = formatTemperature(entry);

    const admin =
      runtime &&
      typeof runtime.isAdmin === "function" &&
      runtime.isAdmin();

    const desiredTag =
      admin
        ? "BUTTON"
        : "SPAN";

    let node = target.box;

    if (node.tagName !== desiredTag) {
      const replacement = document.createElement(
        admin
          ? "button"
          : "span"
      );

      replacement.className = "f31-r70-value";
      replacement.setAttribute(
        "data-f31-r70-slot",
        slot
      );

      if (admin) {
        replacement.type = "button";

        replacement.addEventListener(
          "click",
          (event) => {
            event.preventDefault();
            event.stopPropagation();

            if (
              !runtime ||
              !runtime.isAdmin()
            ) {
              return;
            }

            void runtime.openSourcePicker(
              slot,
              replacement
            );
          }
        );
      }

      node.replaceWith(replacement);
      node = replacement;
    }

    node.setAttribute(
      "data-state",
      value.state
    );

    node.setAttribute(
      "data-seb01-slot",
      slot
    );

    if (admin) {
      const status = String(
        (entry && entry.status) || ""
      ).toLowerCase();

      const text =
        status === "unbound"
          ? "Vybrat"
          : value.text;

      if (node.textContent !== text) {
        node.textContent = text;
      }

      node.title =
        "SEB-01B — vybrat teplotní entitu: " +
        title;
    } else {
      if (node.textContent !== value.text) {
        node.textContent = value.text;
      }

      node.title =
        `${title}: ${value.text}`;
    }
  }

  function registerAdapters() {
    if (
      !runtime ||
      runtime.version !== EXPECTED_RUNTIME
    ) {
      return;
    }

    for (const zone of ZONES) {
      const pairs = [
        {
          slot: zone.currentSlot,
          title:
            `${zone.title} / Vnitřní teplota`
        },
        {
          slot: zone.setSlot,
          title:
            `${zone.title} / Nastavená teplota`
        }
      ];

      for (const item of pairs) {
        try {
          runtime.registerAdapter({
            deviceUuid: DEVICE_UUID,
            slot: item.slot,
            capability: "temperature",
            transport: "zigbee",
            title: item.title,
            digits: 1,

            locate: () =>
              locate(
                zone,
                item.slot
              ),

            paint: (entry) => {
              renderValue(
                zone,
                item.slot,
                item.title,
                entry
              );
            },

            build: () => {
              ensureCircle(zone);
              positionCircle(zone);
            }
          });
        } catch (error) {
          console.warn(
            "R70 adapter registration failed",
            item.slot,
            error
          );
        }
      }
    }
  }

  function boot() {
    ensureStyle();
    positionAll();
    registerAdapters();

    let attempts = 0;

    const timer = setInterval(() => {
      attempts += 1;

      if (
        positionAll() ||
        attempts >= 24
      ) {
        clearInterval(timer);
      }
    }, 250);

    window.addEventListener(
      "resize",
      () => {
        positionAll();
      },
      { passive: true }
    );
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      boot,
      { once: true }
    );
  } else {
    boot();
  }

  // F31_R85_LIFECYCLE_PATCH: replay the existing visual operation on each schema mount.
  window.IQF_F31_R85_LAYOUT_HOOKS=window.IQF_F31_R85_LAYOUT_HOOKS||{};
  window.IQF_F31_R85_LAYOUT_HOOKS["R70"]=positionAll;
  document.dispatchEvent(new Event('iqf-f31-r85-layout-ready'));
})();
