(() => {
  "use strict";

  const F32_R135_00012_BOTTOM_CLEARANCE = true;

  const F32_R134R2_00012_CLEAN_STATS_GUIDE = true;
  const MASK_ID = "f32-r134r2-00012-clean-workspace-mask";
  const STYLE_ID = "f32-r134r2-00012-clean-workspace-style";
  const STORAGE_KEY = "iqf_f32_r134r2_00012_active_tab";

  const blankTabs = new Set(["statistics", "guide"]);

  const labels = {
    SCHEMA: "schema",
    NASTAVENI: "settings",
    STATISTIKY: "statistics",
    SYSTEM: "system",
    NAVOD: "guide",
    NAPOVEDA: "guide",
    UZIVATEL: "user"
  };

  let currentTab = null;
  let mask = null;

  const norm = (v) =>
    String(v || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();

  function isTarget00012Client() {
    const path = String(window.location.pathname || "").toLowerCase();

    if (path === "/admin" || path.startsWith("/admin/")) {
      return false;
    }

    if (!path.includes("/portal")) {
      return false;
    }

    const text = norm(document.body?.textContent || "");

    return (
      text.includes("F800711-TNG-00012") ||
      (
        text.includes("JASANOVA 32") &&
        text.includes("BLANSKO")
      ) ||
      (
        text.includes("SVJ BLANSKO") &&
        text.includes("RIDICI SYSTEM")
      )
    );
  }

  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.display !== "none" && s.visibility !== "hidden";
  }

  function tabFromText(value) {
    const t = norm(value);
    if (!t || t.length > 36) return null;

    for (const [label, tab] of Object.entries(labels)) {
      if (t === label || t.startsWith(label + " ") || t.endsWith(" " + label)) {
        return tab;
      }
    }
    return null;
  }

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${MASK_ID} {
        position: fixed;
        left: 0;
        top: 0;
        width: 100vw;
        height: 0;
        z-index: 2147483647;
        pointer-events: none;
        visibility: hidden;
        opacity: 0;
        background: rgb(3,20,29);
      }
      #${MASK_ID}[data-active="1"] {
        visibility: visible;
        opacity: 1;
      }
    `;
    document.head.appendChild(style);
  }

  function ensureMask() {
    if (mask && mask.isConnected) return mask;

    mask = document.getElementById(MASK_ID);

    if (!mask) {
      mask = document.createElement("div");
      mask.id = MASK_ID;
      mask.dataset.active = "0";
      document.body.appendChild(mask);
    }

    return mask;
  }

  function navCandidates() {
    const result = [];

    for (const el of document.querySelectorAll("button,a,span,div,[role='button'],[tabindex]")) {
      if (!visible(el)) continue;

      const tab = tabFromText(el.textContent);
      if (!tab) continue;

      const r = el.getBoundingClientRect();

      if (r.top < window.innerHeight * 0.55) continue;

      result.push({ tab, el, rect: r });
    }

    return result;
  }

  function navTop() {
    const items = navCandidates();

    if (!items.length) {
      return Math.max(0, window.innerHeight - 188);
    }

    return Math.max(
      0,
      Math.round(Math.min(...items.map((x) => x.rect.top)) - 86)
    );
  }

  function updateMaskGeometry() {
    const el = ensureMask();
    el.style.height = navTop() + "px";

    if (el.dataset.active === "1") {
      document.body.appendChild(el);
    }
  }

  function setTab(tab, persist = true) {
    if (!tab) return;

    currentTab = tab;

    if (persist) {
      try {
        sessionStorage.setItem(STORAGE_KEY, tab);
      } catch (_) {}
    }

    const el = ensureMask();
    el.dataset.active = (isTarget00012Client() && blankTabs.has(tab)) ? "1" : "0";
    updateMaskGeometry();
  }

  function eventTab(event) {
    const path =
      typeof event.composedPath === "function"
        ? event.composedPath()
        : [event.target];

    for (const node of path) {
      if (!node || node === window || node === document) continue;

      const tab = tabFromText(node.textContent);
      if (!tab) continue;

      if (node.getBoundingClientRect) {
        const r = node.getBoundingClientRect();
        if (r.top < window.innerHeight * 0.55) continue;
      }

      return tab;
    }

    return null;
  }

  function activityScore(el) {
    let score = 0;
    let node = el;

    for (let depth = 0; node && depth < 5; depth += 1, node = node.parentElement) {
      const ariaCurrent = norm(node.getAttribute("aria-current"));
      const ariaSelected = norm(node.getAttribute("aria-selected"));
      const dataActive = norm(node.getAttribute("data-active"));
      const cls = norm(typeof node.className === "string" ? node.className : "");

      if (ariaCurrent === "PAGE" || ariaCurrent === "TRUE") score += 10000;
      if (ariaSelected === "TRUE") score += 9000;
      if (dataActive === "1" || dataActive === "TRUE") score += 8000;
      if (cls.includes("ACTIVE") || cls.includes("SELECTED") || cls.includes("CURRENT")) score += 6000;

      const style = getComputedStyle(node);
      const bg = style.backgroundColor.match(/[\d.]+/g);

      if (bg && bg.length >= 3) {
        const r = Number(bg[0]);
        const g = Number(bg[1]);
        const b = Number(bg[2]);
        const a = bg.length >= 4 ? Number(bg[3]) : 1;
        score += (g + b - r) * Math.max(0, a);
      }

      const border = style.borderTopColor.match(/[\d.]+/g);
      if (border && border.length >= 3) {
        score += Number(border[1]) + Number(border[2]);
      }
    }

    return score;
  }

  function detectActiveTab() {
    const items = navCandidates();
    if (!items.length) return null;

    const bestByTab = new Map();

    for (const item of items) {
      const score = activityScore(item.el);
      const prev = bestByTab.get(item.tab);

      if (!prev || score > prev.score) {
        bestByTab.set(item.tab, { score, el: item.el });
      }
    }

    const ranked = [...bestByTab.entries()].sort(
      (a, b) => b[1].score - a[1].score
    );

    if (!ranked.length) return null;

    return ranked[0][1].score > 150 ? ranked[0][0] : null;
  }

  function protectedPageFromContent() {
    const text = norm(document.body.textContent);

    if (
      text.includes("HARDWARE A PROVOZNI STAV") ||
      text.includes("ZIGBEE SIT A ZARIZENI")
    ) {
      return "system";
    }

    if (
      text.includes("KLIENT A ADRESA") ||
      text.includes("ZMENA HESLA")
    ) {
      return "user";
    }

    return null;
  }

  function syncFromDom() {
    if (!isTarget00012Client()) {
      const el = ensureMask();
      el.dataset.active = "0";
      return;
    }

    const protectedTab = protectedPageFromContent();

    if (protectedTab) {
      setTab(protectedTab, false);
      return;
    }

    const detected = detectActiveTab();

    if (detected && detected !== currentTab) {
      setTab(detected, false);
      return;
    }

    updateMaskGeometry();
  }

  function onNavEvent(event) {
    const tab = eventTab(event);
    if (!tab) return;

    setTab(tab, true);

    setTimeout(syncFromDom, 60);
    setTimeout(syncFromDom, 250);
    setTimeout(syncFromDom, 700);
  }

  function restoreSession() {
    let stored = null;

    try {
      stored = sessionStorage.getItem(STORAGE_KEY);
    } catch (_) {}

    if (
      stored &&
      (
        blankTabs.has(stored) ||
        stored === "schema" ||
        stored === "settings" ||
        stored === "system" ||
        stored === "user"
      )
    ) {
      setTab(stored, false);
    }
  }

  function boot() {
    ensureStyle();
    ensureMask();

    document.addEventListener("pointerdown", onNavEvent, true);
    document.addEventListener("click", onNavEvent, true);

    window.addEventListener(
      "resize",
      updateMaskGeometry,
      { passive: true }
    );

    restoreSession();
    syncFromDom();

    setInterval(syncFromDom, 250);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();

