(() => {
  "use strict";

  const runtime = window.IQF_SEB01_RUNTIME;
  const EXPECTED_RUNTIME = "F30.4C-R5-PERSISTED-READER";
  const DEVICE_UUID = "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc";

  if (!runtime || runtime.version !== EXPECTED_RUNTIME) {
    console.warn("R54: shared SEB-01 runtime is not available");
    return;
  }

  const CONFIG = Object.freeze([
    {
      row: "1",
      slot: "circulation-pump-entity-1-state",
      capability: "switch",
      title: "Cirkulační čerpadlo / Spínací prvek",
      unit: "",
      digits: 0
    },
    {
      row: "2",
      slot: "circulation-pump-entity-2-state",
      capability: "temperature",
      title: "Cirkulační čerpadlo / Teplota",
      unit: "°C",
      digits: 1
    }
  ]);

  function capabilityMatches(cfg, entry) {
    const actual = String((entry && entry.capability) || "").trim();

    if (!actual) return true;
    return actual === cfg.capability;
  }

  function stateValue(entry) {
    const e = entry && typeof entry === "object" ? entry : {};
    const status = String(e.status || "").trim().toLowerCase();

    if (
      e.available === false ||
      status === "unavailable" ||
      status === "offline"
    ) {
      return { text: "Nedostupné", state: "unavailable" };
    }

    if (
      e.has_value !== true ||
      [
        "unknown",
        "unbound",
        "snapshot_only",
        "api_stale",
        "no_context",
        "loading"
      ].includes(status) ||
      /^(http_|request_|wrong_device|context_)/.test(status)
    ) {
      return { text: "—", state: "unknown" };
    }

    const v = e.value;

    if (
      v === true ||
      v === 1 ||
      (typeof v === "string" && /^(on|true|1|zapnuto)$/i.test(v.trim()))
    ) {
      return { text: "zapnuto", state: "on" };
    }

    if (
      v === false ||
      v === 0 ||
      (typeof v === "string" && /^(off|false|0|vypnuto)$/i.test(v.trim()))
    ) {
      return { text: "vypnuto", state: "off" };
    }

    return { text: "—", state: "unknown" };
  }

  function formatted(cfg, entry) {
    if (!capabilityMatches(cfg, entry)) {
      return { text: "—", state: "unknown", mismatch: true };
    }

    if (cfg.capability === "temperature") {
      const e = entry && typeof entry === "object" ? entry : {};
      const status = String(e.status || "").trim().toLowerCase();

      if (
        e.available === false ||
        status === "unavailable" ||
        status === "offline"
      ) {
        return { text: "Nedostupné", state: "unavailable" };
      }

      if (e.has_value !== true) {
        return { text: "—", state: "unknown" };
      }

      return {
        text: runtime.format(e, "°C", 1),
        state: "temperature"
      };
    }

    return stateValue(entry);
  }

  function ensureStyle() {
    const id = "f31-r54-pump-switch-temp-style";

    if (document.getElementById(id)) return;

    const style = document.createElement("style");
    style.id = id;

    style.textContent = `
      .f31-r54-pump-seb-host {
        order: 2 !important;
        width: 100%;
        margin-top: 7px !important;
        display: grid !important;
        row-gap: 8px;
        justify-items: center;
      }

      .f31-r54-pump-seb-row {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .f31-r54-pump-seb-value {
        min-width: 82px;
        text-align: center;
        color: #dff8ff;
        font-size: 10px;
        font-weight: 900;
        line-height: 1.1;
        white-space: nowrap;
      }

      button.f31-r54-pump-seb-value {
        min-width: 82px;
        height: 25px;
        padding: 0 8px;
        border: 1px solid rgba(83,218,255,.70);
        border-radius: 6px;
        background: rgba(2,35,52,.96);
        cursor: pointer;
        position: relative;
        z-index: 30;
        pointer-events: auto;
      }

      button.f31-r54-pump-seb-value:hover {
        background: rgba(4,64,89,.98);
        box-shadow: 0 0 9px rgba(56,210,255,.18);
      }

      span.f31-r54-pump-seb-value {
        pointer-events: none;
      }

      .f31-r54-pump-seb-value[data-f31-r54-state="on"] {
        color: #ff4d59;
      }

      .f31-r54-pump-seb-value[data-f31-r54-state="off"] {
        color: #dff8ff;
      }

      .f31-r54-pump-seb-value[data-f31-r54-state="temperature"] {
        color: #dff8ff;
      }

      .f31-r54-pump-seb-value[data-f31-r54-state="unavailable"] {
        color: #91a9b4;
      }
    `;

    document.head.appendChild(style);
  }

  function getPump() {
    return document.querySelector(
      '[data-f29-00012-schema="svj-blansko-only"] .f29-00012-pump'
    );
  }

  function ensureSlots() {
    const pump = getPump();

    if (!pump) return null;

    let host =
      pump.querySelector(".f31-r54-pump-seb-host") ||
      pump.querySelector(".f31-r52-pump-seb-host");

    if (!host) {
      host =
        Array.from(pump.children).find((el) => el.tagName === "SPAN") ||
        document.createElement("span");

      if (!host.isConnected) {
        pump.appendChild(host);
      }
    }

    if (!host.classList.contains("f31-r54-pump-seb-host")) {
      host.className = "f31-r54-pump-seb-host";
      host.replaceChildren();

      for (const cfg of CONFIG) {
        const row = document.createElement("span");
        row.className = "f31-r54-pump-seb-row";
        row.setAttribute("data-f31-r54-row", cfg.row);

        const value = document.createElement("span");
        value.className = "f31-r54-pump-seb-value";
        value.setAttribute("data-f31-r54-slot", cfg.slot);
        value.textContent = "—";

        row.appendChild(value);
        host.appendChild(row);
      }
    }

    return { pump, host };
  }

  function locate(cfg) {
    const shell = ensureSlots();

    if (!shell) return null;

    const box = shell.host.querySelector(
      '[data-f31-r54-slot="' + cfg.slot + '"]'
    );

    return box ? { card: shell.pump, box } : null;
  }

  function defaultNetworkToZigbee() {
    queueMicrotask(() => {
      const dialog = document.querySelector(
        'dialog[data-seb01-source-dialog]'
      );

      if (!dialog) return;

      const network = dialog.querySelector(
        '[data-seb01-network-filter="true"]'
      );

      if (!network) return;

      if (network.value !== "zigbee") {
        network.value = "zigbee";
        network.dispatchEvent(
          new Event("change", { bubbles: true })
        );
      }
    });
  }

  function render(cfg, entry) {
    const target = locate(cfg);

    if (!target) return;

    const value = formatted(cfg, entry);
    const admin = runtime.isAdmin();
    const desiredTag = admin ? "BUTTON" : "SPAN";

    let node = target.box;

    if (node.tagName !== desiredTag) {
      const replacement = document.createElement(
        admin ? "button" : "span"
      );

      replacement.className = "f31-r54-pump-seb-value";
      replacement.setAttribute("data-f31-r54-slot", cfg.slot);

      if (admin) {
        replacement.type = "button";

        replacement.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();

          if (!runtime.isAdmin()) return;

          void runtime.openSourcePicker(cfg.slot, replacement);
          defaultNetworkToZigbee();
        });
      }

      node.replaceWith(replacement);
      node = replacement;
    }

    node.setAttribute("data-f31-r54-state", value.state);
    node.setAttribute("data-seb01-slot", cfg.slot);

    if (admin) {
      const status = String(
        (entry && entry.status) || ""
      ).toLowerCase();

      const unbound =
        status === "unbound" ||
        value.mismatch === true;

      const text = unbound ? "Vybrat" : value.text;

      if (node.textContent !== text) {
        node.textContent = text;
      }

      node.title =
        "SEB-01B — vybrat nebo změnit Zigbee entitu: " +
        cfg.title;

      node.setAttribute(
        "aria-label",
        "Vybrat Zigbee entitu — " + cfg.title
      );
    } else {
      if (node.textContent !== value.text) {
        node.textContent = value.text;
      }

      node.title = cfg.title + ": " + value.text;
    }
  }

  ensureStyle();
  ensureSlots();

  for (const cfg of CONFIG) {
    try {
      runtime.registerAdapter({
        deviceUuid: DEVICE_UUID,
        slot: cfg.slot,
        capability: cfg.capability,
        transport: "zigbee",
        title: cfg.title,
        digits: cfg.digits,

        locate: () => locate(cfg),

        paint: (entry) => {
          render(cfg, entry);
        },

        build: () => {
          ensureSlots();
        }
      });
    } catch (error) {
      console.warn(
        "R54 adapter registration failed",
        cfg.slot,
        error
      );
    }
  }
})();
