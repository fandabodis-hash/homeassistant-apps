(function forceRemoveAllPumpArtifacts00012() {
  "use strict";

  var MARKER = "__F30_03D_R10_FORCE_REMOVE_ALL_PUMP_ARTIFACTS__";
  if (window[MARKER]) return;
  window[MARKER] = true;

  function txt(v) {
    return v === null || v === undefined ? "" : String(v).trim();
  }

  function c(v) {
    return txt(v)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "");
  }

  function schemaRoot() {
    return document.querySelector('[data-f29-00012-schema="svj-blansko-only"], .f29-00012-schema-v2') || document.body;
  }

  function findCard(labelNeedles) {
    var root = schemaRoot();
    var nodes = Array.prototype.slice.call(root.querySelectorAll("section,article,div"));
    var found = nodes.filter(function(el) {
      var s = c(el.textContent || "");
      return labelNeedles.every(function(n) { return s.indexOf(n) !== -1; });
    }).filter(function(el) {
      var r = el.getBoundingClientRect();
      return r.width > 180 && r.height > 120;
    });

    found.sort(function(a,b){
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      return ar.width * ar.height - br.width * br.height;
    });

    return found[0] || null;
  }

  function removeByKnownSelectors(root) {
    [
      ".f30-03d-r2-cp-card",
      ".f30-03d-r3-pump",
      ".f30-03d-r3-symbol",
      ".f30-03d-r4-pump",
      ".f30-03d-r5-pump",
      ".f30-03d-r6-pump",
      ".f30-03d-r7-pump",
      "[data-f30-03d-r3]",
      "[data-f30-03d-r4]",
      "[data-f30-03d-r5]",
      "[data-f30-03d-r6]",
      "[data-f30-03d-r7]",
      "[data-f30-03d-r8]",
      "[data-f30-03d-positioned]"
    ].forEach(function(sel) {
      root.querySelectorAll(sel).forEach(function(node) {
        var wrapper = node.closest(
          ".f30-03d-r2-cp-card,.f30-03d-r3-pump,.f30-03d-r3-symbol,.f30-03d-r4-pump,.f30-03d-r5-pump,.f30-03d-r6-pump,.f30-03d-r7-pump"
        ) || node;
        if (wrapper && wrapper.remove) wrapper.remove();
      });
    });
  }

  function removeNearAkuAndBoiler(root) {
    var aku = findCard(["akunadrz"]) || findCard(["akumulacetepla"]);
    var boiler = findCard(["bojler", "pripravatuv"]);

    var candidates = Array.prototype.slice.call(root.querySelectorAll("div,button,span,a,section,article"));
    candidates.forEach(function(el) {
      // F31_R85_PROTECTED_AKU_SYMBOL: only exempt the current, named AKU widget.
      if (el && el.closest && el.closest('[data-f31-r85-protect="aku-pump"]')) return;
      if (!el || !el.getBoundingClientRect) return;
      if (el === aku || el === boiler) return;
      if (aku && aku.contains(el)) return;
      if (boiler && boiler.contains(el)) return;

      var r = el.getBoundingClientRect();
      if (!r.width || !r.height) return;
      if (r.width > 150 || r.height > 150) return;
      if (r.width < 20 || r.height < 20) return;

      var style = window.getComputedStyle(el);
      var radius = parseFloat(style.borderRadius || "0") || 0;
      var squareLike = Math.abs(r.width - r.height) <= 35;
      var hasSvg = !!el.querySelector("svg");
      var hasCircleLike = radius >= 14 || squareLike;
      var s = c(el.textContent || "");
      var aria = c(el.getAttribute("aria-label") || "");
      var title = c(el.getAttribute("title") || "");
      var className = c(el.className || "");

      var looksPumpish =
        hasSvg ||
        s === "" ||
        s === "â†»" ||
        s === "âźł" ||
        aria.indexOf("pump") !== -1 ||
        aria.indexOf("cirkul") !== -1 ||
        title.indexOf("pump") !== -1 ||
        title.indexOf("cirkul") !== -1 ||
        className.indexOf("pump") !== -1 ||
        className.indexOf("cirkul") !== -1;

      if (!(hasCircleLike && looksPumpish)) return;

      var inAkuZone = false;
      if (aku) {
        var ar = aku.getBoundingClientRect();
        inAkuZone =
          r.left >= ar.left + ar.width * 0.55 &&
          r.left <= ar.right + 120 &&
          r.top >= ar.top + ar.height * 0.55 &&
          r.top <= ar.bottom + 120;
      }

      var betweenBivalenceAndBoilerZone = false;
      if (boiler) {
        var br = boiler.getBoundingClientRect();
        betweenBivalenceAndBoilerZone =
          r.left >= br.left - 180 &&
          r.left <= br.left + 50 &&
          r.top >= br.top - 220 &&
          r.top <= br.top + 40;
      }

      if (!(inAkuZone || betweenBivalenceAndBoilerZone)) return;

      var wrapper = el.closest(
        ".f30-03d-r2-cp-card,.f30-03d-r3-pump,.f30-03d-r3-symbol,.f30-03d-r4-pump,.f30-03d-r5-pump,.f30-03d-r6-pump,.f30-03d-r7-pump"
      ) || el;

      if (wrapper && wrapper.remove) wrapper.remove();
    });
  }

  function killTextFragments(root) {
    var fragments = Array.prototype.slice.call(root.querySelectorAll("div,span,p,strong,small"));
    fragments.forEach(function(el) {
      // F31_R85_PROTECTED_AKU_SYMBOL: only exempt the current, named AKU widget.
      if (el && el.closest && el.closest('[data-f31-r85-protect="aku-pump"]')) return;
      var s = c(el.textContent || "");
      if (
        s.indexOf("cirkulacnicerpadlo") !== -1 ||
        s.indexOf("stavunavailable") !== -1 ||
        s.indexOf("klikninasymbol") !== -1 ||
        s.indexOf("seb01") !== -1 && s.indexOf("cirkulacni") !== -1
      ) {
        var r = el.getBoundingClientRect();
        if (r.width < 280 && r.height < 120) {
          el.remove();
        }
      }
    });
  }

  function cleanup() {
    var root = schemaRoot();
    removeByKnownSelectors(root);
    removeNearAkuAndBoiler(root);
    killTextFragments(root);
  }

  function start() {
    cleanup();

    var mo = new MutationObserver(function() {
      window.setTimeout(cleanup, 40);
      window.setTimeout(cleanup, 250);
    });

    mo.observe(document.documentElement || document.body, {
      childList: true,
      subtree: true
    });

    window.setInterval(cleanup, 1000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
}());
