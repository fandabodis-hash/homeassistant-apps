/*
 * F33_R11_00013_SHARED_SEB_ADMIN_CLIENT_BRIDGE
 *
 * Uses existing IQF_SEB01_RUNTIME only.
 * No own fetch, timer, MutationObserver, storage or device command.
 * Admin and client render the same element_key.
 */
(() => {
  "use strict";

  const MARKER = "__IQF_F33_R11_00013_SHARED_SEB_BRIDGE__";
  if (window[MARKER]) return;
  window[MARKER] = true;

  const ROOT =
    '[data-f33-r8-00013-schema="hpt01-reference"]';

  const specs = [
    ["heatpump-electric-power", "kW", 2, "number"],
    ["heatpump-daily-consumption", "kWh", 2, "number"],
    ["heatpump-heating-state", "", 0, "state"],
    ["heatpump-dhw-state", "", 0, "state"],
    ["heatpump-relative-power", "%", 0, "number"],
    ["room-temperature", "°C", 1, "number"],
    ["room-target-temperature", "°C", 1, "number"],
    ["fireplace-outlet-temperature", "°C", 1, "number"],
    ["fireplace-state", "", 0, "state"],
    ["fireplace-runtime-hours", "h", 1, "number"],
    ["boiler-temperature", "°C", 1, "number"],
    ["boiler-heating-state", "", 0, "state"],
    ["boiler-target-temperature", "°C", 1, "number"],
    ["buffer-temperature", "°C", 1, "number"],
    ["buffer-state", "", 0, "state"],
    ["buffer-target-temperature", "°C", 1, "number"],
    ["heating-flow-temperature", "°C", 1, "number"],
    ["heating-return-temperature", "°C", 1, "number"],
    ["heating-pump-state", "", 0, "state"],
  ];

  function schemaRoot() {
    return document.querySelector(ROOT);
  }

  function containerFor(key) {
    const root = schemaRoot();
    return root
      ? root.querySelector(
          `[data-f30-schema-element-key="${key}"]`
        )
      : null;
  }

  function valueNode(container) {
    if (!container) return null;

    if (
      container.matches &&
      container.matches("strong")
    ) {
      return container;
    }

    return (
      container.querySelector(":scope > strong") ||
      container.querySelector("strong")
    );
  }

  function stateText(raw, status) {
    const s = String(status || "")
      .trim()
      .toLowerCase();

    if (
      s === "unavailable" ||
      s === "offline"
    ) {
      return "nedostupné";
    }

    if (raw === true || raw === 1) {
      return "zapnuto";
    }
    if (raw === false || raw === 0) {
      return "vypnuto";
    }

    const text = String(raw ?? "")
      .trim()
      .toLowerCase();

    if (
      ["1","true","on","running","active","enabled","open","zapnuto"]
        .includes(text)
    ) {
      return "zapnuto";
    }

    if (
      ["0","false","off","stopped","inactive","disabled","closed","vypnuto"]
        .includes(text)
    ) {
      return "vypnuto";
    }

    if (
      text === "" ||
      text === "unknown" ||
      text === "none" ||
      text === "null"
    ) {
      return "—";
    }

    return String(raw);
  }

  function entryRaw(entry) {
    if (!entry || typeof entry !== "object") {
      return null;
    }

    if (entry.has_value === false) {
      return null;
    }

    if (
      entry.value !== undefined &&
      entry.value !== null
    ) {
      return entry.value;
    }

    if (
      entry.state !== undefined &&
      entry.state !== null
    ) {
      return entry.state;
    }

    return null;
  }

  function render(entry, unit, digits, kind) {
    if (!entry || typeof entry !== "object") {
      return unit ? `— ${unit}` : "—";
    }

    const status = String(entry.status || "")
      .trim()
      .toLowerCase();

    if (
      status === "unavailable" ||
      status === "offline"
    ) {
      return "nedostupné";
    }

    if (kind === "state") {
      return stateText(
        entryRaw(entry),
        status
      );
    }

    const display = String(
      entry.display_value ?? ""
    ).trim();

    if (
      display &&
      display !== "—" &&
      display.toLowerCase() !== "unknown"
    ) {
      return display;
    }

    const raw = entryRaw(entry);
    if (
      raw === null ||
      raw === undefined ||
      raw === ""
    ) {
      return unit ? `— ${unit}` : "—";
    }

    const number = Number(
      String(raw).replace(",", ".")
    );

    if (!Number.isFinite(number)) {
      return unit
        ? `${String(raw)} ${unit}`
        : String(raw);
    }

    const formatted = number.toLocaleString(
      "cs-CZ",
      {
        minimumFractionDigits: 0,
        maximumFractionDigits: digits,
      }
    );

    return unit
      ? `${formatted} ${unit}`
      : formatted;
  }

  function register() {
    const R = window.IQF_SEB01_RUNTIME;

    if (
      !R ||
      typeof R.registerAdapter !== "function"
    ) {
      return false;
    }

    for (const [key, unit, digits, kind] of specs) {
      R.registerAdapter({
        slot: key,
        digits,
        title: key,

        locate: () => {
          const container = containerFor(key);
          const box = valueNode(container);

          if (!container || !box) {
            return null;
          }

          return {
            card:
              container.closest(
                "section,article"
              ) ||
              container,
            box,
          };
        },

        paint: (entry) => {
          const container = containerFor(key);
          const box = valueNode(container);

          if (!box) return;

          box.textContent =
            render(entry, unit, digits, kind);

          box.setAttribute(
            "data-f33-r11-seb-painted",
            key
          );

          if (
            typeof R.hint === "function"
          ) {
            box.setAttribute(
              "title",
              R.hint(entry) || ""
            );
          }
        },

        build: () => {},
      });
    }

    window.IQF_F33_R11_00013_SHARED_SEB =
      Object.freeze({
        version: "F33.R11",
        runtime:
          R.version || "IQF_SEB01_RUNTIME",
        slots: specs.map((item) => item[0]),
        ownFetch: false,
        ownTimer: false,
        ownObserver: false,
        adminClientSharedKeys: true,
      });

    return true;
  }

  register();

  /*
   * Client is value-only. Prevent the obsolete generic
   * HPT information dialog from handling schema clicks.
   * This does not change layout or values.
   * Window capture executes before document/card handlers.
   */
  window.addEventListener(
    "click",
    (event) => {
      const target =
        event.target &&
        event.target.closest
          ? event.target.closest(ROOT)
          : null;

      if (!target) return;

      /*
       * F33_R13_CLIENT_ROLE_CLICK_GATE
       *
       * The R8/R11 schema root itself is the authoritative
       * admin/client identity. Do not infer the role from an
       * outer workspace ancestor because the live render can
       * be mounted through a different React/portal boundary.
       *
       * Client is strictly value-only. Admin clicks remain
       * available to the generic SEB picker.
       */
      const role =
        target.getAttribute(
          "data-f33-r11-seb-role"
        ) || "";

      if (role === "client") {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    },
    true
  );
})();
