(() => {
  "use strict";

  const ROOT =
    '[data-f29-00012-schema="svj-blansko-only"]';

  const SLOT_1 =
    'heatpump-stage-1-dhw-state';

  const SLOT_2 =
    'heatpump-stage-2-dhw-state';

  const ID =
    'f31-r95r2-tc-bojler-flow';

  const HP_LINE_Y_RATIO =
    0.78;

  if (
    window.__IQF_F31_R95R2_TC_BOJLER_FLOW__
  ) {
    return;
  }

  window.__IQF_F31_R95R2_TC_BOJLER_FLOW__ =
    true;

  const lastExplicit = {
    [SLOT_1]: null,
    [SLOT_2]: null
  };

  let overlay = null;
  let svg = null;
  let motionPath = null;
  let dots = [];
  let active = false;

  const norm = (value) =>
    String(value || '')
      .normalize('NFD')
      .replace(
        /[\u0300-\u036f]/g,
        ''
      )
      .replace(
        /\s+/g,
        ' '
      )
      .trim()
      .toUpperCase();

  function visible(el) {
    if (
      !el ||
      !el.isConnected
    ) {
      return false;
    }

    const r =
      el.getBoundingClientRect();

    const s =
      getComputedStyle(el);

    return (
      r.width > 0 &&
      r.height > 0 &&
      s.display !== 'none' &&
      s.visibility !== 'hidden'
    );
  }

  function findCard(
    root,
    label,
    minWidth,
    minHeight,
    maxWidth,
    maxHeight
  ) {
    const wanted =
      norm(label);

    let best = null;
    let bestArea =
      Infinity;

    for (
      const el
      of root.querySelectorAll(
        'article,section,div'
      )
    ) {
      if (!visible(el)) {
        continue;
      }

      if (
        !norm(
          el.textContent
        ).includes(
          wanted
        )
      ) {
        continue;
      }

      const r =
        el.getBoundingClientRect();

      if (
        r.width < minWidth ||
        r.height < minHeight ||
        r.width > maxWidth ||
        r.height > maxHeight
      ) {
        continue;
      }

      const area =
        r.width *
        r.height;

      if (
        area <
        bestArea
      ) {
        best =
          el;

        bestArea =
          area;
      }
    }

    return best;
  }

  function parseState(
    value
  ) {
    const text =
      norm(value);

    if (
      text.includes(
        'NEDOSTUPNE'
      ) ||
      text.includes(
        'VYPNUTO'
      ) ||
      text === 'OFF' ||
      text === 'FALSE' ||
      text === '0'
    ) {
      return false;
    }

    if (
      text.includes(
        'ZAPNUTO'
      ) ||
      text === 'ON' ||
      text === 'TRUE' ||
      text === '1'
    ) {
      return true;
    }

    return null;
  }

  function readSlot(
    root,
    slot
  ) {
    const node =
      root.querySelector(
        `[data-seb01-slot="${slot}"]`
      );

    if (!node) {
      return null;
    }

    for (
      const attr
      of [
        'data-state',
        'data-f31-r84-state',
        'data-f31-r83-state',
        'aria-label',
        'title'
      ]
    ) {
      const raw =
        node.getAttribute(
          attr
        );

      if (!raw) {
        continue;
      }

      const parsed =
        parseState(
          raw
        );

      if (
        parsed !== null
      ) {
        return parsed;
      }
    }

    return parseState(
      node.textContent
    );
  }

  function updateState() {
    const root =
      document.querySelector(
        ROOT
      );

    if (
      !root ||
      !visible(root)
    ) {
      active = false;
      if (overlay) {
        overlay.style.display =
          'none';
      }
      return;
    }

    const s1 =
      readSlot(
        root,
        SLOT_1
      );

    const s2 =
      readSlot(
        root,
        SLOT_2
      );

    if (
      s1 !== null
    ) {
      lastExplicit[
        SLOT_1
      ] = s1;
    }

    if (
      s2 !== null
    ) {
      lastExplicit[
        SLOT_2
      ] = s2;
    }

    active =
      lastExplicit[
        SLOT_1
      ] === true ||
      lastExplicit[
        SLOT_2
      ] === true;

    if (overlay) {
      overlay.style.opacity =
        active
          ? '1'
          : '0';
    }
  }

  function ensureOverlay() {
    if (overlay) {
      return;
    }

    overlay =
      document.createElement(
        'div'
      );

    overlay.id =
      ID;

    overlay.style.position =
      'fixed';

    overlay.style.pointerEvents =
      'none';

    overlay.style.zIndex =
      '2147480000';

    overlay.style.opacity =
      '0';

    overlay.style.transition =
      'opacity .12s ease';

    document.body.appendChild(
      overlay
    );

    svg =
      document.createElementNS(
        'http://www.w3.org/2000/svg',
        'svg'
      );

    svg.style.position =
      'absolute';

    svg.style.left =
      '0';

    svg.style.top =
      '0';

    svg.style.overflow =
      'visible';

    overlay.appendChild(
      svg
    );

    motionPath =
      document.createElementNS(
        'http://www.w3.org/2000/svg',
        'path'
      );

    motionPath.setAttribute(
      'fill',
      'none'
    );

    motionPath.setAttribute(
      'stroke',
      'none'
    );

    svg.appendChild(
      motionPath
    );

    dots = [];

    for (
      let i = 0;
      i < 5;
      i += 1
    ) {
      const halo =
        document.createElementNS(
          'http://www.w3.org/2000/svg',
          'circle'
        );

      halo.setAttribute(
        'r',
        '7'
      );

      halo.setAttribute(
        'fill',
        'rgba(43,167,255,.18)'
      );

      svg.appendChild(
        halo
      );

      const dot =
        document.createElementNS(
          'http://www.w3.org/2000/svg',
          'circle'
        );

      dot.setAttribute(
        'r',
        '3.75'
      );

      dot.setAttribute(
        'fill',
        '#2ba7ff'
      );

      dot.style.filter =
        'drop-shadow(0 0 4px rgba(43,167,255,.95))';

      svg.appendChild(
        dot
      );

      dots.push({
        halo,
        dot,
        offset:
          i / 5
      });
    }
  }

  function layout() {
    ensureOverlay();

    const root =
      document.querySelector(
        ROOT
      );

    if (
      !root ||
      !visible(root)
    ) {
      overlay.style.display =
        'none';
      return;
    }

    const heatPump =
      findCard(
        root,
        'TNG HE1500Si DUO 38kW',
        420,
        220,
        1000,
        520
      );

    const boiler =
      findCard(
        root,
        'BOJLER',
        140,
        100,
        520,
        460
      );

    if (
      !heatPump ||
      !boiler
    ) {
      overlay.style.display =
        'none';
      return;
    }

    const hp =
      heatPump.getBoundingClientRect();

    const b =
      boiler.getBoundingClientRect();

    const startX =
      hp.right;

    const startY =
      hp.top +
      hp.height *
        HP_LINE_Y_RATIO;

    const turnX =
      b.left +
      b.width / 2;

    const endY =
      b.top;

    const horizontal =
      turnX -
      startX;

    const vertical =
      endY -
      startY;

    if (
      horizontal < 20 ||
      vertical < 20
    ) {
      overlay.style.display =
        'none';
      return;
    }

    const pad =
      10;

    overlay.style.display =
      'block';

    overlay.style.left =
      Math.round(
        startX -
        pad
      ) +
      'px';

    overlay.style.top =
      Math.round(
        startY -
        pad
      ) +
      'px';

    overlay.style.width =
      Math.round(
        horizontal +
        pad * 2
      ) +
      'px';

    overlay.style.height =
      Math.round(
        vertical +
        pad * 2
      ) +
      'px';

    svg.setAttribute(
      'width',
      String(
        Math.round(
          horizontal +
          pad * 2
        )
      )
    );

    svg.setAttribute(
      'height',
      String(
        Math.round(
          vertical +
          pad * 2
        )
      )
    );

    svg.setAttribute(
      'viewBox',
      `0 0 ${
        Math.round(
          horizontal +
          pad * 2
        )
      } ${
        Math.round(
          vertical +
          pad * 2
        )
      }`
    );

    motionPath.setAttribute(
      'd',
      `M ${pad} ${pad} H ${
        Math.round(
          horizontal +
          pad
        )
      } V ${
        Math.round(
          vertical +
          pad
        )
      }`
    );

    overlay.style.opacity =
      active
        ? '1'
        : '0';
  }

  function animate(
    now
  ) {
    if (
      active &&
      motionPath &&
      motionPath.isConnected
    ) {
      const length =
        motionPath.getTotalLength();

      const phase =
        (
          now /
          1700
        ) % 1;

      for (
        const item
        of dots
      ) {
        const t =
          (
            phase +
            item.offset
          ) % 1;

        const p =
          motionPath.getPointAtLength(
            t *
            length
          );

        item.halo.setAttribute(
          'cx',
          String(
            p.x
          )
        );

        item.halo.setAttribute(
          'cy',
          String(
            p.y
          )
        );

        item.dot.setAttribute(
          'cx',
          String(
            p.x
          )
        );

        item.dot.setAttribute(
          'cy',
          String(
            p.y
          )
        );
      }
    }

    requestAnimationFrame(
      animate
    );
  }

  function boot() {
    ensureOverlay();

    updateState();
    layout();

    setInterval(
      updateState,
      200
    );

    setInterval(
      layout,
      500
    );

    addEventListener(
      'resize',
      layout,
      {
        passive:
          true
      }
    );

    addEventListener(
      'scroll',
      layout,
      {
        passive:
          true
      }
    );

    requestAnimationFrame(
      animate
    );
  }

  if (
    document.readyState ===
    'loading'
  ) {
    document.addEventListener(
      'DOMContentLoaded',
      boot,
      {
        once:
          true
      }
    );
  } else {
    boot();
  }
})();