(() => {
  "use strict";

  const VERSION = "TNG-HP-GENERATION-CHOICE-R3-SCOPED";
  const STYLE_ID = "iqf-solareast-hp-generation-choice-style";
  const ROOT_ID = "iqf-solareast-hp-generation-choice";

  if (window.IQF_SOLAREAST_HP_GENERATION_CHOICE) return;

  let stopped = false;
  let observer = null;
  let raf = 0;

  const norm = (value) =>
    String(value ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();

  function visible(node) {
    if (!node?.isConnected || typeof node.getBoundingClientRect !== "function") {
      return false;
    }

    const r = node.getBoundingClientRect();
    const s = getComputedStyle(node);

    return (
      r.width > 0 &&
      r.height > 0 &&
      s.display !== "none" &&
      s.visibility !== "hidden" &&
      s.opacity !== "0"
    );
  }

  function leafTextCandidates() {
    return [...document.querySelectorAll("h1,h2,h3,h4,p,div,span")]
      .filter(visible);
  }

  function exactText(text) {
    const wanted = norm(text);

    return leafTextCandidates().find((node) => {
      if (norm(node.textContent) !== wanted) return false;

      return ![...node.children].some(
        (child) => norm(child.textContent) === wanted
      );
    }) || null;
  }

  function containsLeaf(fragment) {
    const wanted = norm(fragment);

    return leafTextCandidates().find((node) => {
      const own = norm(node.textContent);

      if (!own.includes(wanted)) return false;

      return ![...node.children].some(
        (child) => norm(child.textContent).includes(wanted)
      );
    }) || null;
  }

  function serialsIn(node) {
    if (!node) return [];

    const text =
      String(
        node.textContent || ""
      );

    const matches = [
      ...text.matchAll(
        /F800711-TNG-\d{5}/gi
      ),
    ].map(
      (match) =>
        match[0].toUpperCase()
    );

    return [
      ...new Set(matches),
    ];
  }

  function installerContext(
    root = document.getElementById(
      ROOT_ID
    )
  ) {
    if (!root) return null;

    /*
     * Same scoping principle as the proven 00016 JMM flow:
     * resolve the concrete device only from the currently opened installer
     * branch, never from the whole admin SPA/document.
     */
    let node = root;

    for (
      let depth = 0;
      depth < 12 && node;
      depth += 1
    ) {
      if (
        node.isConnected &&
        typeof node.getBoundingClientRect ===
          "function"
      ) {
        const text =
          norm(
            node.textContent
          );

        const serials =
          serialsIn(node);

        if (
          serials.length === 1 &&
          (
            text.includes(
              "instalace tepelneho cerpadla"
            ) ||
            text.includes(
              "vyber tepelneho cerpadla"
            ) ||
            (
              text.includes(
                "detail zarizeni"
              ) &&
              text.includes(
                "tepelne cerpadlo"
              )
            )
          )
        ) {
          return {
            node,
            serial:
              serials[0],
          };
        }
      }

      node =
        node.parentElement;
    }

    return null;
  }

  function deviceSerial(
    root = document.getElementById(
      ROOT_ID
    )
  ) {
    return (
      installerContext(root)
        ?.serial ||
      "UNKNOWN"
    );
  }

  function storageKey(serial) {
    return "iqfanda:heatpump-generation:" + serial;
  }

  function readSelection(serial) {
    try {
      const value = localStorage.getItem(storageKey(serial));
      return value === "1" || value === "2" ? value : null;
    } catch (_) {
      return null;
    }
  }

  function writeSelection(serial, generation) {
    try {
      localStorage.setItem(storageKey(serial), generation);
    } catch (_) {
      // UI selection still works in-memory if storage is blocked.
    }
  }

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;

    style.textContent = `
      #${ROOT_ID} {
        margin-top: 22px;
        display: grid;
        gap: 14px;
      }

      #${ROOT_ID} .iqf-hp-generation-kicker {
        color: #56d8ff;
        font-size: 12px;
        font-weight: 850;
        letter-spacing: .17em;
        text-transform: uppercase;
      }

      #${ROOT_ID} .iqf-hp-generation-title {
        margin: 0;
        color: #f4fbff;
        font-size: clamp(20px, 1.55vw, 29px);
        font-weight: 900;
        line-height: 1.15;
      }

      #${ROOT_ID} .iqf-hp-generation-help {
        margin: 0;
        color: #9eb4c0;
        font-size: 14px;
        line-height: 1.45;
      }

      #${ROOT_ID} .iqf-hp-generation-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 18px;
        margin-top: 4px;
      }

      #${ROOT_ID} .iqf-hp-generation-card {
        min-height: 126px;
        border: 1px solid #14546a;
        border-radius: 14px;
        background:
          linear-gradient(180deg, rgba(9,45,59,.82), rgba(5,31,42,.82));
        padding: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
        transition:
          border-color .16s ease,
          box-shadow .16s ease,
          transform .16s ease,
          background .16s ease;
      }

      #${ROOT_ID} .iqf-hp-generation-card:hover {
        border-color: #25b9e7;
        box-shadow: 0 0 0 1px rgba(37,185,231,.12), 0 12px 34px rgba(0,0,0,.18);
      }

      #${ROOT_ID} .iqf-hp-generation-card[data-selected="true"] {
        border-color: #47d9ff;
        background:
          linear-gradient(180deg, rgba(11,65,83,.94), rgba(6,40,53,.94));
        box-shadow:
          0 0 0 1px rgba(71,217,255,.25),
          0 0 24px rgba(24,185,232,.12);
      }

      #${ROOT_ID} .iqf-hp-generation-copy {
        min-width: 0;
      }

      #${ROOT_ID} .iqf-hp-generation-number {
        color: #5bdfff;
        font-size: 11px;
        font-weight: 900;
        letter-spacing: .15em;
        text-transform: uppercase;
        margin-bottom: 8px;
      }

      #${ROOT_ID} .iqf-hp-generation-name {
        color: #f3fbff;
        font-size: clamp(18px, 1.3vw, 24px);
        line-height: 1.2;
        font-weight: 900;
      }

      #${ROOT_ID} .iqf-hp-generation-button {
        flex: 0 0 auto;
        border: 1px solid #346276;
        border-radius: 10px;
        background: #172f3a;
        color: #f3f8fb;
        padding: 12px 18px;
        min-width: 130px;
        font: inherit;
        font-weight: 850;
        cursor: pointer;
        transition:
          border-color .16s ease,
          background .16s ease,
          color .16s ease,
          box-shadow .16s ease;
      }

      #${ROOT_ID} .iqf-hp-generation-button:hover,
      #${ROOT_ID} .iqf-hp-generation-button:focus-visible {
        border-color: #45d8ff;
        background: #123d4d;
        outline: none;
      }

      #${ROOT_ID} .iqf-hp-generation-card[data-selected="true"]
      .iqf-hp-generation-button {
        border-color: #42d9c5;
        color: #9dfff0;
        background: #114d49;
      }

      #${ROOT_ID} .iqf-hp-generation-status {
        min-height: 20px;
        color: #9eb4c0;
        font-size: 13px;
      }

      #${ROOT_ID} .iqf-hp-generation-status strong {
        color: #8ff6e8;
      }

      [data-iqf-solareast-placeholder-hidden="true"] {
        display: none !important;
      }

      @media (max-width: 850px) {
        #${ROOT_ID} .iqf-hp-generation-grid {
          grid-template-columns: 1fr;
        }

        #${ROOT_ID} .iqf-hp-generation-card {
          min-height: 104px;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function closestWorkflowPanel(heading) {
    let current = heading;

    for (let i = 0; i < 7 && current; i++, current = current.parentElement) {
      const text = norm(current.textContent);

      if (
        text.includes("samostatny workflow tc") &&
        text.includes("pripraveno pro fazi 28")
      ) {
        return current;
      }
    }

    return heading.parentElement;
  }

  function setPlaceholderVisibility() {
    for (const phrase of [
      "v dalsim kroku zde vznikne instalace fyzickeho tepelneho cerpadla",
      "zigbee infrastruktura, zha, koordinator a parovani zarizeni se timto workflow nemeni"
    ]) {
      const node = containsLeaf(phrase);

      if (node) {
        node.dataset.iqfSolareastPlaceholderHidden = "true";
      }
    }
  }

  function updateCards(root, selected) {
    root.querySelectorAll("[data-generation]").forEach((card) => {
      const on = card.dataset.generation === selected;
      card.dataset.selected = on ? "true" : "false";

      const button = card.querySelector("button");
      if (button) {
        button.textContent = on ? "Vybráno" : "Vybrat";
        button.setAttribute("aria-pressed", on ? "true" : "false");
      }
    });

    const status = root.querySelector(".iqf-hp-generation-status");

    if (status) {
      status.innerHTML = selected
        ? `Vybráno: <strong>TNG generace ${selected}</strong>`
        : "Zatím není vybrána žádná generace.";
    }
  }

  function choose(root, generation) {
    const value = Number(generation);

    if (
      value !== 1 &&
      value !== 2
    ) {
      return;
    }

    const serial =
      deviceSerial(root);

    if (
      !/^F800711-TNG-\d{5}$/.test(
        serial
      )
    ) {
      const status =
        root?.querySelector(
          ".iqf-hp-generation-status"
        );

      if (status) {
        status.textContent =
          "Nelze jednoznačně určit právě instalované zařízení. Volba nebyla provedena.";
      }

      return;
    }

    /*
     * R4R5 GENERATION PARITY CONTRACT
     *
     * TNG generace 1 and TNG generace 2 use EXACTLY the same installer
     * activation event and therefore the same backend InstallationModule flow.
     * The only variable is `generation`.
     */
    writeSelection(
      serial,
      String(value)
    );

    updateCards(
      root,
      String(value)
    );

    window.dispatchEvent(
      new CustomEvent(
        "iqfanda:heatpump-generation-selected",
        {
          detail: {
            deviceSerial: serial,
            generation: value,
            label:
              "TNG generace "
              + value,
            source: VERSION,
            workflow:
              "heat_pump_module_standard",
            context:
              "current_installer_device",
          },
        }
      )
    );
  }

  function card(generation) {
    const wrapper = document.createElement("section");
    wrapper.className = "iqf-hp-generation-card";
    wrapper.dataset.generation = String(generation);
    wrapper.dataset.selected = "false";

    const copy = document.createElement("div");
    copy.className = "iqf-hp-generation-copy";

    const number = document.createElement("div");
    number.className = "iqf-hp-generation-number";
    number.textContent = "Generace " + generation;

    const name = document.createElement("div");
    name.className = "iqf-hp-generation-name";
    name.textContent = "TNG generace " + generation;

    copy.append(number, name);

    const button = document.createElement("button");
    button.type = "button";
    button.className = "iqf-hp-generation-button";
    button.textContent = "Vybrat";
    button.setAttribute("aria-pressed", "false");
    button.addEventListener("click", () => choose(wrapper.parentElement.parentElement, String(generation)));

    wrapper.append(copy, button);

    wrapper.addEventListener("dblclick", () => {
      choose(wrapper.parentElement.parentElement, String(generation));
    });

    return wrapper;
  }

  function mount() {
    if (stopped) return;

    const originalHeading =
      exactText("Samostatný workflow TČ") ||
      exactText("Samostatny workflow TC");

    if (!originalHeading) return;

    const panel = closestWorkflowPanel(originalHeading);

    if (!panel || !visible(panel)) return;

    originalHeading.textContent = "Výběr tepelného čerpadla";

    setPlaceholderVisibility();
    ensureStyle();

    let root = panel.querySelector("#" + ROOT_ID);

    if (!root) {
      root = document.createElement("div");
      root.id = ROOT_ID;
      root.dataset.version = VERSION;

      const kicker = document.createElement("div");
      kicker.className = "iqf-hp-generation-kicker";
      kicker.textContent = "Typ tepelného čerpadla";

      const title = document.createElement("h3");
      title.className = "iqf-hp-generation-title";
      title.textContent = "Vyberte generaci TNG";

      const help = document.createElement("p");
      help.className = "iqf-hp-generation-help";
      help.textContent =
        "Vyberte generaci tepelného čerpadla pro pokračování instalačního procesu. Obě generace používají stejný modulový workflow TNG IQ FANDA.";

      const grid = document.createElement("div");
      grid.className = "iqf-hp-generation-grid";
      grid.append(card(1), card(2));

      const status = document.createElement("div");
      status.className = "iqf-hp-generation-status";

      root.append(kicker, title, help, grid, status);
      panel.append(root);
    }

    const serial =
      deviceSerial(root);

    const validSerial =
      /^F800711-TNG-\d{5}$/.test(
        serial
      );

    root.dataset.deviceSerial =
      validSerial
        ? serial
        : "";

    root
      .querySelectorAll(
        ".iqf-hp-generation-button"
      )
      .forEach(
        (button) => {
          button.disabled =
            !validSerial;
        }
      );

    if (validSerial) {
      updateCards(
        root,
        readSelection(serial)
      );
    } else {
      updateCards(
        root,
        null
      );

      const status =
        root.querySelector(
          ".iqf-hp-generation-status"
        );

      if (status) {
        status.textContent =
          "Čekám na jednoznačný kontext konkrétního zařízení…";
      }
    }
  }

  function wake() {
    if (stopped || raf) return;

    raf = requestAnimationFrame(() => {
      raf = 0;
      mount();
    });
  }

  observer = new MutationObserver(wake);
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
  });

  window.addEventListener("popstate", wake);
  window.addEventListener("hashchange", wake);
  window.addEventListener("pageshow", wake);

  const api = Object.freeze({
    version: VERSION,
    workflow: "heat_pump_module_standard",
    scope: "current_installer_device",
    supportedGenerations: Object.freeze([1, 2]),
    refresh: wake,
    getSelection: () => {
      const root =
        document.getElementById(
          ROOT_ID
        );

      const serial =
        deviceSerial(root);

      return {
        deviceSerial: serial,
        generation: readSelection(serial),
      };
    },
    clearSelection: () => {
      const root =
        document.getElementById(
          ROOT_ID
        );

      const serial =
        deviceSerial(root);

      try {
        localStorage.removeItem(storageKey(serial));
      } catch (_) {}
      wake();
    },
    dispose: () => {
      stopped = true;
      observer?.disconnect();
      document.getElementById(ROOT_ID)?.remove();
      document.getElementById(STYLE_ID)?.remove();
    },
  });

  window.IQF_SOLAREAST_HP_GENERATION_CHOICE = api;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", wake, { once: true });
  } else {
    wake();
  }
})();
