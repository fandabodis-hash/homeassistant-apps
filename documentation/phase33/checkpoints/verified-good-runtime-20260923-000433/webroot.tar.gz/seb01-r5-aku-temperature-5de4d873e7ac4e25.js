(function phase30Seb01AkuTemperatureFullInventoryV2() {
  "use strict";
  // F30_04C_R4_SHARED_RUNTIME_ADAPTER
  var R = window.IQF_SEB01_RUNTIME;
  if (!R) throw new Error("SEB01_RUNTIME_NOT_LOADED");

  var MARKER = "__F30_02X_SEB01_FULL_ZIGBEE_WIFI_00012__";

  if (window[MARKER]) return;

  window[MARKER] = true;

  var CATALOG_URL = "/phase30-model00012-full-zigbee-wifi-catalog-v2.json?v=20260915-015156";
  var STORE_KEY = "f30_02x_seb01_model00012_aku_temperature";
  var STYLE_ID = "f30-02x-seb01-aku-style";

  var cachedData = null;
  var optionByUid = {};
  var selectedPending = null;
  var userInteractingUntil = 0;

  function text(value) {
    return value === null || value === undefined
      ? ""
      : String(value).trim();
  }

  function normalize(value) {
    return text(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  }

  function compact(value) {
    return normalize(value).replace(/[^a-z0-9]+/g, "");
  }

  function isAdminPage() { return R.isAdmin(); }

  function number(value) {
    if (
      typeof value === "number" &&
      Number.isFinite(value)
    ) {
      return value;
    }

    if (typeof value === "string") {
      var match = value
        .replace(",", ".")
        .match(/-?\d+(?:\.\d+)?/);

      if (match) {
        var n = Number(match[0]);

        if (Number.isFinite(n)) return n;
      }
    }

    return null;
  }

  function formatOptionValue(option) { return R.format(option, "\u00b0C", 1); }

  function findSchema() {
    return document.querySelector(
      '[data-f29-00012-schema="svj-blansko-only"], .f29-00012-schema-v2'
    );
  }

  function findAkuCard(schema) {
    if (!schema) return null;

    var direct = schema.querySelector(
      ".f29-00012-aku,.f29-00012-aku-tank,.f29-00012-storage"
    );

    if (direct) return direct;

    var nodes = Array.prototype.slice.call(
      schema.querySelectorAll("section,article,div")
    );

    var best = null;

    nodes.forEach(function(el) {
      var c = compact(el.textContent || "");

      if (
        (
          c.indexOf("akunadrz") !== -1 ||
          c.indexOf("akumulacetepla") !== -1
        ) &&
        c.indexOf("bojler") === -1
      ) {
        if (
          !best ||
          el.children.length < best.children.length
        ) {
          best = el;
        }
      }
    });

    return best;
  }

  function findTemperatureBox(card) {
    if (!card) return null;

    var direct = card.querySelector(
      ".f29-00012-temperature"
    );

    if (direct) return direct;

    var nodes = Array.prototype.slice.call(
      card.querySelectorAll("div,span,p")
    );

    for (var i = 0; i < nodes.length; i += 1) {
      var c = compact(nodes[i].textContent || "");

      if (
        c === "teplota" ||
        c.indexOf("teplota") === 0
      ) {
        return nodes[i].parentElement || nodes[i];
      }
    }

    return card;
  }

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;

    var style = document.createElement("style");

    style.id = STYLE_ID;

    style.textContent = [
      ".f30-02x-picker{margin-top:.65rem;padding:.7rem;border:1px solid rgba(93,203,255,.38);border-radius:14px;background:rgba(2,22,34,.96);display:grid;gap:.5rem;position:relative;z-index:5;min-width:320px;max-width:460px}",
      ".f30-02x-picker label{display:grid;gap:.35rem;color:#d9f5ff;font-size:.72rem;font-weight:900;letter-spacing:.04em;text-transform:uppercase}",
      ".f30-02x-picker select{width:100%;min-height:38px;border-radius:10px;border:1px solid rgba(124,221,255,.42);background:#061b28;color:#f1fbff;padding:.45rem .55rem;font-size:.82rem}",
      ".f30-02x-picker .f30-02x-actions{display:flex;justify-content:flex-end}",
      ".f30-02x-picker button{border:1px solid rgba(124,221,255,.55);background:rgba(34,184,255,.20);color:#e7fbff;border-radius:10px;padding:.42rem .75rem;font-weight:900;font-size:.76rem;cursor:pointer}",
      ".f30-02x-picker button:disabled{opacity:.45;cursor:not-allowed}",
      ".f30-02x-picker small{color:#9dc8d7;font-size:.70rem;line-height:1.25}",
      ".f30-02x-status{color:#75f0b3!important}",
      ".f30-02x-warning{color:#ffd47a!important}",
      ".f30-02x-source{display:block;margin-top:.2rem;font-size:.68rem;color:#9dc8d7;font-weight:700}",
      ".f30-02x-live-value{display:inline-block;margin-left:.35rem;color:#fff;font-weight:900;text-shadow:0 0 10px rgba(72,220,255,.45)}"
    ].join("\n");

    document.head.appendChild(style);
  }

  async function loadData() { return cachedData; }

  function loadLocalBinding() {
    try {
      var raw = window.localStorage.getItem(STORE_KEY);

      if (raw) return JSON.parse(raw);
    } catch (error) {}

    return null;
  }

  async function saveLocalBinding(binding) {
    try { await R.save("aku-temperature", binding); return true; }
    catch (error) { return false; }
  }

  function selectedOption(options, binding) {
    if (!binding) return null;

    var uid = text(binding.uid);

    if (uid) {
      for (var i = 0; i < options.length; i += 1) {
        if (text(options[i].uid) === uid) {
          return options[i];
        }
      }
    }

    var deviceName = compact(binding.device_name);
    var entityName = compact(binding.entity_name);

    for (var j = 0; j < options.length; j += 1) {
      if (
        deviceName &&
        entityName &&
        compact(options[j].device_name) === deviceName &&
        compact(options[j].entity_name) === entityName
      ) {
        return options[j];
      }
    }

    return null;
  }

  function candidateValueNodes(box) {
    var out = [];

    if (!box) return out;

    var walker = document.createTreeWalker(
      box,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: function(node) {
          var parent = node.parentElement;

          if (!parent) {
            return NodeFilter.FILTER_REJECT;
          }

          if (
            parent.closest(".f30-02x-picker") ||
            parent.closest(".f30-02x-source") ||
            parent.closest(".f30-02x-live-value")
          ) {
            return NodeFilter.FILTER_REJECT;
          }

          var t = text(node.nodeValue);

          if (!t) {
            return NodeFilter.FILTER_REJECT;
          }

          var c = compact(t);

          if (
            c === "teplota" ||
            c.indexOf("zdroj") !== -1
          ) {
            return NodeFilter.FILTER_REJECT;
          }

          if (
            t.indexOf("\u00b0C") !== -1 ||
            t.indexOf("\u2014") !== -1 ||
            t === "-" ||
            /^-?\d+(?:[,.]\d+)?$/.test(t)
          ) {
            return NodeFilter.FILTER_ACCEPT;
          }

          return NodeFilter.FILTER_REJECT;
        }
      }
    );

    var node;

    while ((node = walker.nextNode())) {
      out.push(node);
    }

    return out;
  }

  function applyValue(option) {
    var card = findAkuCard(findSchema());
    var box = findTemperatureBox(card);
    if (!box) return;
    R.paintText(box, function(target) { var nodes = candidateValueNodes(target); return nodes.length ? nodes[0] : null; }, R.view("aku-temperature", "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc"), "\u00b0C", 1, "aku-temperature");
  }

  function optionLabel(option) {
    var parts = [
      text(option.entity_name || "Entita"),
      formatOptionValue(option)
    ];

    return parts
      .filter(Boolean)
      .join(" - ");
  }

  function addOptions(
    select,
    label,
    options
  ) {
    if (!options || !options.length) return;

    var group = document.createElement("optgroup");

    group.label = label;

    options.forEach(function(option) {
      var uid = text(option.uid);

      if (!uid) return;

      optionByUid[uid] = option;

      var opt = document.createElement("option");

      opt.value = uid;
      opt.textContent = optionLabel(option);

      group.appendChild(opt);
    });

    select.appendChild(group);
  }

  function currentSelected(select) {
    if (!select) return null;

    var uid = text(select.value);

    if (!uid) return null;

    return optionByUid[uid] || null;
  }

  function removeOldAkuPicker(card) {
    var old = card.querySelector(
      ".f30-02w-seb01-picker"
    );

    if (old) old.remove();
  }

  function buildAdminPicker(
    card,
    data,
    selected
  ) {
    if (
      !card ||
      card.querySelector(".f30-02x-picker")
    ) {
      return;
    }

    removeOldAkuPicker(card);
    ensureStyle();

    optionByUid = {};

    var box = findTemperatureBox(card) || card;

    var picker = document.createElement("div");

    picker.className = "f30-02x-picker";

    picker.setAttribute(
      "data-f30-02x-seb01",
      "full-zigbee-wifi-inventory"
    );

    picker.innerHTML =
      '<label>Teplota AKU - SEB-01 / kompletni seznam<select></select></label>' +
      '<small>Kompletni Zigbee + Wi-Fi seznam patri pouze modelu 00012. Nazvy zarizeni jsou podle instalatera.</small>' +
      '<div class="f30-02x-actions"><button type="button" class="f30-02x-save" disabled>Ulozit</button></div>' +
      '<small class="f30-02x-status"></small>';

    box.appendChild(picker);

    var select = picker.querySelector("select");
    var saveButton = picker.querySelector(
      ".f30-02x-save"
    );
    var status = picker.querySelector(
      ".f30-02x-status"
    );

    var empty = document.createElement("option");

    empty.value = "";
    empty.textContent = data.options.length
      ? "Vyber zarizeni / entitu..."
      : "Katalog modelu 00012 je prazdny";

    select.appendChild(empty);

    addOptions(
      select,
      "Doporuceno pro AKU nadrz",
      data.recommended || []
    );

    (data.devices || []).forEach(function(device) {
      var prefix = device.transport === "wifi"
        ? "Wi-Fi"
        : "Zigbee";

      addOptions(
        select,
        prefix + " - " + text(device.device_name || "zarizeni"),
        device.entities || []
      );
    });

    if (
      selected &&
      text(selected.uid) &&
      optionByUid[text(selected.uid)]
    ) {
      select.value = text(selected.uid);
    }

    function markInteracting() {
      userInteractingUntil = Date.now() + 60000;
    }

    function refreshStatus() {
      var chosen = currentSelected(select);

      selectedPending = chosen;
      saveButton.disabled = !chosen;

      if (!status) return;

      if (chosen) {
        status.className = "f30-02x-status";

        status.textContent =
          "Vybrano: " +
          text(chosen.device_name || "zarizeni") +
          " / " +
          text(chosen.entity_name || "entita") +
          " = " +
          formatOptionValue(chosen) +
          ". Potvrd tlacitkem Ulozit.";
      } else {
        status.className =
          "f30-02x-status" +
          (data.options.length
            ? ""
            : " f30-02x-warning");

        status.textContent =
          "SEB-01: Zigbee " +
          (data.counts && data.counts.zigbee_devices || 0) +
          " zarizeni, Wi-Fi " +
          (data.counts && data.counts.wifi_devices || 0) +
          " zarizeni, celkem " +
          data.options.length +
          " entit.";
      }
    }

    [
      "focus",
      "pointerdown",
      "mousedown",
      "keydown",
      "input",
      "change",
      "click"
    ].forEach(function(eventName) {
      select.addEventListener(
        eventName,
        markInteracting
      );
    });

    select.addEventListener(
      "input",
      refreshStatus
    );

    select.addEventListener(
      "change",
      refreshStatus
    );

    saveButton.addEventListener(
      "click",
      async function() {
        markInteracting();

        var chosen =
          currentSelected(select) ||
          selectedPending;

        if (!chosen) {
          refreshStatus();
          return;
        }

        var ok = await saveLocalBinding(chosen);
        if (!ok) {
          if (status) status.textContent = "Ulozeni vazby na server selhalo; vyber nebyl potvrzen.";
          return;
        }

        applyValue(chosen);

        if (status) {
          status.className =
            "f30-02x-status" +
            (ok ? "" : " f30-02x-warning");

          status.textContent = R.saveMessage("aku-temperature", "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc");
        }
      }
    );

    if (selected) {
      applyValue(selected);
    }

    refreshStatus();
  }

  R.registerAdapter({
    deviceUuid: "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc", slot: "aku-temperature", capability: "temperature",
    digits: 1, legacy: loadLocalBinding,
    pickerSelector: ".f30-02x-picker", statusSelector: ".f30-02x-status",
    locate: function() { var card=findAkuCard(findSchema()); return card ? {card:card,box:findTemperatureBox(card)} : null; },
    paint: function(entry) { applyValue(entry); },
    build: function(data,selected) { cachedData=data; var card=findAkuCard(findSchema()); if(card) buildAdminPicker(card,data,selected); }
  });
})();
