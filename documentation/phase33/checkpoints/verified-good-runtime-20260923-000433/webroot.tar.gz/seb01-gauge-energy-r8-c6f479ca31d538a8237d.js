/* F30.4D R3 -- SEB-01B current-electric-power -> existing F29 gauge.
 * Replaces the existing power-picker adapter, not a second slot registration.
 * Uses normalized runtime entry. Never scrapes displayed kW, tokens or a page.
 * No fetch, no own timer and no MutationObserver: the shared R5 reader owns both.
 */
(function(root,factory){
  if(typeof module==='object'&&module.exports) module.exports=factory;
  else factory(root,true);
}(typeof window!=='undefined'?window:globalThis,function(env,install){
  'use strict';
  const VERSION='F30.4D-R3-SEB01B-BOUND-GAUGE';
  const SLOT='current-electric-power';
  const UUID='28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc';
  const MIN_KW=0.3,MAX_KW=15;
  const MISSING='\u2014 %';
  const frames=new WeakMap();
  let calls=0,lastDiagnostic=[];
  const error=code=>{throw new Error(code);};
  function numeric(v){
    if(typeof v==='number') return Number.isFinite(v)?v:null;
    if(typeof v!=='string'||!/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:e[+-]?\d+)?$/i.test(v.trim()))return null;
    const n=Number(v.trim().replace(',','.'));return Number.isFinite(n)?n:null;
  }
  function percentFromKw(kw){
    if(typeof kw!=='number'||!Number.isFinite(kw))return null;
    return Math.max(0,Math.min(100,(kw-MIN_KW)/(MAX_KW-MIN_KW)*100));
  }
  function project(entry){
    const e=entry||{};
    if(e.has_value!==true||e.available===false)return {kw:null,percent:null,status:String(e.status||'unavailable')};
    if(/^(snapshot_only|unknown|unavailable|offline|unbound|no_context|api_stale|stale|loading)$/i.test(e.status||''))
      return {kw:null,percent:null,status:String(e.status)};
    const n=numeric(e.value),unit=String(e.unit||'').trim();
    if(n===null||!['W','kW'].includes(unit))return {kw:null,percent:null,status:'invalid_power'};
    const kw=unit==='W'?n/1000:n;
    return {kw,percent:percentFromKw(kw),status:String(e.status||'available')};
  }
  function set(node,name,value){
    const s=String(value);if(node.getAttribute(name)!==s)node.setAttribute(name,s);
  }
  function label(node,value){if(node.textContent!==value)node.textContent=value;}
  function targets(){
    const result=[],seen=new Set();
    for(const box of env.document.querySelectorAll('[data-f30-r34-bound-power="current-electric-power"]')){
      const card=box.closest('.f29-00012-heatpump');
      if(!card||seen.has(card))continue;
      const workspace=card.closest('[data-f29-00012-schema="svj-blansko-only"]');
      if(!workspace)continue;
      seen.add(card);result.push({card,box});
    }
    return result;
  }
  function one(root,selector,code){const a=root.querySelectorAll(selector);if(a.length!==1)error(code);return a[0];}
  function elements(card){
    const gauge=one(card,'.f29-00012-gauge.f29-00012-gauge-r2','GAUGE_ROOT_NOT_UNIQUE');
    const svg=one(gauge,':scope > svg','GAUGE_SVG_NOT_UNIQUE');
    const text=one(gauge,':scope > strong','GAUGE_HTML_PERCENT_NOT_UNIQUE');
    const track=one(svg,'path.f29-00012-gauge-track','GAUGE_TRACK_NOT_UNIQUE');
    const needle=one(svg,'line.f29-00012-gauge-needle','GAUGE_NEEDLE_NOT_UNIQUE');
    const pin=one(svg,'circle.f29-00012-gauge-pin','GAUGE_PIN_NOT_UNIQUE');
    if(!svg.viewBox||svg.viewBox.baseVal.width<=0)error('GAUGE_VIEWBOX_INVALID');
    return {gauge,svg,text,track,needle,pin};
  }
  function pathPoint(track,needle,percent){
    const len=track.getTotalLength();
    if(!Number.isFinite(len)||len<=0)error('GAUGE_TRACK_LENGTH_INVALID');
    const tm=track.getCTM(),nm=needle.getCTM();
    if(!tm||!nm)error('GAUGE_TRANSFORM_UNAVAILABLE');
    const matrix=nm.inverse().multiply(tm);
    const map=p=>{
      const x=matrix.a*p.x+matrix.c*p.y+matrix.e,y=matrix.b*p.x+matrix.d*p.y+matrix.f;
      if(!Number.isFinite(x)||!Number.isFinite(y))error('GAUGE_COORDINATES_INVALID');
      return {x,y};
    };
    const first=map(track.getPointAtLength(0)),last=map(track.getPointAtLength(len));
    if(Math.abs(first.x-last.x)<1)error('GAUGE_LEFT_RIGHT_AMBIGUOUS');
    const forward=first.x<last.x,ratio=Math.max(0,Math.min(100,percent))/100;
    const p=map(track.getPointAtLength(len*(forward?ratio:1-ratio)));
    return {point:p,zero:forward?first:last,full:forward?last:first,length:len};
  }
  function paint(entry){
    calls+=1;const derived=project(entry),diagnostics=[];
    for(const target of targets()){
      let parts;
      try{
        parts=elements(target.card);
        const {gauge,svg,text,track,needle}=parts;
        const missing=derived.percent===null;
        let geometry=null;
        if(!missing)geometry=pathPoint(track,needle,derived.percent);
        const display=missing?MISSING:Math.round(derived.percent)+'%';
        // Same nodes as the production template: no rebuild or replacement.
        label(text,display);
        set(needle,'visibility',missing?'hidden':'visible');
        if(geometry){
          set(needle,'x2',geometry.point.x.toFixed(4));
          set(needle,'y2',geometry.point.y.toFixed(4));
        }
        set(gauge,'data-seb01b-gauge-version',VERSION);
        set(gauge,'data-seb01b-gauge-state',derived.status);
        set(gauge,'data-seb01b-input-kw',missing?'':derived.kw);
        set(gauge,'data-seb01b-percent',missing?'':derived.percent.toFixed(6));
        set(gauge,'data-seb01b-gauge-slot',SLOT);
        const hint='Relativn\u00ed v\u00fdkon podle elektrick\u00e9ho p\u0159\u00edkonu: 0 % p\u0159i 0,3 kW, 100 % p\u0159i 15 kW. '+
          'Nejde o m\u011b\u0159en\u00fd tepeln\u00fd v\u00fdkon. '+(missing?'SEB-01: '+derived.status:'SEB-01B: '+display);
        set(text,'title',hint);
        set(svg,'aria-label',missing?'Relativni vykon nedostupny':('Relativni vykon '+Math.round(derived.percent)+' procent'));
        const d={slot:SLOT,inputKw:derived.kw,percent:derived.percent,display,status:derived.status,
          geometry,needleHidden:missing,renderedText:text.textContent,
          needleX:Number(needle.getAttribute('x2')),needleY:Number(needle.getAttribute('y2'))};
        frames.set(gauge,d);diagnostics.push(d);
      }catch(e){
        const code=/^[A-Z_]+$/.test(e.message||'')?e.message:'GAUGE_PAINT_ERROR';
        if(parts){label(parts.text,MISSING);set(parts.needle,'visibility','hidden');set(parts.gauge,'data-seb01b-gauge-state',code);}
        diagnostics.push({slot:SLOT,error:code});
        if(env.console)env.console.error('SEB-01B gauge: '+code);
      }
    }
    lastDiagnostic=diagnostics;
  }
  function diagnostics(){
    return {version:VERSION,slot:SLOT,paintCalls:calls,matchedGauges:targets().length,
      minKw:MIN_KW,maxKw:MAX_KW,source:'shared_seb01_runtime_entry',frames:lastDiagnostic,
      browserRenderTest:'NOT_AUTOMATICALLY_CERTIFIED',endToEnd20sVerified:false};
  }
  if(install){
    const R=env.IQF_SEB01_RUNTIME;
    if(!R||R.version!=='F30.4C-R5-PERSISTED-READER')error('SEB01_R5_RUNTIME_REQUIRED');
    if(env.IQF_SEB01_GAUGE_03_15)error('GAUGE_ADAPTER_ALREADY_LOADED');
    R.registerAdapter({
      slot:SLOT,capability:'power',digits:3,deviceUuid:UUID,
      title:'Elektrom\u011br \u2013 aktu\u00e1ln\u00ed \u010dinn\u00fd v\u00fdkon',
      locate:()=>targets()[0]||null,paint,build:()=>{}
    });
    env.IQF_SEB01_GAUGE_03_15=Object.freeze({version:VERSION,diagnostics});
  }
  return Object.freeze({version:VERSION,project,percentFromKw,pathPoint,paint,diagnostics});
}));
/* F30_04E_R8_ENERGY_ACTUAL_ROW
 * Display adapter only. The R5 runtime owns authentication, polling and lifetime.
 * Render only the leaf of the current F29 metric row; never a parent container.
 */
(function () {
  'use strict';
  const R = window.IQF_SEB01_RUNTIME;
  const VERSION = 'F30.4E-R8-ACTUAL-ENERGY-ROW';
  const UUID = '28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc';
  const SLOT = 'heatpump-energy-today';
  const MISSING = '\u2014 kWh';
  const normal = s => String(s == null ? '' : s).normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  let calls = 0, frames = [], lastScan = 'not_scanned';

  if (!R || R.version !== 'F30.4C-R5-PERSISTED-READER') {
    throw new Error('R8_SHARED_RUNTIME_CONTRACT_MISMATCH');
  }
  if (window.IQF_F30_04E_R8_ENERGY) throw new Error('R8_ADAPTER_ALREADY_REGISTERED');

  function targets() {
    const out = [];
    const cards = document.querySelectorAll(
      '[data-f29-00012-schema="svj-blansko-only"] .f29-00012-heatpump'
    );
    lastScan = cards.length ? 'energy_row_not_found' : 'workspace_not_mounted';
    for (const card of cards) {
      if (!card.querySelector('[data-f30-r34-bound-power="current-electric-power"]')) continue;
      const boxes = card.querySelectorAll('.f29-00012-metric-box.f29-00012-metric-box-r2');
      if (boxes.length !== 1) { lastScan = 'metric_box_not_unique'; continue; }
      const matches = Array.from(boxes[0].querySelectorAll(':scope > .f29-00012-metric-row'))
        .filter(row => {
          const labels = row.querySelectorAll(':scope > span.f29-00012-metric-label');
          return labels.length === 1 && normal(labels[0].textContent) === 'dnesni spotreba';
        });
      if (matches.length !== 1) { lastScan = 'energy_row_not_unique'; continue; }
      const box = matches[0];
      const leaves = box.querySelectorAll(':scope > strong.f29-00012-metric-value');
      if (leaves.length !== 1 || leaves[0].childElementCount !== 0 ||
          Array.from(leaves[0].childNodes).some(n => n.nodeType !== 3)) {
        lastScan = 'energy_value_is_not_a_unique_text_leaf'; continue;
      }
      out.push({card, box, node:leaves[0]});
    }
    if (out.length) lastScan = 'matched';
    return out;
  }
  function presentation(raw) {
    const entry = raw || {};
    const quality = String(entry.quality || entry.status || 'waiting_for_value');
    const bad = /^(?:unavailable|offline|unknown|stale|api_stale|no_context|loading|unbound|snapshot_only|waiting_for_value|not_initialized|energy_source_missing)$/i;
    const valid = entry.has_value === true && entry.available !== false &&
      entry.unit === 'kWh' && typeof entry.value === 'number' &&
      Number.isFinite(entry.value) && entry.value >= 0 && !bad.test(quality);
    const partial = valid && /^(partial_period|initializing|source_rebound)$/.test(quality);
    const value = valid ? R.format(entry, 'kWh', 2) + (partial ? ' *' : '') : MISSING;
    const hint = !valid ? 'Dne\u0161n\u00ed spot\u0159eba nen\u00ed dostupn\u00e1. ' + R.hint(entry) :
      (partial ? '\u010c\u00e1ste\u010dn\u00e9 obdob\u00ed: hodnota nemus\u00ed pokr\u00fdvat cel\u00fd den od p\u016flnoci. ' : '') +
      'Serverov\u00e1 energie v kWh; nikoli okam\u017eit\u00fd elektrick\u00fd p\u0159\u00edkon. ' + R.hint(entry);
    return {value, hint, partial, quality, valid};
  }
  function attr(node, name, value) {
    if (node.getAttribute(name) !== String(value)) node.setAttribute(name, String(value));
  }
  function paint(entry) {
    calls += 1;
    const p = presentation(entry);
    frames = [];
    for (const t of targets()) {
      // Preserve the exact strong element and its siblings. The first paint
      // may create its sole text node; subsequent paints update nodeValue.
      if (t.node.textContent !== p.value) {
        if (t.node.childNodes.length === 1) t.node.firstChild.nodeValue = p.value;
        else { while(t.node.firstChild) t.node.removeChild(t.node.firstChild);
          t.node.appendChild(document.createTextNode(p.value)); }
      }
      attr(t.node, 'data-seb01b-derived-slot', SLOT);
      attr(t.node, 'data-seb01b-energy-version', VERSION);
      attr(t.node, 'data-seb01b-energy-status', p.quality);
      attr(t.node, 'data-seb01b-energy-partial', p.partial ? 'true' : 'false');
      attr(t.node, 'title', p.hint);
      frames.push({slot:SLOT, displayed:t.node.textContent, hasValue:p.valid,
        partial:p.partial, quality:p.quality});
    }
  }
  R.registerAdapter({
    slot:SLOT, deviceUuid:UUID, capability:'energy', digits:2,
    title:'Dne\u0161n\u00ed spot\u0159eba tepeln\u00e9ho \u010derpadla',
    locate:() => targets()[0] || null, paint, build:() => {}
  });
  window.IQF_F30_04E_R8_ENERGY = Object.freeze({
    version:VERSION,
    diagnostics:() => ({version:VERSION, slot:SLOT, paintCalls:calls,
      matchedRows:targets().length, locator:lastScan, frames,
      source:'existing_seb01b_server_value', noOwnPolling:true})
  });
})();
