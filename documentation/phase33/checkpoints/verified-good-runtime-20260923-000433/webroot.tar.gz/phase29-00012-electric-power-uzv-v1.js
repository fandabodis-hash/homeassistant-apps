(() => {
  "use strict";

  const VERSION =
    "f29-07i-00012-electric-power-uzv-v1";

  const DEVICE_UUID =
    "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc";

  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';

  const PANEL_CLASS =
    "f29-00012-power-uzv-picker";

  const STYLE_ID =
    "f29-00012-power-uzv-style";

  let timer = null;
  let bootedRoot = null;
  let busy = false;

  const txt = {
    label:
      "Zdroj aktu\u00e1ln\u00edho elektrick\u00e9ho p\u0159\u00edkonu",
    helper:
      "Vyberte pojmenovan\u00e9 m\u011b\u0159ic\u00ed za\u0159\u00edzen\u00ed. Zigbee a Wi-Fi jsou v jednom UZV seznamu.",
    empty:
      "\u2014 bez p\u0159i\u0159azen\u00ed \u2014",
    saving:
      "Ukl\u00e1d\u00e1m\u2026",
    saved:
      "Ulo\u017eeno.",
    cleared:
      "Zdroj m\u011b\u0159en\u00ed byl zru\u0161en.",
    error:
      "Chyba",
    offline:
      "offline",
  };

function storedToken() {
    if (
      typeof window === "undefined"
    ) {
      return "";
    }

    function cleanToken(value) {
      if (
        value === undefined ||
        value === null
      ) {
        return "";
      }

      let text =
        String(value).trim();

      if (!text) {
        return "";
      }

      if (
        (
          text.startsWith('"') &&
          text.endsWith('"')
        ) ||
        (
          text.startsWith("'") &&
          text.endsWith("'")
        )
      ) {
        text =
          text.slice(
            1,
            -1,
          ).trim();
      }

      if (
        /^bearer\s+/i.test(text)
      ) {
        text =
          text.replace(
            /^bearer\s+/i,
            "",
          ).trim();
      }

      if (
        /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(
          text,
        )
      ) {
        return text;
      }

      if (
        text.length > 40 &&
        !/[{}\[\]\s]/.test(
          text,
        ) &&
        /[A-Za-z0-9_-]/.test(
          text,
        )
      ) {
        return text;
      }

      return "";
    }

    function findTokenInValue(
      value,
      depth = 0,
    ) {
      if (
        value === undefined ||
        value === null ||
        depth > 8
      ) {
        return "";
      }

      if (
        typeof value === "string"
      ) {
        const direct =
          cleanToken(value);

        if (direct) {
          return direct;
        }

        const text =
          value.trim();

        if (
          (
            text.startsWith("{") &&
            text.endsWith("}")
          ) ||
          (
            text.startsWith("[") &&
            text.endsWith("]")
          )
        ) {
          try {
            return findTokenInValue(
              JSON.parse(text),
              depth + 1,
            );
          } catch (error) {
            return "";
          }
        }

        return "";
      }

      if (
        typeof value !== "object"
      ) {
        return cleanToken(value);
      }

      const priorityKeys = [
        "admin_access_token",
        "adminAccessToken",
        "access_token",
        "accessToken",
        "access",
        "id_token",
        "idToken",
        "jwt",
        "bearer",
        "authToken",
        "adminToken",
        "customerToken",
        "portalToken",
        "token",
      ];

      for (
        const key
        of priorityKeys
      ) {
        if (
          Object.prototype
            .hasOwnProperty.call(
              value,
              key,
            )
        ) {
          const found =
            findTokenInValue(
              value[key],
              depth + 1,
            );

          if (found) {
            return found;
          }
        }
      }

      for (
        const [key, nested]
        of Object.entries(value)
      ) {
        if (
          /token|jwt|bearer|auth|access|session|admin|portal|customer/i.test(
            key,
          )
        ) {
          const found =
            findTokenInValue(
              nested,
              depth + 1,
            );

          if (found) {
            return found;
          }
        }
      }

      for (
        const nested
        of Object.values(value)
      ) {
        const found =
          findTokenInValue(
            nested,
            depth + 1,
          );

        if (found) {
          return found;
        }
      }

      return "";
    }

    const preferredKeys = [
      "adminToken",
      "admin_token",
      "adminAccessToken",
      "admin_access_token",
      "iqf_admin_token",
      "tng_iq_fanda_admin_token",
      "tngIqFandaAdminToken",
      "auth",
      "auth-store",
      "authStore",
      "admin-auth",
      "adminAuth",
      "iqf_auth",
      "iqfAuth",
      "tng_iq_fanda_auth",
      "tngIqFandaAuth",
      "iqfanda_access_token",
      "access_token",
      "accessToken",
      "auth_token",
      "authToken",
      "token",
    ];

    for (
      const storage
      of [
        window.localStorage,
        window.sessionStorage,
      ]
    ) {
      if (!storage) {
        continue;
      }

      for (
        const key
        of preferredKeys
      ) {
        const found =
          findTokenInValue(
            storage.getItem(key),
          );

        if (found) {
          return found;
        }
      }

      for (
        let index = 0;
        index < storage.length;
        index += 1
      ) {
        const key =
          storage.key(index) || "";

        if (
          !/token|jwt|bearer|auth|access|session|admin|portal|customer|iqf|tng/i.test(
            key,
          )
        ) {
          continue;
        }

        const found =
          findTokenInValue(
            storage.getItem(key),
          );

        if (found) {
          return found;
        }
      }

      for (
        let index = 0;
        index < storage.length;
        index += 1
      ) {
        const found =
          findTokenInValue(
            storage.getItem(
              storage.key(index) ||
              "",
            ),
          );

        if (found) {
          return found;
        }
      }
    }

    if (
      typeof document !==
        "undefined" &&
      document.cookie
    ) {
      for (
        const part
        of document.cookie.split(";")
      ) {
        const [
          rawKey,
          ...rawValue
        ] = part.split("=");

        const key =
          decodeURIComponent(
            (rawKey || "").trim(),
          );

        if (
          !/token|jwt|bearer|auth|access|session|admin|portal|customer/i.test(
            key,
          )
        ) {
          continue;
        }

        const value =
          decodeURIComponent(
            rawValue
              .join("=")
              .trim(),
          );

        const found =
          findTokenInValue(value);

        if (found) {
          return found;
        }
      }
    }

    return "";
  }

  function isAdmin() {
    return (
      window.location.pathname
        .includes("/admin") ||
      document.body?.dataset
        ?.role === "admin"
    );
  }

  async function apiJson(
    url,
    options = {},
  ) {
    const token =
      storedToken();

    if (!token) {
      throw new Error(
        "Missing access token.",
      );
    }

    const method =
      String(
        options.method || "GET",
      ).toUpperCase();

    const requestUrl =
      method === "GET"
        ? (
            url
            + (
                url.includes("?")
                  ? "&"
                  : "?"
              )
            + "_iqf="
            + Date.now()
          )
        : url;

    const response =
      await fetch(
        requestUrl,
        {
          ...options,
          cache: "no-store",
          headers: {
            Authorization:
              `Bearer ${token}`,
            "Cache-Control":
              "no-cache, no-store, max-age=0",
            Pragma:
              "no-cache",
            ...(options.body
              ? {
                  "Content-Type":
                    "application/json",
                }
              : {}),
            ...(options.headers || {}),
          },
        },
      );

    let data = null;

    try {
      data =
        await response.json();
    } catch (error) {
      data = null;
    }

    if (!response.ok) {
      throw new Error(
        data?.detail ||
        `${response.status} ${requestUrl}`,
      );
    }

    return data;
  }

  function powerText(value) {
    const number =
      Number(value);

    if (
      !Number.isFinite(number)
    ) {
      return "\u2014 kW";
    }

    return (
      number.toLocaleString(
        "cs-CZ",
        {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        },
      )
      + " kW"
    );
  }

  function targets(root) {
    const box =
      root.querySelector(
        ".f29-00012-metric-box-r2",
      );

    const rows =
      box
        ? box.querySelectorAll(
            ".f29-00012-metric-row",
          )
        : [];

    const value =
      rows?.[0]?.querySelector(
        ".f29-00012-metric-value",
      ) || null;

    const host =
      root.querySelector(
        ".f29-00012-hp-left",
      );

    return {
      box,
      value,
      host,
    };
  }

  function applyValue(
    root,
    data,
  ) {
    const target =
      targets(root);

    if (target.value) {
      target.value.textContent =
        powerText(
          data?.power_kw ??
          data?.point?.power_kw,
        );
    }

    root.dataset
      .f29PowerQuality =
        data?.point?.quality ||
        "unknown";

    root.dataset
      .f29PowerConfigured =
        data?.point?.configured
          ? "yes"
          : "no";
  }

  function ensureStyle() {
    if (
      document.getElementById(
        STYLE_ID,
      )
    ) {
      return;
    }

    const style =
      document.createElement(
        "style",
      );

    style.id =
      STYLE_ID;

    style.textContent = `
      [data-f29-00012-schema="svj-blansko-only"]
      .${PANEL_CLASS} {
        margin: 7px 0 4px;
        padding: 7px 8px;
        display: grid;
        gap: 4px;
        border:
          1px solid rgba(72,216,255,.22);
        border-radius: 8px;
        background: rgba(1,16,24,.56);
        text-align: left;
      }

      [data-f29-00012-schema="svj-blansko-only"]
      .${PANEL_CLASS} > label {
        color: #70ddff;
        font-size: .54rem;
        font-weight: 900;
        letter-spacing: .06em;
        text-transform: uppercase;
      }

      [data-f29-00012-schema="svj-blansko-only"]
      .${PANEL_CLASS} select {
        width: 100%;
        min-height: 28px;
        padding: 4px 6px;
        color: #eafaff;
        background: #041923;
        border:
          1px solid rgba(72,216,255,.34);
        border-radius: 7px;
        outline: none;
        font-size: .66rem;
      }

      [data-f29-00012-schema="svj-blansko-only"]
      .${PANEL_CLASS} small {
        min-height: 1em;
        color: #8fb9c9;
        font-size: .52rem;
        line-height: 1.2;
      }

      [data-f29-00012-schema="svj-blansko-only"]
      .${PANEL_CLASS}[data-saving="true"]
      select {
        opacity: .56;
        pointer-events: none;
      }
    `;

    document.head.appendChild(
      style,
    );
  }

  function encodedValue(item) {
    return (
      encodeURIComponent(
        item.transport || "",
      )
      + "|"
      + encodeURIComponent(
        item.entity_id || "",
      )
    );
  }

  function decodedValue(value) {
    if (!value) {
      return {
        transport: "",
        entity_id: "",
      };
    }

    const parts =
      String(value).split("|");

    return {
      transport:
        decodeURIComponent(
          parts[0] || "",
        ),
      entity_id:
        decodeURIComponent(
          parts[1] || "",
        ),
    };
  }

  function displayLabel(item) {
    return String(
      item?.admin_name ||
      item?.label ||
      item?.entity_label ||
      item?.entity_id ||
      "",
    )
      .replace(/\s+/g, " ")
      .trim();
  }

  function options(data) {
    const direct =
      Array.isArray(
        data?.options?.combined,
      )
        ? data.options.combined
        : [];

    const fallback = [
      ...(
        Array.isArray(
          data?.options?.zigbee,
        )
          ? data.options.zigbee
          : []
      ),
      ...(
        Array.isArray(
          data?.options?.wifi,
        )
          ? data.options.wifi
          : []
      ),
    ];

    const source =
      direct.length
        ? direct
        : fallback;

    const map =
      new Map();

    for (const raw of source) {
      if (
        !raw ||
        typeof raw !== "object"
      ) {
        continue;
      }

      const transport =
        String(
          raw.transport || "",
        ).trim();

      const entityId =
        String(
          raw.entity_id || "",
        ).trim();

      if (
        !transport ||
        !entityId
      ) {
        continue;
      }

      const key =
        transport
        + "|"
        + entityId;

      map.set(
        key,
        {
          ...raw,
          transport,
          entity_id:
            entityId,
          label:
            displayLabel(raw),
        },
      );
    }

    return Array.from(
      map.values(),
    ).sort(
      (a, b) =>
        displayLabel(a)
          .localeCompare(
            displayLabel(b),
            "cs",
          ),
    );
  }

  function picker(
    root,
    data,
  ) {
    const target =
      targets(root);

    if (
      !target.host ||
      !target.box
    ) {
      return;
    }

    let panel =
      target.host.querySelector(
        `.${PANEL_CLASS}`,
      );

    if (!panel) {
      panel =
        document.createElement(
          "div",
        );

      panel.className =
        PANEL_CLASS;

      const label =
        document.createElement(
          "label",
        );

      label.textContent =
        txt.label;

      const select =
        document.createElement(
          "select",
        );

      select.setAttribute(
        "aria-label",
        label.textContent,
      );

      const status =
        document.createElement(
          "small",
        );

      status.textContent =
        txt.helper;

      panel.appendChild(
        label,
      );

      panel.appendChild(
        select,
      );

      panel.appendChild(
        status,
      );

      target.box.insertAdjacentElement(
        "afterend",
        panel,
      );

      select.addEventListener(
        "change",
        async () => {
          const picked =
            decodedValue(
              select.value,
            );

          panel.dataset.saving =
            "true";

          status.textContent =
            txt.saving;

          try {
            const result =
              await apiJson(
                `/api/v1/admin/devices/${DEVICE_UUID}/individual-project/00012-electric-power-uzv-v1`,
                {
                  method: "PUT",
                  body:
                    JSON.stringify(
                      {
                        transport:
                          picked.transport,
                        entity_id:
                          picked.entity_id,
                      },
                    ),
                },
              );

            applyValue(
              root,
              result,
            );

            status.textContent =
              picked.entity_id
                ? txt.saved
                : txt.cleared;
          } catch (error) {
            console.error(
              VERSION,
              error,
            );

            status.textContent =
              `${txt.error}: ${
                error.message ||
                error
              }`;
          } finally {
            panel.dataset.saving =
              "false";
          }
        },
      );
    }

    const select =
      panel.querySelector(
        "select",
      );

    if (
      !select ||
      document.activeElement ===
        select ||
      panel.dataset.saving ===
        "true"
    ) {
      return;
    }

    const items =
      options(data);

    select.innerHTML = "";

    const empty =
      document.createElement(
        "option",
      );

    empty.value = "";

    empty.textContent =
      txt.empty;

    select.appendChild(
      empty,
    );

    for (const item of items) {
      const option =
        document.createElement(
          "option",
        );

      option.value =
        encodedValue(item);

      option.textContent =
        displayLabel(item)
        + (
          item.available === false
            ? ` (${txt.offline})`
            : ""
        );

      select.appendChild(
        option,
      );
    }

    const current =
      data?.binding || {};

    const desired =
      encodedValue(
        {
          transport:
            current.transport,
          entity_id:
            current.entity_id,
        },
      );

    const exists =
      Array.from(
        select.options,
      ).some(
        (option) =>
          option.value === desired,
      );

    select.value =
      exists
        ? desired
        : "";

    panel.dataset.optionCount =
      String(items.length);
  }

  async function refreshAdmin(root) {
    if (busy) {
      return;
    }

    busy = true;

    try {
      const data =
        await apiJson(
          `/api/v1/admin/devices/${DEVICE_UUID}/individual-project/00012-electric-power-uzv-v1`,
        );

      applyValue(
        root,
        data,
      );

      picker(
        root,
        data,
      );
    } catch (error) {
      console.error(
        VERSION,
        error,
      );
    } finally {
      busy = false;
    }
  }

  async function refreshClient(root) {
    if (busy) {
      return;
    }

    busy = true;

    try {
      const data =
        await apiJson(
          `/api/v1/portal/devices/${DEVICE_UUID}/client-view/individual-project/00012-electric-power-uzv-v1`,
        );

      applyValue(
        root,
        data,
      );

      root
        .querySelectorAll(
          `.${PANEL_CLASS}`,
        )
        .forEach(
          (node) =>
            node.remove(),
        );
    } catch (error) {
      console.error(
        VERSION,
        error,
      );
    } finally {
      busy = false;
    }
  }

  function start(root) {
    if (
      bootedRoot === root
    ) {
      return;
    }

    if (timer) {
      window.clearInterval(
        timer,
      );

      timer = null;
    }

    bootedRoot = root;

    ensureStyle();

    if (isAdmin()) {
      refreshAdmin(root);

      timer =
        window.setInterval(
          () =>
            refreshAdmin(root),
          5000,
        );
    } else {
      refreshClient(root);

      timer =
        window.setInterval(
          () =>
            refreshClient(root),
          5000,
        );
    }
  }

  function scan() {
    const root =
      document.querySelector(
        ROOT_SELECTOR,
      );

    if (!root) {
      return;
    }

    start(root);
  }

  let scheduled = false;

  function schedule() {
    if (scheduled) {
      return;
    }

    scheduled = true;

    window.requestAnimationFrame(
      () => {
        scheduled = false;
        scan();
      },
    );
  }

  if (
    document.readyState ===
    "loading"
  ) {
    document.addEventListener(
      "DOMContentLoaded",
      schedule,
    );
  } else {
    schedule();
  }

  window.addEventListener(
    "popstate",
    schedule,
  );

  window.addEventListener(
    "hashchange",
    schedule,
  );

  if (
    window.MutationObserver &&
    document.documentElement
  ) {
    const observer =
      new MutationObserver(
        schedule,
      );

    observer.observe(
      document.documentElement,
      {
        childList: true,
        subtree: true,
      },
    );
  }
})();