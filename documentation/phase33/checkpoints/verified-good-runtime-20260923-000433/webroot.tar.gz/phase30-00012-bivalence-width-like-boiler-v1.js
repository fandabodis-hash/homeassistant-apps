(function phase30BivalenceWidthLikeBoiler00012() {
  "use strict";

  var MARKER = "__F30_02Z_BIVALENCE_WIDTH_LIKE_BOILER_00012__";
  if (window[MARKER]) return;
  window[MARKER] = true;

  var lastWidth = 0;

  function text(value) {
    return value === null || value === undefined ? "" : String(value).trim();
  }

  function normalize(value) {
    return text(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/\s+/g, " ");
  }

  function compact(value) {
    return normalize(value).replace(/[^a-z0-9]+/g, "");
  }

  function findSchema() {
    return document.querySelector(
      '[data-f29-00012-schema="svj-blansko-only"], .f29-00012-schema-v2'
    );
  }

  function titleMatches(el, needle) {
    var c = compact(el && el.textContent);
    return c.indexOf(needle) !== -1;
  }

  function findTitleElement(schema, needle) {
    if (!schema) return null;

    var nodes = Array.prototype.slice.call(
      schema.querySelectorAll("h1,h2,h3,h4,h5,strong,b,div,span,p")
    );

    var candidates = nodes.filter(function(el) {
      var c = compact(el.textContent || "");
      if (c.indexOf(needle) === -1) return false;

      var r = el.getBoundingClientRect();
      return r.width > 20 && r.height > 8;
    });

    candidates.sort(function(a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      return (ar.width * ar.height) - (br.width * br.height);
    });

    return candidates[0] || null;
  }

  function findCardFromTitle(titleEl) {
    if (!titleEl) return null;

    var el = titleEl;

    for (var i = 0; i < 10 && el; i += 1) {
      var r = el.getBoundingClientRect();

      if (
        r.width >= 250 &&
        r.height >= 180 &&
        r.width <= 700 &&
        r.height <= 500
      ) {
        return el;
      }

      el = el.parentElement;
    }

    return null;
  }

  function findBoilerCard(schema) {
    var direct = schema && schema.querySelector(".f29-00012-boiler");

    if (direct) return direct;

    var title = findTitleElement(schema, "bojler");
    return findCardFromTitle(title);
  }

  function findBivalenceCard(schema) {
    var direct = schema && schema.querySelector(
      ".f29-00012-bivalence,.f29-00012-bivalence-tuv,.f29-00012-bivalence-card"
    );

    if (direct) return direct;

    var title = findTitleElement(schema, "bivalencetuvcztblansko");
    return findCardFromTitle(title);
  }

  function applyWidth() {
    var schema = findSchema();
    if (!schema) return;

    var boiler = findBoilerCard(schema);
    var bivalence = findBivalenceCard(schema);

    if (!boiler || !bivalence || boiler === bivalence) return;

    var boilerRect = boiler.getBoundingClientRect();

    if (!boilerRect.width || boilerRect.width < 200) return;

    var targetWidth = Math.round(boilerRect.width);

    if (targetWidth === lastWidth && bivalence.getAttribute("data-f30-02z-width-applied") === String(targetWidth)) {
      return;
    }

    lastWidth = targetWidth;

    bivalence.style.setProperty("width", targetWidth + "px", "important");
    bivalence.style.setProperty("min-width", targetWidth + "px", "important");
    bivalence.style.setProperty("max-width", targetWidth + "px", "important");
    bivalence.style.setProperty("flex-basis", targetWidth + "px", "important");
    bivalence.style.setProperty("box-sizing", "border-box", "important");

    bivalence.setAttribute("data-f30-02z-width-applied", String(targetWidth));
  }

  function start() {
    applyWidth();

    window.addEventListener("resize", function() {
      window.setTimeout(applyWidth, 80);
    });

    var observer = new MutationObserver(function() {
      window.setTimeout(applyWidth, 120);
    });

    observer.observe(
      document.documentElement || document.body,
      { childList: true, subtree: true }
    );

    window.setInterval(applyWidth, 2500);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
}());
