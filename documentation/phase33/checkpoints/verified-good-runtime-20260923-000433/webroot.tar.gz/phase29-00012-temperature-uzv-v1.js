(() => {
  "use strict";

  const VERSION =
    "f29-07i-00012-temperature-uzv-t3";
  const DEVICE_UUID =
    "28fb44c3-4f8d-4ea4-90ab-f7e6a3b509fc";
  const ROOT_SELECTOR =
    '[data-f29-00012-schema="svj-blansko-only"]';
  const STYLE_ID =
    "f29-00012-temperature-uzv-style";
  const PICKER_CLASS =
    "f29-00012-temperature-uzv-picker";

  let bootedRoot = null;
  let timer = null;
  let requestBusy = false;

  const txt = {
    boiler:
      "Zdroj teploty bojleru",
    accumulator:
      "Zdroj teploty AKU n\u00e1dr\u017ee",
    empty:
      "\u2014 bez p\u0159i\u0159azen\u00ed \u2014",
    helper:
      "Vyberte pojmenovan\u00e9 teplotn\u00ed \u010didlo t\u00e9to instalace.",
    saving:
      "Ukl\u00e1d\u00e1m\u2026",
    saved:
      "Ulo\u017eeno.",
    cleared:
      "Zdroj teploty byl zru\u0161en.",
    error:
      "Chyba",
    offline:
      "offline",
  };

  function storedToken() {
    if (!window.localStorage) {
      return "";
    }

    const preferred = [
      "iqfanda_access_token",
      "access_token",
      "accessToken",
      "token",
      "auth_token",
      "authToken",
      "tng_iq_fanda_token",
      "tng_iqfanda_token",
    ];

    for (const key of preferred) {
      const value =
        window.localStorage.getItem(
          key,
        );

      if (
        value &&
        value.length > 16
      ) {
        return value;
      }
    }

    for (
      const key
      of Object.keys(
        window.localStorage,
      )
    ) {
      const value =
        window.localStorage.getItem(
          key,
        );

      if (
        value &&
        value.length > 40 &&
        (
          key
            .toLowerCase()
            .includes("token") ||
          value.split(".").length === 3
        )
      ) {
        return value;
      }
    }

    return "";
  }

  function isAdmin() {
    return (
      window.location.pathname
        .includes("/admin") ||
      document.body?.dataset
        ?.role === "admin"
    );
  }

  async function apiJson(
    url,
    options = {},
  ) {
    const token =
      storedToken();

    if (!token) {
      throw new Error(
        "Missing access token.",
      );
    }

    const response =
      await fetch(
        url,
        {
          ...options,
          headers: {
            Authorization:
              `Bearer ${token}`,
            ...(options.body
              ? {
                  "Content-Type":
                    "application/json",
                }
              : {}),
            ...(options.headers || {}),
          },
        },
      );

    let data = null;

    try {
      data =
        await response.json();
    } catch (error) {
      data = null;
    }

    if (!response.ok) {
      throw new Error(
        data?.detail ||
        `${response.status} ${url}`,
      );
    }

    return data;
  }

  function temperatureText(value) {
    const number =
      Number(value);

    if (
      !Number.isFinite(number)
    ) {
      return "\u2014 \u00b0C";
    }

    return (
      number.toLocaleString(
        "cs-CZ",
        {
          minimumFractionDigits: 1,
          maximumFractionDigits: 1,
        },
      )
      + " \u00b0C"
    );
  }

  function targetElements(
    root,
    slot,
  ) {
    const card =
      root.querySelector(
        slot === "boiler"
          ? ".f29-00012-boiler"
          : ".f29-00012-accumulator",
      );

    return {
      card,
      value:
        card?.querySelector(
          ".f29-00012-temperature strong",
        ) || null,
    };
  }

  function applyValues(
    root,
    data,
  ) {
    for (
      const slot
      of [
        "boiler",
        "accumulator",
      ]
    ) {
      const target =
        targetElements(
          root,
          slot,
        );

      const point =
        data?.points?.[slot];

      if (target.value) {
        target.value.textContent =
          temperatureText(
            point?.temperature_c,
          );
      }
    }
  }

  function ensureStyle() {
    const old =
      document.getElementById(
        STYLE_ID,
      );

    if (old) {
      old.remove();
    }

    const style =
      document.createElement(
        "style",
      );

    style.id =
      STYLE_ID;

    style.textContent = `
      [data-f29-00012-schema="svj-blansko-only"]
      .${PICKER_CLASS} {
        width: min(94%, 340px);
        margin-top: 10px;
        padding: 8px 9px;
        display: grid;
        gap: 5px;
        border:
          1px solid rgba(72,216,255,.22);
        border-radius: 9px;
        background: rgba(1,16,24,.54);
        text-align: left;
      }

      [data-f29-00012-schema="svj-blansko-only"]
      .${PICKER_CLASS} > label {
        color: #70ddff;
        font-size: .57rem;
        font-weight: 900;
        letter-spacing: .08em;
        text-transform: uppercase;
      }

      [data-f29-00012-schema="svj-blansko-only"]
      .${PICKER_CLASS} select {
        width: 100%;
        min-height: 30px;
        padding: 5px 7px;
        color: #eafaff;
        background: #041923;
        border:
          1px solid rgba(72,216,255,.34);
        border-radius: 7px;
        outline: none;
        font-size: .69rem;
      }

      [data-f29-00012-schema="svj-blansko-only"]
      .${PICKER_CLASS} small {
        min-height: 1em;
        color: #8fb9c9;
        font-size: .56rem;
        line-height: 1.25;
      }

      [data-f29-00012-schema="svj-blansko-only"]
      .${PICKER_CLASS}[data-saving="true"]
      select {
        opacity: .56;
        pointer-events: none;
      }
    `;

    document.head.appendChild(
      style,
    );
  }

  function encodedValue(item) {
    return (
      encodeURIComponent(
        item.transport || "",
      )
      + "|"
      + encodeURIComponent(
        item.entity_id || "",
      )
    );
  }

  function decodedValue(value) {
    if (!value) {
      return {
        transport: "",
        entity_id: "",
      };
    }

    const parts =
      String(value).split("|");

    return {
      transport:
        decodeURIComponent(
          parts[0] || "",
        ),
      entity_id:
        decodeURIComponent(
          parts[1] || "",
        ),
    };
  }

  function displayLabel(item) {
    return String(
      item?.admin_name ||
      item?.label ||
      item?.entity_label ||
      item?.entity_id ||
      "",
    )
      .replace(/\s+/g, " ")
      .trim();
  }

  function combinedOptions(data) {
    const direct =
      Array.isArray(
        data?.options?.combined,
      )
        ? data.options.combined
        : [];

    const fallback = [
      ...(
        Array.isArray(
          data?.options?.zigbee,
        )
          ? data.options.zigbee
          : []
      ),
      ...(
        Array.isArray(
          data?.options?.wifi,
        )
          ? data.options.wifi
          : []
      ),
    ];

    const source =
      direct.length
        ? direct
        : fallback;

    const map =
      new Map();

    for (const raw of source) {
      if (
        !raw ||
        typeof raw !== "object"
      ) {
        continue;
      }

      const transport =
        String(
          raw.transport || "",
        ).trim();

      const entityId =
        String(
          raw.entity_id || "",
        ).trim();

      if (
        !transport ||
        !entityId
      ) {
        continue;
      }

      const key =
        transport
        + "|"
        + entityId;

      map.set(
        key,
        {
          ...raw,
          transport,
          entity_id:
            entityId,
          label:
            displayLabel(raw),
        },
      );
    }

    return Array.from(
      map.values(),
    ).sort(
      (a, b) =>
        displayLabel(a)
          .localeCompare(
            displayLabel(b),
            "cs",
          ),
    );
  }

  function picker(
    root,
    slot,
    data,
  ) {
    const target =
      targetElements(
        root,
        slot,
      );

    if (!target.card) {
      return;
    }

    let panel =
      target.card.querySelector(
        `.${PICKER_CLASS}[data-slot="${slot}"]`,
      );

    if (!panel) {
      panel =
        document.createElement(
          "div",
        );

      panel.className =
        PICKER_CLASS;

      panel.dataset.slot =
        slot;

      const label =
        document.createElement(
          "label",
        );

      label.textContent =
        slot === "boiler"
          ? txt.boiler
          : txt.accumulator;

      const select =
        document.createElement(
          "select",
        );

      select.setAttribute(
        "aria-label",
        label.textContent,
      );

      const status =
        document.createElement(
          "small",
        );

      status.textContent =
        txt.helper;

      panel.appendChild(
        label,
      );

      panel.appendChild(
        select,
      );

      panel.appendChild(
        status,
      );

      target.card.appendChild(
        panel,
      );

      select.addEventListener(
        "change",
        async () => {
          const picked =
            decodedValue(
              select.value,
            );

          panel.dataset.saving =
            "true";

          status.textContent =
            txt.saving;

          try {
            const result =
              await apiJson(
                `/api/v1/admin/devices/${DEVICE_UUID}/individual-project/00012-temperature-uzv-v1`,
                {
                  method: "PUT",
                  body:
                    JSON.stringify(
                      {
                        slot,
                        transport:
                          picked.transport,
                        entity_id:
                          picked.entity_id,
                      },
                    ),
                },
              );

            applyValues(
              root,
              result,
            );

            status.textContent =
              picked.entity_id
                ? txt.saved
                : txt.cleared;
          } catch (error) {
            console.error(
              VERSION,
              error,
            );

            status.textContent =
              `${txt.error}: ${
                error.message ||
                error
              }`;
          } finally {
            panel.dataset.saving =
              "false";
          }
        },
      );
    }

    const select =
      panel.querySelector(
        "select",
      );

    if (
      !select ||
      document.activeElement ===
        select ||
      panel.dataset.saving ===
        "true"
    ) {
      return;
    }

    const current =
      data?.binding?.[slot] ||
      {};

    const options =
      combinedOptions(data);

    select.innerHTML = "";

    const empty =
      document.createElement(
        "option",
      );

    empty.value = "";
    empty.textContent =
      txt.empty;

    select.appendChild(
      empty,
    );

    for (
      const item
      of options
    ) {
      const option =
        document.createElement(
          "option",
        );

      option.value =
        encodedValue(item);

      option.textContent =
        displayLabel(item)
        + (
          item.available === false
            ? ` (${txt.offline})`
            : ""
        );

      select.appendChild(
        option,
      );
    }

    const desired =
      encodedValue(
        {
          transport:
            current.transport,
          entity_id:
            current.entity_id,
        },
      );

    const exists =
      Array.from(
        select.options,
      ).some(
        (option) =>
          option.value === desired,
      );

    select.value =
      exists
        ? desired
        : "";

    panel.dataset.optionCount =
      String(options.length);
  }

  async function refreshAdmin(
    root,
  ) {
    if (requestBusy) {
      return;
    }

    requestBusy = true;

    try {
      const data =
        await apiJson(
          `/api/v1/admin/devices/${DEVICE_UUID}/individual-project/00012-temperature-uzv-v1`,
        );

      applyValues(
        root,
        data,
      );

      picker(
        root,
        "boiler",
        data,
      );

      picker(
        root,
        "accumulator",
        data,
      );

      root.dataset
        .f29UzvCombinedCount =
          String(
            combinedOptions(
              data,
            ).length,
          );
    } catch (error) {
      console.error(
        VERSION,
        error,
      );
    } finally {
      requestBusy = false;
    }
  }

  async function refreshClient(
    root,
  ) {
    if (requestBusy) {
      return;
    }

    requestBusy = true;

    try {
      const data =
        await apiJson(
          `/api/v1/portal/devices/${DEVICE_UUID}/client-view/individual-project/00012-temperature-uzv-v1`,
        );

      applyValues(
        root,
        data,
      );

      root
        .querySelectorAll(
          `.${PICKER_CLASS}`,
        )
        .forEach(
          (node) =>
            node.remove(),
        );
    } catch (error) {
      console.error(
        VERSION,
        error,
      );
    } finally {
      requestBusy = false;
    }
  }

  function start(root) {
    if (
      bootedRoot === root
    ) {
      return;
    }

    if (timer) {
      window.clearInterval(
        timer,
      );

      timer = null;
    }

    bootedRoot = root;

    ensureStyle();

    if (isAdmin()) {
      refreshAdmin(root);

      timer =
        window.setInterval(
          () =>
            refreshAdmin(root),
          12000,
        );
    } else {
      refreshClient(root);

      timer =
        window.setInterval(
          () =>
            refreshClient(root),
          12000,
        );
    }
  }

  function scan() {
    const root =
      document.querySelector(
        ROOT_SELECTOR,
      );

    if (!root) {
      return;
    }

    start(root);
  }

  let scheduled = false;

  function schedule() {
    if (scheduled) {
      return;
    }

    scheduled = true;

    window.requestAnimationFrame(
      () => {
        scheduled = false;
        scan();
      },
    );
  }

  if (
    document.readyState ===
    "loading"
  ) {
    document.addEventListener(
      "DOMContentLoaded",
      schedule,
    );
  } else {
    schedule();
  }

  window.addEventListener(
    "popstate",
    schedule,
  );

  window.addEventListener(
    "hashchange",
    schedule,
  );

  if (
    window.MutationObserver &&
    document.documentElement
  ) {
    const observer =
      new MutationObserver(
        schedule,
      );

    observer.observe(
      document.documentElement,
      {
        childList: true,
        subtree: true,
      },
    );
  }
})();