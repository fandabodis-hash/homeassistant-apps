(function phase30BivalenceAddTemperatureV2() {
  "use strict";

  var MARKER = "__F30_03A_R2_BIVALENCE_ADD_TEMPERATURE_00012__";
  if (window[MARKER]) return;
  window[MARKER] = true;

  function text(value) {
    return value === null || value === undefined ? "" : String(value).trim();
  }

  function normalize(value) {
    return text(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/\s+/g, " ");
  }

  function compact(value) {
    return normalize(value).replace(/[^a-z0-9]+/g, "");
  }

  function findSchema() {
    return document.querySelector(
      '[data-f29-00012-schema="svj-blansko-only"], .f29-00012-schema-v2'
    );
  }

  function findBivalenceCard(schema) {
    if (!schema) return null;

    var direct = schema.querySelector(
      ".f29-00012-bivalence,.f29-00012-bivalence-tuv,.f29-00012-bivalence-card"
    );

    if (direct) return direct;

    var all = Array.prototype.slice.call(
      schema.querySelectorAll("section,article,div")
    );

    var matches = all.filter(function(el) {
      var c = compact(el.textContent || "");
      if (c.indexOf("bivalencetuvcztblansko") === -1) return false;

      var r = el.getBoundingClientRect();

      return (
        r.width >= 250 &&
        r.width <= 600 &&
        r.height >= 180 &&
        r.height <= 500
      );
    });

    matches.sort(function(a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      return (ar.width * ar.height) - (br.width * br.height);
    });

    return matches[0] || null;
  }

  function ensureStyle() {
    if (document.getElementById("f30-03a-r2-bivalence-temp-style")) return;

    var style = document.createElement("style");
    style.id = "f30-03a-r2-bivalence-temp-style";

    style.textContent = [
      ".f30-03a-r2-temp-row{display:flex;align-items:center;justify-content:space-between;width:100%;min-height:32px;padding:0 10px;border:1px solid rgba(45,189,232,.45);border-radius:8px;background:rgba(1,21,33,.56);box-sizing:border-box;}",
      ".f30-03a-r2-temp-label{font-size:11px;line-height:1;color:#35d8ff;font-weight:900;letter-spacing:.04em;text-transform:uppercase;}",
      ".f30-03a-r2-temp-value{font-size:14px;line-height:1;color:#fff;font-weight:900;white-space:nowrap;}"
    ].join("");

    document.head.appendChild(style);
  }

  function findExistingRows(card) {
    if (!card) return [];

    var nodes = Array.prototype.slice.call(card.querySelectorAll("div"));

    return nodes.filter(function(el) {
      var c = compact(el.textContent || "");
      if (
        c.indexOf("stavzapvyp") === -1 &&
        c.indexOf("motohodiny") === -1
      ) {
        return false;
      }

      var r = el.getBoundingClientRect();

      return (
        r.width > 150 &&
        r.width <= card.getBoundingClientRect().width + 10 &&
        r.height >= 20 &&
        r.height <= 70
      );
    });
  }

  function commonRowsParent(rows, card) {
    if (!rows.length) return null;

    var first = rows[0];

    if (
      first.parentElement &&
      card.contains(first.parentElement)
    ) {
      var parent = first.parentElement;

      var siblingRows = rows.filter(function(row) {
        return row.parentElement === parent;
      });

      if (siblingRows.length >= 1) {
        return parent;
      }
    }

    return null;
  }

  function ensureTemperature() {
    var schema = findSchema();
    var card = findBivalenceCard(schema);

    if (!card) return;

    ensureStyle();

    if (card.querySelector('[data-f30-03a-r2="temperature"]')) {
      return;
    }

    var row = document.createElement("div");
    row.className = "f30-03a-r2-temp-row";
    row.setAttribute("data-f30-03a-r2", "temperature");

    var label = document.createElement("span");
    label.className = "f30-03a-r2-temp-label";
    label.textContent = "TEPLOTA";

    var value = document.createElement("span");
    value.className = "f30-03a-r2-temp-value";
    value.textContent = "\u2014 \u00b0C";

    row.appendChild(label);
    row.appendChild(value);

    var existingRows = findExistingRows(card);
    var rowsParent = commonRowsParent(existingRows, card);

    if (rowsParent && existingRows.length) {
      var firstRow = existingRows[0];
      rowsParent.insertBefore(row, firstRow);
      return;
    }

    var titleCandidates = Array.prototype.slice.call(
      card.querySelectorAll("h1,h2,h3,h4,strong,b,div")
    ).filter(function(el) {
      var c = compact(el.textContent || "");
      return c.indexOf("bivalencetuvcztblansko") !== -1;
    });

    if (titleCandidates.length) {
      var title = titleCandidates[0];

      if (title.parentElement === card) {
        title.insertAdjacentElement("afterend", row);
        return;
      }

      if (title.parentElement && card.contains(title.parentElement)) {
        title.parentElement.insertAdjacentElement("afterend", row);
        return;
      }
    }

    card.appendChild(row);
  }

  function start() {
    ensureTemperature();

    var observer = new MutationObserver(function() {
      window.setTimeout(ensureTemperature, 150);
    });

    observer.observe(document.documentElement || document.body, {
      childList: true,
      subtree: true
    });

    window.setInterval(ensureTemperature, 2500);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
}());
